#include <pthread.h>
#include <stdio.h>
#include "udpclient.h"
#include "ComPort.h"

#include <unistd.h> //linux ver
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>

int sock;                        /* Socket */
struct sockaddr_in echoServAddr; /* Local address */
struct sockaddr_in echoClntAddr; /* Client address */
char echoBuffer[255];        /* Buffer for echo string */
unsigned short echoServPort;     /* Server port */
int cliLen;                      /* Length of incoming message */
int recvMsgSize;                 /* Size of received message */

int total = 0;
int rnd;

extern int onoffmesg[5];

void main()
{
	
	pthread_t pth1,pth2,pth3;
	char udpvinfo[9];
	int pri = 40;
	int i = 0;

	pthread_create(&pth1,NULL,&Comopen,NULL); //serial

	pthread_create(&pth2,NULL,&udpopen,NULL); //socket

	pthread_create(&pth3,NULL,&cliopen,NULL); // cli commend
	while(1)
	{
//total = 0;
		sleep(2); //2 sec
		for(i=0;i<5;i++){
			if(getonoff() == 1)
			{
		 		udpvinfo[0] = 4;
		 		udpvinfo[1] = 0x00;
		 		udpvinfo[2] = i; //device id
		  		udpvinfo[3] = 0x00;
		  		udpvinfo[4] = 0x00; //group id
		  		udpvinfo[5] = 1;
		 		udpvinfo[6] = 20;
		 		udpvinfo[7] = 1;
		 		srand((unsigned)time(NULL));
				rnd = 55+(rand()%20);
				total = total + rnd;
		 		udpvinfo[8] = rnd;
				SendTo(udpvinfo,9);
			}
			else {
				udpvinfo[0] = 2;
		  		udpvinfo[1] = 0x00;
		  		udpvinfo[2] = i; //device id
		  		udpvinfo[3] = 0x00;
		  		udpvinfo[4] = 0x00; //group id
		  		udpvinfo[5] = onoffmesg[i];
				SendTo(udpvinfo,6);
 			}
		}
	  }
 }
