//void SendNodeInfo(udpinfo info);
void *udpopen();
//void GetTwoDayData();
//void GetTwoWeekData();
void SendTo(char* info,int len);
int getkind();
int getlevel();
//void SendTo(char* bytes, int size);
//void DieWithError(char *errorMessage);
