

#include "udpclient.h"
#include "ComPort.h"
#include <unistd.h> //linux ver
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>
#define ECHOMAX 255     /* Longest string to echo */

#include <stdio.h>      /* for printf(), fprintf() */
#include <stdlib.h>     /* for exit() */
#include <stdlib.h>

#define Debug

int sock;                        /* Socket */
struct sockaddr_in echoServAddr; /* Local address */
struct sockaddr_in echoClntAddr; /* Client address */
char echoBuffer[ECHOMAX];        /* Buffer for echo string */
unsigned short echoServPort;     /* Server port */
int cliLen;                      /* Length of incoming message */
int recvMsgSize;                 /* Size of received message */
//WSADATA wsaData;                 /* Structure for WinSock setup communication */
short TwoDay[24];
char TwoDayByte[50];
short TwoWeek[14];
char TwoWeekByte[30];
char udpvinfo[9];
int kind;
int level;

void* udpopen()
{
#ifdef Debug
	printf("udp start\n");
	#endif
	echoServPort = 12345;  /* first arg:  Local port */

   	/* Create socket for sending/receiving datagrams */
     	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0){
    		printf("udp fail\n");
	}
        

    	/* Construct local address structure */
    	memset(&echoServAddr, 0, sizeof(echoServAddr));
    	echoServAddr.sin_family = AF_INET;
    	echoServAddr.sin_addr.s_addr = inet_addr("192.168.1.143");
   	 echoServAddr.sin_port = htons(echoServPort);

   	/* Bind to the local address */
    	printf("udp connect\n");
    	sendto(sock, "111", 3, 0, (struct sockaddr *) &echoServAddr,
                         sizeof(echoServAddr));
   	for (;;) /* Run forever */{
        /* Set the size of the in-out parameter */
        cliLen = sizeof(echoClntAddr); 
        /* Block until receive message from a client */
        if ((recvMsgSize = recvfrom(sock, echoBuffer, ECHOMAX, 0,
             (struct sockaddr *) &echoClntAddr, &cliLen)) < 0)
             printf("recvfrom() failed\n");
		
       // printf("Handling client %s\n", inet_ntoa(echoClntAddr.sin_addr));
		switch (echoBuffer[0]){
		case 2:
			//FindIndexFromID(echoBuffer[2]);
			makeframe(echoBuffer[5],echoBuffer[1]);
			printf("on/off");
			break;
		case 3:
			printf("set dimming %d\n",echoBuffer[5]);
			dimming(echoBuffer[5]);
			makeframe(echoBuffer[4],echoBuffer[1]); //nodeid need
			break;
		case 8:
			if(echoBuffer[1]>100){
				kind = (echoBuffer[1]-100)/10;
			}else{
				kind = echoBuffer[1]/10;
			}
			level = echoBuffer[1]%10;
			break;
		}
	}
}
     /* NOT REACHED */

void SendTo(char* info,int len){
	if (sendto(sock, info, len, 0, (struct sockaddr *) &echoServAddr,
                     sizeof(echoServAddr)) != 3)
	{
		//printf("sendto() sent a different number of bytes than expected");
	}
}

int getkind(){
	return kind;
}

int getlevel(){
	return level;
}

