#include "ComPort.h"
#include "udpclient.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define BUF_SIZE 1024
#define TOUCHPORT "/dev/ttyUSB0"
#define BAUDRATE B9600
#define TRUE 1
#define FALSE 0
#define U32 unsigned int
#define Debug
#define SerialSet
int bfLen = 0;
int seq = 0;
int onoff = 1;
int setdimming = 20;
char frame[14];
int fd = 0;
int ackcheck = 0;
char serialbuffer[BUF_SIZE];

int onoffmesg[5];

void* Comopen() {
	SerialRead();
}

void SerialRead() //linux ver
{
	char buf[BUF_SIZE] = { 0 };
	int r = 0;    // file descript
	//int stat=0, cnt=0;
	int i = 0;
#ifdef Debug
	printf("SerialRead ---> Start !!\n");
	printf("TouchPort Open !! \n");
#endif

	fd = open(TOUCHPORT, O_RDWR | O_NOCTTY);
	//fd = open(TOUCHPORT,O_RDONLY | O_NONBLOCK);
	if (fd < 0) {
		perror(TOUCHPORT);
		//close(fd);
		exit(-1);
	}
#ifdef SerialSet
#ifdef Debug
	printf("SerialSet .. Start !!\n");
#endif
	struct termios tio;
	tcgetattr(fd, &tio);
	tio.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD;
	tio.c_iflag = IGNPAR | IGNBRK | IXANY;
	tio.c_oflag = 0;
	tio.c_lflag &= (~ISIG);
	tio.c_lflag &= (~ICANON);
	tio.c_cc[VMIN] = 0;
	tio.c_cc[VTIME] = 0;
	tcsetattr(fd, TCSANOW, &tio);
#ifdef Debug
	printf("SerialSet .. End !!\n");
#endif
#ifdef Debug
	printf("TouchPort descript ==> %d\n", fd);
	printf("Read Call !! \n");
#endif
#ifdef Debug
	while (1) {
		if(r = read(fd, &buf, sizeof(buf))>0)
		{
			serialPort1_DataReceived(buf, r);
			//printf("read data %d\n", r);
		}
		memset(buf, 0, sizeof(buf));
	} // while
#endif
#endif  // SerialSet

} // SerialRead()

void writeserial(int len) {
	int i;
	int count =5;
	while(1){
		sleep(1);
		count--;
		if (ackcheck == 1) {
			write(fd, frame, len);
			printf("%d send : ", len);
			for(i=0;i<len;i++){
				printf("%x", frame[i]);
			}
			printf("\n");
		}
		if(count<=0){
			break;
		}
	}
}

void serialPort1_DataReceived(char* buffer, int num) {
	char* bytes = buffer;
	// string str = "";
	int len = num;
	int i, j;
	char udpframe[7];
	for (i = 0; i < len; i++) {

		serialbuffer[bfLen++] = bytes[i];
		if (bfLen >= 13) {
			printf("recv data : ");
			//sendinfo(buffer, len);
			for (j = 0; j < bfLen; j++) {
				printf("%x", serialbuffer[j]);
			}
			printf("\n");
			bfLen = 0;
			ackcheck = 0;
			break;
		}
	}
}

void* cliopen() {
	int commend;
	int nodeid;
	int state;
	while(1){
		printf("commend (nodeid(1~5)+setstate(1~5) : ");
		scanf("%d",&commend);
		nodeid = (commend/10)-1;
		state = commend%10;
		makeframe(state,nodeid);
		sleep(1);
	}
}

char* makeframe(int setvalue,int setid) { 
	char udpframe[7];
	int set = 0;
	char add = 0;
	memset(frame, 0, sizeof(frame));
	if (setvalue == 1) // ON 
			{
		frame[set++] = (char) 0xB3;
		frame[set++] = (char) seq;
		add += frame[set - 1];
		frame[set++] = (char) 0x02;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) setid;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0xFF;
		add += frame[set - 1];
		frame[set++] = (char) 0xF1;
		add += frame[set - 1];
		frame[set++] = (char) 0x31;
		add += frame[set - 1];
		frame[set++] = (char) 0x1F;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) add;
		writeserial(13);
		onoff = 0;
		onoffmesg[setid] = 1;
	} else if (setvalue == 2) // DIMMING CONTROL
			{
		frame[set++] = (char) 0xB3;
		frame[set++] = (char) seq;
		add += frame[set - 1];
		frame[set++] = (char) 0x02;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) setid;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0xFF;
		add += frame[set - 1];
		frame[set++] = (char) 0xF1;
		add += frame[set - 1];
		frame[set++] = (char) 0x31;
		add += frame[set - 1];
		frame[set++] = (char) 0x1A;
		add += frame[set - 1];
		frame[set++] = (char) 0x01;
		add += frame[set - 1];

		frame[set++] = (char) setdimming;
		add += frame[set - 1];
		frame[set++] = (char) add;
		writeserial(14);
		udpframe[0] = (char) 3;
		udpframe[1] = (char) 0x00; // DEVICE ID
		udpframe[2] = (char) setid;
		udpframe[3] = (char) 0x00; // GROUP ID
		udpframe[4] = (char) 0x01;
		udpframe[5] = setdimming;
		udpframe[6] = 0;
		udpframe[7] = 1;
		udpframe[8] = 0;
		SendTo(udpframe, 10);
	} else if (setvalue == 3) // DIMMING DOWN
			{
		frame[set++] = (char) 0xB3;
		frame[set++] = (char) seq;
		add += frame[set - 1];
		frame[set++] = (char) 0x02;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) setid;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0xFF;
		add += frame[set - 1];
		frame[set++] = (char) 0xF1;
		add += frame[set - 1];
		frame[set++] = (char) 0x31;
		add += frame[set - 1];
		frame[set++] = (char) 0x1A;
		add += frame[set - 1];
		frame[set++] = (char) 0x01;
		add += frame[set - 1];
		setdimming--;
		if (setdimming <= 0) {
			setdimming = 0;
		}
		frame[set++] = (char) setdimming;
		add += frame[set - 1];
		frame[set++] = (char) add;
		writeserial(14);
		udpframe[0] = (char) 3;
		udpframe[1] = (char) 0x00; // DEVICE ID
		udpframe[2] = (char) setid;
		udpframe[3] = (char) 0x00; // GROUP ID
		udpframe[4] = (char) 0x01;
		udpframe[5] = setdimming;
		udpframe[6] = 0;
		udpframe[7] = 1;
		udpframe[8] = 0;
		SendTo(udpframe, 10);
	} else if (setvalue == 4) // GET VALUE
			{
		frame[set++] = (char) 0xB3;
		frame[set++] = (char) seq;
		add += frame[set - 1];
		frame[set++] = (char) 0x02;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) setid;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0xFF;
		add += frame[set - 1];
		frame[set++] = (char) 0xF1;
		add += frame[set - 1];
		frame[set++] = (char) 0x21;
		add += frame[set - 1];
		frame[set++] = (char) 0x21;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) add;
	} else // OFF
	{
		frame[set++] = (char) 0xB3;
		frame[set++] = (char) seq;
		add += frame[set - 1];
		frame[set++] = (char) 0x02;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) setid;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) 0xFF;
		add += frame[set - 1];
		frame[set++] = (char) 0xF1;
		add += frame[set - 1];
		frame[set++] = (char) 0x31;
		add += frame[set - 1];
		frame[set++] = (char) 0x10;
		add += frame[set - 1];
		frame[set++] = (char) 0x00;
		add += frame[set - 1];
		frame[set++] = (char) add;
		writeserial(13);
		onoff = 0;
		onoffmesg[setid] = 0;
	}
	printf("%d\n",onoffmesg[setid]);
	ackcheck = 1;
	return frame;
}

int getonoff(){
	return onoff;
}

void dimming(int dimming) {
	setdimming = dimming;
}
