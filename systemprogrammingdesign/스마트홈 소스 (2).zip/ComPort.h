
void serialPort1_DataReceived(char* buffer, int num);
void* Comopen();
void SerialRead();
char* makeframe(int setvalue,int setid);
void dimming(int dimming);
void writeserial(int len);
void sendtcp(char* buf);
void* cliopen();
int getonoff();
