#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

char *EXIT_STRING = "exit";

#define MAXLINE 1000
#define NAMELEN 20

int recv_and_print(int sd);
int input_and_send(int sd, struct sockaddr_in clisock, char *name);

int main(int argc, char *argv[])
{
    struct sockaddr_in servaddr;
    int s_sock, nbyte; 
    int addrlen = sizeof(servaddr);
    pid_t pid;
    
    if (argc != 4){
       printf("useage : %s server_ip port_number nickname\n", argv[0]);
        exit(0);
    }
  
    if ((s_sock = socket(PF_INET, SOCK_DGRAM, 0)) < 0){
        perror("socket fail!");
        exit(0);
   } else {
       printf("socket success!\n");
   }

    bzero((char *)&servaddr, sizeof(servaddr));

   servaddr.sin_family   = AF_INET; //UDP
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);
    servaddr.sin_port   = htons(atoi(argv[2]));
   
   
   if ((pid = fork()) > 0)
     {   
      input_and_send(s_sock, servaddr, argv[3]);
   }else if (pid == 0)
        recv_and_print(s_sock);
      
    close(s_sock);
}



int input_and_send(int sd, struct sockaddr_in servsock, char *name)
{
    char buf[MAXLINE], bufall[MAXLINE + NAMELEN];
    int namelen;
   FILE *f;

    sprintf(bufall, "[%s] ", name);
   namelen = strlen(bufall);
   
   if((f = fopen("/home/test/chat/client2/log.txt","a+")) == NULL)
   {
      printf("File Open error.\n");
      return -1;
   } else {   
      while (fgets (buf, sizeof(buf), stdin) != NULL) {   
         strcat(bufall, buf);
   	 //printf("value : %s\n", buf);
        fputs(buf,f);
         
	if (sendto(sd, bufall, strlen(bufall), 0, (struct sockaddr *)&servsock, sizeof(struct sockaddr)) < 0)    {
            perror("sendto fail");
            break;
         }
	 bufall[namelen] = '\0';
         if (strstr(buf, EXIT_STRING) != NULL) 
         {
         
            puts("good bye~");
            break;
         }
      
      }

      bufall[namelen] = 0; 
   }
   fclose(f);
    return 0;
}



int recv_and_print(int sd)
{
   struct sockaddr_in cliaddr;
   char buf[MAXLINE + 1];
   int nbyte, addrlen;
    
     	while(1){
	     	nbyte = recvfrom(sd, buf, MAXLINE, 0, (struct sockaddr *)&cliaddr, &addrlen);
				
      	if (nbyte < 0) {
         	perror("recvfrom fail");
         	break;
      	}
    	
	buf[nbyte] = 0;

      	if (strstr(buf, EXIT_STRING) != NULL )
         	break;
      	printf("%s", buf);
   	}
   
   return 0;
}
 
