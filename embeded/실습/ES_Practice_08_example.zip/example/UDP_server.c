#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define MAXLINE 511
#define MAX_SOCK 1024
char *EXIT_STRING = "exit";
char *START_STRING = "welcome!!"; 
int g_iClientNo = 0; 
struct sockaddr_in cliaddr_list[ MAX_SOCK ];

int existClient(struct sockaddr_in cliaddr);
void addClient(struct sockaddr_in cliaddr, int index);
void removeClient(int index);
void broadcastMsg(int s_sock, struct sockaddr_in cliaddr, char *msg);

int main(int argc, char *argv[]) 
{

	struct sockaddr_in cliaddr, servaddr;
	int s_sock, nbyte, addrlen = sizeof(servaddr);
	char buf[MAXLINE + 1];

	g_iClientNo = 0; 

	if (argc != 2){
		printf("useage : %s port_number\n", argv[0]);//Port_number
		exit(0);
	}

	printf("-------------------------------------------\n");
	if ((s_sock = socket(PF_INET, SOCK_DGRAM, 0)) < 0){
		perror("socket fail");
		exit(0);
	} else printf("socket success\n");

	bzero((char *)&servaddr, addrlen);

	servaddr.sin_family   = AF_INET; //UDP
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port   = htons(atoi(argv[1]));

	if (bind(s_sock, (struct sockaddr*)&servaddr, addrlen) < 0){
		perror("bind fail!");
		close(s_sock);
		exit(0);
	} else printf("bind success\n");
	printf("-------------------------------------------\n");
	printf("<now server is waiting for client's connection>\n");

	while(1){
		bzero((char *)&cliaddr, addrlen);
		nbyte = recvfrom(s_sock, buf, MAXLINE, 0,(struct sockaddr *)&cliaddr, &addrlen);
		if (nbyte < 0) {
			perror("recvfrom() fail");
			close(s_sock);
			exit;
		}

		if (strstr(buf, EXIT_STRING) != NULL ){
			removeClient(existClient(cliaddr));   
		} else {
			addClient(cliaddr, g_iClientNo);

			if (g_iClientNo > 0) {
				buf[nbyte] = 0;
				broadcastMsg(s_sock, cliaddr, buf);
			}
		}  
	}
}

int existClient(struct sockaddr_in cliaddr)
{
	int i, rtn = -1;

	for (i = 0; i < g_iClientNo; i++){
		if ((cliaddr_list[i].sin_port == cliaddr.sin_port) && (cliaddr_list[i].sin_addr.s_addr == cliaddr.sin_addr.s_addr)){    			rtn = i;
			break;
		}
	} 

	if (rtn > -1)
		printf("already exist! index[%d]\n", rtn);
	else
		printf("not exist!\n");

	return rtn;
}

void addClient(struct sockaddr_in cliaddr, int index) 
{
	if (existClient(cliaddr) < 0) {
		bzero((char*)&cliaddr_list[index], sizeof(struct sockaddr_in));  
		cliaddr_list[index].sin_family = AF_INET;
		cliaddr_list[index].sin_addr.s_addr = cliaddr.sin_addr.s_addr;
		cliaddr_list[index].sin_port = cliaddr.sin_port;
		printf("add! index[%d]\n", index); 
		g_iClientNo++;  

		printf("-----------------------\n%d client remain\n", g_iClientNo);

	}
}

void removeClient(int index) 
{
	if (index < 0) {
		printf("index below 0\n");
		exit(0);
	}
	else if (index == g_iClientNo - 1) { 
		printf("remove! index[%d]\n", index);
		bzero((char *)&cliaddr_list[index], sizeof(struct sockaddr_in));
	} else {
		printf("change and remove! index[%d] -> index[%d]\n", g_iClientNo - 1, index);
		bzero((char*)&cliaddr_list[index], sizeof(struct sockaddr_in));  
		cliaddr_list[index].sin_family = AF_INET;
		cliaddr_list[index].sin_addr.s_addr = 
		cliaddr_list[g_iClientNo - 1].sin_addr.s_addr;
		cliaddr_list[index].sin_port = cliaddr_list[g_iClientNo - 1].sin_port;
		bzero((char *)&cliaddr_list[g_iClientNo - 1], sizeof(struct sockaddr_in));
	}
	if (g_iClientNo > 0) g_iClientNo = g_iClientNo - 1;

		printf("-----------------------\n%d client remain\n", g_iClientNo);
}

void broadcastMsg(int s_sock, struct sockaddr_in cliaddr, char *msg) 
{  
	int i;
	printf("[BroadcastMsg] %s\n", msg);
	for (i = 0; i < g_iClientNo; i++) {
		if ((cliaddr_list[i].sin_port == cliaddr.sin_port) && (cliaddr_list[i].sin_addr.s_addr == cliaddr.sin_addr.s_addr)) {
		} else {
			if (sendto(s_sock, msg, strlen(msg), 0,	(struct sockaddr *)&cliaddr_list[i], sizeof(struct sockaddr_in)) < 0) {

				perror("sendto fail");
				break;
			}
		}
	}   
}
