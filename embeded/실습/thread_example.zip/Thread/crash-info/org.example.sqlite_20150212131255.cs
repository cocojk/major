S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1722
Date: 2015-02-12 13:12:54+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x21

Register Information
r0   = 0xb73b1048, r1   = 0xb73b0618
r2   = 0x98761237, r3   = 0xb73b1048
r4   = 0x00000011, r5   = 0x00000000
r6   = 0xb73fac48, r7   = 0xb17bde38
r8   = 0xb73fac48, r9   = 0xb73faa88
r10  = 0xb17bdf40, fp   = 0x00000042
ip   = 0xb6116db0, sp   = 0xb17bddf8
lr   = 0xb60f9dcd, pc   = 0xb60d6fb0
cpsr = 0x40000030

Memory Information
MemTotal:   987264 KB
MemFree:    566228 KB
Buffers:     15908 KB
Cached:     132724 KB
VmPeak:      99748 KB
VmSize:      99748 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20816 KB
VmRSS:       20816 KB
VmData:      35132 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22324 KB
VmPTE:          68 KB
VmSwap:          0 KB

Threads Information
Threads: 4
PID = 1722 TID = 1895
1722 1726 1894 1895 

Maps Information
b0fc1000 b17c0000 rw-p [stack:1895]
b1b61000 b2360000 rw-p [stack:1894]
b2f6b000 b2f70000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2ffc000 b3004000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b3015000 b3016000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3026000 b302d000 r-xp /usr/lib/libfeedback.so.0.1.4
b3051000 b3064000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b3078000 b307d000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b308d000 b308e000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b309e000 b30a1000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b30b2000 b30b3000 r-xp /usr/lib/libxshmfence.so.1.0.0
b30c3000 b30c5000 r-xp /usr/lib/libxcb-present.so.0.0.0
b30d5000 b30d7000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b30e7000 b30ef000 r-xp /usr/lib/libdrm.so.2.4.0
b30ff000 b3101000 r-xp /usr/lib/libdri2.so.0.0.0
b3111000 b3119000 r-xp /usr/lib/libtbm.so.1.0.0
b3129000 b312a000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b313c000 b313d000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b314d000 b3159000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b316a000 b3171000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3183000 b3193000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b329b000 b329f000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32b0000 b3390000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33a6000 b33aa000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b33b2000 b33d9000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33ec000 b3beb000 rw-p [stack:1726]
b3beb000 b3bed000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dfd000 b3e06000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e17000 b3e20000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e31000 b3e42000 r-xp /lib/libnsl-2.20-2014.11.so
b3e55000 b3e5b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e6c000 b3e86000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e97000 b3e98000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ea8000 b3eaa000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ebb000 b3ec0000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ed0000 b3ed3000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ee4000 b3eeb000 r-xp /usr/lib/libsensord-share.so
b3efb000 b3f0c000 r-xp /usr/lib/libsensor.so.1.2.0
b3f1d000 b3f23000 r-xp /usr/lib/libappcore-common.so.1.1
b3f46000 b3f4b000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f62000 b3f64000 r-xp /usr/lib/libXau.so.6.0.0
b3f74000 b3f88000 r-xp /usr/lib/libxcb.so.1.1.0
b3f98000 b3f9f000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fd7000 b3fd9000 r-xp /usr/lib/libiri.so
b3fea000 b3fff000 r-xp /lib/libexpat.so.1.5.2
b4011000 b405f000 r-xp /usr/lib/libssl.so.1.0.0
b4074000 b407d000 r-xp /usr/lib/libethumb.so.1.13.0
b408e000 b4091000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40a1000 b4258000 r-xp /usr/lib/libcrypto.so.1.0.0
b57ef000 b57f8000 r-xp /usr/lib/libXi.so.6.1.0
b5809000 b580b000 r-xp /usr/lib/libXgesture.so.7.0.0
b581b000 b581f000 r-xp /usr/lib/libXtst.so.6.1.0
b582f000 b5835000 r-xp /usr/lib/libXrender.so.1.3.0
b5845000 b584b000 r-xp /usr/lib/libXrandr.so.2.2.0
b585b000 b585d000 r-xp /usr/lib/libXinerama.so.1.0.0
b586d000 b5870000 r-xp /usr/lib/libXfixes.so.3.1.0
b5881000 b588c000 r-xp /usr/lib/libXext.so.6.4.0
b589c000 b589e000 r-xp /usr/lib/libXdamage.so.1.1.0
b58ae000 b58b0000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58c0000 b59a3000 r-xp /usr/lib/libX11.so.6.3.0
b59b6000 b59bd000 r-xp /usr/lib/libXcursor.so.1.0.2
b59ce000 b59e6000 r-xp /usr/lib/libudev.so.1.6.0
b59e8000 b59eb000 r-xp /lib/libattr.so.1.1.0
b59fb000 b5a1b000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a1c000 b5a21000 r-xp /usr/lib/libffi.so.6.0.2
b5a31000 b5a49000 r-xp /lib/libz.so.1.2.8
b5a59000 b5a5b000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a6b000 b5b40000 r-xp /usr/lib/libxml2.so.2.9.2
b5b55000 b5bf0000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c0c000 b5c0f000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c1f000 b5c39000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c49000 b5c5a000 r-xp /lib/libresolv-2.20-2014.11.so
b5c6e000 b5c85000 r-xp /usr/lib/liblzma.so.5.0.3
b5c95000 b5c97000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5ca7000 b5cae000 r-xp /usr/lib/libembryo.so.1.13.0
b5cbe000 b5cd6000 r-xp /usr/lib/libpng12.so.0.50.0
b5ce7000 b5d0a000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d2a000 b5d30000 r-xp /lib/librt-2.20-2014.11.so
b5d41000 b5d55000 r-xp /usr/lib/libector.so.1.13.0
b5d66000 b5d7e000 r-xp /usr/lib/liblua-5.1.so
b5d8f000 b5de6000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dfa000 b5e22000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e33000 b5e46000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e57000 b5e91000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ea2000 b5f0d000 r-xp /lib/libm-2.20-2014.11.so
b5f1e000 b5f2b000 r-xp /usr/lib/libeio.so.1.13.0
b5f3b000 b5f3d000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f4d000 b5f52000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f62000 b5f79000 r-xp /usr/lib/libefreet.so.1.13.0
b5f8b000 b5fab000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fbb000 b5fdb000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fdd000 b5fe3000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5ff3000 b5ffa000 r-xp /usr/lib/libethumb_client.so.1.13.0
b600a000 b6018000 r-xp /usr/lib/libeo.so.1.13.0
b6028000 b603a000 r-xp /usr/lib/libecore_input.so.1.13.0
b604b000 b6050000 r-xp /usr/lib/libecore_file.so.1.13.0
b6060000 b6078000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6089000 b60a6000 r-xp /usr/lib/libeet.so.1.13.0
b60bf000 b6107000 r-xp /usr/lib/libeina.so.1.13.0
b6118000 b6128000 r-xp /usr/lib/libefl.so.1.13.0
b6139000 b621e000 r-xp /usr/lib/libicuuc.so.51.1
b623b000 b637b000 r-xp /usr/lib/libicui18n.so.51.1
b6392000 b63ca000 r-xp /usr/lib/libecore_x.so.1.13.0
b63dc000 b63df000 r-xp /lib/libcap.so.2.21
b63ef000 b6418000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6429000 b6430000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6442000 b6478000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6489000 b6571000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6585000 b65fb000 r-xp /usr/lib/libsqlite3.so.0.8.6
b660d000 b6610000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6620000 b662b000 r-xp /usr/lib/libvconf.so.0.2.45
b663b000 b663d000 r-xp /usr/lib/libvasum.so.0.3.1
b664d000 b664f000 r-xp /usr/lib/libttrace.so.1.1
b665f000 b6662000 r-xp /usr/lib/libiniparser.so.0
b6672000 b6695000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66a5000 b66aa000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66bb000 b66d2000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66e3000 b66f0000 r-xp /usr/lib/libunwind.so.8.0.1
b6726000 b684a000 r-xp /lib/libc-2.20-2014.11.so
b685f000 b6878000 r-xp /lib/libgcc_s-4.9.so.1
b6888000 b696a000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b697b000 b69af000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69bf000 b69f9000 r-xp /usr/lib/libsystemd.so.0.4.0
b69fb000 b6a7b000 r-xp /usr/lib/libedje.so.1.13.0
b6a7e000 b6a9c000 r-xp /usr/lib/libecore.so.1.13.0
b6abc000 b6c1e000 r-xp /usr/lib/libevas.so.1.13.0
b6c55000 b6c69000 r-xp /lib/libpthread-2.20-2014.11.so
b6c7d000 b6ea1000 r-xp /usr/lib/libelementary.so.1.13.0
b6ecf000 b6ed3000 r-xp /usr/lib/libsmack.so.1.0.0
b6ee3000 b6ee9000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6efa000 b6efc000 r-xp /usr/lib/libdlog.so.0.0.0
b6f0c000 b6f0f000 r-xp /usr/lib/libbundle.so.0.1.22
b6f1f000 b6f21000 r-xp /lib/libdl-2.20-2014.11.so
b6f32000 b6f4b000 r-xp /usr/lib/libaul.so.0.1.0
b6f5d000 b6f5f000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f70000 b6f74000 r-xp /usr/lib/libsys-assert.so
b6f85000 b6fa5000 r-xp /lib/ld-2.20-2014.11.so
b6fb6000 b6fbc000 r-xp /usr/bin/launchpad-loader
b71d1000 b7428000 rw-p [heap]
be9f4000 bea15000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1722)
Call Stack Count: 17
 0: eina_list_append + 0x2b (0xb60d6fb0) [/usr/lib/libeina.so.1] + 0x17fb0
 1: (0xb6b36c9d) [/usr/lib/libevas.so.1] + 0x7ac9d
 2: (0xb6b36eef) [/usr/lib/libevas.so.1] + 0x7aeef
 3: (0xb6b3709d) [/usr/lib/libevas.so.1] + 0x7b09d
 4: (0xb6b3b8c7) [/usr/lib/libevas.so.1] + 0x7f8c7
 5: (0xb6b3cb27) [/usr/lib/libevas.so.1] + 0x80b27
 6: evas_textblock_cursor_geometry_bidi_get + 0xd2 (0xb6b3f24b) [/usr/lib/libevas.so.1] + 0x8324b
 7: (0xb6a460fd) [/usr/lib/libedje.so.1] + 0x4b0fd
 8: (0xb6a634cb) [/usr/lib/libedje.so.1] + 0x684cb
 9: (0xb6a65fe5) [/usr/lib/libedje.so.1] + 0x6afe5
10: edje_obj_part_text_append + 0x62 (0xb6a57327) [/usr/lib/libedje.so.1] + 0x5c327
11: edje_object_part_text_append + 0x2a (0xb6a5ede3) [/usr/lib/libedje.so.1] + 0x63de3
12: elm_obj_entry_append + 0x5c (0xb6d4c081) [/usr/lib/libelementary.so.1] + 0xcf081
13: elm_entry_entry_append + 0x26 (0xb6d56ecb) [/usr/lib/libelementary.so.1] + 0xd9ecb
14: _add_entry_text + 0x28 (0xb33a786d) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x186d
15: (0xb3f3652b) (null)
16: (0xb67f2650) [/lib/libc.so.6] + 0xcc650
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
 syslocale is null
02-12 13:12:12.744+0900 D/PKGMGR_INFO( 1767): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_count(3502) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:12.744+0900 D/PKGMGR_INFO( 1767): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_count(3508) > [SECURE_LOG] query = select DISTINCT package_app_info.app_id, package_app_info.app_component, package_app_info.app_installed_storage from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale='No Locale' LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:12.754+0900 E/VCONF   ( 1767): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-12 13:12:12.754+0900 E/VCONF   ( 1767): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-12 13:12:12.754+0900 E/VCONF   ( 1767): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-12 13:12:12.754+0900 E/VCONF   ( 1767): vconf.c: vconf_get_str(2887) > vconf_get_str(1767) : db/menu_widget/language error
02-12 13:12:12.754+0900 E/PKGMGR_INFO( 1767): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-12 13:12:12.754+0900 D/PKGMGR_INFO( 1767): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:12.754+0900 D/PKGMGR_INFO( 1767): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'No Locale') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:12.764+0900 E/VCONF   ( 1767): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-12 13:12:12.764+0900 E/VCONF   ( 1767): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-12 13:12:12.764+0900 E/VCONF   ( 1767): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-12 13:12:12.764+0900 E/VCONF   ( 1767): vconf.c: vconf_get_str(2887) > vconf_get_str(1767) : db/menu_widget/language error
02-12 13:12:12.764+0900 E/PKGMGR_INFO( 1767): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-12 13:12:12.764+0900 D/PKGMGR_INFO( 1767): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:12.764+0900 D/PKGMGR_INFO( 1767): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'No Locale') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:12.774+0900 E/VCONF   ( 1767): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-12 13:12:12.774+0900 E/VCONF   ( 1767): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-12 13:12:12.774+0900 E/VCONF   ( 1767): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-12 13:12:12.774+0900 E/VCONF   ( 1767): vconf.c: vconf_get_str(2887) > vconf_get_str(1767) : db/menu_widget/language error
02-12 13:12:12.774+0900 E/PKGMGR_INFO( 1767): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-12 13:12:13.325+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:12:13.335+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:12:13.515+0900 E/RESOURCED(  868): heart-abnormal.c: heart_abnormal_process_crashed(77) > Failed: dbus_message_get_args()
02-12 13:12:31.462+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:12:31.462+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:12:31.462+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:12:31.462+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:12:31.462+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:12:31.462+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:12:31.462+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 2, (3:lcdoff, 4:sleep)
02-12 13:12:31.472+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(177) > LCD is dimmed
02-12 13:12:32.233+0900 E/PKGMGR_SERVER( 1835): pkgmgr-server.c: main(2209) > package manager server start
02-12 13:12:32.233+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkg_mgr_server_gdbus_init(405) > initialize_gdbus Enter
02-12 13:12:32.233+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkg_mgr_server_gdbus_init(423) > initialize_gdbus Exit
02-12 13:12:32.263+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: on_bus_acquired(376) > on_bus_acquired
02-12 13:12:32.263+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: on_bus_acquired(400) > on_bus_acquired done
02-12 13:12:32.283+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkgmgr_request(145) > Called
02-12 13:12:32.283+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkgmgr_request(164) > sender_name: :1.172
02-12 13:12:32.283+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkg_mgr_get_sender_pid(79) > zone pid : 1833
02-12 13:12:32.283+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkgmgr_request(166) > sender_pid: 1833
02-12 13:12:32.283+0900 D/PKGMGR  ( 1835): comm_pkg_mgr_server.c: pkgmgr_request(175) > [SECURE_LOG] Call request callback(obj, org.example.sqlite_1413007215, 14, tpk, org.example.sqlite, , host)
02-12 13:12:32.283+0900 D/PKGMGR_SERVER( 1835): pkgmgr-server.c: req_cb(625) > [SECURE_LOG] >> in callback >> Got request: [org.example.sqlite_1413007215] [14] [tpk] [org.example.sqlite] [] [] [host]
02-12 13:12:32.283+0900 D/PKGMGR_SERVER( 1835): pkgmgr-server.c: req_cb(646) > req_type=(14)  backend_flag=(0) zone(host)
02-12 13:12:32.283+0900 D/PKGMGR_SERVER( 1835): pkgmgr-server.c: queue_job(1880) > target zone(host, host)
02-12 13:12:32.293+0900 D/PKGMGR_SERVER( 1835): pkgmgr-server.c: queue_job(1884) > child forked [1838] for request type [14]
02-12 13:12:32.293+0900 D/PKGMGR_SERVER( 1835): pkgmgr-server.c: queue_job(2126) > parent exit
02-12 13:12:32.293+0900 D/PKGMGR_SERVER( 1838): pkgmgr-server.c: queue_job(1884) > child forked [0] for request type [14]
02-12 13:12:32.293+0900 D/PKGMGR_SERVER( 1838): pkgmgr-server.c: queue_job(2057) > kill/check request
02-12 13:12:32.293+0900 D/PKGMGR  ( 1833): pkgmgr.c: __check_sync_process(873) > file is not generated yet.... wait
02-12 13:12:32.323+0900 D/PKGMGR_SERVER( 1838): pkgmgr-server.c: __pkgcmd_app_cb(1458) > sub_cmd(kill), zone_name(host)
02-12 13:12:32.333+0900 D/AUL     ( 1838): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(14)
02-12 13:12:32.333+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 14
02-12 13:12:32.343+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1028) > [SECURE_LOG] APP_IS_RUNNING : org.example.sqlite : -1
02-12 13:12:32.343+0900 W/AUL_AMD (  812): amd_request.c: __send_result_to_client(150) > __send_result_to_client, pid: -1
02-12 13:12:32.343+0900 D/PKGMGR_SERVER( 1838): pkgmgr-server.c: __make_pid_info_file(1384) > cano_path(tmp/org.example.sqlite)
02-12 13:12:32.353+0900 D/PKGMGR_SERVER( 1838): pkgmgr-server.c: __make_pid_info_file(1403) > security_server_label_access(tmp/org.example.sqlite, *) is ok.
02-12 13:12:32.363+0900 D/PKGMGR_SERVER( 1835): pkgmgr-server.c: sighandler(387) > child exit [1838]
02-12 13:12:32.363+0900 E/PKGMGR_SERVER( 1835): pkgmgr-server.c: sighandler(402) > child NORMAL exit [1838]
02-12 13:12:32.393+0900 D/PKGMGR  ( 1833): pkgmgr.c: __check_sync_process(868) > info_file file is generated, result = 0
02-12 13:12:32.393+0900 D/PKGMGR  ( 1833): . 
02-12 13:12:32.393+0900 E/PKGMGR  ( 1833): pkgmgr.c: __check_sync_process(884) > file is can not remove[/tmp/org.example.sqlite, -1]
02-12 13:12:32.904+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:12:32.904+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:12:32.904+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:12:32.904+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:12:32.904+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:12:32.914+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:12:32.914+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:12:32.914+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(169) > LCD is on
02-12 13:12:32.974+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: _OnScrollStart(1488) >  on appsview scroll started[1] xPos[-0] 
02-12 13:12:32.984+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:12:33.094+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-12 13:12:33.094+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200082 
02-12 13:12:33.334+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1505) >  Horizontal Apps scrollview is stopped normally.
02-12 13:12:33.334+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1508) >  mMenuScrollView.GetCurrentPage(0)
02-12 13:12:33.334+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1510) >  on appsview scroll completed[1] xPos[-0]
02-12 13:12:33.334+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: SetAppsViewFocusedPage(834) >  page [1]
02-12 13:12:33.334+0900 D/test-log(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1114) >  page change updated, get new page map
02-12 13:12:33.334+0900 D/test-log(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1115) >  focused page!!!!!!!!!!!!!![1]
02-12 13:12:33.334+0900 D/cluster-view(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1155) >  Current View state[1]
02-12 13:12:33.334+0900 D/cluster-view(  911): cluster-home-accessibility.cpp: SetCurrentGroup(62) >  Focus Group changed [12]->[12] Block[0]
02-12 13:12:33.334+0900 D/cluster-view(  911): mainmenu-view-manager-impl.cpp: _UpdateScreenReader(2054) >  [TTS] For Home update type[1], group[12]
02-12 13:12:33.334+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:12:33.334+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:12:33.334+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:12:33.334+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:12:33.334+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[60010]
02-12 13:12:33.334+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[60010]
02-12 13:12:33.334+0900 W/cluster-view(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1550) >  booster timer is still running on apps-view, Stop boost timer!!!
02-12 13:12:34.105+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x2400002
02-12 13:12:34.395+0900 E/PKGMGR_SERVER( 1835): pkgmgr-server.c: exit_server(1240) > exit_server Start [backend_status=1, queue_status=1, drm_status=1] 
02-12 13:12:34.395+0900 E/PKGMGR_SERVER( 1835): pkgmgr-server.c: main(2265) > package manager server terminated.
02-12 13:12:36.848+0900 D/AUL     ( 1888): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-12 13:12:36.848+0900 D/AUL     ( 1888): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-12 13:12:36.858+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 0
02-12 13:12:36.858+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-12 13:12:36.858+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:12:36.858+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:12:36.868+0900 I/AUL     (  812): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/launch_app, ret : 0
02-12 13:12:36.868+0900 D/AUL     (  812): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 1886, pid = 1888
02-12 13:12:36.868+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-12 13:12:36.868+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-12 13:12:36.868+0900 I/AUL     (  812): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /bin/bash, ret : 0
02-12 13:12:36.868+0900 E/AUL_AMD (  812): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-12 13:12:36.868+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2232) > caller pid : 1888
02-12 13:12:36.868+0900 E/AUL_AMD (  812): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-12 13:12:36.878+0900 W/AUL_AMD (  812): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-12 13:12:36.878+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2646) > process_pool: false
02-12 13:12:36.878+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-12 13:12:36.878+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-12 13:12:36.878+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2663) > pad pid(-5)
02-12 13:12:36.878+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-12 13:12:36.878+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-12 13:12:36.878+0900 D/AUL     (  812): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-12 13:12:36.878+0900 D/AUL_PAD (  960): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-12 13:12:36.878+0900 W/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-12 13:12:36.878+0900 D/AUL     (  960): process_pool.c: __send_pkt_raw_data(219) > send(12) : 616 / 616
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1722, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:12:36.878+0900 W/AUL_PAD (  960): launchpad.c: __send_result_to_caller(265) > Check app launching
02-12 13:12:36.878+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-12 13:12:36.878+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-12 13:12:36.878+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-12 13:12:36.878+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-12 13:12:36.878+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-12 13:12:36.878+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-12 13:12:36.878+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-12 13:12:36.878+0900 D/AUL     ( 1722): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1726) is sent.
02-12 13:12:36.888+0900 D/AUL     ( 1722): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1726, signo: 10
02-12 13:12:36.888+0900 D/AUL     ( 1722): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:12:36.888+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-12 13:12:36.888+0900 D/RESOURCED(  868): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 3
02-12 13:12:36.888+0900 E/RESOURCED(  868): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM3MTQzNTYvODYwMzgyAA==##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAxODg4AA==##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-12 13:12:36.888+0900 D/AUL_PAD ( 1722): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-12 13:12:36.898+0900 I/CAPI_APPFW_APPLICATION( 1722): app_main.c: ui_app_main(788) > app_efl_main
02-12 13:12:36.898+0900 D/LAUNCH  ( 1722): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-12 13:12:36.898+0900 D/APP_CORE( 1722): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-12 13:12:36.898+0900 D/APP_CORE( 1722): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-12 13:12:36.898+0900 D/APP_CORE( 1722): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-12 13:12:36.948+0900 D/APP_CORE( 1722): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-12 13:12:36.948+0900 D/AUL     ( 1722): app_sock.c: __create_server_sock(156) > pg path - already exists
02-12 13:12:36.948+0900 D/APP_CORE( 1722): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3f32dd0
02-12 13:12:36.948+0900 D/LAUNCH  ( 1722): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-12 13:12:36.948+0900 I/CAPI_APPFW_APPLICATION( 1722): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-12 13:12:36.978+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-12 13:12:36.978+0900 W/AUL     (  812): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 1722, appid: org.example.sqlite
02-12 13:12:36.978+0900 D/AUL     (  812): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-12 13:12:36.978+0900 E/AUL     (  812): simple_util.c: __trm_app_info_send_socket(330) > access
02-12 13:12:36.978+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2698) > add app group info
02-12 13:12:36.978+0900 E/AUL     (  812): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-12 13:12:36.978+0900 D/AUL_AMD (  812): amd_status.c: _status_add_app_info_list(427) > pid(1722) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-12 13:12:36.978+0900 D/AUL     ( 1888): launch.c: app_request_to_launchpad(425) > launch request result : 1722
02-12 13:12:36.978+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 1722
02-12 13:12:36.978+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-12 13:12:37.979+0900 D/AUL_AMD (  812): amd_launch.c: __grab_timeout_handler(1444) > pid(1722) ecore_x_pointer_ungrab
02-12 13:12:37.979+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:12:37.979+0900 W/AUL_AMD (  812): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:12:37.979+0900 W/AUL_AMD (  812): amd_launch.c: __grab_timeout_handler(1446) > back key ungrab error
02-12 13:12:37.989+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
02-12 13:12:37.989+0900 D/AUL_PAD ( 1889): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
02-12 13:12:38.009+0900 D/AUL_PAD (  960): sigchild.h: __send_app_launch_signal(130) > send launch signal done
02-12 13:12:38.479+0900 D/AUL_AMD (  812): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:12:38.479+0900 D/RUA     (  812): rua.c: rua_add_history(179) > rua_add_history start
02-12 13:12:38.499+0900 D/RUA     (  812): rua.c: rua_add_history(247) > rua_add_history ok
02-12 13:12:39.110+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200082 bd->visible=1
02-12 13:12:39.130+0900 D/AUL_PAD ( 1889): launchpad_loader.c: main(588) > sleeping 1 sec...
02-12 13:12:39.130+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(52) > max_cmdline_size = 1053
02-12 13:12:39.140+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b71d0768
02-12 13:12:39.140+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:12:39.140+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(73) > get shutdown function
02-12 13:12:39.140+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b71d0a48
02-12 13:12:39.150+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b71d25b0
02-12 13:12:39.150+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:12:39.160+0900 D/AUL_PAD ( 1889): preload.h: __preload_init(73) > get shutdown function
02-12 13:12:39.160+0900 D/AUL_PAD ( 1889): preexec.h: __preexec_init(76) > preexec start
02-12 13:12:39.160+0900 D/AUL_PAD ( 1889): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
02-12 13:12:39.160+0900 D/AUL     ( 1889): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
02-12 13:12:39.160+0900 D/AUL     ( 1889): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
02-12 13:12:39.160+0900 D/AUL     ( 1889): process_pool.c: __connect_to_launchpad(132) > send(1889) : 4
02-12 13:12:39.160+0900 D/AUL     ( 1889): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
02-12 13:12:39.160+0900 D/AUL_PAD (  960): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 1889
02-12 13:12:39.430+0900 D/AUL_PAD ( 1889): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
02-12 13:12:39.470+0900 D/AUL_PAD ( 1889): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
02-12 13:12:39.470+0900 D/AUL_PAD ( 1889): launchpad_loader.c: main(693) > [candidate] ecore handler add
02-12 13:12:39.470+0900 D/AUL_PAD ( 1889): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
02-12 13:12:41.983+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1722) status(4)
02-12 13:12:41.983+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1722) appid(org.example.sqlite) pkgid(org.example.sqlite) status(4)
02-12 13:12:41.983+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.example.sqlite
02-12 13:12:41.983+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1722, appid: org.example.sqlite, status: bg
02-12 13:12:41.983+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1722, proc_name: ---, cg_name: previous, oom_score_adj: 300
02-12 13:12:41.983+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 1722
02-12 13:12:44.445+0900 D/LAUNCH  ( 1722): appcore-efl.c: __before_loop(1154) > [sqlite:Application:create:done]
02-12 13:12:44.445+0900 E/E17     (  533): e_manager.c: _e_manager_cb_window_show_request(1134) > Show request(0x01200002)
02-12 13:12:44.455+0900 E/E17     (  533): e_border.c: e_border_show(2088) > BD_SHOW(0x01200002)
02-12 13:12:44.555+0900 D/APP_CORE( 1722): appcore-efl.c: __check_wm_rotation_support(835) > Disable window manager rotation
02-12 13:12:44.555+0900 W/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=1722
02-12 13:12:44.565+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:12:44.565+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:12:44.565+0900 D/INDICATOR(  886): main.c: _property_changed_cb(432) > UNSNIFF API 2400002
02-12 13:12:44.565+0900 D/INDICATOR(  886): util.c: util_signal_emit_by_win(116) > emission bg.opaque
02-12 13:12:44.585+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:12:44.585+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:44.585+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:44.595+0900 D/AUL_AMD (  812): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 1722 is org.example.sqlite
02-12 13:12:44.595+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 1722 : 0
02-12 13:12:44.595+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
02-12 13:12:44.665+0900 D/INDICATOR(  886): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:12:44.665+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:12:44.665+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:12:44.665+0900 D/INDICATOR(  886): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:12:44.665+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11d9330), gem(10), surface(0x1259a08)
02-12 13:12:44.675+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x125b330), gem(12), surface(0x126e700)
02-12 13:12:44.675+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:12:45.296+0900 D/APP_CORE( 1722): appcore.c: __aul_handler(587) > [APP 1722]     AUL event: AUL_START
02-12 13:12:45.296+0900 I/APP_CORE( 1722): appcore-efl.c: __do_app(496) > [APP 1722] Event: RESET State: CREATED
02-12 13:12:45.296+0900 D/APP_CORE( 1722): appcore-efl.c: __do_app(527) > [APP 1722] RESET
02-12 13:12:45.296+0900 D/LAUNCH  ( 1722): appcore-efl.c: __do_app(529) > [sqlite:Application:reset:start]
02-12 13:12:45.296+0900 D/APP_CORE( 1722): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
02-12 13:12:45.296+0900 D/APP_CORE( 1722): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:12:45.296+0900 I/CAPI_APPFW_APPLICATION( 1722): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
02-12 13:12:45.296+0900 D/AUL     ( 1722): service.c: __set_bundle(186) > __set_bundle
02-12 13:12:45.296+0900 D/LAUNCH  ( 1722): appcore-efl.c: __do_app(544) > [sqlite:Application:reset:done]
02-12 13:12:45.296+0900 D/APP_CORE( 1722): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : (null)
02-12 13:12:45.346+0900 E/EFL     ( 1722): edje<1722> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:12:45.346+0900 E/EFL     ( 1722): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:12:46.067+0900 E/EFL     ( 1722): edje<1722> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:12:46.067+0900 E/EFL     ( 1722): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:12:46.817+0900 E/EFL     ( 1722): edje<1722> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:12:46.817+0900 E/EFL     ( 1722): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:12:46.988+0900 W/APP_CORE( 1722): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:1200002
02-12 13:12:46.988+0900 D/APP_CORE( 1722): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:1200002
02-12 13:12:46.988+0900 D/APP_CORE( 1722): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
02-12 13:12:46.988+0900 D/AUL     ( 1722): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
02-12 13:12:46.988+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 34
02-12 13:12:48.939+0900 D/APP_CORE( 1722): appcore.c: __prt_ltime(236) > [APP 1722] first idle after reset: 12086 msec
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:138 _ecore_evas_idle_enter() stuck async render: time=3.645631, ee=0xb7276e20, engine=software_x11, geometry=(0, 0, 720, 1280), visible=1, shaped=0, alpha=0, transparent=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:140 _ecore_evas_idle_enter() delayed.avoid_damage=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:141 _ecore_evas_idle_enter() delayed.resize_shape=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:142 _ecore_evas_idle_enter() delayed.shaped=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:143 _ecore_evas_idle_enter() delayed.shaped_changed=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:144 _ecore_evas_idle_enter() delayed.alpha=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:145 _ecore_evas_idle_enter() delayed.alpha_changed=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:146 _ecore_evas_idle_enter() delayed.transparent=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:147 _ecore_evas_idle_enter() delayed.transparent_changed=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:148 _ecore_evas_idle_enter() delayed.rotation=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:149 _ecore_evas_idle_enter() delayed.rotation_resize=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:150 _ecore_evas_idle_enter() delayed.rotation_changed=0
02-12 13:12:48.959+0900 E/EFL     ( 1722): ecore_evas<1722> lib/ecore_evas/ecore_evas.c:152 _ecore_evas_idle_enter() reset in_async_render of ee=0xb7276e20
02-12 13:12:49.010+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11d8b38), gem(16), surface(0x126a8c8)
02-12 13:12:49.010+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11d9330), gem(10), surface(0x11d0fd8)
02-12 13:12:49.020+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11d8b38), gem(16), surface(0x1271110)
02-12 13:12:49.030+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-12 13:12:49.030+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-12 13:12:49.030+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:12:49.030+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:12:49.030+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: PAUSE State: RUNNING
02-12 13:12:49.030+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(565) > [APP 911] PAUSE
02-12 13:12:49.030+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:12:49.030+0900 E/cluster-home(  911): homescreen.cpp: OnPause(84) >  app pause
02-12 13:12:49.030+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-12 13:12:49.030+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(923) >  END
02-12 13:12:49.030+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:12:49.030+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:12:49.030+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(911) status(4)
02-12 13:12:49.030+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-12 13:12:49.030+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-12 13:12:49.030+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: bg
02-12 13:12:49.040+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2887) > pid(1722) status(3)
02-12 13:12:49.040+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:12:49.040+0900 W/AUL_AMD (  812): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:12:49.040+0900 W/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-12 13:12:49.040+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1722) status(3)
02-12 13:12:49.040+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1722) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-12 13:12:49.040+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-12 13:12:49.040+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1722, appid: org.example.sqlite, status: fg
02-12 13:12:49.040+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1722
02-12 13:12:49.040+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1722, proc_name: ---, cg_name: foreground, oom_score_adj: 200
02-12 13:12:49.040+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 1722
02-12 13:12:49.040+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 911 is paused
02-12 13:12:49.040+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:12:49.040+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_pause_cb(292) > widget obj was paused
02-12 13:12:49.040+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(142) > enter background group
02-12 13:12:49.040+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: bg
02-12 13:12:49.100+0900 D/APP_CORE( 1722): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:1200002 fully_obscured 0
02-12 13:12:49.100+0900 D/APP_CORE( 1722): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
02-12 13:12:49.100+0900 D/APP_CORE( 1722): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:12:49.100+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
02-12 13:12:49.100+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
02-12 13:12:49.100+0900 I/APP_CORE( 1722): appcore-efl.c: __do_app(496) > [APP 1722] Event: RESUME State: CREATED
02-12 13:12:49.100+0900 D/LAUNCH  ( 1722): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-12 13:12:49.100+0900 D/APP_CORE( 1722): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:12:49.100+0900 D/APP_CORE( 1722): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:12:49.100+0900 D/APP_CORE( 1722): appcore-efl.c: __do_app(607) > [APP 1722] RESUME
02-12 13:12:49.190+0900 D/RESOURCED(  868): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
02-12 13:12:49.190+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
02-12 13:12:49.220+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2906) > pid(1722) status(0)
02-12 13:12:49.630+0900 I/APP_CORE( 1722): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
02-12 13:12:49.630+0900 I/APP_CORE( 1722): appcore-efl.c: __do_app(614) > [APP 1722] Initial Launching, call the resume_cb
02-12 13:12:49.630+0900 I/CAPI_APPFW_APPLICATION( 1722): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:12:49.630+0900 D/LAUNCH  ( 1722): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-12 13:12:49.630+0900 D/LAUNCH  ( 1722): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-12 13:12:49.630+0900 D/APP_CORE( 1722): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:12:49.630+0900 E/APP_CORE( 1722): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:12:53.664+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200708 
02-12 13:12:54.024+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
02-12 13:12:54.024+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: MEM_FLUSH State: PAUSED
02-12 13:12:54.024+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
02-12 13:12:54.024+0900 D/APP_CORE(  911): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 911
02-12 13:12:54.024+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
02-12 13:12:54.024+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 911
02-12 13:12:54.315+0900 D/sqlite  ( 1722): DB Path: /opt/usr/apps/org.example.sqlite/data/test.db
02-12 13:12:54.665+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x1200002
02-12 13:12:55.085+0900 W/CRASH_MANAGER( 1896): worker.c: worker_job(1204) > 110172273716c142371437
