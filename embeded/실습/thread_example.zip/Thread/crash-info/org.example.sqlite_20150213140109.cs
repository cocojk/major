S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1216
Date: 2015-02-13 14:01:09+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 1216, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x0000056f
r2   = 0x00000006, r3   = 0xb0f7f6d0
r4   = 0x00000002, r5   = 0xb0f7f210
r6   = 0xb67bc09c, r7   = 0x0000010c
r8   = 0x00000001, r9   = 0x00000002
r10  = 0x00000007, fp   = 0xb0f7e428
ip   = 0x00000000, sp   = 0xb0f7e1ec
lr   = 0xb66b2f18, pc   = 0xb66b1b84
cpsr = 0x200e0010

Memory Information
MemTotal:   987264 KB
MemFree:    579664 KB
Buffers:     21776 KB
Cached:     123932 KB
VmPeak:     108064 KB
VmSize:     108060 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20956 KB
VmRSS:       20956 KB
VmData:      36028 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22316 KB
VmPTE:          72 KB
VmSwap:          0 KB

Threads Information
Threads: 4
PID = 1216 TID = 1391
1216 1217 1390 1391 

Maps Information
b0781000 b0f80000 rw-p [stack:1391]
b0f81000 b1780000 rw-p [stack:1390]
b2ecc000 b2ed1000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2f5d000 b2f65000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b2f76000 b2f77000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2f87000 b2f8e000 r-xp /usr/lib/libfeedback.so.0.1.4
b2fb2000 b2fc5000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2fd9000 b2fde000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2fee000 b2fef000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b2fff000 b3002000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b3013000 b3014000 r-xp /usr/lib/libxshmfence.so.1.0.0
b3024000 b3026000 r-xp /usr/lib/libxcb-present.so.0.0.0
b3036000 b3038000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b3048000 b3050000 r-xp /usr/lib/libdrm.so.2.4.0
b3060000 b3062000 r-xp /usr/lib/libdri2.so.0.0.0
b3072000 b307a000 r-xp /usr/lib/libtbm.so.1.0.0
b308a000 b308b000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b309d000 b309e000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b30ae000 b30ba000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b30cb000 b30d2000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30e4000 b30f4000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b31fc000 b3200000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3211000 b32f1000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3309000 b330b000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b3313000 b333a000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b334d000 b3b4c000 rw-p [stack:1217]
b3b4c000 b3b4e000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d5e000 b3d67000 r-xp /lib/libnss_files-2.20-2014.11.so
b3d78000 b3d81000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3d92000 b3da3000 r-xp /lib/libnsl-2.20-2014.11.so
b3db6000 b3dbc000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3dcd000 b3de7000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3df8000 b3df9000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e09000 b3e0b000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e1c000 b3e21000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e31000 b3e34000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e45000 b3e4c000 r-xp /usr/lib/libsensord-share.so
b3e5c000 b3e6d000 r-xp /usr/lib/libsensor.so.1.2.0
b3e7e000 b3e84000 r-xp /usr/lib/libappcore-common.so.1.1
b3ea7000 b3eac000 r-xp /usr/lib/libappcore-efl.so.1.1
b3ec2000 b3ec4000 r-xp /usr/lib/libXau.so.6.0.0
b3ed4000 b3ee8000 r-xp /usr/lib/libxcb.so.1.1.0
b3ef8000 b3eff000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f37000 b3f39000 r-xp /usr/lib/libiri.so
b3f4a000 b3f5f000 r-xp /lib/libexpat.so.1.5.2
b3f71000 b3fbf000 r-xp /usr/lib/libssl.so.1.0.0
b3fd4000 b3fdd000 r-xp /usr/lib/libethumb.so.1.13.0
b3fee000 b3ff1000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4001000 b41b8000 r-xp /usr/lib/libcrypto.so.1.0.0
b574f000 b5758000 r-xp /usr/lib/libXi.so.6.1.0
b5769000 b576b000 r-xp /usr/lib/libXgesture.so.7.0.0
b577b000 b577f000 r-xp /usr/lib/libXtst.so.6.1.0
b578f000 b5795000 r-xp /usr/lib/libXrender.so.1.3.0
b57a5000 b57ab000 r-xp /usr/lib/libXrandr.so.2.2.0
b57bb000 b57bd000 r-xp /usr/lib/libXinerama.so.1.0.0
b57cd000 b57d0000 r-xp /usr/lib/libXfixes.so.3.1.0
b57e1000 b57ec000 r-xp /usr/lib/libXext.so.6.4.0
b57fc000 b57fe000 r-xp /usr/lib/libXdamage.so.1.1.0
b580e000 b5810000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5820000 b5903000 r-xp /usr/lib/libX11.so.6.3.0
b5916000 b591d000 r-xp /usr/lib/libXcursor.so.1.0.2
b592e000 b5946000 r-xp /usr/lib/libudev.so.1.6.0
b5948000 b594b000 r-xp /lib/libattr.so.1.1.0
b595b000 b597b000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b597c000 b5981000 r-xp /usr/lib/libffi.so.6.0.2
b5991000 b59a9000 r-xp /lib/libz.so.1.2.8
b59b9000 b59bb000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59cb000 b5aa0000 r-xp /usr/lib/libxml2.so.2.9.2
b5ab5000 b5b50000 r-xp /usr/lib/libstdc++.so.6.0.20
b5b6c000 b5b6f000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5b7f000 b5b99000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5ba9000 b5bba000 r-xp /lib/libresolv-2.20-2014.11.so
b5bce000 b5be5000 r-xp /usr/lib/liblzma.so.5.0.3
b5bf5000 b5bf7000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c07000 b5c0e000 r-xp /usr/lib/libembryo.so.1.13.0
b5c1e000 b5c36000 r-xp /usr/lib/libpng12.so.0.50.0
b5c47000 b5c6a000 r-xp /usr/lib/libjpeg.so.8.0.2
b5c8a000 b5c90000 r-xp /lib/librt-2.20-2014.11.so
b5ca1000 b5cb5000 r-xp /usr/lib/libector.so.1.13.0
b5cc6000 b5cde000 r-xp /usr/lib/liblua-5.1.so
b5cef000 b5d46000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d5a000 b5d82000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5d93000 b5da6000 r-xp /usr/lib/libfribidi.so.0.3.1
b5db7000 b5df1000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e02000 b5e6d000 r-xp /lib/libm-2.20-2014.11.so
b5e7e000 b5e8b000 r-xp /usr/lib/libeio.so.1.13.0
b5e9b000 b5e9d000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5ead000 b5eb2000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5ec2000 b5ed9000 r-xp /usr/lib/libefreet.so.1.13.0
b5eeb000 b5f0b000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f1b000 b5f3b000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f3d000 b5f43000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f53000 b5f5a000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f6a000 b5f78000 r-xp /usr/lib/libeo.so.1.13.0
b5f88000 b5f9a000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fab000 b5fb0000 r-xp /usr/lib/libecore_file.so.1.13.0
b5fc0000 b5fd8000 r-xp /usr/lib/libecore_evas.so.1.13.0
b5fe9000 b6006000 r-xp /usr/lib/libeet.so.1.13.0
b601f000 b6067000 r-xp /usr/lib/libeina.so.1.13.0
b6078000 b6088000 r-xp /usr/lib/libefl.so.1.13.0
b6099000 b617e000 r-xp /usr/lib/libicuuc.so.51.1
b619b000 b62db000 r-xp /usr/lib/libicui18n.so.51.1
b62f2000 b632a000 r-xp /usr/lib/libecore_x.so.1.13.0
b633c000 b633f000 r-xp /lib/libcap.so.2.21
b634f000 b6378000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6389000 b6390000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63a2000 b63d8000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b63e9000 b64d1000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b64e5000 b655b000 r-xp /usr/lib/libsqlite3.so.0.8.6
b656d000 b6570000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6580000 b658b000 r-xp /usr/lib/libvconf.so.0.2.45
b659b000 b659d000 r-xp /usr/lib/libvasum.so.0.3.1
b65ad000 b65af000 r-xp /usr/lib/libttrace.so.1.1
b65bf000 b65c2000 r-xp /usr/lib/libiniparser.so.0
b65d2000 b65f5000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6605000 b660a000 r-xp /usr/lib/libxdgmime.so.1.1.0
b661b000 b6632000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6643000 b6650000 r-xp /usr/lib/libunwind.so.8.0.1
b6686000 b67aa000 r-xp /lib/libc-2.20-2014.11.so
b67bf000 b67d8000 r-xp /lib/libgcc_s-4.9.so.1
b67e8000 b68ca000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b68db000 b690f000 r-xp /usr/lib/libdbus-1.so.3.8.11
b691f000 b6959000 r-xp /usr/lib/libsystemd.so.0.4.0
b695b000 b69db000 r-xp /usr/lib/libedje.so.1.13.0
b69de000 b69fc000 r-xp /usr/lib/libecore.so.1.13.0
b6a1c000 b6b7e000 r-xp /usr/lib/libevas.so.1.13.0
b6bb5000 b6bc9000 r-xp /lib/libpthread-2.20-2014.11.so
b6bdd000 b6e01000 r-xp /usr/lib/libelementary.so.1.13.0
b6e2f000 b6e33000 r-xp /usr/lib/libsmack.so.1.0.0
b6e43000 b6e49000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e5a000 b6e5c000 r-xp /usr/lib/libdlog.so.0.0.0
b6e6c000 b6e6f000 r-xp /usr/lib/libbundle.so.0.1.22
b6e7f000 b6e81000 r-xp /lib/libdl-2.20-2014.11.so
b6e92000 b6eab000 r-xp /usr/lib/libaul.so.0.1.0
b6ebd000 b6ebf000 r-xp /usr/lib/libappsvc.so.0.1.0
b6ed0000 b6ed4000 r-xp /usr/lib/libsys-assert.so
b6ee5000 b6f05000 r-xp /lib/ld-2.20-2014.11.so
b6f16000 b6f1c000 r-xp /usr/bin/launchpad-loader
b825d000 b84b4000 rw-p [heap]
be85e000 be87f000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1216)
Call Stack Count: 18
 0: gsignal + 0x34 (0xb66b1b84) [/lib/libc.so.6] + 0x2bb84
 1: abort + 0x12c (0xb66b2f18) [/lib/libc.so.6] + 0x2cf18
 2: (0xb66ed46c) [/lib/libc.so.6] + 0x6746c
 3: (0xb66f30d4) [/lib/libc.so.6] + 0x6d0d4
 4: (0xb66f3a5c) [/lib/libc.so.6] + 0x6da5c
 5: (0xb6a9c4b1) [/usr/lib/libevas.so.1] + 0x804b1
 6: (0xb6a9cb27) [/usr/lib/libevas.so.1] + 0x80b27
 7: evas_textblock_cursor_geometry_bidi_get + 0xd2 (0xb6a9f24b) [/usr/lib/libevas.so.1] + 0x8324b
 8: (0xb69a60fd) [/usr/lib/libedje.so.1] + 0x4b0fd
 9: (0xb69c34cb) [/usr/lib/libedje.so.1] + 0x684cb
10: (0xb69c5fe5) [/usr/lib/libedje.so.1] + 0x6afe5
11: edje_obj_part_text_append + 0x62 (0xb69b7327) [/usr/lib/libedje.so.1] + 0x5c327
12: edje_object_part_text_append + 0x2a (0xb69bede3) [/usr/lib/libedje.so.1] + 0x63de3
13: elm_obj_entry_append + 0x5c (0xb6cac081) [/usr/lib/libelementary.so.1] + 0xcf081
14: elm_entry_entry_append + 0x26 (0xb6cb6ecb) [/usr/lib/libelementary.so.1] + 0xd9ecb
15: _add_entry_text + 0x28 (0xb330a29d) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x129d
16: thread_run_1 + 0x56 (0xb330aaf7) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x1af7
17: (0xb6bbacf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
pps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[1]
02-13 14:01:01.852+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.tizen.phone] Name[Phone] Icon[/usr/share/icons/default/small/org.tizen.phone.png] enable[1] system[1]
02-13 14:01:01.862+0900 D/BADGE   (  911): badge_internal.c: _badge_check_data_inserted(154) > [SECURE_LOG] [_badge_check_data_inserted : 154] [SELECT count(*) FROM badge_data WHERE pkgname = 'org.tizen.phone'], count[0]
02-13 14:01:01.862+0900 E/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(618) >  Failed to get badge count [org.tizen.phone][-17956860][0]
02-13 14:01:01.862+0900 D/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(622) >  pageId[100001] appId[org.tizen.phone]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(768) >  MoveBox Name[Phone] pos[2, 3] pageId[100001]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(976) >  Find box pageid[100001], boxid[10]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(980) >  nBoxOrder[10], [2, 3]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(1001) >  nOriBoxOrder[10], [2, 3]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[1]
02-13 14:01:01.862+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.tizen.setting] Name[Settings] Icon[/usr/share/icons/default/small/org.tizen.setting.png] enable[1] system[1]
02-13 14:01:01.862+0900 D/BADGE   (  911): badge_internal.c: _badge_check_data_inserted(154) > [SECURE_LOG] [_badge_check_data_inserted : 154] [SELECT count(*) FROM badge_data WHERE pkgname = 'org.tizen.setting'], count[0]
02-13 14:01:01.862+0900 E/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(618) >  Failed to get badge count [org.tizen.setting][-17956860][0]
02-13 14:01:01.862+0900 D/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(622) >  pageId[100001] appId[org.tizen.setting]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(768) >  MoveBox Name[Settings] pos[3, 3] pageId[100001]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(976) >  Find box pageid[100001], boxid[11]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(980) >  nBoxOrder[11], [3, 3]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(1001) >  nOriBoxOrder[11], [3, 3]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[1]
02-13 14:01:01.862+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.example.sqlite] Name[sqlite] Icon[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png] enable[1] system[0]
02-13 14:01:01.862+0900 D/BADGE   (  911): badge_internal.c: _badge_check_data_inserted(154) > [SECURE_LOG] [_badge_check_data_inserted : 154] [SELECT count(*) FROM badge_data WHERE pkgname = 'org.example.sqlite'], count[0]
02-13 14:01:01.862+0900 E/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(618) >  Failed to get badge count [org.example.sqlite][-17956860][0]
02-13 14:01:01.862+0900 D/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(622) >  pageId[100001] appId[org.example.sqlite]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(768) >  MoveBox Name[sqlite] pos[4, 3] pageId[100001]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[0]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(787) >  AddBoxToMenuView
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: AddBoxToMenuView(347) >  AddBox Name[sqlite] pageid[100001] pos[4, 3]
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: AddBoxToMenuView(354) >  menuPage.GetPageId() = 100001, boxPageId = 100001
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: AddBoxToPage(112) >  void ClusterHome3D::Internal::CMainMenuPage::AddBoxToPage(std::shared_ptr<CMainMenuBoxData>) : 112
02-13 14:01:01.862+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: AddBoxToPage(122) >  void ClusterHome3D::Internal::CMainMenuPage::AddBoxToPage(std::shared_ptr<CMainMenuBoxData>) : 122
02-13 14:01:01.862+0900 D/test-log(  911): mainmenu-page-impl.cpp: AddBoxToPage(123) >  create box[org.example.sqlite] [4,3]
02-13 14:01:01.862+0900 D/test-log(  911): mainmenu-box-impl.cpp: CMainMenuBox(148) >  create box
02-13 14:01:01.882+0900 D/test-log(  911): mainmenu-box-impl.cpp: SetPosition(459) >  cut Animation : sqlite
02-13 14:01:01.882+0900 D/test-log(  911): mainmenu-page-impl.cpp: AddBoxToPage(177) >  add created box
02-13 14:01:01.882+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.tizen.videos] Name[Video] Icon[/usr/share/icons/default/small/org.tizen.videos.png] enable[1] system[1]
02-13 14:01:01.882+0900 D/BADGE   (  911): badge_internal.c: _badge_check_data_inserted(154) > [SECURE_LOG] [_badge_check_data_inserted : 154] [SELECT count(*) FROM badge_data WHERE pkgname = 'org.tizen.videos'], count[0]
02-13 14:01:01.882+0900 E/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(618) >  Failed to get badge count [org.tizen.videos][-17956860][0]
02-13 14:01:01.882+0900 D/cluster-home(  911): mainmenu-presenter.cpp: _ReorderAppsItems(622) >  pageId[100001] appId[org.tizen.videos]
02-13 14:01:01.882+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(768) >  MoveBox Name[Video] pos[1, 4] pageId[100001]
02-13 14:01:01.882+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(976) >  Find box pageid[100001], boxid[12]
02-13 14:01:01.882+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(980) >  nBoxOrder[13], [1, 4]
02-13 14:01:01.882+0900 D/cluster-view(  911): mainmenu-page-impl.cpp: MoveMenuBox(1001) >  nOriBoxOrder[12], [4, 3]
02-13 14:01:01.882+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[1]
02-13 14:01:01.882+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: RearrangeItems(243) >  view type [1]
02-13 14:01:01.892+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-13 14:01:02.163+0900 D/APP_CORE(  911): appcore-rotation.c: __changed_cb(121) > [APP 911] Rotation: 3 -> 1
02-13 14:01:02.163+0900 D/APP_CORE(  911): appcore-rotation.c: __changed_cb(124) > [APP 911] Rotation: 3 -> 1
02-13 14:01:02.163+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
02-13 14:01:02.373+0900 D/rpm-installer( 1331): rpm-installer-privilege.c: __ri_privilege_perm_end(55) > [smack] perm_end, result=[0]
02-13 14:01:02.373+0900 D/rpm-installer( 1331): rpm-appcore-intf.c: main(259) > ------------------------------------------------
02-13 14:01:02.373+0900 D/rpm-installer( 1331): rpm-appcore-intf.c: main(260) >  [END] rpm-installer: result=[0]
02-13 14:01:02.373+0900 D/rpm-installer( 1331): rpm-appcore-intf.c: main(261) > ------------------------------------------------
02-13 14:01:02.373+0900 D/PKGMGR_SERVER( 1328): pkgmgr-server.c: sighandler(387) > child exit [1331]
02-13 14:01:02.373+0900 E/PKGMGR_SERVER( 1328): pkgmgr-server.c: sighandler(402) > child NORMAL exit [1331]
02-13 14:01:03.414+0900 E/PKGMGR_SERVER( 1328): pkgmgr-server.c: exit_server(1240) > exit_server Start [backend_status=1, queue_status=1, drm_status=1] 
02-13 14:01:03.414+0900 E/PKGMGR_SERVER( 1328): pkgmgr-server.c: main(2265) > package manager server terminated.
02-13 14:01:03.874+0900 D/AUL_AMD (  807): amd_status.c: __app_terminate_timer_cb(442) > pid(1124)
02-13 14:01:03.874+0900 W/AUL_AMD (  807): amd_status.c: __app_terminate_timer_cb(446) > send SIGKILL: No such process
02-13 14:01:05.236+0900 D/AUL     ( 1385): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-13 14:01:05.236+0900 D/AUL     ( 1385): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-13 14:01:05.246+0900 D/AUL_AMD (  807): amd_request.c: __request_handler(838) > __request_handler: 0
02-13 14:01:05.246+0900 D/AUL_AMD (  807): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-13 14:01:05.246+0900 D/PKGMGR_INFO(  807): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-13 14:01:05.246+0900 D/PKGMGR_INFO(  807): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-13 14:01:05.246+0900 I/AUL     (  807): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/launch_app, ret : 0
02-13 14:01:05.246+0900 D/AUL     (  807): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 1383, pid = 1385
02-13 14:01:05.246+0900 D/PKGMGR_INFO(  807): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-13 14:01:05.246+0900 D/PKGMGR_INFO(  807): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-13 14:01:05.256+0900 I/AUL     (  807): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /bin/bash, ret : 0
02-13 14:01:05.256+0900 E/AUL_AMD (  807): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-13 14:01:05.256+0900 W/AUL_AMD (  807): amd_launch.c: _start_app(2232) > caller pid : 1385
02-13 14:01:05.256+0900 E/AUL_AMD (  807): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-13 14:01:05.256+0900 W/AUL_AMD (  807): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-13 14:01:05.256+0900 D/AUL_AMD (  807): amd_launch.c: _start_app(2646) > process_pool: false
02-13 14:01:05.256+0900 D/AUL_AMD (  807): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-13 14:01:05.256+0900 D/AUL_AMD (  807): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-13 14:01:05.256+0900 W/AUL_AMD (  807): amd_launch.c: _start_app(2663) > pad pid(-5)
02-13 14:01:05.256+0900 D/AUL_AMD (  807): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-13 14:01:05.256+0900 D/AUL_AMD (  807): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-13 14:01:05.256+0900 D/AUL     (  807): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:01:05.256+0900 D/AUL_PAD (  959): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-13 14:01:05.266+0900 D/AUL_PAD (  959): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-13 14:01:05.266+0900 W/AUL_PAD (  959): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-13 14:01:05.266+0900 D/AUL     (  959): process_pool.c: __send_pkt_raw_data(219) > send(11) : 616 / 616
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1216, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:01:05.266+0900 W/AUL_PAD (  959): launchpad.c: __send_result_to_caller(265) > Check app launching
02-13 14:01:05.266+0900 D/AUL_PAD (  959): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-13 14:01:05.266+0900 D/AUL     ( 1216): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1217) is sent.
02-13 14:01:05.266+0900 D/AUL     ( 1216): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1217, signo: 10
02-13 14:01:05.266+0900 D/AUL     ( 1216): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM4MDM2NjUvMjUxNzM5AA==##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAxMzg1AA==##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-13 14:01:05.266+0900 D/AUL_PAD ( 1216): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-13 14:01:05.276+0900 D/RESOURCED(  867): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-13 14:01:05.276+0900 D/RESOURCED(  867): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 1
02-13 14:01:05.276+0900 I/CAPI_APPFW_APPLICATION( 1216): app_main.c: ui_app_main(788) > app_efl_main
02-13 14:01:05.276+0900 D/LAUNCH  ( 1216): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-13 14:01:05.276+0900 D/APP_CORE( 1216): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-13 14:01:05.276+0900 D/APP_CORE( 1216): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-13 14:01:05.276+0900 E/RESOURCED(  867): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-13 14:01:05.276+0900 D/APP_CORE( 1216): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-13 14:01:05.296+0900 D/APP_CORE( 1216): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-13 14:01:05.296+0900 D/AUL     ( 1216): app_sock.c: __create_server_sock(156) > pg path - already exists
02-13 14:01:05.296+0900 D/APP_CORE( 1216): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3e93dd0
02-13 14:01:05.296+0900 D/LAUNCH  ( 1216): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-13 14:01:05.296+0900 I/CAPI_APPFW_APPLICATION( 1216): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-13 14:01:05.366+0900 D/AUL_PAD (  959): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-13 14:01:05.366+0900 W/AUL     (  807): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 1216, appid: org.example.sqlite
02-13 14:01:05.366+0900 D/AUL     (  807): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-13 14:01:05.366+0900 E/AUL     (  807): simple_util.c: __trm_app_info_send_socket(330) > access
02-13 14:01:05.366+0900 D/AUL_AMD (  807): amd_launch.c: _start_app(2698) > add app group info
02-13 14:01:05.366+0900 E/AUL     (  807): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-13 14:01:05.366+0900 D/AUL_AMD (  807): amd_status.c: _status_add_app_info_list(427) > pid(1216) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-13 14:01:05.366+0900 D/AUL     ( 1385): launch.c: app_request_to_launchpad(425) > launch request result : 1216
02-13 14:01:05.366+0900 D/RESOURCED(  867): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 1216
02-13 14:01:05.366+0900 D/RESOURCED(  867): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-13 14:01:05.506+0900 D/LAUNCH  ( 1216): appcore-efl.c: __before_loop(1154) > [sqlite:Application:create:done]
02-13 14:01:05.506+0900 E/E17     (  532): e_manager.c: _e_manager_cb_window_show_request(1134) > Show request(0x01600002)
02-13 14:01:05.506+0900 D/APP_CORE( 1216): appcore-efl.c: __check_wm_rotation_support(835) > Disable window manager rotation
02-13 14:01:05.516+0900 E/E17     (  532): e_border.c: e_border_show(2088) > BD_SHOW(0x01600002)
02-13 14:01:05.606+0900 W/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=1216
02-13 14:01:05.606+0900 E/EFL     (  532): eo<532> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-13 14:01:05.606+0900 E/EFL     (  532): eo<532> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-13 14:01:05.616+0900 D/APP_CORE( 1216): appcore.c: __aul_handler(587) > [APP 1216]     AUL event: AUL_START
02-13 14:01:05.616+0900 I/APP_CORE( 1216): appcore-efl.c: __do_app(496) > [APP 1216] Event: RESET State: CREATED
02-13 14:01:05.616+0900 D/APP_CORE( 1216): appcore-efl.c: __do_app(527) > [APP 1216] RESET
02-13 14:01:05.616+0900 D/LAUNCH  ( 1216): appcore-efl.c: __do_app(529) > [sqlite:Application:reset:start]
02-13 14:01:05.616+0900 D/APP_CORE( 1216): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
02-13 14:01:05.616+0900 D/APP_CORE( 1216): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-13 14:01:05.616+0900 I/CAPI_APPFW_APPLICATION( 1216): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
02-13 14:01:05.616+0900 D/AUL     ( 1216): service.c: __set_bundle(186) > __set_bundle
02-13 14:01:05.616+0900 D/LAUNCH  ( 1216): appcore-efl.c: __do_app(544) > [sqlite:Application:reset:done]
02-13 14:01:05.616+0900 D/APP_CORE( 1216): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : (null)
02-13 14:01:05.616+0900 E/EFL     ( 1216): edje<1216> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-13 14:01:05.616+0900 E/EFL     ( 1216): By the power of Grayskull, your previous Embryo stack is now broken!
02-13 14:01:05.626+0900 E/EFL     ( 1216): edje<1216> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-13 14:01:05.626+0900 E/EFL     ( 1216): By the power of Grayskull, your previous Embryo stack is now broken!
02-13 14:01:05.626+0900 E/EFL     ( 1216): edje<1216> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-13 14:01:05.626+0900 E/EFL     ( 1216): By the power of Grayskull, your previous Embryo stack is now broken!
02-13 14:01:05.626+0900 D/AUL_AMD (  807): amd_request.c: __request_handler(838) > __request_handler: 15
02-13 14:01:05.636+0900 D/PKGMGR_INFO(  807): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:01:05.636+0900 D/PKGMGR_INFO(  807): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:01:05.636+0900 D/AUL_AMD (  807): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 1216 is org.example.sqlite
02-13 14:01:05.636+0900 D/AUL     (  999): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
02-13 14:01:05.636+0900 D/AUL_AMD (  807): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 1216 : 0
02-13 14:01:05.696+0900 D/INDICATOR(  873): main.c: _property_changed_cb(432) > UNSNIFF API 2400002
02-13 14:01:05.696+0900 D/INDICATOR(  873): util.c: util_signal_emit_by_win(116) > emission bg.opaque
02-13 14:01:05.696+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1eaa5a0), gem(11), surface(0x1eb7ac8)
02-13 14:01:05.706+0900 D/INDICATOR(  873): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-13 14:01:05.706+0900 D/INDICATOR(  873): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-13 14:01:05.706+0900 D/INDICATOR(  873): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-13 14:01:05.706+0900 D/INDICATOR(  873): main.c: _rotate_window(252) > port :: hide more icon
02-13 14:01:05.706+0900 W/APP_CORE( 1216): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:1600002
02-13 14:01:05.706+0900 D/APP_CORE( 1216): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:1600002
02-13 14:01:05.706+0900 D/APP_CORE( 1216): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
02-13 14:01:05.706+0900 D/AUL     ( 1216): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
02-13 14:01:05.706+0900 D/AUL_AMD (  807): amd_request.c: __request_handler(838) > __request_handler: 34
02-13 14:01:05.706+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x1e46050), gem(12), surface(0x1eb5d68)
02-13 14:01:05.726+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-13 14:01:05.766+0900 D/APP_CORE( 1216): appcore.c: __prt_ltime(236) > [APP 1216] first idle after reset: 526 msec
02-13 14:01:05.776+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1e4aa40), gem(13), surface(0x1ea1e38)
02-13 14:01:05.786+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1e46050), gem(12), surface(0x1eb5980)
02-13 14:01:05.786+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1e4aa40), gem(13), surface(0x1e39cb8)
02-13 14:01:05.796+0900 E/E17     (  532): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-13 14:01:05.796+0900 D/APP_CORE( 1216): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:1600002 fully_obscured 0
02-13 14:01:05.796+0900 D/APP_CORE( 1216): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
02-13 14:01:05.796+0900 D/APP_CORE( 1216): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-13 14:01:05.796+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-13 14:01:05.796+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-13 14:01:05.796+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-13 14:01:05.796+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: PAUSE State: RUNNING
02-13 14:01:05.796+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(565) > [APP 911] PAUSE
02-13 14:01:05.796+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-13 14:01:05.796+0900 E/cluster-home(  911): homescreen.cpp: OnPause(84) >  app pause
02-13 14:01:05.796+0900 I/APP_CORE( 1216): appcore-efl.c: __do_app(496) > [APP 1216] Event: RESUME State: CREATED
02-13 14:01:05.796+0900 D/LAUNCH  ( 1216): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-13 14:01:05.796+0900 D/APP_CORE( 1216): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-13 14:01:05.796+0900 D/APP_CORE( 1216): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-13 14:01:05.796+0900 D/APP_CORE( 1216): appcore-efl.c: __do_app(607) > [APP 1216] RESUME
02-13 14:01:05.796+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-13 14:01:05.796+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(923) >  END
02-13 14:01:05.796+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-13 14:01:05.796+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-13 14:01:05.796+0900 D/AUL_AMD (  807): amd_status.c: _status_update_app_info_list(456) > pid(911) status(4)
02-13 14:01:05.796+0900 D/AUL_AMD (  807): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-13 14:01:05.796+0900 D/AUL     (  807): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-13 14:01:05.796+0900 W/AUL     (  807): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: bg
02-13 14:01:05.796+0900 D/AUL_AMD (  807): amd_launch.c: __e17_status_handler(2887) > pid(1216) status(3)
02-13 14:01:05.796+0900 D/AUL_AMD (  807): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-13 14:01:05.796+0900 W/AUL_AMD (  807): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-13 14:01:05.796+0900 W/AUL_AMD (  807): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-13 14:01:05.796+0900 D/AUL_AMD (  807): amd_status.c: _status_update_app_info_list(456) > pid(1216) status(3)
02-13 14:01:05.796+0900 D/AUL_AMD (  807): amd_status.c: _status_update_app_info_list(468) > pid(1216) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-13 14:01:05.796+0900 D/AUL     (  807): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-13 14:01:05.796+0900 W/AUL     (  807): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1216, appid: org.example.sqlite, status: fg
02-13 14:01:05.806+0900 D/RESOURCED(  867): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1216
02-13 14:01:05.806+0900 D/RESOURCED(  867): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1216, proc_name: ---, cg_name: foreground, oom_score_adj: 200
02-13 14:01:05.806+0900 D/RESOURCED(  867): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 1216
02-13 14:01:05.806+0900 D/DATA_PROVIDER_MASTER(  972): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 911 is paused
02-13 14:01:05.806+0900 D/DATA_PROVIDER_MASTER(  972): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-13 14:01:05.806+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_pause_cb(292) > widget obj was paused
02-13 14:01:05.806+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(142) > enter background group
02-13 14:01:05.806+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: bg
02-13 14:01:05.806+0900 I/APP_CORE( 1216): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
02-13 14:01:05.806+0900 I/APP_CORE( 1216): appcore-efl.c: __do_app(614) > [APP 1216] Initial Launching, call the resume_cb
02-13 14:01:05.806+0900 I/CAPI_APPFW_APPLICATION( 1216): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-13 14:01:05.806+0900 D/LAUNCH  ( 1216): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-13 14:01:05.806+0900 D/LAUNCH  ( 1216): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-13 14:01:05.806+0900 D/APP_CORE( 1216): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-13 14:01:05.806+0900 E/APP_CORE( 1216): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-13 14:01:05.896+0900 D/RESOURCED(  867): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
02-13 14:01:05.896+0900 D/RESOURCED(  867): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
02-13 14:01:05.946+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x1e34990), gem(10), surface(0x1e395f0)
02-13 14:01:05.986+0900 D/RESOURCED(  867): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
02-13 14:01:05.986+0900 D/RESOURCED(  867): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
02-13 14:01:05.996+0900 D/AUL_AMD (  807): amd_launch.c: __e17_status_handler(2906) > pid(1216) status(0)
02-13 14:01:05.996+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x1eb7c20), gem(10), surface(0x1e39438)
02-13 14:01:06.367+0900 D/AUL_PAD (  959): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
02-13 14:01:06.377+0900 D/AUL_PAD ( 1387): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
02-13 14:01:06.387+0900 D/AUL_PAD (  959): sigchild.h: __send_app_launch_signal(130) > send launch signal done
02-13 14:01:06.407+0900 E/RESOURCED(  867): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.151
02-13 14:01:06.867+0900 D/AUL_AMD (  807): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:01:06.867+0900 D/RUA     (  807): rua.c: rua_add_history(179) > rua_add_history start
02-13 14:01:06.877+0900 D/RUA     (  807): rua.c: rua_add_history(247) > rua_add_history ok
02-13 14:01:07.488+0900 D/AUL_PAD ( 1387): launchpad_loader.c: main(588) > sleeping 1 sec...
02-13 14:01:07.488+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(52) > max_cmdline_size = 1053
02-13 14:01:07.498+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b8567768
02-13 14:01:07.498+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(69) > get pre-initialization function
02-13 14:01:07.498+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(73) > get shutdown function
02-13 14:01:07.498+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b8567a48
02-13 14:01:07.508+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b85695b0
02-13 14:01:07.508+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(69) > get pre-initialization function
02-13 14:01:07.508+0900 D/AUL_PAD ( 1387): preload.h: __preload_init(73) > get shutdown function
02-13 14:01:07.508+0900 D/AUL_PAD ( 1387): preexec.h: __preexec_init(76) > preexec start
02-13 14:01:07.508+0900 D/AUL_PAD ( 1387): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
02-13 14:01:07.508+0900 D/AUL     ( 1387): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
02-13 14:01:07.508+0900 D/AUL     ( 1387): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
02-13 14:01:07.508+0900 D/AUL_PAD (  959): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 1387
02-13 14:01:07.508+0900 D/AUL     ( 1387): process_pool.c: __connect_to_launchpad(132) > send(1387) : 4
02-13 14:01:07.508+0900 D/AUL     ( 1387): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
02-13 14:01:07.758+0900 D/AUL_PAD ( 1387): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
02-13 14:01:07.788+0900 D/AUL_PAD ( 1387): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
02-13 14:01:07.788+0900 D/AUL_PAD ( 1387): launchpad_loader.c: main(693) > [candidate] ecore handler add
02-13 14:01:07.788+0900 D/AUL_PAD ( 1387): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
02-13 14:01:09.129+0900 D/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200437 
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:01:09.600+0900 D/AUL_PAD (  959): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:01:09.600+0900 I/AUL_PAD (  959): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 1216 pgid = 1216
02-13 14:01:09.600+0900 I/AUL_PAD (  959): sigchild.h: __sigchild_action(141) > dead_pid(1216)
02-13 14:01:09.610+0900 E/EFL     (  532): eo<532> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-13 14:01:09.630+0900 E/E17     (  532): e_border.c: e_border_show(2088) > BD_SHOW(0x02400002)
02-13 14:01:09.640+0900 E/E17     (  532): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600002), visible:1
02-13 14:01:09.650+0900 D/INDICATOR(  873): main.c: _property_changed_cb(432) > UNSNIFF API 1600002
02-13 14:01:09.650+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1e46050), gem(12), surface(0x1ebae00)
02-13 14:01:09.650+0900 D/INDICATOR(  873): util.c: util_signal_emit_by_win(116) > emission bg.translucent
02-13 14:01:09.680+0900 D/INDICATOR(  873): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-13 14:01:09.690+0900 D/INDICATOR(  873): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-13 14:01:09.690+0900 D/INDICATOR(  873): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-13 14:01:09.690+0900 D/INDICATOR(  873): main.c: _rotate_window(252) > port :: hide more icon
02-13 14:01:09.700+0900 D/AUL_AMD (  807): amd_launch.c: __e17_status_handler(2887) > pid(911) status(3)
02-13 14:01:09.700+0900 D/AUL_AMD (  807): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-13 14:01:09.720+0900 D/AUL_PAD (  959): sigchild.h: __send_app_dead_signal(90) > send dead signal done
02-13 14:01:09.720+0900 I/AUL_PAD (  959): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
02-13 14:01:09.720+0900 I/AUL_PAD (  959): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
02-13 14:01:09.720+0900 E/AUL_PAD (  959): launchpad.c: main(688) > error reading sigchld info
02-13 14:01:09.720+0900 I/ESD     (  986): esd_main.c: __esd_app_dead_handler(1771) > pid: 1216
02-13 14:01:09.720+0900 D/STARTER (  869): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 1216 is termianted
02-13 14:01:09.720+0900 D/STARTER (  869): starter.c: _check_dead_signal(202) > [_check_dead_signal:202] Unknown process, ignore it
02-13 14:01:09.730+0900 E/RESOURCED(  867): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.156
02-13 14:01:09.740+0900 W/AUL_AMD (  807): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-13 14:01:09.740+0900 W/AUL_AMD (  807): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-13 14:01:09.740+0900 D/AUL_AMD (  807): amd_status.c: _status_update_app_info_list(456) > pid(911) status(3)
02-13 14:01:09.740+0900 D/AUL_AMD (  807): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
02-13 14:01:09.740+0900 D/AUL     (  807): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
02-13 14:01:09.740+0900 W/AUL     (  807): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: fg
02-13 14:01:09.740+0900 W/AUL_AMD (  807): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 1216
02-13 14:01:09.740+0900 W/AUL_AMD (  807): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 1216
02-13 14:01:09.740+0900 D/AUL_AMD (  807): amd_key.c: _unregister_key_event(179) > ===key stack===
02-13 14:01:09.740+0900 E/AUL_AMD (  807): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
02-13 14:01:09.740+0900 D/AUL_AMD (  807): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.example.sqlite)
02-13 14:01:09.740+0900 D/AUL     (  807): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-13 14:01:09.740+0900 E/AUL     (  807): simple_util.c: __trm_app_info_send_socket(330) > access
02-13 14:01:09.740+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1e49c28), gem(10), surface(0x1eb5e18)
02-13 14:01:09.740+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1e49c28), gem(10), surface(0x1e6dc10)
02-13 14:01:09.740+0900 W/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=911
02-13 14:01:09.740+0900 D/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_wininfo_del(160) > [PROCESSMGR] delete anr_trigger_timer!
02-13 14:01:09.760+0900 D/RESOURCED(  867): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 911
02-13 14:01:09.760+0900 D/RESOURCED(  867): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 911, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
02-13 14:01:09.760+0900 D/RESOURCED(  867): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 911, appname = org.tizen.homescreen
02-13 14:01:09.760+0900 D/RESOURCED(  867): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 911
02-13 14:01:09.760+0900 E/RESOURCED(  867): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 911 foreground
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 0
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-13 14:01:09.760+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: RESUME State: PAUSED
02-13 14:01:09.760+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(597) > [homescreen:Application:resume:start]
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(607) > [APP 911] RESUME
02-13 14:01:09.760+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-13 14:01:09.760+0900 E/cluster-home(  911): homescreen.cpp: OnResume(66) >  app resume
02-13 14:01:09.760+0900 D/cluster-home(  911): widget-data-provider.cpp: SetBoxVisibility(1519) >  
02-13 14:01:09.760+0900 D/cluster-home(  911): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[1]
02-13 14:01:09.760+0900 D/WIDGET_VIEWER(  911): widget.c: widget_viewer_set_visibility(3865) > [SECURE_LOG] org.tizen.calendar.widget has no changes
02-13 14:01:09.760+0900 D/cluster-home(  911): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[2]
02-13 14:01:09.760+0900 D/cluster-home(  911): widget-data-provider.cpp: SetBoxVisibility(1528) >  No boxes in page[2]
02-13 14:01:09.760+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppResume(892) >  BEGIN
02-13 14:01:09.760+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppResume(910) >  END
02-13 14:01:09.760+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-13 14:01:09.760+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-13 14:01:09.760+0900 D/cluster-view(  911): homescreen-page-indicator.cpp: CancelOperation(300) >  CancelOperation
02-13 14:01:09.760+0900 D/cluster-view(  911): cluster-impl.cpp: ScrollToFitPage(466) >  ScrollToFitPage
02-13 14:01:09.760+0900 E/EFL     (  532): eo<532> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-13 14:01:09.760+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollSnapStart(613) >  TODO current page[0] new page[0]
02-13 14:01:09.760+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollSnapStart(623) >  TODO current page[0] new page[0]
02-13 14:01:09.760+0900 D/test-log(  911): cluster-impl.cpp: SetFocusedPage(791) >  Set mFocusedPage: 1
02-13 14:01:09.760+0900 D/test-log(  911): cluster-impl.cpp: GetFocusedPage(798) >  mFocusedPage: 1
02-13 14:01:09.760+0900 D/cluster-view(  911): cluster-view-controller.cpp: OnClusterChangeFocusedPage(1779) >  Cluster[0:] 1 page focused
02-13 14:01:09.760+0900 D/cluster-home(  911): widget-data-provider.cpp: OnCustomClusterFocusedPageChanged(2910) >  Cluster[0] page[1] focused
02-13 14:01:09.760+0900 D/RESOURCED(  867): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 1216
02-13 14:01:09.760+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(636) > [homescreen:Application:resume:done]
02-13 14:01:09.760+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(638) > [homescreen:Application:Launching:done]
02-13 14:01:09.760+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-13 14:01:09.760+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-13 14:01:09.770+0900 W/CRASH_MANAGER( 1392): worker.c: worker_job(1204) > 060121673716c142380366
