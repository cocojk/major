S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1657
Date: 2015-02-13 14:30:28+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x3c

Register Information
r0   = 0xb1e00720, r1   = 0x0000003c
r2   = 0x0000003c, r3   = 0xb1e00878
r4   = 0xb1e00720, r5   = 0xb60c4bb0
r6   = 0xb1e01cb8, r7   = 0x00000000
r8   = 0x00000022, r9   = 0xb7d39408
r10  = 0xb2718530, fp   = 0x00000000
ip   = 0xb6bdd678, sp   = 0xb2718480
lr   = 0xb6ae0c6d, pc   = 0xb60837fe
cpsr = 0xa0000030

Memory Information
MemTotal:   987264 KB
MemFree:    581952 KB
Buffers:     18564 KB
Cached:     128292 KB
VmPeak:     108668 KB
VmSize:     108664 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       15852 KB
VmRSS:       15852 KB
VmData:      31228 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22316 KB
VmPTE:          64 KB
VmSwap:          0 KB

Threads Information
Threads: 4
PID = 1657 TID = 1686
1657 1661 1685 1686 

Maps Information
b1f1b000 b271a000 rw-p [stack:1686]
b271b000 b2f1a000 rw-p [stack:1685]
b2f1a000 b2f1f000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2fab000 b2fb3000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b2fc4000 b2fc5000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2fd5000 b2fdc000 r-xp /usr/lib/libfeedback.so.0.1.4
b3000000 b3013000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b3027000 b302c000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b303c000 b303d000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b304d000 b3050000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b3061000 b3062000 r-xp /usr/lib/libxshmfence.so.1.0.0
b3072000 b3074000 r-xp /usr/lib/libxcb-present.so.0.0.0
b3084000 b3086000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b3096000 b309e000 r-xp /usr/lib/libdrm.so.2.4.0
b30ae000 b30b0000 r-xp /usr/lib/libdri2.so.0.0.0
b30c0000 b30c8000 r-xp /usr/lib/libtbm.so.1.0.0
b30d8000 b30d9000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b30eb000 b30ec000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b30fc000 b3108000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b3119000 b3120000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3132000 b3142000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b324a000 b324e000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b325f000 b333f000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3356000 b3358000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b3361000 b3388000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b339b000 b3b9a000 rw-p [stack:1661]
b3b9a000 b3b9c000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dac000 b3db5000 r-xp /lib/libnss_files-2.20-2014.11.so
b3dc6000 b3dcf000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3de0000 b3df1000 r-xp /lib/libnsl-2.20-2014.11.so
b3e04000 b3e0a000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e1b000 b3e35000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e46000 b3e47000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e57000 b3e59000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e6a000 b3e6f000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e7f000 b3e82000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e93000 b3e9a000 r-xp /usr/lib/libsensord-share.so
b3eaa000 b3ebb000 r-xp /usr/lib/libsensor.so.1.2.0
b3ecc000 b3ed2000 r-xp /usr/lib/libappcore-common.so.1.1
b3ef5000 b3efa000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f10000 b3f12000 r-xp /usr/lib/libXau.so.6.0.0
b3f22000 b3f36000 r-xp /usr/lib/libxcb.so.1.1.0
b3f46000 b3f4d000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f85000 b3f87000 r-xp /usr/lib/libiri.so
b3f98000 b3fad000 r-xp /lib/libexpat.so.1.5.2
b3fbf000 b400d000 r-xp /usr/lib/libssl.so.1.0.0
b4022000 b402b000 r-xp /usr/lib/libethumb.so.1.13.0
b403c000 b403f000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b404f000 b4206000 r-xp /usr/lib/libcrypto.so.1.0.0
b579d000 b57a6000 r-xp /usr/lib/libXi.so.6.1.0
b57b7000 b57b9000 r-xp /usr/lib/libXgesture.so.7.0.0
b57c9000 b57cd000 r-xp /usr/lib/libXtst.so.6.1.0
b57dd000 b57e3000 r-xp /usr/lib/libXrender.so.1.3.0
b57f3000 b57f9000 r-xp /usr/lib/libXrandr.so.2.2.0
b5809000 b580b000 r-xp /usr/lib/libXinerama.so.1.0.0
b581b000 b581e000 r-xp /usr/lib/libXfixes.so.3.1.0
b582f000 b583a000 r-xp /usr/lib/libXext.so.6.4.0
b584a000 b584c000 r-xp /usr/lib/libXdamage.so.1.1.0
b585c000 b585e000 r-xp /usr/lib/libXcomposite.so.1.0.0
b586e000 b5951000 r-xp /usr/lib/libX11.so.6.3.0
b5964000 b596b000 r-xp /usr/lib/libXcursor.so.1.0.2
b597c000 b5994000 r-xp /usr/lib/libudev.so.1.6.0
b5996000 b5999000 r-xp /lib/libattr.so.1.1.0
b59a9000 b59c9000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59ca000 b59cf000 r-xp /usr/lib/libffi.so.6.0.2
b59df000 b59f7000 r-xp /lib/libz.so.1.2.8
b5a07000 b5a09000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a19000 b5aee000 r-xp /usr/lib/libxml2.so.2.9.2
b5b03000 b5b9e000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bba000 b5bbd000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bcd000 b5be7000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bf7000 b5c08000 r-xp /lib/libresolv-2.20-2014.11.so
b5c1c000 b5c33000 r-xp /usr/lib/liblzma.so.5.0.3
b5c43000 b5c45000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c55000 b5c5c000 r-xp /usr/lib/libembryo.so.1.13.0
b5c6c000 b5c84000 r-xp /usr/lib/libpng12.so.0.50.0
b5c95000 b5cb8000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cd8000 b5cde000 r-xp /lib/librt-2.20-2014.11.so
b5cef000 b5d03000 r-xp /usr/lib/libector.so.1.13.0
b5d14000 b5d2c000 r-xp /usr/lib/liblua-5.1.so
b5d3d000 b5d94000 r-xp /usr/lib/libfreetype.so.6.11.3
b5da8000 b5dd0000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5de1000 b5df4000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e05000 b5e3f000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e50000 b5ebb000 r-xp /lib/libm-2.20-2014.11.so
b5ecc000 b5ed9000 r-xp /usr/lib/libeio.so.1.13.0
b5ee9000 b5eeb000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5efb000 b5f00000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f10000 b5f27000 r-xp /usr/lib/libefreet.so.1.13.0
b5f39000 b5f59000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f69000 b5f89000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f8b000 b5f91000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fa1000 b5fa8000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fb8000 b5fc6000 r-xp /usr/lib/libeo.so.1.13.0
b5fd6000 b5fe8000 r-xp /usr/lib/libecore_input.so.1.13.0
b5ff9000 b5ffe000 r-xp /usr/lib/libecore_file.so.1.13.0
b600e000 b6026000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6037000 b6054000 r-xp /usr/lib/libeet.so.1.13.0
b606d000 b60b5000 r-xp /usr/lib/libeina.so.1.13.0
b60c6000 b60d6000 r-xp /usr/lib/libefl.so.1.13.0
b60e7000 b61cc000 r-xp /usr/lib/libicuuc.so.51.1
b61e9000 b6329000 r-xp /usr/lib/libicui18n.so.51.1
b6340000 b6378000 r-xp /usr/lib/libecore_x.so.1.13.0
b638a000 b638d000 r-xp /lib/libcap.so.2.21
b639d000 b63c6000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63d7000 b63de000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63f0000 b6426000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6437000 b651f000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6533000 b65a9000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65bb000 b65be000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65ce000 b65d9000 r-xp /usr/lib/libvconf.so.0.2.45
b65e9000 b65eb000 r-xp /usr/lib/libvasum.so.0.3.1
b65fb000 b65fd000 r-xp /usr/lib/libttrace.so.1.1
b660d000 b6610000 r-xp /usr/lib/libiniparser.so.0
b6620000 b6643000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6653000 b6658000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6669000 b6680000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6691000 b669e000 r-xp /usr/lib/libunwind.so.8.0.1
b66d4000 b67f8000 r-xp /lib/libc-2.20-2014.11.so
b680d000 b6826000 r-xp /lib/libgcc_s-4.9.so.1
b6836000 b6918000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6929000 b695d000 r-xp /usr/lib/libdbus-1.so.3.8.11
b696d000 b69a7000 r-xp /usr/lib/libsystemd.so.0.4.0
b69a9000 b6a29000 r-xp /usr/lib/libedje.so.1.13.0
b6a2c000 b6a4a000 r-xp /usr/lib/libecore.so.1.13.0
b6a6a000 b6bcc000 r-xp /usr/lib/libevas.so.1.13.0
b6c03000 b6c17000 r-xp /lib/libpthread-2.20-2014.11.so
b6c2b000 b6e4f000 r-xp /usr/lib/libelementary.so.1.13.0
b6e7d000 b6e81000 r-xp /usr/lib/libsmack.so.1.0.0
b6e91000 b6e97000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ea8000 b6eaa000 r-xp /usr/lib/libdlog.so.0.0.0
b6eba000 b6ebd000 r-xp /usr/lib/libbundle.so.0.1.22
b6ecd000 b6ecf000 r-xp /lib/libdl-2.20-2014.11.so
b6ee0000 b6ef9000 r-xp /usr/lib/libaul.so.0.1.0
b6f0b000 b6f0d000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f1e000 b6f22000 r-xp /usr/lib/libsys-assert.so
b6f33000 b6f53000 r-xp /lib/ld-2.20-2014.11.so
b6f64000 b6f6a000 r-xp /usr/bin/launchpad-loader
b7b60000 b7d87000 rw-p [heap]
be847000 be868000 rw-p [stack]
b6eba000 b6ebd000 r-xp /usr/lib/libbundle.so.0.1.22
b6ecd000 b6ecf000 r-xp /lib/libdl-2.20-2014.11.so
b6ee0000 b6ef9000 r-xp /usr/lib/libaul.so.0.1.0
b6f0b000 b6f0d000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f1e000 b6f22000 r-xp /usr/lib/libsys-assert.so
b6f33000 b6f53000 r-xp /lib/ld-2.20-2014.11.so
b6f64000 b6f6a000 r-xp /usr/bin/launchpad-loader
b7b60000 b7d87000 rw-p [heap]
be847000 be868000 rw-p [stack]
b7b60000 b7d87000 rw-p [heap]
be847000 be868000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1657)
Call Stack Count: 15
 0: eina_inlist_prepend_relative + 0x21 (0xb60837fe) [/usr/lib/libeina.so.1] + 0x167fe
 1: (0xb6ae0c6d) [/usr/lib/libevas.so.1] + 0x76c6d
 2: (0xb6aea177) [/usr/lib/libevas.so.1] + 0x80177
 3: (0xb6aeab27) [/usr/lib/libevas.so.1] + 0x80b27
 4: evas_textblock_cursor_geometry_bidi_get + 0xd2 (0xb6aed24b) [/usr/lib/libevas.so.1] + 0x8324b
 5: (0xb69f40fd) [/usr/lib/libedje.so.1] + 0x4b0fd
 6: (0xb6a114cb) [/usr/lib/libedje.so.1] + 0x684cb
 7: (0xb6a13fe5) [/usr/lib/libedje.so.1] + 0x6afe5
 8: edje_obj_part_text_append + 0x62 (0xb6a05327) [/usr/lib/libedje.so.1] + 0x5c327
 9: edje_object_part_text_append + 0x2a (0xb6a0cde3) [/usr/lib/libedje.so.1] + 0x63de3
10: elm_obj_entry_append + 0x5c (0xb6cfa081) [/usr/lib/libelementary.so.1] + 0xcf081
11: elm_entry_entry_append + 0x26 (0xb6d04ecb) [/usr/lib/libelementary.so.1] + 0xd9ecb
12: _add_entry_text + 0x36 (0xb33572ab) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x12ab
13: thread_run_1 + 0x56 (0xb3357aab) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x1aab
14: (0xb6c08cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
old icon path[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png], New icon path[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png]!!!!!
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: UpdateBoxData(853) >  Query [UPDATE boxes set isFolder = 0, pageId = 1, appId = $appId, name = $name, col = 1, row = 4, isPreload = 0, isSystem = 0 WHERE boxId = 40]
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: __ri_privilege_perm_end(55) > [smack] perm_end, result=[0]
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-appcore-intf.c: main(259) > ------------------------------------------------
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-appcore-intf.c: main(260) >  [END] rpm-installer: result=[0]
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-appcore-intf.c: main(261) > ------------------------------------------------
02-13 14:30:05.902+0900 D/PKGMGR_SERVER( 1593): pkgmgr-server.c: sighandler(387) > child exit [1596]
02-13 14:30:05.902+0900 E/PKGMGR_SERVER( 1593): pkgmgr-server.c: sighandler(402) > child NORMAL exit [1596]
02-13 14:30:06.823+0900 E/PKGMGR_SERVER( 1593): pkgmgr-server.c: exit_server(1240) > exit_server Start [backend_status=1, queue_status=1, drm_status=1] 
02-13 14:30:06.823+0900 E/PKGMGR_SERVER( 1593): pkgmgr-server.c: main(2265) > package manager server terminated.
02-13 14:30:07.263+0900 D/AUL     ( 1649): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-13 14:30:07.263+0900 D/AUL     ( 1649): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-13 14:30:07.273+0900 D/AUL_AMD (  699): amd_request.c: __request_handler(838) > __request_handler: 0
02-13 14:30:07.273+0900 D/AUL_AMD (  699): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.273+0900 I/AUL     (  699): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/launch_app, ret : 0
02-13 14:30:07.273+0900 D/AUL     (  699): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 1647, pid = 1649
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.283+0900 I/AUL     (  699): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /bin/bash, ret : 0
02-13 14:30:07.283+0900 E/AUL_AMD (  699): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-13 14:30:07.283+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2232) > caller pid : 1649
02-13 14:30:07.283+0900 E/AUL_AMD (  699): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-13 14:30:07.283+0900 W/AUL_AMD (  699): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2646) > process_pool: false
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-13 14:30:07.283+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2663) > pad pid(-5)
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-13 14:30:07.283+0900 D/AUL     (  699): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-13 14:30:07.293+0900 D/AUL_PAD (  870): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-13 14:30:07.293+0900 W/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-13 14:30:07.293+0900 D/AUL     (  870): process_pool.c: __send_pkt_raw_data(219) > send(13) : 616 / 616
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1453, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:07.293+0900 W/AUL_PAD (  870): launchpad.c: __send_result_to_caller(265) > Check app launching
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-13 14:30:07.293+0900 D/AUL     ( 1453): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1454) is sent.
02-13 14:30:07.293+0900 D/AUL     ( 1453): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1454, signo: 10
02-13 14:30:07.293+0900 D/AUL     ( 1453): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM4MDU0MDcvMjc3NDg5AA==##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAxNjQ5AA==##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-13 14:30:07.303+0900 D/RESOURCED(  773): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-13 14:30:07.303+0900 D/RESOURCED(  773): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 3
02-13 14:30:07.303+0900 E/RESOURCED(  773): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-13 14:30:07.303+0900 I/CAPI_APPFW_APPLICATION( 1453): app_main.c: ui_app_main(788) > app_efl_main
02-13 14:30:07.303+0900 D/LAUNCH  ( 1453): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-13 14:30:07.303+0900 D/APP_CORE( 1453): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-13 14:30:07.303+0900 D/APP_CORE( 1453): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-13 14:30:07.303+0900 D/APP_CORE( 1453): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-13 14:30:07.323+0900 D/APP_CORE( 1453): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-13 14:30:07.323+0900 D/AUL     ( 1453): app_sock.c: __create_server_sock(156) > pg path - already exists
02-13 14:30:07.323+0900 D/APP_CORE( 1453): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3f02dd0
02-13 14:30:07.323+0900 D/LAUNCH  ( 1453): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-13 14:30:07.323+0900 I/CAPI_APPFW_APPLICATION( 1453): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-13 14:30:07.393+0900 D/AUL_PAD (  870): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-13 14:30:07.393+0900 W/AUL     (  699): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 1453, appid: org.example.sqlite
02-13 14:30:07.393+0900 D/AUL     (  699): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-13 14:30:07.393+0900 E/AUL     (  699): simple_util.c: __trm_app_info_send_socket(330) > access
02-13 14:30:07.393+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2698) > add app group info
02-13 14:30:07.393+0900 E/AUL     (  699): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-13 14:30:07.393+0900 D/AUL_AMD (  699): amd_status.c: _status_add_app_info_list(427) > pid(1453) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-13 14:30:07.393+0900 D/AUL     ( 1649): launch.c: app_request_to_launchpad(425) > launch request result : 1453
02-13 14:30:07.393+0900 D/RESOURCED(  773): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 1453
02-13 14:30:07.393+0900 D/RESOURCED(  773): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-13 14:30:07.524+0900 E/EFL     ( 1453): ecore<1453> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:07.524+0900 E/EFL     ( 1453): ecore<1453> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:07.534+0900 E/EFL     ( 1453): ecore<1453> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:07.594+0900 W/CRASH_MANAGER( 1457): worker.c: worker_job(1204) > 110145373716c1423805407
02-13 14:30:08.394+0900 D/AUL_AMD (  699): amd_launch.c: __grab_timeout_handler(1444) > pid(1453) ecore_x_pointer_ungrab
02-13 14:30:08.394+0900 D/AUL_AMD (  699): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-13 14:30:08.394+0900 W/AUL_AMD (  699): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-13 14:30:08.394+0900 W/AUL_AMD (  699): amd_launch.c: __grab_timeout_handler(1446) > back key ungrab error
02-13 14:30:08.394+0900 D/AUL_PAD (  870): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
02-13 14:30:08.394+0900 D/AUL_PAD ( 1657): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
02-13 14:30:08.414+0900 D/AUL_PAD (  870): sigchild.h: __send_app_launch_signal(130) > send launch signal done
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:30:08.414+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:30:08.414+0900 I/AUL_PAD (  870): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 1453 pgid = 1453
02-13 14:30:08.414+0900 I/AUL_PAD (  870): sigchild.h: __sigchild_action(141) > dead_pid(1453)
02-13 14:30:08.424+0900 E/RESOURCED(  773): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.270
02-13 14:30:08.454+0900 D/AUL_PAD (  870): sigchild.h: __send_app_dead_signal(90) > send dead signal done
02-13 14:30:08.454+0900 I/AUL_PAD (  870): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
02-13 14:30:08.454+0900 I/AUL_PAD (  870): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
02-13 14:30:08.454+0900 E/AUL_PAD (  870): launchpad.c: main(688) > error reading sigchld info
02-13 14:30:08.454+0900 I/ESD     (  903): esd_main.c: __esd_app_dead_handler(1771) > pid: 1453
02-13 14:30:08.454+0900 D/STARTER (  776): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 1453 is termianted
02-13 14:30:08.454+0900 D/STARTER (  776): starter.c: _check_dead_signal(202) > [_check_dead_signal:202] Unknown process, ignore it
02-13 14:30:08.454+0900 W/AUL_AMD (  699): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 1453
02-13 14:30:08.454+0900 W/AUL_AMD (  699): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 1453
02-13 14:30:08.454+0900 D/AUL_AMD (  699): amd_key.c: _unregister_key_event(179) > ===key stack===
02-13 14:30:08.454+0900 E/AUL_AMD (  699): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
02-13 14:30:08.454+0900 D/AUL_AMD (  699): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.example.sqlite)
02-13 14:30:08.454+0900 D/AUL     (  699): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-13 14:30:08.454+0900 E/AUL     (  699): simple_util.c: __trm_app_info_send_socket(330) > access
02-13 14:30:08.464+0900 E/RESOURCED(  773): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.271
02-13 14:30:08.464+0900 D/RESOURCED(  773): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 1453
02-13 14:30:08.895+0900 D/AUL_AMD (  699): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:08.895+0900 D/RUA     (  699): rua.c: rua_add_history(179) > rua_add_history start
02-13 14:30:08.905+0900 D/RUA     (  699): rua.c: rua_add_history(247) > rua_add_history ok
02-13 14:30:09.095+0900 E/VCONF   ( 1457): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: vconf_get_str(2887) > vconf_get_str(1457) : db/menu_widget/language error
02-13 14:30:09.105+0900 E/PKGMGR_INFO( 1457): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-13 14:30:09.105+0900 D/PKGMGR_INFO( 1457): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_count(3502) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:30:09.105+0900 D/PKGMGR_INFO( 1457): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_count(3508) > [SECURE_LOG] query = select DISTINCT package_app_info.app_id, package_app_info.app_component, package_app_info.app_installed_storage from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale='No Locale' LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-13 14:30:09.105+0900 E/VCONF   ( 1457): vconf.c: vconf_get_str(2887) > vconf_get_str(1457) : db/menu_widget/language error
02-13 14:30:09.105+0900 E/PKGMGR_INFO( 1457): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-13 14:30:09.105+0900 D/PKGMGR_INFO( 1457): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:30:09.105+0900 D/PKGMGR_INFO( 1457): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'No Locale') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:30:09.115+0900 E/VCONF   ( 1457): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-13 14:30:09.115+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-13 14:30:09.115+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-13 14:30:09.115+0900 E/VCONF   ( 1457): vconf.c: vconf_get_str(2887) > vconf_get_str(1457) : db/menu_widget/language error
02-13 14:30:09.115+0900 E/PKGMGR_INFO( 1457): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-13 14:30:09.115+0900 D/PKGMGR_INFO( 1457): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:30:09.115+0900 D/PKGMGR_INFO( 1457): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'No Locale') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-13 14:30:09.125+0900 E/VCONF   ( 1457): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
02-13 14:30:09.125+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
02-13 14:30:09.125+0900 E/VCONF   ( 1457): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
02-13 14:30:09.125+0900 E/VCONF   ( 1457): vconf.c: vconf_get_str(2887) > vconf_get_str(1457) : db/menu_widget/language error
02-13 14:30:09.125+0900 E/PKGMGR_INFO( 1457): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
02-13 14:30:09.495+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(588) > sleeping 1 sec...
02-13 14:30:09.495+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(52) > max_cmdline_size = 1053
02-13 14:30:09.506+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b7b66768
02-13 14:30:09.506+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(69) > get pre-initialization function
02-13 14:30:09.506+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(73) > get shutdown function
02-13 14:30:09.506+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b7b66a48
02-13 14:30:09.516+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b7b685b0
02-13 14:30:09.516+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(69) > get pre-initialization function
02-13 14:30:09.516+0900 D/AUL_PAD ( 1657): preload.h: __preload_init(73) > get shutdown function
02-13 14:30:09.516+0900 D/AUL_PAD ( 1657): preexec.h: __preexec_init(76) > preexec start
02-13 14:30:09.516+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
02-13 14:30:09.516+0900 D/AUL     ( 1657): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
02-13 14:30:09.516+0900 D/AUL     ( 1657): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
02-13 14:30:09.516+0900 D/AUL     ( 1657): process_pool.c: __connect_to_launchpad(132) > send(1657) : 4
02-13 14:30:09.516+0900 D/AUL     ( 1657): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
02-13 14:30:09.516+0900 D/AUL_PAD (  870): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 1657
02-13 14:30:09.726+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
02-13 14:30:09.746+0900 E/RESOURCED(  773): heart-abnormal.c: heart_abnormal_process_crashed(77) > Failed: dbus_message_get_args()
02-13 14:30:09.756+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
02-13 14:30:09.756+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(693) > [candidate] ecore handler add
02-13 14:30:09.756+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
02-13 14:30:10.316+0900 D/eventsystem(  676): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-13 14:30:10.316+0900 D/eventsystem(  676): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-13 14:30:10.316+0900 D/eventsystem(  676): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-13 14:30:10.316+0900 D/eventsystem(  676): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-13 14:30:10.316+0900 D/eventsystem(  676): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-13 14:30:10.316+0900 D/DATA_PROVIDER_MASTER(  885): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-13 14:30:10.316+0900 E/DATA_PROVIDER_MASTER(  885): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 2, (3:lcdoff, 4:sleep)
02-13 14:30:10.336+0900 D/INDICATOR(  791): main.c: _indicator_notify_pm_state_cb(177) > LCD is dimmed
02-13 14:30:11.608+0900 D/eventsystem(  676): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-13 14:30:11.608+0900 D/eventsystem(  676): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-13 14:30:11.608+0900 D/eventsystem(  676): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-13 14:30:11.608+0900 D/eventsystem(  676): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-13 14:30:11.608+0900 D/eventsystem(  676): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-13 14:30:11.618+0900 D/DATA_PROVIDER_MASTER(  885): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-13 14:30:11.618+0900 E/DATA_PROVIDER_MASTER(  885): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-13 14:30:11.618+0900 D/INDICATOR(  791): main.c: _indicator_notify_pm_state_cb(169) > LCD is on
02-13 14:30:11.688+0900 D/cluster-view(  826): mainmenu-apps-view-impl.cpp: _OnScrollStart(1488) >  on appsview scroll started[1] xPos[-0] 
02-13 14:30:11.778+0900 D/test-log(  826): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-13 14:30:11.778+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200033  register trigger_timer!  pointed_win=0x200080 
02-13 14:30:12.018+0900 D/test-log(  826): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1505) >  Horizontal Apps scrollview is stopped normally.
02-13 14:30:12.018+0900 D/test-log(  826): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1508) >  mMenuScrollView.GetCurrentPage(0)
02-13 14:30:12.018+0900 D/test-log(  826): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1510) >  on appsview scroll completed[1] xPos[-0]
02-13 14:30:12.018+0900 D/cluster-view(  826): mainmenu-apps-view-impl.cpp: SetAppsViewFocusedPage(834) >  page [1]
02-13 14:30:12.018+0900 D/test-log(  826): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1114) >  page change updated, get new page map
02-13 14:30:12.018+0900 D/test-log(  826): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1115) >  focused page!!!!!!!!!!!!!![1]
02-13 14:30:12.018+0900 D/cluster-view(  826): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1155) >  Current View state[1]
02-13 14:30:12.018+0900 D/cluster-view(  826): cluster-home-accessibility.cpp: SetCurrentGroup(62) >  Focus Group changed [12]->[12] Block[0]
02-13 14:30:12.018+0900 D/cluster-view(  826): mainmenu-view-manager-impl.cpp: _UpdateScreenReader(2054) >  [TTS] For Home update type[1], group[12]
02-13 14:30:12.018+0900 D/cluster-view(  826): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-13 14:30:12.018+0900 D/cluster-view(  826): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-13 14:30:12.018+0900 D/cluster-view(  826): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-13 14:30:12.018+0900 D/cluster-view(  826): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-13 14:30:12.018+0900 D/cluster-view(  826): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[60010]
02-13 14:30:12.018+0900 D/cluster-view(  826): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[60010]
02-13 14:30:12.018+0900 W/cluster-view(  826): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1550) >  booster timer is still running on apps-view, Stop boost timer!!!
02-13 14:30:12.398+0900 D/AUL_AMD (  699): amd_status.c: _status_update_app_info_list(456) > pid(1453) status(4)
02-13 14:30:12.769+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x2200002
02-13 14:30:17.774+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200080 bd->visible=1
02-13 14:30:28.374+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1023) >  menu box Pick touched
02-13 14:30:28.374+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1034) >  Long Tap Timer Start
02-13 14:30:28.444+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1194) >  Box[0] pick ended by Up
02-13 14:30:28.444+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1199) >  Cancel Long Tap Timer
02-13 14:30:28.444+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1240) >  app launch state[1]
02-13 14:30:28.444+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1249) >  touch is moved upper position!!!
02-13 14:30:28.444+0900 D/test-log(  826): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1298) >  laundch!!!!! touch position is moved from[600.00][599.00] to[600.00][599.00]!
02-13 14:30:28.444+0900 D/cluster-view(  826): homescreen-view-manager.cpp: IsOverScrollThreshold(997) >  is Over Scrollview TreshHold?[0]
02-13 14:30:28.454+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200033  register trigger_timer!  pointed_win=0x200080 
02-13 14:30:28.454+0900 D/cluster-home(  826): mainmenu-custom-box-impl.cpp: OnClicked(171) >  [40]MenuBox clicked
02-13 14:30:28.454+0900 D/cluster-home(  826): mainmenu-custom-box-impl.cpp: OnClicked(184) >  launch application via service(operation APP_CONTROL_OPERATION_DEFAULT)
02-13 14:30:28.454+0900 D/AUL     (  826): service.c: __set_bundle(186) > __set_bundle
02-13 14:30:28.454+0900 D/AUL     (  826): service.c: __get_alias_appid(548) > [SECURE_LOG] alias_id : (null)
02-13 14:30:28.454+0900 D/AUL     (  826): service.c: __set_bundle(186) > __set_bundle
02-13 14:30:28.454+0900 D/AUL     (  826): service.c: __run_svc_with_pkgname(276) > [SECURE_LOG] pkg_name : org.example.sqlite - no result
02-13 14:30:28.454+0900 D/AUL     (  826): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-13 14:30:28.454+0900 D/AUL     (  826): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-13 14:30:28.464+0900 D/AUL_AMD (  699): amd_request.c: __request_handler(838) > __request_handler: 0
02-13 14:30:28.464+0900 D/AUL_AMD (  699): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-13 14:30:28.464+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2230) > [SECURE_LOG] caller appid : org.tizen.homescreen
02-13 14:30:28.464+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2232) > caller pid : 826
02-13 14:30:28.464+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2442) > win(a00002) ecore_x_pointer_grab(1)
02-13 14:30:28.464+0900 D/AUL_AMD (  699): amd_key.c: _key_grab(243) > _key_grab, win : a00002
02-13 14:30:28.464+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2447) > back key grab
02-13 14:30:28.464+0900 W/AUL_AMD (  699): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-13 14:30:28.474+0900 D/RESOURCED(  773): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-13 14:30:28.474+0900 D/RESOURCED(  773): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 4
02-13 14:30:28.474+0900 E/RESOURCED(  773): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-13 14:30:28.474+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2516) > org.tizen.system.deviced.PmQos-AppLaunch : 0
02-13 14:30:28.474+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2646) > process_pool: false
02-13 14:30:28.474+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-13 14:30:28.474+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-13 14:30:28.474+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2663) > pad pid(-5)
02-13 14:30:28.474+0900 D/AUL_AMD (  699): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-13 14:30:28.474+0900 D/AUL_AMD (  699): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-13 14:30:28.474+0900 D/AUL     (  699): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:30:28.474+0900 D/AUL_PAD (  870): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-13 14:30:28.484+0900 D/AUL_PAD (  870): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-13 14:30:28.484+0900 W/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-13 14:30:28.484+0900 D/AUL     (  870): process_pool.c: __send_pkt_raw_data(219) > send(13) : 876 / 876
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1657, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:28.484+0900 W/AUL_PAD (  870): launchpad.c: __send_result_to_caller(265) > Check app launching
02-13 14:30:28.484+0900 D/AUL_PAD (  870): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 876, pkt->len: 868
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-13 14:30:28.484+0900 D/AUL     ( 1657): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1661) is sent.
02-13 14:30:28.484+0900 D/AUL     ( 1657): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1661, signo: 10
02-13 14:30:28.484+0900 D/AUL     ( 1657): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __APP_SVC_OP_TYPE__##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : UgAAAAEEAAAUAAAAX19BUFBfU1ZDX09QX1RZUEVfXwAuAAAAaHR0cDovL3RpemVuLm9yZy9hcHBjb250cm9sL29wZXJhdGlvbi9kZWZhdWx0AA==##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __APP_SVC_PKG_NAME__##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : OAAAAAEEAAAVAAAAX19BUFBfU1ZDX1BLR19OQU1FX18AEwAAAG9yZy5leGFtcGxlLnNxbGl0ZQA=##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_STARTTIME__##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM4MDU0MjgvNDY4MDcxAA==##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 8 : __AUL_CALLER_PID__##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 9 : JwAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAQAAAA4MjYA##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 10 : __AUL_CALLER_APPID__##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 11 : OgAAAAEEAAAVAAAAX19BVUxfQ0FMTEVSX0FQUElEX18AFQAAAG9yZy50aXplbi5ob21lc2NyZWVuAA==##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 12 : __AUL_INTERNAL_POOL__##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 13 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 14
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-13 14:30:28.484+0900 D/AUL_PAD ( 1657): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-13 14:30:28.494+0900 I/CAPI_APPFW_APPLICATION( 1657): app_main.c: ui_app_main(788) > app_efl_main
02-13 14:30:28.494+0900 D/LAUNCH  ( 1657): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-13 14:30:28.494+0900 D/APP_CORE( 1657): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-13 14:30:28.494+0900 D/APP_CORE( 1657): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-13 14:30:28.494+0900 D/APP_CORE( 1657): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-13 14:30:28.514+0900 D/APP_CORE( 1657): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-13 14:30:28.514+0900 D/AUL     ( 1657): app_sock.c: __create_server_sock(156) > pg path - already exists
02-13 14:30:28.514+0900 D/APP_CORE( 1657): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3ee1dd0
02-13 14:30:28.514+0900 D/LAUNCH  ( 1657): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-13 14:30:28.514+0900 I/CAPI_APPFW_APPLICATION( 1657): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-13 14:30:28.584+0900 D/AUL_PAD (  870): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-13 14:30:28.584+0900 W/AUL     (  699): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 1657, appid: org.example.sqlite
02-13 14:30:28.584+0900 D/AUL     (  699): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-13 14:30:28.584+0900 E/AUL     (  699): simple_util.c: __trm_app_info_send_socket(330) > access
02-13 14:30:28.584+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2698) > add app group info
02-13 14:30:28.584+0900 E/AUL     (  699): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-13 14:30:28.584+0900 D/AUL_AMD (  699): amd_status.c: _status_add_app_info_list(427) > pid(1657) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-13 14:30:28.584+0900 D/AUL     (  826): launch.c: app_request_to_launchpad(425) > launch request result : 1657
02-13 14:30:28.584+0900 E/cluster-home(  826): mainmenu-custom-box-impl.cpp: OnClicked(202) >  Success to launch [0][org.example.sqlite]
02-13 14:30:28.584+0900 D/test-log(  826): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-13 14:30:28.584+0900 D/RESOURCED(  773): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 1657
02-13 14:30:28.584+0900 D/RESOURCED(  773): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-13 14:30:28.724+0900 E/EFL     ( 1657): ecore<1657> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:28.724+0900 E/EFL     ( 1657): ecore<1657> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:28.724+0900 E/EFL     ( 1657): ecore<1657> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:28.724+0900 E/EFL     ( 1657): ecore<1657> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:28.724+0900 E/EFL     ( 1657): <1657> lib/ecore/ecore_events.c:227 ecore_event_del() safety check failed: event->delete_me is true
02-13 14:30:28.724+0900 E/EFL     ( 1657): ecore<1657> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:28.724+0900 E/EFL     ( 1657): ecore<1657> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:28.794+0900 W/CRASH_MANAGER( 1457): worker.c: worker_job(1204) > 110165773716c142380542
