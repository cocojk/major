S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1939
Date: 2015-02-12 13:16:09+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0xb33abeff

Register Information
r0   = 0xb33ae000, r1   = 0x00000000
r2   = 0xffffdeff, r3   = 0xb33af30c
r4   = 0x00000000, r5   = 0xb33ae000
r6   = 0x00000015, r7   = 0x00000049
r8   = 0xb33ae000, r9   = 0xb33af324
r10  = 0xb89fdb40, fp   = 0xbe84a14c
ip   = 0xb33abeff, sp   = 0xbe84a090
lr   = 0xb6f96458, pc   = 0xb6f98c7c
cpsr = 0x600d0010

Memory Information
MemTotal:   987264 KB
MemFree:    568624 KB
Buffers:     16520 KB
Cached:     132960 KB
VmPeak:      66412 KB
VmSize:      66408 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       11108 KB
VmRSS:       11108 KB
VmData:      11540 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       21916 KB
VmPTE:          46 KB
VmSwap:          0 KB

Threads Information
Threads: 2
PID = 1939 TID = 1939
1939 1943 

Maps Information
b3172000 b3179000 r-xp /usr/lib/libefl-extension.so.0.1.0
b32a3000 b32a7000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32b8000 b3398000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33ae000 b33b2000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b33ba000 b33e1000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33f4000 b3bf3000 rw-p [stack:1943]
b3bf3000 b3bf5000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3e05000 b3e0e000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e1f000 b3e28000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e39000 b3e4a000 r-xp /lib/libnsl-2.20-2014.11.so
b3e5d000 b3e63000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e74000 b3e8e000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e9f000 b3ea0000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3eb0000 b3eb2000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ec3000 b3ec8000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ed8000 b3edb000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3eec000 b3ef3000 r-xp /usr/lib/libsensord-share.so
b3f03000 b3f14000 r-xp /usr/lib/libsensor.so.1.2.0
b3f25000 b3f2b000 r-xp /usr/lib/libappcore-common.so.1.1
b3f4e000 b3f53000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f6a000 b3f6c000 r-xp /usr/lib/libXau.so.6.0.0
b3f7c000 b3f90000 r-xp /usr/lib/libxcb.so.1.1.0
b3fa0000 b3fa7000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fdf000 b3fe1000 r-xp /usr/lib/libiri.so
b3ff2000 b4007000 r-xp /lib/libexpat.so.1.5.2
b4019000 b4067000 r-xp /usr/lib/libssl.so.1.0.0
b407c000 b4085000 r-xp /usr/lib/libethumb.so.1.13.0
b4096000 b4099000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40a9000 b4260000 r-xp /usr/lib/libcrypto.so.1.0.0
b57f7000 b5800000 r-xp /usr/lib/libXi.so.6.1.0
b5811000 b5813000 r-xp /usr/lib/libXgesture.so.7.0.0
b5823000 b5827000 r-xp /usr/lib/libXtst.so.6.1.0
b5837000 b583d000 r-xp /usr/lib/libXrender.so.1.3.0
b584d000 b5853000 r-xp /usr/lib/libXrandr.so.2.2.0
b5863000 b5865000 r-xp /usr/lib/libXinerama.so.1.0.0
b5875000 b5878000 r-xp /usr/lib/libXfixes.so.3.1.0
b5889000 b5894000 r-xp /usr/lib/libXext.so.6.4.0
b58a4000 b58a6000 r-xp /usr/lib/libXdamage.so.1.1.0
b58b6000 b58b8000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58c8000 b59ab000 r-xp /usr/lib/libX11.so.6.3.0
b59be000 b59c5000 r-xp /usr/lib/libXcursor.so.1.0.2
b59d6000 b59ee000 r-xp /usr/lib/libudev.so.1.6.0
b59f0000 b59f3000 r-xp /lib/libattr.so.1.1.0
b5a03000 b5a23000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a24000 b5a29000 r-xp /usr/lib/libffi.so.6.0.2
b5a39000 b5a51000 r-xp /lib/libz.so.1.2.8
b5a61000 b5a63000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a73000 b5b48000 r-xp /usr/lib/libxml2.so.2.9.2
b5b5d000 b5bf8000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c14000 b5c17000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c27000 b5c41000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c51000 b5c62000 r-xp /lib/libresolv-2.20-2014.11.so
b5c76000 b5c8d000 r-xp /usr/lib/liblzma.so.5.0.3
b5c9d000 b5c9f000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5caf000 b5cb6000 r-xp /usr/lib/libembryo.so.1.13.0
b5cc6000 b5cde000 r-xp /usr/lib/libpng12.so.0.50.0
b5cef000 b5d12000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d32000 b5d38000 r-xp /lib/librt-2.20-2014.11.so
b5d49000 b5d5d000 r-xp /usr/lib/libector.so.1.13.0
b5d6e000 b5d86000 r-xp /usr/lib/liblua-5.1.so
b5d97000 b5dee000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e02000 b5e2a000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e3b000 b5e4e000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e5f000 b5e99000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5eaa000 b5f15000 r-xp /lib/libm-2.20-2014.11.so
b5f26000 b5f33000 r-xp /usr/lib/libeio.so.1.13.0
b5f43000 b5f45000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f55000 b5f5a000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f6a000 b5f81000 r-xp /usr/lib/libefreet.so.1.13.0
b5f93000 b5fb3000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fc3000 b5fe3000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fe5000 b5feb000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5ffb000 b6002000 r-xp /usr/lib/libethumb_client.so.1.13.0
b6012000 b6020000 r-xp /usr/lib/libeo.so.1.13.0
b6030000 b6042000 r-xp /usr/lib/libecore_input.so.1.13.0
b6053000 b6058000 r-xp /usr/lib/libecore_file.so.1.13.0
b6068000 b6080000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6091000 b60ae000 r-xp /usr/lib/libeet.so.1.13.0
b60c7000 b610f000 r-xp /usr/lib/libeina.so.1.13.0
b6120000 b6130000 r-xp /usr/lib/libefl.so.1.13.0
b6141000 b6226000 r-xp /usr/lib/libicuuc.so.51.1
b6243000 b6383000 r-xp /usr/lib/libicui18n.so.51.1
b639a000 b63d2000 r-xp /usr/lib/libecore_x.so.1.13.0
b63e4000 b63e7000 r-xp /lib/libcap.so.2.21
b63f7000 b6420000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6431000 b6438000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b644a000 b6480000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6491000 b6579000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b658d000 b6603000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6615000 b6618000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6628000 b6633000 r-xp /usr/lib/libvconf.so.0.2.45
b6643000 b6645000 r-xp /usr/lib/libvasum.so.0.3.1
b6655000 b6657000 r-xp /usr/lib/libttrace.so.1.1
b6667000 b666a000 r-xp /usr/lib/libiniparser.so.0
b667a000 b669d000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66ad000 b66b2000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66c3000 b66da000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66eb000 b66f8000 r-xp /usr/lib/libunwind.so.8.0.1
b672e000 b6852000 r-xp /lib/libc-2.20-2014.11.so
b6867000 b6880000 r-xp /lib/libgcc_s-4.9.so.1
b6890000 b6972000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6983000 b69b7000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69c7000 b6a01000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a03000 b6a83000 r-xp /usr/lib/libedje.so.1.13.0
b6a86000 b6aa4000 r-xp /usr/lib/libecore.so.1.13.0
b6ac4000 b6c26000 r-xp /usr/lib/libevas.so.1.13.0
b6c5d000 b6c71000 r-xp /lib/libpthread-2.20-2014.11.so
b6c85000 b6ea9000 r-xp /usr/lib/libelementary.so.1.13.0
b6ed7000 b6edb000 r-xp /usr/lib/libsmack.so.1.0.0
b6eeb000 b6ef1000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6f02000 b6f04000 r-xp /usr/lib/libdlog.so.0.0.0
b6f14000 b6f17000 r-xp /usr/lib/libbundle.so.0.1.22
b6f27000 b6f29000 r-xp /lib/libdl-2.20-2014.11.so
b6f3a000 b6f53000 r-xp /usr/lib/libaul.so.0.1.0
b6f65000 b6f67000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f78000 b6f7c000 r-xp /usr/lib/libsys-assert.so
b6f8d000 b6fad000 r-xp /lib/ld-2.20-2014.11.so
b6fbe000 b6fc4000 r-xp /usr/bin/launchpad-loader
b894b000 b8a7c000 rw-p [heap]
be82a000 be84b000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1939)
Call Stack Count: 5
 0: (0xb6f98c7c) [/lib/ld-linux.so.3] + 0xbc7c
 1: (0xb6fa1954) [/lib/ld-linux.so.3] + 0x14954
 2: (0xb6f9cd60) [/lib/ld-linux.so.3] + 0xfd60
 3: (0xb6fa0f88) [/lib/ld-linux.so.3] + 0x13f88
 4: (0xb6f27b14) [/lib/libdl.so.2] + 0xb14
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
id=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.903+0900 D/PKGMGR  ( 1003): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.903+0900 D/PKGMGR  ( 1056): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 D/PKGMGR  (  982): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 D/DATA_PROVIDER_MASTER(  982): pkgmgr.c: progress_cb(374) > [SECURE_LOG] [org.example.sqlite] 30
02-12 13:16:06.913+0900 D/PKGMGR  (  993): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 D/ESD     (  993): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9930002), pkg_type(tpk), pkgid(org.example.sqlite), key(install_percent), val(30)
02-12 13:16:06.913+0900 D/PKGMGR  (  976): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 D/PKGMGR  (  976): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-12 13:16:06.913+0900 D/PKGMGR  (  989): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 D/QUICKPANEL(  989): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:install_percent val:30
02-12 13:16:06.913+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 W/cluster-home(  911): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[1], package[org.example.sqlite]
02-12 13:16:06.913+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-12 13:16:06.913+0900 D/cluster-home(  911): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[9110003] pkg_type[tpk] package[org.example.sqlite] key[install_percent] val[30] pmsg[(null)]
02-12 13:16:06.933+0900 D/CERT_SVC( 2089): cert-service.c: _cert_svc_verify_certificate_with_caflag(188) > [SECURE_LOG] root cert path : /usr/share/cert-svc/certs/code-signing/tizen/tizen-developers-root.pem
02-12 13:16:06.933+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_verify_sig_and_cert(1744) > cert_svc_verify() is done successfully. validity=[1]
02-12 13:16:06.943+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_verify_sig_and_cert(1758) > cert_svc_get_visibility() returns visibility=[1]
02-12 13:16:06.943+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_verify_sig_and_cert(1771) > Root CA cert path=[/usr/share/cert-svc/certs/code-signing/tizen/tizen-developers-root.pem]
02-12 13:16:06.963+0900 D/rpm-installer( 2089): rpm-installer.c: __ri_verify_file(336) > valid signature
02-12 13:16:06.973+0900 D/rpm-installer( 2089): rpm-installer.c: __ri_get_cert_from_file(1029) > Root CA, len=[1108]
02-12 13:16:06.973+0900 D/rpm-installer( 2089): MIIDOzCCAiOgAwIBAgIBADANBgkqhkiG9w0BAQUFADBYMRowGAYDVQQKDBFUaXplbiBBc3NvY2lhdGlvbjEaMBgGA1UECwwRVGl6ZW4gQXNzb2NpYXRpb24xHjAcBgNVBAMMFVRpemVuIERldmVsb3BlcnMgUm9vdDAeFw0xMjAxMDEwMDAwMDBaFw0zMjAxMDEwMDAwMDBaMFgxGjAYBgNVBAoMEVRpemVuIEFzc29jaWF0aW9uMRowGAYDVQQLDBFUaXplbiBBc3NvY2lhdGlvbjEeMBwGA1UEAwwVVGl6ZW4gRGV2ZWxvcGVycyBSb290MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp2rCwXTYh28vcagXWLIeVtEvXA5EeTR9UnL4Dzyd7hIq8rkxLbIMMOcCrXMTc7bEH2twFaTuXxyKXMW/2c+id3m3Z1B5caCqwSPr72oKPSI4jSkvrAC5W7EHx16M818aG4tQkXIUBhDrtSmH6dFOdt8zGq2fanj1sETfUmXAeLGE7OQYcEb2SoWGXR75Ytfp1LAw/L3luuG/kbzBcrZt1Cv05jfCP575eope6p5p80Gl0tieXyPYhSLVTLwhEdWx18CMaC7IXQo2Bm+JdjDH0Ruh/vTRnjFtmVB+nBOZNVzMHNOPUVFKSgysX/+PlM4jBTvbaTnPCZUkC/O75tYIpwIDAQABoxAwDjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4IBAQBw95ibcuAiKpAEqBMyTZtOf0okhSi9NYfs/AFIPLH5REnhtQkPmKsvDp21OSdzrFEL42rV94K98QChD9tGO6Mwp1ZHM3No7/PLC3EelOwmn4dr3KPGdjvQNSwKRblGh0Hjn4fI+studFLLv6ldCLIpA/Ssgf9GuUbcjTC8OWBYPVUQ6YoXAcuHbfhr6a
02-12 13:16:06.973+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_verify_signatures(1274) > _ri_verify_sig_and_cert(/opt/usr/apps/org.example.sqlite/author-signature.xml) succeed.
02-12 13:16:06.973+0900 D/rpm-installer( 2089): rpm-installer-signature.c: _ri_process_signaturevalue(533) > SignatureValue, len=[176]
02-12 13:16:06.973+0900 D/rpm-installer( 2089): 
02-12 13:16:06.973+0900 D/rpm-installer( 2089): BClTKj6tkgQSyAz0gznBm8tsqOF9Y6kT5bU8zzT37or2KAQX9K0sePtcqowe3hE7D5DdCWz6rG/L
02-12 13:16:06.973+0900 D/rpm-installer( 2089): 3B3zuPHx5O6WHWM85D7hH/85V58nsJrn6I848obLqQnahnDAiudl/UBzoS+UIx0gwLU8rOy85iCx
02-12 13:16:06.973+0900 D/rpm-installer( 2089): UZJqd2ZimVVdnxndtck=
02-12 13:16:06.973+0900 D/rpm-installer( 2089): rpm-installer-signature.c: _ri_process_x509certificate(441) > x509certificate, len=[909]
02-12 13:16:06.973+0900 D/rpm-installer( 2089): 
02-12 13:16:06.973+0900 D/rpm-installer( 2089): MIICmzCCAgQCCQDXI7WLdVZwiTANBgkqhkiG9w0BAQUFADCBjzELMAkGA1UEBhMCS1IxDjAMBgNV
02-12 13:16:06.973+0900 D/rpm-installer( 2089): BAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEiMCAGA1UE
02-12 13:16:06.973+0900 D/rpm-installer( 2089): CwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwbVGl6ZW4gUHVibGljIERpc3Ry
02-12 13:16:06.973+0900 D/rpm-installer( 2089): aWJ1dG9yIENBMB4XDTEyMTAyOTEzMDMwNFoXDTIyMTAyNzEzMDMwNFowgZMxCzAJBgNVBAYTAktS
02-12 13:16:06.973+0900 D/rpm-installer( 2089): MQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0Ex
02-12 13:16:06.973+0900 D/rpm-installer( 2089): IjAgBgNVBAsMGVRpemVuIERpc3RyaWJ1dG9yIFRlc3QgQ0ExKDAmBgNVBAMMH1RpemVuIFB1Ymxp
02-12 13:16:06.973+0900 D/rpm-installer( 2089): YyBEaXN0cmlidXRvciBTaWduZXIwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALtMvlc5hENK
02-12 13:16:06.973+0900 D/rpm-installer( 2089): 90ZdA+y66+Sy0enD1gpZDBh5T9RP0oRsptJv5jjNTseQbQi0SZOdOXb6J7iQdlBCtR343RpIEz8H
02-12 13:16:06.973+0900 D/rpm-installer( 2089): mrBy7mSY7mgwoU4EPpp4CTSUeAuKcmvrNOngTp5Hv7Ngf02TTHOLK3hZLpGayaDviyNZB5PdqQdB
02-12 13:16:06.973+0900 D/rpm-installer( 2089): hokKjzAzAgMBAAEwDQYJKoZIhvcNAQEFBQADgYEAvGp1gxxAIlFfhJH1efjb9BJK/rtRkbYn9+Ez
02-12 13:16:06.973+0900 D/rpm-installer( 2089): GEbEULg1svsgnyWisFimI3uFvgI/swzr1eKVY3Sc8MQ3+Fdy3EkbDZ2+WAubhcEkorTWjzWz2fL1
02-12 13:16:06.973+0900 D/rpm-installer( 2089): vKaYjeIsuEX6TVRUugHWudPzcEuQRLQf8ibZWjbQdBmpeQYBMg5x+xKLCJc=
02-12 13:16:06.973+0900 D/rpm-installer( 2089): rpm-installer-signature.c: _ri_process_x509certificate(441) > x509certificate, len=[942]
02-12 13:16:06.973+0900 D/rpm-installer( 2089): 
02-12 13:16:06.973+0900 D/rpm-installer( 2089): MIICtDCCAh2gAwIBAgIJAMDbehElPNKvMA0GCSqGSIb3DQEBBQUAMIGVMQswCQYDVQQGEwJLUjEO
02-12 13:16:06.973+0900 D/rpm-installer( 2089): MAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSMw
02-12 13:16:06.973+0900 D/rpm-installer( 2089): IQYDVQQLDBpUVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEpMCcGA1UEAwwgVGl6ZW4gUHVibGlj
02-12 13:16:06.973+0900 D/rpm-installer( 2089): IERpc3RyaWJ1dG9yIFJvb3QgQ0EwHhcNMTIxMDI5MTMwMjUwWhcNMjIxMDI3MTMwMjUwWjCBjzEL
02-12 13:16:06.973+0900 D/rpm-installer( 2089): MAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6
02-12 13:16:06.973+0900 D/rpm-installer( 2089): ZW4gVGVzdCBDQTEiMCAGA1UECwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwb
02-12 13:16:06.973+0900 D/rpm-installer( 2089): VGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIENBMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDe
02-12 13:16:06.973+0900 D/rpm-installer( 2089): OTS/3nXvkDEmsFCJIvRlQ3RKDcxdWJJp625pFqHdmoJBdV+x6jl1raGK2Y1sp2Gdvpjc/z92yzAp
02-12 13:16:06.973+0900 D/rpm-installer( 2089): bE/UVLPh/tRNZPeGhzU4ejDDm7kzdr2f7Ia0U98K+OoY12ucwg7TYNItj9is7Cj4blGfuMDzd2ah
02-12 13:16:06.973+0900 D/rpm-installer( 2089): 2AgnCGlwNwV/pv+uVQIDAQABoxAwDjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBACqJ
02-12 13:16:06.973+0900 D/rpm-installer( 2089): KO33YdoGudwanZIxMdXuxnnD9R6u72ltKk1S4zPfMJJv482CRGCI4FK6djhlsI4i0Lt1SVIJEed+
02-12 13:16:06.973+0900 D/rpm-installer( 2089): yc3qckGm19dW+4xdlkekon7pViEBWuyHw8OWv3RXtTum1+PGHjBJ2eYY4ZKIpz73U/1NC16sTB/0
02-12 13:16:06.973+0900 D/rpm-installer( 2089): VhfnkHwPl
02-12 13:16:06.993+0900 D/CERT_SVC( 2089): cert-service.c: _cert_svc_verify_certificate_with_caflag(188) > [SECURE_LOG] root cert path : /usr/share/cert-svc/certs/code-signing/tizen/tizen-distributor-root-ca-public.pem
02-12 13:16:06.993+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_verify_sig_and_cert(1744) > cert_svc_verify() is done successfully. validity=[1]
02-12 13:16:07.003+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_verify_sig_and_cert(1758) > cert_svc_get_visibility() returns visibility=[64]
02-12 13:16:07.003+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_verify_sig_and_cert(1771) > Root CA cert path=[/usr/share/cert-svc/certs/code-signing/tizen/tizen-distributor-root-ca-public.pem]
02-12 13:16:07.023+0900 D/rpm-installer( 2089): rpm-installer.c: __ri_verify_file(336) > valid signature
02-12 13:16:07.023+0900 D/rpm-installer( 2089): rpm-installer.c: __ri_get_cert_from_file(1029) > Root CA, len=[908]
02-12 13:16:07.023+0900 D/rpm-installer( 2089): MIICozCCAgwCCQD9XW6kNg4bbjANBgkqhkiG9w0BAQUFADCBlTELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEjMCEGA1UECwwaVFRpemVuIERpc3RyaWJ1dG9yIFRlc3QgQ0ExKTAnBgNVBAMMIFRpemVuIFB1YmxpYyBEaXN0cmlidXRvciBSb290IENBMB4XDTEyMTAyNjA4MDAyN1oXDTIyMTAyNDA4MDAyN1owgZUxCzAJBgNVBAYTAktSMQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0ExIzAhBgNVBAsMGlRUaXplbiBEaXN0cmlidXRvciBUZXN0IENBMSkwJwYDVQQDDCBUaXplbiBQdWJsaWMgRGlzdHJpYnV0b3IgUm9vdCBDQTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEA8o0kPY1U9El1BbBUF1k4jCq6mH8a6MmDJdjgsz+hILAYsPWimRTXUcW8GAUWhZWgm1Fbb49xWcasA8b4bIJabC/6hLb8uWiozzpRXyQJbe7k//RocskRqDmFOky8ANFsCCww72/Xbq8BFK1sxlGdmOWQiGwDWBDlS2Lw1XOMqb0CAwEAATANBgkqhkiG9w0BAQUFAAOBgQBUotZqTNFr+SNyqeZqhOToRsg3ojN1VJUa07qdlVo5I1UObSE+UTJPJ0NtSj7OyTY7fF3E4xzUv/w8aUoabQP1erEmztY/AVD+phHaPytkZ/Dx+zDZ1u5e9bKm5zfY4dQs/A53zDQta5a/NkZOEF97Dj3+bzAh2bP7KOszlocFYw==
02-12 13:16:07.023+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_verify_signatures(1284) > _ri_verify_sig_and_cert(/opt/usr/apps/org.example.sqlite/signature1.xml) succeed.
02-12 13:16:07.023+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_package_reinstall(4971) > signature and certificate verifying success
02-12 13:16:07.023+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(2089), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-12 13:16:07.023+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(2089), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-12 13:16:07.023+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr_status), signal_name(status)
02-12 13:16:07.023+0900 D/PKGMGR_INSTALLER( 2089): pkgmgr_installer.c: __send_event(112) > option is pkgid[org.example.sqlite] key[install_percent] value[60]
02-12 13:16:07.023+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(2089), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-12 13:16:07.023+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(2089), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-12 13:16:07.023+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr.install.progress), signal_name(install_progress)
02-12 13:16:07.023+0900 D/PKGMGR  ( 2084): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/PKGMGR  (  989): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/QUICKPANEL(  989): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:install_percent val:60
02-12 13:16:07.023+0900 D/PKGMGR  ( 1103): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/PKGMGR  ( 1003): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(427) > Transaction Begin
02-12 13:16:07.023+0900 D/PKGMGR  ( 1056): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/PKGMGR  (  982): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/PKGMGR  (  993): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/DATA_PROVIDER_MASTER(  982): pkgmgr.c: progress_cb(374) > [SECURE_LOG] [org.example.sqlite] 60
02-12 13:16:07.023+0900 D/ESD     (  993): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9930002), pkg_type(tpk), pkgid(org.example.sqlite), key(install_percent), val(60)
02-12 13:16:07.023+0900 D/PKGMGR  (  976): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 D/PKGMGR  (  976): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-12 13:16:07.023+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.023+0900 W/cluster-home(  911): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[1], package[org.example.sqlite]
02-12 13:16:07.033+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-12 13:16:07.033+0900 D/cluster-home(  911): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[9110003] pkg_type[tpk] package[org.example.sqlite] key[install_percent] val[60] pmsg[(null)]
02-12 13:16:07.033+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 1 16
02-12 13:16:07.033+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 2 16
02-12 13:16:07.033+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 10 1
02-12 13:16:07.033+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 7 3
02-12 13:16:07.033+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 8 3
02-12 13:16:07.033+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 9 3
02-12 13:16:07.043+0900 E/PKGMGR_CERT( 2089): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(576) > Transaction Commit and End
02-12 13:16:07.053+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_unregister_package(85) > [smack] app_uninstall(org.example.sqlite), result=[0]
02-12 13:16:07.053+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_register_package(65) > [smack] app_install(org.example.sqlite), result=[0]
02-12 13:16:07.063+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite, 5, _), result=[0]
02-12 13:16:07.063+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared, 5, _), result=[0]
02-12 13:16:07.063+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared/res, 5, _), result=[0]
02-12 13:16:07.063+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(117) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared/data, 2), result=[0]
02-12 13:16:07.063+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_get_smack_label_access(1101) > [smack] get_smack_label, path=[/opt/usr/apps/org.example.sqlite/shared/data], label=[$1$org.exam$xPr%1eP1MY4%flPE94qLi0]
02-12 13:16:07.063+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_set_smack_label_access(1088) > [smack] set_smack_label, path=[/opt/usr/apps/org.example.sqlite/shared/cache], label=[$1$org.exam$xPr%1eP1MY4%flPE94qLi0]
02-12 13:16:07.063+0900 E/rpm-installer( 2089): installer-util.c: _installer_util_get_configuration_value(418) > [signature]=[on]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_get_group_id(2472) > encoding done, len=[28]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_apply_smack(2575) > groupid = [0GPbCyJScBGxp4IBf3k8XX89Q#E=] for shared/trusted.
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared/trusted, 1, 0GPbCyJScBGxp4IBf3k8XX89Q#E=), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/bin, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/data, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/lib, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/res, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/cache, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/tizen-manifest.xml, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/author-signature.xml, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/signature1.xml, 0, org.example.sqlite), result=[0]
02-12 13:16:07.073+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/share/packages/org.example.sqlite.xml, 0, org.example.sqlite), result=[0]
02-12 13:16:07.083+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_set_package_version(75) > [smack] app[org.example.sqlite] version set to [2.4] result=[0]
02-12 13:16:07.093+0900 D/rpm-installer( 2089): rpm-installer.c: _ri_apply_privilege(1924) > api-version[2.4] fot privilege has done successfully.
02-12 13:16:07.093+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: _ri_privilege_enable_permissions(106) > [smack] app_enable_permissions(org.example.sqlite, 7), result=[0]
02-12 13:16:07.093+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_package_reinstall(5074) > #permission applying success.
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(2089), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(2089), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr_status), signal_name(status)
02-12 13:16:07.093+0900 D/PKGMGR_INSTALLER( 2089): pkgmgr_installer.c: __send_event(112) > option is pkgid[org.example.sqlite] key[install_percent] value[100]
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(2089), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(2089), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr.install.progress), signal_name(install_progress)
02-12 13:16:07.093+0900 D/rpm-installer( 2089): coretpk-installer.c: _coretpk_installer_package_reinstall(5087) > _coretpk_installer_package_reinstall(org.example.sqlite) is done.
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(2089), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(2089), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr_status), signal_name(status)
02-12 13:16:07.093+0900 D/PKGMGR_INSTALLER( 2089): pkgmgr_installer.c: __send_event(112) > option is pkgid[org.example.sqlite] key[end] value[ok]
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(2089), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(2089), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-12 13:16:07.093+0900 D/PKGMGR  ( 2089): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr.upgrade), signal_name(upgrade)
02-12 13:16:07.093+0900 D/PKGMGR  (  989): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/QUICKPANEL(  989): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:install_percent val:100
02-12 13:16:07.093+0900 D/PKGMGR  ( 2084): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/PKGMGR  ( 1056): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/PKGMGR  (  982): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/DATA_PROVIDER_MASTER(  982): pkgmgr.c: progress_cb(374) > [SECURE_LOG] [org.example.sqlite] 100
02-12 13:16:07.093+0900 D/PKGMGR  (  993): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/ESD     (  993): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9930002), pkg_type(tpk), pkgid(org.example.sqlite), key(install_percent), val(100)
02-12 13:16:07.093+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 W/cluster-home(  911): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[1], package[org.example.sqlite]
02-12 13:16:07.093+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/cluster-home(  911): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[9110003] pkg_type[tpk] package[org.example.sqlite] key[install_percent] val[100] pmsg[(null)]
02-12 13:16:07.093+0900 D/PKGMGR  (  976): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.093+0900 D/PKGMGR  (  976): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-12 13:16:07.103+0900 D/PKGMGR  (  976): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 D/PKGMGR  (  976): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-12 13:16:07.103+0900 D/PKGMGR  ( 1056): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 D/ISF_PANEL_EFL( 1056): isf_panel_efl.cpp: _package_manager_event_cb(1279) > type=tpk package=org.example.sqlite event_type=UPDATE event_state=COMPLETED progress=100 error=0
02-12 13:16:07.103+0900 D/PKGMGR  ( 1103): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.103+0900 D/PKGMGR  (  982): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 D/DATA_PROVIDER_MASTER(  982): pkgmgr.c: end_cb(409) > [SECURE_LOG] [org.example.sqlite] ok
02-12 13:16:07.103+0900 D/DATA_PROVIDER_MASTER(  982): notification_service.c: _invoke_package_change_event(916) > [SECURE_LOG] pkgname[org.example.sqlite], event_type[1]
02-12 13:16:07.103+0900 D/DATA_PROVIDER_MASTER(  982): notification_service.c: _invoke_package_change_event(945) > [SECURE_LOG] _invoke_package_change_event returns [0]
02-12 13:16:07.103+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 W/cluster-home(  911): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[2], package[org.example.sqlite]
02-12 13:16:07.103+0900 D/cluster-home(  911): widget-data-provider.cpp: PackageUpdated(2136) >  No boxes that pkgname is[org.example.sqlite]
02-12 13:16:07.103+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 D/cluster-home(  911): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[9110003] pkg_type[tpk] package[org.example.sqlite] key[end] val[ok] pmsg[(null)]
02-12 13:16:07.103+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: OnClientListenCb(463) >  #Step 1
02-12 13:16:07.103+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: OnClientListenCb(467) >  #Step 2
02-12 13:16:07.103+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _GetAppIds(334) >  BEGIN
02-12 13:16:07.103+0900 D/DATA_PROVIDER_MASTER(  982): notification_service.c: service_thread_main(883) > [SECURE_LOG] (nil) PACKET_REQ_NOACK: Command: [package_install]
02-12 13:16:07.103+0900 D/DATA_PROVIDER_MASTER(  982): notification_service.c: _handler_package_install(579) > [SECURE_LOG] _handler_package_install
02-12 13:16:07.103+0900 D/DATA_PROVIDER_MASTER(  982): notification_service.c: _handler_package_install(581) > [SECURE_LOG] package_name [org.example.sqlite]
02-12 13:16:07.103+0900 D/PKGMGR  ( 1003): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-12 13:16:07.103+0900 D/PKGMGR  ( 1003): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 D/PKGMGR  (  812): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[upgrade], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.103+0900 D/AUL_AMD (  812): amd_appinfo.c: __amd_pkgmgrinfo_status_cb(638) > [SECURE_LOG] pkgid(org.example.sqlite), key(end), value(ok)
02-12 13:16:07.103+0900 W/AUL_AMD (  812): amd_appinfo.c: __amd_pkgmgrinfo_status_cb(664) > [SECURE_LOG] op(update), value(ok)
02-12 13:16:07.113+0900 D/PKGMGR  ( 1103): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.113+0900 D/PKGMGR  (  993): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.113+0900 D/ESD     (  993): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9930002), pkg_type(tpk), pkgid(org.example.sqlite), key(end), val(ok)
02-12 13:16:07.113+0900 D/ESD     (  993): esd_main.c: __esd_pkgmgr_event_callback(1728) > install end (ok)
02-12 13:16:07.113+0900 D/PKGMGR  ( 2084): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.123+0900 D/AUL_AMD (  812): amd_appinfo.c: __app_info_insert_handler(488) > [SECURE_LOG] appinfo file:org.example.sqlite, type:rpm
02-12 13:16:07.123+0900 D/PKGMGR  (  989): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_1627428724], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-12 13:16:07.123+0900 D/QUICKPANEL(  989): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:end val:ok
02-12 13:16:07.133+0900 D/cluster-home(  911): mainmenu-package-manager.cpp: _PkgMgrAppInfoGetListCb(220) >  NoDisplay [0]
02-12 13:16:07.133+0900 D/cluster-home(  911): mainmenu-package-manager.cpp: _PkgMgrAppInfoGetListCb(225) >  app Id [org.example.sqlite]
02-12 13:16:07.133+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _PkgMgrAppInfoGetListCb(236) >  ##### [org.example.sqlite]
02-12 13:16:07.133+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _GetAppIds(355) >  ##### [org.example.sqlite]
02-12 13:16:07.133+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _GetAppIds(359) >  END
02-12 13:16:07.133+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _DoPkgJob(387) >  #Step 3 size[1]
02-12 13:16:07.133+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _DoPkgJob(391) >  appId[org.example.sqlite]
02-12 13:16:07.133+0900 W/ISF_PANEL_EFL( 1056): isf_panel_efl.cpp: _package_manager_event_cb(1371) > isf_db_select_appids_by_pkgid returned 0.
02-12 13:16:07.143+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: _GetAppInfo(848) >  AppId[org.example.sqlite] Name[sqlite] Icon[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png] enable[1] system[0]
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-presenter.cpp: OnAppUpdated(337) >  pAppId [org.example.sqlite]
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-data-manager.cpp: GetBoxDataByAppId(1832) >  BEGIN, strAppId: org.example.sqlite
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-data-manager.cpp: GetBoxDataByAppId(1874) >  nId[28], isFolder[0], pageId[1], col[1], row[4], appId[org.example.sqlite], name[sqlite], menuId[1], isPreload[0] isPreload[0]
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-data-manager.cpp: GetBoxDataByAppId(1881) >  DONE
02-12 13:16:07.143+0900 E/cluster-home(  911): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.example.sqlite] Name[sqlite] Icon[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png] enable[1] system[0]
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-presenter.cpp: OnAppUpdated(364) >  name [sqlite]
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-data-manager.cpp: GetMenuBoxData(1241) >  BEGIN
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-data-manager.cpp: GetMenuBoxData(1291) >  DONE
02-12 13:16:07.143+0900 D/test-log(  911): mainmenu-box-impl.cpp: UpdateBoxData(812) >  update box data!!!!! old icon path[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png], New icon path[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png]!!!!!
02-12 13:16:07.143+0900 D/cluster-home(  911): mainmenu-data-manager.cpp: UpdateBoxData(853) >  Query [UPDATE boxes set isFolder = 0, pageId = 1, appId = $appId, name = $name, col = 1, row = 4, isPreload = 0, isSystem = 0 WHERE boxId = 28]
02-12 13:16:07.163+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:16:07.673+0900 D/rpm-installer( 2089): rpm-installer-privilege.c: __ri_privilege_perm_end(55) > [smack] perm_end, result=[0]
02-12 13:16:07.673+0900 D/rpm-installer( 2089): rpm-appcore-intf.c: main(259) > ------------------------------------------------
02-12 13:16:07.673+0900 D/rpm-installer( 2089): rpm-appcore-intf.c: main(260) >  [END] rpm-installer: result=[0]
02-12 13:16:07.673+0900 D/rpm-installer( 2089): rpm-appcore-intf.c: main(261) > ------------------------------------------------
02-12 13:16:07.683+0900 D/PKGMGR_SERVER( 2086): pkgmgr-server.c: sighandler(387) > child exit [2089]
02-12 13:16:07.683+0900 E/PKGMGR_SERVER( 2086): pkgmgr-server.c: sighandler(402) > child NORMAL exit [2089]
02-12 13:16:08.764+0900 D/AUL_AMD (  812): amd_status.c: __app_terminate_timer_cb(442) > pid(1889)
02-12 13:16:08.764+0900 W/AUL_AMD (  812): amd_status.c: __app_terminate_timer_cb(446) > send SIGKILL: No such process
02-12 13:16:09.395+0900 E/PKGMGR_SERVER( 2086): pkgmgr-server.c: exit_server(1240) > exit_server Start [backend_status=1, queue_status=1, drm_status=1] 
02-12 13:16:09.395+0900 E/PKGMGR_SERVER( 2086): pkgmgr-server.c: main(2265) > package manager server terminated.
02-12 13:16:09.735+0900 D/AUL     ( 2142): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-12 13:16:09.735+0900 D/AUL     ( 2142): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-12 13:16:09.735+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 0
02-12 13:16:09.735+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-12 13:16:09.735+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:16:09.735+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:16:09.745+0900 I/AUL     (  812): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/launch_app, ret : 0
02-12 13:16:09.745+0900 D/AUL     (  812): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 2140, pid = 2142
02-12 13:16:09.745+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-12 13:16:09.745+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-12 13:16:09.745+0900 I/AUL     (  812): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /bin/bash, ret : 0
02-12 13:16:09.745+0900 E/AUL_AMD (  812): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-12 13:16:09.745+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2232) > caller pid : 2142
02-12 13:16:09.745+0900 E/AUL_AMD (  812): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-12 13:16:09.755+0900 W/AUL_AMD (  812): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-12 13:16:09.755+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2646) > process_pool: false
02-12 13:16:09.755+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-12 13:16:09.755+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-12 13:16:09.755+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2663) > pad pid(-5)
02-12 13:16:09.755+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-12 13:16:09.755+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-12 13:16:09.755+0900 D/AUL     (  812): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-12 13:16:09.755+0900 D/AUL_PAD (  960): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-12 13:16:09.755+0900 W/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-12 13:16:09.755+0900 D/AUL     (  960): process_pool.c: __send_pkt_raw_data(219) > send(12) : 616 / 616
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1939, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:16:09.755+0900 W/AUL_PAD (  960): launchpad.c: __send_result_to_caller(265) > Check app launching
02-12 13:16:09.755+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-12 13:16:09.755+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-12 13:16:09.755+0900 D/RESOURCED(  868): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 4
02-12 13:16:09.755+0900 E/RESOURCED(  868): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-12 13:16:09.755+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-12 13:16:09.755+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-12 13:16:09.765+0900 D/AUL     ( 1939): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1943) is sent.
02-12 13:16:09.765+0900 D/AUL     ( 1939): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1943, signo: 10
02-12 13:16:09.765+0900 D/AUL     ( 1939): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM3MTQ1NjkvNzQ1ODQ5AA==##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAyMTQyAA==##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-12 13:16:09.765+0900 D/AUL_PAD ( 1939): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-12 13:16:09.855+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-12 13:16:09.946+0900 W/CRASH_MANAGER( 2143): worker.c: worker_job(1204) > 110193973716c142371456
