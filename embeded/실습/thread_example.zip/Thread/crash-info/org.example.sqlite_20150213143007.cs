S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1453
Date: 2015-02-13 14:30:07+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x29

Register Information
r0   = 0x00000029, r1   = 0x00000029
r2   = 0xb60e5bb0, r3   = 0x000000b8
r4   = 0x00000029, r5   = 0x00000029
r6   = 0xb76a8680, r7   = 0x8001e2f2
r8   = 0x00000035, r9   = 0x00000032
r10  = 0xb76a9390, fp   = 0x00000000
ip   = 0xb6bfed04, sp   = 0xb2f39470
lr   = 0xb6b05431, pc   = 0xb60a4896
cpsr = 0x60000030

Memory Information
MemTotal:   987264 KB
MemFree:    586212 KB
Buffers:     18532 KB
Cached:     125008 KB
VmPeak:      78804 KB
VmSize:      78800 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       15344 KB
VmRSS:       15344 KB
VmData:      21908 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22316 KB
VmPTE:          52 KB
VmSwap:          0 KB

Threads Information
Threads: 3
PID = 1453 TID = 1650
1453 1454 1650 

Maps Information
b273c000 b2f3b000 rw-p [stack:1650]
b2f3b000 b2f40000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2fcc000 b2fd4000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b2fe5000 b2fe6000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2ff6000 b2ffd000 r-xp /usr/lib/libfeedback.so.0.1.4
b3021000 b3034000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b3048000 b304d000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b305d000 b305e000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b306e000 b3071000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b3082000 b3083000 r-xp /usr/lib/libxshmfence.so.1.0.0
b3093000 b3095000 r-xp /usr/lib/libxcb-present.so.0.0.0
b30a5000 b30a7000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b30b7000 b30bf000 r-xp /usr/lib/libdrm.so.2.4.0
b30cf000 b30d1000 r-xp /usr/lib/libdri2.so.0.0.0
b30e1000 b30e9000 r-xp /usr/lib/libtbm.so.1.0.0
b30f9000 b30fa000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b310c000 b310d000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b311d000 b3129000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b313a000 b3141000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3153000 b3163000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b326b000 b326f000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3280000 b3360000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3377000 b3379000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b3382000 b33a9000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33bc000 b3bbb000 rw-p [stack:1454]
b3bbb000 b3bbd000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dcd000 b3dd6000 r-xp /lib/libnss_files-2.20-2014.11.so
b3de7000 b3df0000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e01000 b3e12000 r-xp /lib/libnsl-2.20-2014.11.so
b3e25000 b3e2b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e3c000 b3e56000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e67000 b3e68000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e78000 b3e7a000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e8b000 b3e90000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ea0000 b3ea3000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3eb4000 b3ebb000 r-xp /usr/lib/libsensord-share.so
b3ecb000 b3edc000 r-xp /usr/lib/libsensor.so.1.2.0
b3eed000 b3ef3000 r-xp /usr/lib/libappcore-common.so.1.1
b3f16000 b3f1b000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f31000 b3f33000 r-xp /usr/lib/libXau.so.6.0.0
b3f43000 b3f57000 r-xp /usr/lib/libxcb.so.1.1.0
b3f67000 b3f6e000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fa6000 b3fa8000 r-xp /usr/lib/libiri.so
b3fb9000 b3fce000 r-xp /lib/libexpat.so.1.5.2
b3fe0000 b402e000 r-xp /usr/lib/libssl.so.1.0.0
b4043000 b404c000 r-xp /usr/lib/libethumb.so.1.13.0
b405d000 b4060000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4070000 b4227000 r-xp /usr/lib/libcrypto.so.1.0.0
b57be000 b57c7000 r-xp /usr/lib/libXi.so.6.1.0
b57d8000 b57da000 r-xp /usr/lib/libXgesture.so.7.0.0
b57ea000 b57ee000 r-xp /usr/lib/libXtst.so.6.1.0
b57fe000 b5804000 r-xp /usr/lib/libXrender.so.1.3.0
b5814000 b581a000 r-xp /usr/lib/libXrandr.so.2.2.0
b582a000 b582c000 r-xp /usr/lib/libXinerama.so.1.0.0
b583c000 b583f000 r-xp /usr/lib/libXfixes.so.3.1.0
b5850000 b585b000 r-xp /usr/lib/libXext.so.6.4.0
b586b000 b586d000 r-xp /usr/lib/libXdamage.so.1.1.0
b587d000 b587f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b588f000 b5972000 r-xp /usr/lib/libX11.so.6.3.0
b5985000 b598c000 r-xp /usr/lib/libXcursor.so.1.0.2
b599d000 b59b5000 r-xp /usr/lib/libudev.so.1.6.0
b59b7000 b59ba000 r-xp /lib/libattr.so.1.1.0
b59ca000 b59ea000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59eb000 b59f0000 r-xp /usr/lib/libffi.so.6.0.2
b5a00000 b5a18000 r-xp /lib/libz.so.1.2.8
b5a28000 b5a2a000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a3a000 b5b0f000 r-xp /usr/lib/libxml2.so.2.9.2
b5b24000 b5bbf000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bdb000 b5bde000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bee000 b5c08000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c18000 b5c29000 r-xp /lib/libresolv-2.20-2014.11.so
b5c3d000 b5c54000 r-xp /usr/lib/liblzma.so.5.0.3
b5c64000 b5c66000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c76000 b5c7d000 r-xp /usr/lib/libembryo.so.1.13.0
b5c8d000 b5ca5000 r-xp /usr/lib/libpng12.so.0.50.0
b5cb6000 b5cd9000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cf9000 b5cff000 r-xp /lib/librt-2.20-2014.11.so
b5d10000 b5d24000 r-xp /usr/lib/libector.so.1.13.0
b5d35000 b5d4d000 r-xp /usr/lib/liblua-5.1.so
b5d5e000 b5db5000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dc9000 b5df1000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e02000 b5e15000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e26000 b5e60000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e71000 b5edc000 r-xp /lib/libm-2.20-2014.11.so
b5eed000 b5efa000 r-xp /usr/lib/libeio.so.1.13.0
b5f0a000 b5f0c000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f1c000 b5f21000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f31000 b5f48000 r-xp /usr/lib/libefreet.so.1.13.0
b5f5a000 b5f7a000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f8a000 b5faa000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fac000 b5fb2000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fc2000 b5fc9000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fd9000 b5fe7000 r-xp /usr/lib/libeo.so.1.13.0
b5ff7000 b6009000 r-xp /usr/lib/libecore_input.so.1.13.0
b601a000 b601f000 r-xp /usr/lib/libecore_file.so.1.13.0
b602f000 b6047000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6058000 b6075000 r-xp /usr/lib/libeet.so.1.13.0
b608e000 b60d6000 r-xp /usr/lib/libeina.so.1.13.0
b60e7000 b60f7000 r-xp /usr/lib/libefl.so.1.13.0
b6108000 b61ed000 r-xp /usr/lib/libicuuc.so.51.1
b620a000 b634a000 r-xp /usr/lib/libicui18n.so.51.1
b6361000 b6399000 r-xp /usr/lib/libecore_x.so.1.13.0
b63ab000 b63ae000 r-xp /lib/libcap.so.2.21
b63be000 b63e7000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63f8000 b63ff000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6411000 b6447000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6458000 b6540000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6554000 b65ca000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65dc000 b65df000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65ef000 b65fa000 r-xp /usr/lib/libvconf.so.0.2.45
b660a000 b660c000 r-xp /usr/lib/libvasum.so.0.3.1
b661c000 b661e000 r-xp /usr/lib/libttrace.so.1.1
b662e000 b6631000 r-xp /usr/lib/libiniparser.so.0
b6641000 b6664000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6674000 b6679000 r-xp /usr/lib/libxdgmime.so.1.1.0
b668a000 b66a1000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66b2000 b66bf000 r-xp /usr/lib/libunwind.so.8.0.1
b66f5000 b6819000 r-xp /lib/libc-2.20-2014.11.so
b682e000 b6847000 r-xp /lib/libgcc_s-4.9.so.1
b6857000 b6939000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b694a000 b697e000 r-xp /usr/lib/libdbus-1.so.3.8.11
b698e000 b69c8000 r-xp /usr/lib/libsystemd.so.0.4.0
b69ca000 b6a4a000 r-xp /usr/lib/libedje.so.1.13.0
b6a4d000 b6a6b000 r-xp /usr/lib/libecore.so.1.13.0
b6a8b000 b6bed000 r-xp /usr/lib/libevas.so.1.13.0
b6c24000 b6c38000 r-xp /lib/libpthread-2.20-2014.11.so
b6c4c000 b6e70000 r-xp /usr/lib/libelementary.so.1.13.0
b6e9e000 b6ea2000 r-xp /usr/lib/libsmack.so.1.0.0
b6eb2000 b6eb8000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ec9000 b6ecb000 r-xp /usr/lib/libdlog.so.0.0.0
b6edb000 b6ede000 r-xp /usr/lib/libbundle.so.0.1.22
b6eee000 b6ef0000 r-xp /lib/libdl-2.20-2014.11.so
b6f01000 b6f1a000 r-xp /usr/lib/libaul.so.0.1.0
b6f2c000 b6f2e000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f3f000 b6f43000 r-xp /usr/lib/libsys-assert.so
b6f54000 b6f74000 r-xp /lib/ld-2.20-2014.11.so
b6f85000 b6f8b000 r-xp /usr/bin/launchpad-loader
b74cf000 b76f6000 rw-p [heap]
bee6e000 bee8f000 rw-p [stack]
bee6e000 bee8f000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1453)
Call Stack Count: 16
 0: eina_inlist_remove + 0x15 (0xb60a4896) [/usr/lib/libeina.so.1] + 0x16896
 1: (0xb6b05431) [/usr/lib/libevas.so.1] + 0x7a431
 2: (0xb6b0a64d) [/usr/lib/libevas.so.1] + 0x7f64d
 3: (0xb6b0a7f9) [/usr/lib/libevas.so.1] + 0x7f7f9
 4: (0xb6b0bb27) [/usr/lib/libevas.so.1] + 0x80b27
 5: evas_textblock_cursor_geometry_bidi_get + 0xd2 (0xb6b0e24b) [/usr/lib/libevas.so.1] + 0x8324b
 6: (0xb6a150fd) [/usr/lib/libedje.so.1] + 0x4b0fd
 7: (0xb6a324cb) [/usr/lib/libedje.so.1] + 0x684cb
 8: (0xb6a34fe5) [/usr/lib/libedje.so.1] + 0x6afe5
 9: edje_obj_part_text_append + 0x62 (0xb6a26327) [/usr/lib/libedje.so.1] + 0x5c327
10: edje_object_part_text_append + 0x2a (0xb6a2dde3) [/usr/lib/libedje.so.1] + 0x63de3
11: elm_obj_entry_append + 0x5c (0xb6d1b081) [/usr/lib/libelementary.so.1] + 0xcf081
12: elm_entry_entry_append + 0x26 (0xb6d25ecb) [/usr/lib/libelementary.so.1] + 0xd9ecb
13: _add_entry_text + 0x28 (0xb337829d) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x129d
14: thread_run_1 + 0x56 (0xb3378aab) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x1aab
15: (0xb6c29cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
tatus], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[30]
02-13 14:30:05.001+0900 D/cluster-home(  826): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[8260003] pkg_type[tpk] package[org.example.sqlite] key[install_percent] val[30] pmsg[(null)]
02-13 14:30:05.031+0900 D/CERT_SVC( 1596): cert-service.c: _cert_svc_verify_certificate_with_caflag(188) > [SECURE_LOG] root cert path : /usr/share/cert-svc/certs/code-signing/tizen/tizen-developers-root.pem
02-13 14:30:05.031+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_verify_sig_and_cert(1744) > cert_svc_verify() is done successfully. validity=[1]
02-13 14:30:05.031+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_verify_sig_and_cert(1758) > cert_svc_get_visibility() returns visibility=[1]
02-13 14:30:05.031+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_verify_sig_and_cert(1771) > Root CA cert path=[/usr/share/cert-svc/certs/code-signing/tizen/tizen-developers-root.pem]
02-13 14:30:05.061+0900 D/rpm-installer( 1596): rpm-installer.c: __ri_verify_file(336) > valid signature
02-13 14:30:05.061+0900 D/rpm-installer( 1596): rpm-installer.c: __ri_get_cert_from_file(1029) > Root CA, len=[1108]
02-13 14:30:05.061+0900 D/rpm-installer( 1596): MIIDOzCCAiOgAwIBAgIBADANBgkqhkiG9w0BAQUFADBYMRowGAYDVQQKDBFUaXplbiBBc3NvY2lhdGlvbjEaMBgGA1UECwwRVGl6ZW4gQXNzb2NpYXRpb24xHjAcBgNVBAMMFVRpemVuIERldmVsb3BlcnMgUm9vdDAeFw0xMjAxMDEwMDAwMDBaFw0zMjAxMDEwMDAwMDBaMFgxGjAYBgNVBAoMEVRpemVuIEFzc29jaWF0aW9uMRowGAYDVQQLDBFUaXplbiBBc3NvY2lhdGlvbjEeMBwGA1UEAwwVVGl6ZW4gRGV2ZWxvcGVycyBSb290MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp2rCwXTYh28vcagXWLIeVtEvXA5EeTR9UnL4Dzyd7hIq8rkxLbIMMOcCrXMTc7bEH2twFaTuXxyKXMW/2c+id3m3Z1B5caCqwSPr72oKPSI4jSkvrAC5W7EHx16M818aG4tQkXIUBhDrtSmH6dFOdt8zGq2fanj1sETfUmXAeLGE7OQYcEb2SoWGXR75Ytfp1LAw/L3luuG/kbzBcrZt1Cv05jfCP575eope6p5p80Gl0tieXyPYhSLVTLwhEdWx18CMaC7IXQo2Bm+JdjDH0Ruh/vTRnjFtmVB+nBOZNVzMHNOPUVFKSgysX/+PlM4jBTvbaTnPCZUkC/O75tYIpwIDAQABoxAwDjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4IBAQBw95ibcuAiKpAEqBMyTZtOf0okhSi9NYfs/AFIPLH5REnhtQkPmKsvDp21OSdzrFEL42rV94K98QChD9tGO6Mwp1ZHM3No7/PLC3EelOwmn4dr3KPGdjvQNSwKRblGh0Hjn4fI+studFLLv6ldCLIpA/Ssgf9GuUbcjTC8OWBYPVUQ6YoXAcuHbfhr6a
02-13 14:30:05.061+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_verify_signatures(1274) > _ri_verify_sig_and_cert(/opt/usr/apps/org.example.sqlite/author-signature.xml) succeed.
02-13 14:30:05.061+0900 D/rpm-installer( 1596): rpm-installer-signature.c: _ri_process_signaturevalue(533) > SignatureValue, len=[176]
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 
02-13 14:30:05.061+0900 D/rpm-installer( 1596): Ek8FJeCV17FC47DldV1DM+BfYLmiw8AfD7CUjKdNSsEQTYjP45pwmuvWYhMBkzo2gp+4GhLv+OL+
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 9xv64RiYve2cWiBHFFL72aoV7WJhjE/9CPi8FSwS9RoEwkvGvkH/ggKVa8+b+1OHM1KgcKXnGC0q
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 2Jd/shfvqYzXOUbFj8w=
02-13 14:30:05.061+0900 D/rpm-installer( 1596): rpm-installer-signature.c: _ri_process_x509certificate(441) > x509certificate, len=[909]
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 
02-13 14:30:05.061+0900 D/rpm-installer( 1596): MIICmzCCAgQCCQDXI7WLdVZwiTANBgkqhkiG9w0BAQUFADCBjzELMAkGA1UEBhMCS1IxDjAMBgNV
02-13 14:30:05.061+0900 D/rpm-installer( 1596): BAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEiMCAGA1UE
02-13 14:30:05.061+0900 D/rpm-installer( 1596): CwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwbVGl6ZW4gUHVibGljIERpc3Ry
02-13 14:30:05.061+0900 D/rpm-installer( 1596): aWJ1dG9yIENBMB4XDTEyMTAyOTEzMDMwNFoXDTIyMTAyNzEzMDMwNFowgZMxCzAJBgNVBAYTAktS
02-13 14:30:05.061+0900 D/rpm-installer( 1596): MQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0Ex
02-13 14:30:05.061+0900 D/rpm-installer( 1596): IjAgBgNVBAsMGVRpemVuIERpc3RyaWJ1dG9yIFRlc3QgQ0ExKDAmBgNVBAMMH1RpemVuIFB1Ymxp
02-13 14:30:05.061+0900 D/rpm-installer( 1596): YyBEaXN0cmlidXRvciBTaWduZXIwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALtMvlc5hENK
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 90ZdA+y66+Sy0enD1gpZDBh5T9RP0oRsptJv5jjNTseQbQi0SZOdOXb6J7iQdlBCtR343RpIEz8H
02-13 14:30:05.061+0900 D/rpm-installer( 1596): mrBy7mSY7mgwoU4EPpp4CTSUeAuKcmvrNOngTp5Hv7Ngf02TTHOLK3hZLpGayaDviyNZB5PdqQdB
02-13 14:30:05.061+0900 D/rpm-installer( 1596): hokKjzAzAgMBAAEwDQYJKoZIhvcNAQEFBQADgYEAvGp1gxxAIlFfhJH1efjb9BJK/rtRkbYn9+Ez
02-13 14:30:05.061+0900 D/rpm-installer( 1596): GEbEULg1svsgnyWisFimI3uFvgI/swzr1eKVY3Sc8MQ3+Fdy3EkbDZ2+WAubhcEkorTWjzWz2fL1
02-13 14:30:05.061+0900 D/rpm-installer( 1596): vKaYjeIsuEX6TVRUugHWudPzcEuQRLQf8ibZWjbQdBmpeQYBMg5x+xKLCJc=
02-13 14:30:05.061+0900 D/rpm-installer( 1596): rpm-installer-signature.c: _ri_process_x509certificate(441) > x509certificate, len=[942]
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 
02-13 14:30:05.061+0900 D/rpm-installer( 1596): MIICtDCCAh2gAwIBAgIJAMDbehElPNKvMA0GCSqGSIb3DQEBBQUAMIGVMQswCQYDVQQGEwJLUjEO
02-13 14:30:05.061+0900 D/rpm-installer( 1596): MAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSMw
02-13 14:30:05.061+0900 D/rpm-installer( 1596): IQYDVQQLDBpUVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEpMCcGA1UEAwwgVGl6ZW4gUHVibGlj
02-13 14:30:05.061+0900 D/rpm-installer( 1596): IERpc3RyaWJ1dG9yIFJvb3QgQ0EwHhcNMTIxMDI5MTMwMjUwWhcNMjIxMDI3MTMwMjUwWjCBjzEL
02-13 14:30:05.061+0900 D/rpm-installer( 1596): MAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6
02-13 14:30:05.061+0900 D/rpm-installer( 1596): ZW4gVGVzdCBDQTEiMCAGA1UECwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwb
02-13 14:30:05.061+0900 D/rpm-installer( 1596): VGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIENBMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDe
02-13 14:30:05.061+0900 D/rpm-installer( 1596): OTS/3nXvkDEmsFCJIvRlQ3RKDcxdWJJp625pFqHdmoJBdV+x6jl1raGK2Y1sp2Gdvpjc/z92yzAp
02-13 14:30:05.061+0900 D/rpm-installer( 1596): bE/UVLPh/tRNZPeGhzU4ejDDm7kzdr2f7Ia0U98K+OoY12ucwg7TYNItj9is7Cj4blGfuMDzd2ah
02-13 14:30:05.061+0900 D/rpm-installer( 1596): 2AgnCGlwNwV/pv+uVQIDAQABoxAwDjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBACqJ
02-13 14:30:05.061+0900 D/rpm-installer( 1596): KO33YdoGudwanZIxMdXuxnnD9R6u72ltKk1S4zPfMJJv482CRGCI4FK6djhlsI4i0Lt1SVIJEed+
02-13 14:30:05.061+0900 D/rpm-installer( 1596): yc3qckGm19dW+4xdlkekon7pViEBWuyHw8OWv3RXtTum1+PGHjBJ2eYY4ZKIpz73U/1NC16sTB/0
02-13 14:30:05.061+0900 D/rpm-installer( 1596): VhfnkHwPl
02-13 14:30:05.081+0900 D/CERT_SVC( 1596): cert-service.c: _cert_svc_verify_certificate_with_caflag(188) > [SECURE_LOG] root cert path : /usr/share/cert-svc/certs/code-signing/tizen/tizen-distributor-root-ca-public.pem
02-13 14:30:05.091+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_verify_sig_and_cert(1744) > cert_svc_verify() is done successfully. validity=[1]
02-13 14:30:05.091+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_verify_sig_and_cert(1758) > cert_svc_get_visibility() returns visibility=[64]
02-13 14:30:05.091+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_verify_sig_and_cert(1771) > Root CA cert path=[/usr/share/cert-svc/certs/code-signing/tizen/tizen-distributor-root-ca-public.pem]
02-13 14:30:05.111+0900 D/rpm-installer( 1596): rpm-installer.c: __ri_verify_file(336) > valid signature
02-13 14:30:05.111+0900 D/rpm-installer( 1596): rpm-installer.c: __ri_get_cert_from_file(1029) > Root CA, len=[908]
02-13 14:30:05.111+0900 D/rpm-installer( 1596): MIICozCCAgwCCQD9XW6kNg4bbjANBgkqhkiG9w0BAQUFADCBlTELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEjMCEGA1UECwwaVFRpemVuIERpc3RyaWJ1dG9yIFRlc3QgQ0ExKTAnBgNVBAMMIFRpemVuIFB1YmxpYyBEaXN0cmlidXRvciBSb290IENBMB4XDTEyMTAyNjA4MDAyN1oXDTIyMTAyNDA4MDAyN1owgZUxCzAJBgNVBAYTAktSMQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0ExIzAhBgNVBAsMGlRUaXplbiBEaXN0cmlidXRvciBUZXN0IENBMSkwJwYDVQQDDCBUaXplbiBQdWJsaWMgRGlzdHJpYnV0b3IgUm9vdCBDQTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEA8o0kPY1U9El1BbBUF1k4jCq6mH8a6MmDJdjgsz+hILAYsPWimRTXUcW8GAUWhZWgm1Fbb49xWcasA8b4bIJabC/6hLb8uWiozzpRXyQJbe7k//RocskRqDmFOky8ANFsCCww72/Xbq8BFK1sxlGdmOWQiGwDWBDlS2Lw1XOMqb0CAwEAATANBgkqhkiG9w0BAQUFAAOBgQBUotZqTNFr+SNyqeZqhOToRsg3ojN1VJUa07qdlVo5I1UObSE+UTJPJ0NtSj7OyTY7fF3E4xzUv/w8aUoabQP1erEmztY/AVD+phHaPytkZ/Dx+zDZ1u5e9bKm5zfY4dQs/A53zDQta5a/NkZOEF97Dj3+bzAh2bP7KOszlocFYw==
02-13 14:30:05.111+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_verify_signatures(1284) > _ri_verify_sig_and_cert(/opt/usr/apps/org.example.sqlite/signature1.xml) succeed.
02-13 14:30:05.111+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_package_reinstall(4971) > signature and certificate verifying success
02-13 14:30:05.111+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(1596), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-13 14:30:05.111+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(1596), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-13 14:30:05.111+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr_status), signal_name(status)
02-13 14:30:05.111+0900 D/PKGMGR_INSTALLER( 1596): pkgmgr_installer.c: __send_event(112) > option is pkgid[org.example.sqlite] key[install_percent] value[60]
02-13 14:30:05.111+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(1596), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-13 14:30:05.111+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(1596), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(60)
02-13 14:30:05.111+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr.install.progress), signal_name(install_progress)
02-13 14:30:05.111+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(427) > Transaction Begin
02-13 14:30:05.111+0900 D/PKGMGR  ( 1008): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/PKGMGR  ( 1591): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/PKGMGR  (  895): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/QUICKPANEL(  895): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:install_percent val:60
02-13 14:30:05.111+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/PKGMGR  (  970): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/PKGMGR  (  903): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/ESD     (  903): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9030002), pkg_type(tpk), pkgid(org.example.sqlite), key(install_percent), val(60)
02-13 14:30:05.111+0900 D/PKGMGR  (  885): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/DATA_PROVIDER_MASTER(  885): pkgmgr.c: progress_cb(374) > [SECURE_LOG] [org.example.sqlite] 60
02-13 14:30:05.111+0900 D/PKGMGR  (  884): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/PKGMGR  (  884): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-13 14:30:05.111+0900 D/PKGMGR  (  826): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 W/cluster-home(  826): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[1], package[org.example.sqlite]
02-13 14:30:05.111+0900 D/PKGMGR  (  826): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[60]
02-13 14:30:05.111+0900 D/cluster-home(  826): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[8260003] pkg_type[tpk] package[org.example.sqlite] key[install_percent] val[60] pmsg[(null)]
02-13 14:30:05.121+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 1 16
02-13 14:30:05.121+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 2 16
02-13 14:30:05.121+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 10 1
02-13 14:30:05.121+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 7 3
02-13 14:30:05.121+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 8 3
02-13 14:30:05.121+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(496) > Id:Count = 9 3
02-13 14:30:05.131+0900 E/PKGMGR_CERT( 1596): pkgmgrinfo_certinfo.c: pkgmgrinfo_save_certinfo(576) > Transaction Commit and End
02-13 14:30:05.151+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_unregister_package(85) > [smack] app_uninstall(org.example.sqlite), result=[0]
02-13 14:30:05.151+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_register_package(65) > [smack] app_install(org.example.sqlite), result=[0]
02-13 14:30:05.161+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite, 5, _), result=[0]
02-13 14:30:05.161+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared, 5, _), result=[0]
02-13 14:30:05.161+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared/res, 5, _), result=[0]
02-13 14:30:05.171+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(117) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared/data, 2), result=[0]
02-13 14:30:05.171+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_get_smack_label_access(1101) > [smack] get_smack_label, path=[/opt/usr/apps/org.example.sqlite/shared/data], label=[$1$org.exam$xPr%1eP1MY4%flPE94qLi0]
02-13 14:30:05.171+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_set_smack_label_access(1088) > [smack] set_smack_label, path=[/opt/usr/apps/org.example.sqlite/shared/cache], label=[$1$org.exam$xPr%1eP1MY4%flPE94qLi0]
02-13 14:30:05.171+0900 E/rpm-installer( 1596): installer-util.c: _installer_util_get_configuration_value(418) > [signature]=[on]
02-13 14:30:05.171+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_get_group_id(2472) > encoding done, len=[28]
02-13 14:30:05.171+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_apply_smack(2575) > groupid = [0GPbCyJScBGxp4IBf3k8XX89Q#E=] for shared/trusted.
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/shared/trusted, 1, 0GPbCyJScBGxp4IBf3k8XX89Q#E=), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/bin, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/data, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/lib, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/res, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/cache, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/tizen-manifest.xml, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/author-signature.xml, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/usr/apps/org.example.sqlite/signature1.xml, 0, org.example.sqlite), result=[0]
02-13 14:30:05.181+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_setup_path(120) > [smack] app_setup_path(org.example.sqlite, /opt/share/packages/org.example.sqlite.xml, 0, org.example.sqlite), result=[0]
02-13 14:30:05.191+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_set_package_version(75) > [smack] app[org.example.sqlite] version set to [2.4] result=[0]
02-13 14:30:05.191+0900 D/rpm-installer( 1596): rpm-installer.c: _ri_apply_privilege(1924) > api-version[2.4] fot privilege has done successfully.
02-13 14:30:05.191+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: _ri_privilege_enable_permissions(106) > [smack] app_enable_permissions(org.example.sqlite, 7), result=[0]
02-13 14:30:05.191+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_package_reinstall(5074) > #permission applying success.
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(1596), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(1596), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr_status), signal_name(status)
02-13 14:30:05.191+0900 D/PKGMGR_INSTALLER( 1596): pkgmgr_installer.c: __send_event(112) > option is pkgid[org.example.sqlite] key[install_percent] value[100]
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(1596), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(1596), pkg_typ(tpk), pkg_id(org.example.sqlite), key(install_percent), val(100)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr.install.progress), signal_name(install_progress)
02-13 14:30:05.191+0900 D/rpm-installer( 1596): coretpk-installer.c: _coretpk_installer_package_reinstall(5087) > _coretpk_installer_package_reinstall(org.example.sqlite) is done.
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(1596), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(1596), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr_status), signal_name(status)
02-13 14:30:05.191+0900 D/PKGMGR_INSTALLER( 1596): pkgmgr_installer.c: __send_event(112) > option is pkgid[org.example.sqlite] key[end] value[ok]
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(273) > send signal : pid(1596), zone(host), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(277) > send signal : pid(1596), pkg_typ(tpk), pkg_id(org.example.sqlite), key(end), val(ok)
02-13 14:30:05.191+0900 D/PKGMGR  ( 1596): comm_status_broadcast_server_dbus.c: comm_status_broadcast_server_send_signal(279) > send signal : interface_name(org.tizen.pkgmgr.upgrade), signal_name(upgrade)
02-13 14:30:05.201+0900 D/PKGMGR  ( 1008): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/PKGMGR  ( 1591): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/PKGMGR  (  885): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): pkgmgr.c: progress_cb(374) > [SECURE_LOG] [org.example.sqlite] 100
02-13 14:30:05.201+0900 D/PKGMGR  (  826): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 W/cluster-home(  826): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[1], package[org.example.sqlite]
02-13 14:30:05.201+0900 D/PKGMGR  (  826): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/cluster-home(  826): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[8260003] pkg_type[tpk] package[org.example.sqlite] key[install_percent] val[100] pmsg[(null)]
02-13 14:30:05.201+0900 D/PKGMGR  (  895): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/QUICKPANEL(  895): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:install_percent val:100
02-13 14:30:05.201+0900 D/PKGMGR  (  884): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/PKGMGR  (  884): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-13 14:30:05.201+0900 D/PKGMGR  (  903): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/ESD     (  903): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9030002), pkg_type(tpk), pkgid(org.example.sqlite), key(install_percent), val(100)
02-13 14:30:05.201+0900 D/PKGMGR  (  970): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/PKGMGR  ( 1591): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/PKGMGR  ( 1008): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/PKGMGR  (  903): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/ESD     (  903): esd_main.c: __esd_pkgmgr_event_callback(1710) > req_id(9030002), pkg_type(tpk), pkgid(org.example.sqlite), key(end), val(ok)
02-13 14:30:05.201+0900 D/ESD     (  903): esd_main.c: __esd_pkgmgr_event_callback(1728) > install end (ok)
02-13 14:30:05.201+0900 D/PKGMGR  (  885): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): pkgmgr.c: end_cb(409) > [SECURE_LOG] [org.example.sqlite] ok
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): notification_service.c: _invoke_package_change_event(916) > [SECURE_LOG] pkgname[org.example.sqlite], event_type[1]
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): notification_service.c: _invoke_package_change_event(945) > [SECURE_LOG] _invoke_package_change_event returns [0]
02-13 14:30:05.201+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[install_percent], value=[100]
02-13 14:30:05.201+0900 D/PKGMGR  (  911): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): notification_service.c: service_thread_main(883) > [SECURE_LOG] (nil) PACKET_REQ_NOACK: Command: [package_install]
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): notification_service.c: _handler_package_install(579) > [SECURE_LOG] _handler_package_install
02-13 14:30:05.201+0900 D/DATA_PROVIDER_MASTER(  885): notification_service.c: _handler_package_install(581) > [SECURE_LOG] package_name [org.example.sqlite]
02-13 14:30:05.201+0900 D/PKGMGR  (  884): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/PKGMGR  (  884): pkgmgr.c: __status_callback(441) > call event_cb_with_zone
02-13 14:30:05.201+0900 D/PKGMGR  (  699): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[upgrade], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.201+0900 D/AUL_AMD (  699): amd_appinfo.c: __amd_pkgmgrinfo_status_cb(638) > [SECURE_LOG] pkgid(org.example.sqlite), key(end), value(ok)
02-13 14:30:05.201+0900 W/AUL_AMD (  699): amd_appinfo.c: __amd_pkgmgrinfo_status_cb(664) > [SECURE_LOG] op(update), value(ok)
02-13 14:30:05.211+0900 D/PKGMGR  (  826): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.211+0900 W/cluster-home(  826): widget-data-provider.cpp: WidgetDataProviderPackageManagerEventCB(352) > [SECURE_LOG]  PackageManager Event type[2], state[2], package[org.example.sqlite]
02-13 14:30:05.211+0900 D/cluster-home(  826): widget-data-provider.cpp: PackageUpdated(2136) >  No boxes that pkgname is[org.example.sqlite]
02-13 14:30:05.211+0900 D/PKGMGR  (  826): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.211+0900 D/cluster-home(  826): mainmenu-package-manager.cpp: OnClientListenCb(436) >  req_id[8260003] pkg_type[tpk] package[org.example.sqlite] key[end] val[ok] pmsg[(null)]
02-13 14:30:05.211+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: OnClientListenCb(463) >  #Step 1
02-13 14:30:05.211+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: OnClientListenCb(467) >  #Step 2
02-13 14:30:05.211+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _GetAppIds(334) >  BEGIN
02-13 14:30:05.211+0900 D/PKGMGR  (  970): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.211+0900 D/ISF_PANEL_EFL(  970): isf_panel_efl.cpp: _package_manager_event_cb(1279) > type=tpk package=org.example.sqlite event_type=UPDATE event_state=COMPLETED progress=100 error=0
02-13 14:30:05.221+0900 D/AUL_AMD (  699): amd_appinfo.c: __app_info_insert_handler(488) > [SECURE_LOG] appinfo file:org.example.sqlite, type:rpm
02-13 14:30:05.231+0900 D/PKGMGR  (  895): comm_client_gdbus.c: _on_signal_handle_filter(353) > [SECURE_LOG] signal_name=[status], req_id=[org.example.sqlite_-2023702137], pkg_type=[tpk], pkgid=[org.example.sqlite], key=[end], value=[ok]
02-13 14:30:05.231+0900 D/QUICKPANEL(  895): uninstall.c: _pkgmgr_event_cb(88) > [SECURE_LOG] [_pkgmgr_event_cb : 88] pkg:org.example.sqlite key:end val:ok
02-13 14:30:05.231+0900 D/cluster-home(  826): mainmenu-package-manager.cpp: _PkgMgrAppInfoGetListCb(220) >  NoDisplay [0]
02-13 14:30:05.231+0900 D/cluster-home(  826): mainmenu-package-manager.cpp: _PkgMgrAppInfoGetListCb(225) >  app Id [org.example.sqlite]
02-13 14:30:05.231+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _PkgMgrAppInfoGetListCb(236) >  ##### [org.example.sqlite]
02-13 14:30:05.241+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _GetAppIds(355) >  ##### [org.example.sqlite]
02-13 14:30:05.241+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _GetAppIds(359) >  END
02-13 14:30:05.241+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _DoPkgJob(387) >  #Step 3 size[1]
02-13 14:30:05.241+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _DoPkgJob(391) >  appId[org.example.sqlite]
02-13 14:30:05.241+0900 W/ISF_PANEL_EFL(  970): isf_panel_efl.cpp: _package_manager_event_cb(1371) > isf_db_select_appids_by_pkgid returned 0.
02-13 14:30:05.251+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: _GetAppInfo(848) >  AppId[org.example.sqlite] Name[sqlite] Icon[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png] enable[1] system[0]
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-presenter.cpp: OnAppUpdated(337) >  pAppId [org.example.sqlite]
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: GetBoxDataByAppId(1832) >  BEGIN, strAppId: org.example.sqlite
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: GetBoxDataByAppId(1874) >  nId[40], isFolder[0], pageId[1], col[1], row[4], appId[org.example.sqlite], name[sqlite], menuId[1], isPreload[0] isPreload[0]
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: GetBoxDataByAppId(1881) >  DONE
02-13 14:30:05.251+0900 E/cluster-home(  826): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.example.sqlite] Name[sqlite] Icon[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png] enable[1] system[0]
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-presenter.cpp: OnAppUpdated(364) >  name [sqlite]
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: GetMenuBoxData(1241) >  BEGIN
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: GetMenuBoxData(1291) >  DONE
02-13 14:30:05.251+0900 D/test-log(  826): mainmenu-box-impl.cpp: UpdateBoxData(812) >  update box data!!!!! old icon path[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png], New icon path[/opt/usr/apps/org.example.sqlite/shared/res/sqlite.png]!!!!!
02-13 14:30:05.251+0900 D/cluster-home(  826): mainmenu-data-manager.cpp: UpdateBoxData(853) >  Query [UPDATE boxes set isFolder = 0, pageId = 1, appId = $appId, name = $name, col = 1, row = 4, isPreload = 0, isSystem = 0 WHERE boxId = 40]
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-installer-privilege.c: __ri_privilege_perm_end(55) > [smack] perm_end, result=[0]
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-appcore-intf.c: main(259) > ------------------------------------------------
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-appcore-intf.c: main(260) >  [END] rpm-installer: result=[0]
02-13 14:30:05.892+0900 D/rpm-installer( 1596): rpm-appcore-intf.c: main(261) > ------------------------------------------------
02-13 14:30:05.902+0900 D/PKGMGR_SERVER( 1593): pkgmgr-server.c: sighandler(387) > child exit [1596]
02-13 14:30:05.902+0900 E/PKGMGR_SERVER( 1593): pkgmgr-server.c: sighandler(402) > child NORMAL exit [1596]
02-13 14:30:06.823+0900 E/PKGMGR_SERVER( 1593): pkgmgr-server.c: exit_server(1240) > exit_server Start [backend_status=1, queue_status=1, drm_status=1] 
02-13 14:30:06.823+0900 E/PKGMGR_SERVER( 1593): pkgmgr-server.c: main(2265) > package manager server terminated.
02-13 14:30:07.263+0900 D/AUL     ( 1649): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-13 14:30:07.263+0900 D/AUL     ( 1649): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-13 14:30:07.273+0900 D/AUL_AMD (  699): amd_request.c: __request_handler(838) > __request_handler: 0
02-13 14:30:07.273+0900 D/AUL_AMD (  699): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.273+0900 I/AUL     (  699): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/launch_app, ret : 0
02-13 14:30:07.273+0900 D/AUL     (  699): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 1647, pid = 1649
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.273+0900 D/PKGMGR_INFO(  699): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-13 14:30:07.283+0900 I/AUL     (  699): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /bin/bash, ret : 0
02-13 14:30:07.283+0900 E/AUL_AMD (  699): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-13 14:30:07.283+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2232) > caller pid : 1649
02-13 14:30:07.283+0900 E/AUL_AMD (  699): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-13 14:30:07.283+0900 W/AUL_AMD (  699): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2646) > process_pool: false
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-13 14:30:07.283+0900 W/AUL_AMD (  699): amd_launch.c: _start_app(2663) > pad pid(-5)
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-13 14:30:07.283+0900 D/AUL_AMD (  699): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-13 14:30:07.283+0900 D/AUL     (  699): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-13 14:30:07.293+0900 D/AUL_PAD (  870): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-13 14:30:07.293+0900 W/AUL_PAD (  870): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-13 14:30:07.293+0900 D/AUL     (  870): process_pool.c: __send_pkt_raw_data(219) > send(13) : 616 / 616
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1453, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:07.293+0900 W/AUL_PAD (  870): launchpad.c: __send_result_to_caller(265) > Check app launching
02-13 14:30:07.293+0900 D/AUL_PAD (  870): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-13 14:30:07.293+0900 D/AUL     ( 1453): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1454) is sent.
02-13 14:30:07.293+0900 D/AUL     ( 1453): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1454, signo: 10
02-13 14:30:07.293+0900 D/AUL     ( 1453): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM4MDU0MDcvMjc3NDg5AA==##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAxNjQ5AA==##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-13 14:30:07.293+0900 D/AUL_PAD ( 1453): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-13 14:30:07.303+0900 D/RESOURCED(  773): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-13 14:30:07.303+0900 D/RESOURCED(  773): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 3
02-13 14:30:07.303+0900 E/RESOURCED(  773): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-13 14:30:07.303+0900 I/CAPI_APPFW_APPLICATION( 1453): app_main.c: ui_app_main(788) > app_efl_main
02-13 14:30:07.303+0900 D/LAUNCH  ( 1453): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-13 14:30:07.303+0900 D/APP_CORE( 1453): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-13 14:30:07.303+0900 D/APP_CORE( 1453): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-13 14:30:07.303+0900 D/APP_CORE( 1453): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-13 14:30:07.323+0900 D/APP_CORE( 1453): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-13 14:30:07.323+0900 D/AUL     ( 1453): app_sock.c: __create_server_sock(156) > pg path - already exists
02-13 14:30:07.323+0900 D/APP_CORE( 1453): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3f02dd0
02-13 14:30:07.323+0900 D/LAUNCH  ( 1453): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-13 14:30:07.323+0900 I/CAPI_APPFW_APPLICATION( 1453): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-13 14:30:07.393+0900 D/AUL_PAD (  870): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-13 14:30:07.393+0900 W/AUL     (  699): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 1453, appid: org.example.sqlite
02-13 14:30:07.393+0900 D/AUL     (  699): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-13 14:30:07.393+0900 E/AUL     (  699): simple_util.c: __trm_app_info_send_socket(330) > access
02-13 14:30:07.393+0900 D/AUL_AMD (  699): amd_launch.c: _start_app(2698) > add app group info
02-13 14:30:07.393+0900 E/AUL     (  699): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-13 14:30:07.393+0900 D/AUL_AMD (  699): amd_status.c: _status_add_app_info_list(427) > pid(1453) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-13 14:30:07.393+0900 D/AUL     ( 1649): launch.c: app_request_to_launchpad(425) > launch request result : 1453
02-13 14:30:07.393+0900 D/RESOURCED(  773): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 1453
02-13 14:30:07.393+0900 D/RESOURCED(  773): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-13 14:30:07.524+0900 E/EFL     ( 1453): ecore<1453> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:07.524+0900 E/EFL     ( 1453): ecore<1453> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:07.534+0900 E/EFL     ( 1453): ecore<1453> lib/ecore/ecore_job.c:63 _ecore_job_constructor() You are calling _ecore_job_constructor from outside of the main loop threads. Program cannot run nomally
02-13 14:30:07.594+0900 W/CRASH_MANAGER( 1457): worker.c: worker_job(1204) > 110145373716c142380540
