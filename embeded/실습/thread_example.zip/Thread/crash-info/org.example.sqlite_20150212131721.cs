S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 2340
Date: 2015-02-12 13:17:21+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x111

Register Information
r0   = 0xb71e9248, r1   = 0x00000111
r2   = 0xffffffff, r3   = 0x00000111
r4   = 0x00000111, r5   = 0x8001e2f2
r6   = 0x00000000, r7   = 0x0000001b
r8   = 0x00000000, r9   = 0x000002d0
r10  = 0xbea47150, fp   = 0x00000000
ip   = 0x00000002, sp   = 0xbea470d8
lr   = 0x00000000, pc   = 0xb6b028ec
cpsr = 0x60000030

Memory Information
MemTotal:   987264 KB
MemFree:    556116 KB
Buffers:     17228 KB
Cached:     133316 KB
VmPeak:     108896 KB
VmSize:     108892 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20880 KB
VmRSS:       20880 KB
VmData:      44340 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22324 KB
VmPTE:          70 KB
VmSwap:          0 KB

Threads Information
Threads: 5
PID = 2340 TID = 2340
2340 2345 2346 2349 2351 

Maps Information
b0801000 b1000000 rw-p [stack:2351]
b1169000 b1968000 rw-p [stack:2349]
b2733000 b2f32000 rw-p [stack:2346]
b2f32000 b2f37000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2fc3000 b2fcb000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b2fdc000 b2fdd000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2fed000 b2ff4000 r-xp /usr/lib/libfeedback.so.0.1.4
b3018000 b302b000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b303f000 b3044000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b3054000 b3055000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b3065000 b3068000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b3079000 b307a000 r-xp /usr/lib/libxshmfence.so.1.0.0
b308a000 b308c000 r-xp /usr/lib/libxcb-present.so.0.0.0
b309c000 b309e000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b30ae000 b30b6000 r-xp /usr/lib/libdrm.so.2.4.0
b30c6000 b30c8000 r-xp /usr/lib/libdri2.so.0.0.0
b30d8000 b30e0000 r-xp /usr/lib/libtbm.so.1.0.0
b30f0000 b30f1000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b3103000 b3104000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b3114000 b3120000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b3131000 b3138000 r-xp /usr/lib/libefl-extension.so.0.1.0
b314a000 b315a000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b3262000 b3266000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3277000 b3357000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b336d000 b3371000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b3379000 b33a0000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33b3000 b3bb2000 rw-p [stack:2345]
b3bb2000 b3bb4000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dc4000 b3dcd000 r-xp /lib/libnss_files-2.20-2014.11.so
b3dde000 b3de7000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3df8000 b3e09000 r-xp /lib/libnsl-2.20-2014.11.so
b3e1c000 b3e22000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e33000 b3e4d000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e5e000 b3e5f000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e6f000 b3e71000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e82000 b3e87000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e97000 b3e9a000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3eab000 b3eb2000 r-xp /usr/lib/libsensord-share.so
b3ec2000 b3ed3000 r-xp /usr/lib/libsensor.so.1.2.0
b3ee4000 b3eea000 r-xp /usr/lib/libappcore-common.so.1.1
b3f0d000 b3f12000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f29000 b3f2b000 r-xp /usr/lib/libXau.so.6.0.0
b3f3b000 b3f4f000 r-xp /usr/lib/libxcb.so.1.1.0
b3f5f000 b3f66000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f9e000 b3fa0000 r-xp /usr/lib/libiri.so
b3fb1000 b3fc6000 r-xp /lib/libexpat.so.1.5.2
b3fd8000 b4026000 r-xp /usr/lib/libssl.so.1.0.0
b403b000 b4044000 r-xp /usr/lib/libethumb.so.1.13.0
b4055000 b4058000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4068000 b421f000 r-xp /usr/lib/libcrypto.so.1.0.0
b57b6000 b57bf000 r-xp /usr/lib/libXi.so.6.1.0
b57d0000 b57d2000 r-xp /usr/lib/libXgesture.so.7.0.0
b57e2000 b57e6000 r-xp /usr/lib/libXtst.so.6.1.0
b57f6000 b57fc000 r-xp /usr/lib/libXrender.so.1.3.0
b580c000 b5812000 r-xp /usr/lib/libXrandr.so.2.2.0
b5822000 b5824000 r-xp /usr/lib/libXinerama.so.1.0.0
b5834000 b5837000 r-xp /usr/lib/libXfixes.so.3.1.0
b5848000 b5853000 r-xp /usr/lib/libXext.so.6.4.0
b5863000 b5865000 r-xp /usr/lib/libXdamage.so.1.1.0
b5875000 b5877000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5887000 b596a000 r-xp /usr/lib/libX11.so.6.3.0
b597d000 b5984000 r-xp /usr/lib/libXcursor.so.1.0.2
b5995000 b59ad000 r-xp /usr/lib/libudev.so.1.6.0
b59af000 b59b2000 r-xp /lib/libattr.so.1.1.0
b59c2000 b59e2000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59e3000 b59e8000 r-xp /usr/lib/libffi.so.6.0.2
b59f8000 b5a10000 r-xp /lib/libz.so.1.2.8
b5a20000 b5a22000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a32000 b5b07000 r-xp /usr/lib/libxml2.so.2.9.2
b5b1c000 b5bb7000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bd3000 b5bd6000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5be6000 b5c00000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c10000 b5c21000 r-xp /lib/libresolv-2.20-2014.11.so
b5c35000 b5c4c000 r-xp /usr/lib/liblzma.so.5.0.3
b5c5c000 b5c5e000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c6e000 b5c75000 r-xp /usr/lib/libembryo.so.1.13.0
b5c85000 b5c9d000 r-xp /usr/lib/libpng12.so.0.50.0
b5cae000 b5cd1000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cf1000 b5cf7000 r-xp /lib/librt-2.20-2014.11.so
b5d08000 b5d1c000 r-xp /usr/lib/libector.so.1.13.0
b5d2d000 b5d45000 r-xp /usr/lib/liblua-5.1.so
b5d56000 b5dad000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dc1000 b5de9000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5dfa000 b5e0d000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e1e000 b5e58000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e69000 b5ed4000 r-xp /lib/libm-2.20-2014.11.so
b5ee5000 b5ef2000 r-xp /usr/lib/libeio.so.1.13.0
b5f02000 b5f04000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f14000 b5f19000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f29000 b5f40000 r-xp /usr/lib/libefreet.so.1.13.0
b5f52000 b5f72000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f82000 b5fa2000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fa4000 b5faa000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fba000 b5fc1000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fd1000 b5fdf000 r-xp /usr/lib/libeo.so.1.13.0
b5fef000 b6001000 r-xp /usr/lib/libecore_input.so.1.13.0
b6012000 b6017000 r-xp /usr/lib/libecore_file.so.1.13.0
b6027000 b603f000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6050000 b606d000 r-xp /usr/lib/libeet.so.1.13.0
b6086000 b60ce000 r-xp /usr/lib/libeina.so.1.13.0
b60df000 b60ef000 r-xp /usr/lib/libefl.so.1.13.0
b6100000 b61e5000 r-xp /usr/lib/libicuuc.so.51.1
b6202000 b6342000 r-xp /usr/lib/libicui18n.so.51.1
b6359000 b6391000 r-xp /usr/lib/libecore_x.so.1.13.0
b63a3000 b63a6000 r-xp /lib/libcap.so.2.21
b63b6000 b63df000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63f0000 b63f7000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6409000 b643f000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6450000 b6538000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b654c000 b65c2000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65d4000 b65d7000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65e7000 b65f2000 r-xp /usr/lib/libvconf.so.0.2.45
b6602000 b6604000 r-xp /usr/lib/libvasum.so.0.3.1
b6614000 b6616000 r-xp /usr/lib/libttrace.so.1.1
b6626000 b6629000 r-xp /usr/lib/libiniparser.so.0
b6639000 b665c000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b666c000 b6671000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6682000 b6699000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66aa000 b66b7000 r-xp /usr/lib/libunwind.so.8.0.1
b66ed000 b6811000 r-xp /lib/libc-2.20-2014.11.so
b6826000 b683f000 r-xp /lib/libgcc_s-4.9.so.1
b684f000 b6931000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6942000 b6976000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6986000 b69c0000 r-xp /usr/lib/libsystemd.so.0.4.0
b69c2000 b6a42000 r-xp /usr/lib/libedje.so.1.13.0
b6a45000 b6a63000 r-xp /usr/lib/libecore.so.1.13.0
b6a83000 b6be5000 r-xp /usr/lib/libevas.so.1.13.0
b6c1c000 b6c30000 r-xp /lib/libpthread-2.20-2014.11.so
b6c44000 b6e68000 r-xp /usr/lib/libelementary.so.1.13.0
b6e96000 b6e9a000 r-xp /usr/lib/libsmack.so.1.0.0
b6eaa000 b6eb0000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ec1000 b6ec3000 r-xp /usr/lib/libdlog.so.0.0.0
b6ed3000 b6ed6000 r-xp /usr/lib/libbundle.so.0.1.22
b6ee6000 b6ee8000 r-xp /lib/libdl-2.20-2014.11.so
b6ef9000 b6f12000 r-xp /usr/lib/libaul.so.0.1.0
b6f24000 b6f26000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f37000 b6f3b000 r-xp /usr/lib/libsys-assert.so
b6f4c000 b6f6c000 r-xp /lib/ld-2.20-2014.11.so
b6f7d000 b6f83000 r-xp /usr/bin/launchpad-loader
b6fce000 b7223000 rw-p [heap]
bea29000 bea4a000 rw-p [stack]
bea29000 bea4a000 rw-p [stack]
End of Maps Information

Callstack Information (PID:2340)
Call Stack Count: 31
 0: (0xb6b028ec) [/usr/lib/libevas.so.1] + 0x7f8ec
 1: (0xb6b03b27) [/usr/lib/libevas.so.1] + 0x80b27
 2: evas_textblock_cursor_geometry_get + 0x5c (0xb6b060bd) [/usr/lib/libevas.so.1] + 0x830bd
 3: (0xb6a0d693) [/usr/lib/libedje.so.1] + 0x4b693
 4: (0xb6a2d135) [/usr/lib/libedje.so.1] + 0x6b135
 5: edje_obj_part_text_cursor_geometry_get + 0x7a (0xb6a22a8b) [/usr/lib/libedje.so.1] + 0x60a8b
 6: edje_object_part_text_cursor_geometry_get + 0x34 (0xb6a27ac1) [/usr/lib/libedje.so.1] + 0x65ac1
 7: (0xb6d0f127) [/usr/lib/libelementary.so.1] + 0xcb127
 8: elm_obj_entry_cursor_geometry_get + 0x70 (0xb6d118d9) [/usr/lib/libelementary.so.1] + 0xcd8d9
 9: elm_entry_cursor_geometry_get + 0x30 (0xb6d1c19d) [/usr/lib/libelementary.so.1] + 0xd819d
10: _add_entry_text + 0x56 (0xb336e8c7) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x18c7
11: _sqlite_start + 0x168 (0xb336f019) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x2019
12: (0xb6ae56b1) [/usr/lib/libevas.so.1] + 0x626b1
13: (0xb5fdb985) [/usr/lib/libeo.so.1] + 0xa985
14: eo_event_callback_call + 0x68 (0xb5fda241) [/usr/lib/libeo.so.1] + 0x9241
15: evas_object_smart_callback_call + 0x38 (0xb6ae6da1) [/usr/lib/libevas.so.1] + 0x63da1
16: (0xb6a18307) [/usr/lib/libedje.so.1] + 0x56307
17: (0xb6a1c63f) [/usr/lib/libedje.so.1] + 0x5a63f
18: (0xb6a18cc1) [/usr/lib/libedje.so.1] + 0x56cc1
19: (0xb6a19081) [/usr/lib/libedje.so.1] + 0x57081
20: (0xb6a191d1) [/usr/lib/libedje.so.1] + 0x571d1
21: (0xb6a54d51) [/usr/lib/libecore.so.1] + 0xfd51
22: (0xb6a50c4b) [/usr/lib/libecore.so.1] + 0xbc4b
23: (0xb6a56a9d) [/usr/lib/libecore.so.1] + 0x11a9d
24: ecore_main_loop_begin + 0x3e (0xb6a56cc3) [/usr/lib/libecore.so.1] + 0x11cc3
25: appcore_efl_main + 0x340 (0xb3f0ff11) [/usr/lib/libappcore-efl.so.1] + 0x2f11
26: ui_app_main + 0xc0 (0xb3e990b5) [/usr/lib/libcapi-appfw-application.so.0] + 0x20b5
27: main + 0x54 (0xb336e949) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x1949
28: _create_new_cd_display + 0x15a (0xb6f7ecab) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x1cab
29: __libc_start_main + 0x114 (0xb67034bc) [/lib/libc.so.6] + 0x164bc
30: _sqlite_start + 0x283 (0xb6f7f134) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x2134
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
> CM_RETURN_VAL_IF_FAIL: Failed: Returning [-22]
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=16
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 15, key = 16, type = 1
02-12 13:17:18.002+0900 D/SYSTEM-SETTINGS( 2325): system_setting_platform.c: system_setting_unset_changed_callback_time_changed(1669) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_time_changed. [0m
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=14
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 13, key = 14, type = 2
02-12 13:17:18.002+0900 D/SYSTEM-SETTINGS( 2325): system_setting_platform.c: system_setting_unset_changed_callback_locale_timeformat_24hour(1614) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_locale_timeformat_24hour. [0m
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=12
02-12 13:17:18.002+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 11, key = 12, type = 0
02-12 13:17:18.002+0900 D/SYSTEM-SETTINGS( 2325): system_setting_platform.c: system_setting_unset_changed_callback_locale_country(1504) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_locale_country. [0m
02-12 13:17:18.012+0900 D/LOCKSCREEN( 2325): property.c: lock_property_unregister(254) > [lock_property_unregister:254:D] unregister property cb
02-12 13:17:18.012+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
02-12 13:17:18.012+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=17
02-12 13:17:18.012+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 16, key = 17, type = 2
02-12 13:17:18.012+0900 D/SYSTEM-SETTINGS( 2325): system_setting_platform.c: system_setting_unset_changed_callback_sound_lock(1697) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_sound_lock. [0m
02-12 13:17:18.012+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
02-12 13:17:18.012+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=19
02-12 13:17:18.012+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2325): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 18, key = 19, type = 2
02-12 13:17:18.012+0900 D/SYSTEM-SETTINGS( 2325): system_setting_platform.c: system_setting_unset_changed_callback_sound_touch(1810) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_sound_touch. [0m
02-12 13:17:18.022+0900 D/LOCKSCREEN( 2325): dbus.c: lock_dbus_fini(328) > [lock_dbus_fini:328:D] DBUS connection is closed
02-12 13:17:18.022+0900 E/E17_TZSH(  533): policy_tzsh.c: _policy_tzsh_service_destroy(118) > TZSH SERVICE DESTROY.. WIN:b34af7b8, role:118
02-12 13:17:18.022+0900 E/EFL     ( 2325): eo<2325> lib/eo/eo_ptr_indirection.x:294 _eo_obj_pointer_get() obj_id 0x80006433 is not pointing to a valid object. Maybe it has already been freed.
02-12 13:17:18.022+0900 E/EFL     ( 2325): eo<2325> lib/eo/eo.c:485 _eo_do_internal() Obj (0x80006433) is an invalid ref.
02-12 13:17:18.022+0900 I/TZSH    (  989): tzsh.c: _tizen_ws_shell_cb_service_remove(56) > INF: Removed service: 'lockscreen'
02-12 13:17:18.022+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x01400007), visible:1
02-12 13:17:18.022+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:17:18.022+0900 W/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=911
02-12 13:17:18.032+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_wininfo_del(160) > [PROCESSMGR] delete anr_trigger_timer!
02-12 13:17:18.042+0900 D/INDICATOR(  886): main.c: _property_changed_cb(432) > UNSNIFF API 1400007
02-12 13:17:18.042+0900 D/INDICATOR(  886): util.c: util_signal_emit_by_win(116) > emission bg.translucent
02-12 13:17:18.042+0900 D/INDICATOR(  886): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:17:18.042+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:17:18.042+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:17:18.042+0900 D/INDICATOR(  886): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:17:18.042+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:17:18.062+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 0
02-12 13:17:18.062+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
02-12 13:17:18.062+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:17:18.062+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: RESUME State: PAUSED
02-12 13:17:18.062+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(597) > [homescreen:Application:resume:start]
02-12 13:17:18.062+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:17:18.062+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:17:18.062+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(607) > [APP 911] RESUME
02-12 13:17:18.062+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:17:18.072+0900 E/cluster-home(  911): homescreen.cpp: OnResume(66) >  app resume
02-12 13:17:18.072+0900 D/cluster-home(  911): widget-data-provider.cpp: SetBoxVisibility(1519) >  
02-12 13:17:18.072+0900 D/cluster-home(  911): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[1]
02-12 13:17:18.072+0900 D/WIDGET_VIEWER(  911): widget.c: widget_viewer_set_visibility(3865) > [SECURE_LOG] org.tizen.calendar.widget has no changes
02-12 13:17:18.072+0900 D/cluster-home(  911): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[2]
02-12 13:17:18.072+0900 D/cluster-home(  911): widget-data-provider.cpp: SetBoxVisibility(1528) >  No boxes in page[2]
02-12 13:17:18.072+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppResume(892) >  BEGIN
02-12 13:17:18.072+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppResume(910) >  END
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:17:18.072+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:17:18.072+0900 D/cluster-view(  911): homescreen-page-indicator.cpp: CancelOperation(300) >  CancelOperation
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-impl.cpp: ScrollToFitPage(466) >  ScrollToFitPage
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollSnapStart(613) >  TODO current page[0] new page[0]
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollSnapStart(623) >  TODO current page[0] new page[0]
02-12 13:17:18.072+0900 D/test-log(  911): cluster-impl.cpp: SetFocusedPage(791) >  Set mFocusedPage: 1
02-12 13:17:18.072+0900 D/test-log(  911): cluster-impl.cpp: GetFocusedPage(798) >  mFocusedPage: 1
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-view-controller.cpp: OnClusterChangeFocusedPage(1779) >  Cluster[0:] 1 page focused
02-12 13:17:18.072+0900 D/cluster-home(  911): widget-data-provider.cpp: OnCustomClusterFocusedPageChanged(2910) >  Cluster[0] page[1] focused
02-12 13:17:18.072+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(636) > [homescreen:Application:resume:done]
02-12 13:17:18.072+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(638) > [homescreen:Application:Launching:done]
02-12 13:17:18.072+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:17:18.072+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:17:18.072+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnCustomScrollComplete(5141) >  ##################### scroll complete ########################### 
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollComplete(639) >  Horizontal Cluster scrollview is stopped normally, pos[0.00, 0.00]
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollComplete(653) >  scroll position x : -0.00 (page:0)
02-12 13:17:18.072+0900 D/test-log(  911): cluster-impl.cpp: SetFocusedPage(791) >  Set mFocusedPage: 1
02-12 13:17:18.072+0900 D/test-log(  911): cluster-impl.cpp: GetFocusedPage(798) >  mFocusedPage: 1
02-12 13:17:18.072+0900 D/cluster-view(  911): cluster-view-controller.cpp: OnClusterChangeFocusedPage(1779) >  Cluster[0:] 1 page focused
02-12 13:17:18.072+0900 D/cluster-home(  911): widget-data-provider.cpp: OnCustomClusterFocusedPageChanged(2910) >  Cluster[0] page[1] focused
02-12 13:17:18.082+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_resume(339) > [SECURE_LOG] 911 is resumed
02-12 13:17:18.082+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:17:18.082+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:17:18.082+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_resume_cb(310) > widget obj was resumed
02-12 13:17:18.082+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(132) > enter foreground group
02-12 13:17:18.082+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: fg
02-12 13:17:18.082+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 966
02-12 13:17:18.082+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: foreground, oom_score_adj: 200
02-12 13:17:18.082+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 966
02-12 13:17:18.102+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:17:18.112+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/apps/org.tizen.homescreen/bin/homescreen' and package_app_info.app_disable IN ('false','False')
02-12 13:17:18.112+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/apps/org.tizen.homescreen/bin/homescreen' and package_app_info.app_disable IN ('false','False')
02-12 13:17:18.112+0900 D/AUL_AMD (  812): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 911 is org.tizen.homescreen
02-12 13:17:18.112+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 911 : 0
02-12 13:17:18.122+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 29
02-12 13:17:18.152+0900 I/MALI    ( 2325): egl_platform_x11.c: __egl_platform_terminate(333) > [EGL-X11] ################################################
02-12 13:17:18.152+0900 I/MALI    ( 2325): egl_platform_x11.c: __egl_platform_terminate(334) > [EGL-X11] PID=2325   close drm_fd=31 
02-12 13:17:18.152+0900 I/MALI    ( 2325): egl_platform_x11.c: __egl_platform_terminate(335) > [EGL-X11] ################################################
02-12 13:17:18.182+0900 D/RESOURCED(  868): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 966, appname = org.tizen.calendar.widget
02-12 13:17:18.182+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 966
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:17:18.552+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:17:18.552+0900 I/AUL_PAD (  960): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 2325 pgid = 2325
02-12 13:17:18.552+0900 I/AUL_PAD (  960): sigchild.h: __sigchild_action(141) > dead_pid(2325)
02-12 13:17:18.603+0900 D/AUL_PAD (  960): sigchild.h: __send_app_dead_signal(90) > send dead signal done
02-12 13:17:18.603+0900 I/AUL_PAD (  960): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
02-12 13:17:18.603+0900 I/AUL_PAD (  960): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
02-12 13:17:18.603+0900 E/AUL_PAD (  960): launchpad.c: main(688) > error reading sigchld info
02-12 13:17:18.603+0900 I/ESD     (  993): esd_main.c: __esd_app_dead_handler(1771) > pid: 2325
02-12 13:17:18.603+0900 D/STARTER (  871): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 2325 is termianted
02-12 13:17:18.603+0900 D/STARTER (  871): starter.c: _check_dead_signal(199) > [_check_dead_signal:199] lockscreen is dead
02-12 13:17:18.603+0900 E/STARTER (  871): lock_pwd_util.c: lock_pwd_util_win_visible_get(71) > [lock_pwd_util_win_visible_get:71] (!s_lock_pwd_util.lock_pwd_win) -> lock_pwd_util_win_visible_get() return
02-12 13:17:18.603+0900 D/STARTER (  871): lock_mgr.c: lock_mgr_unlock(339) > [lock_mgr_unlock:339] pwd win visible(0), lock type(1)
02-12 13:17:18.603+0900 D/STARTER (  871): lock_mgr.c: lock_mgr_idle_lock_state_set(253) > [lock_mgr_idle_lock_state_set:253] lock state : 0
02-12 13:17:18.613+0900 W/STARTER (  871): window_mgr.c: _pwd_transient_unset(159) > [_pwd_transient_unset:159] 0x1400007 is not transient
02-12 13:17:18.613+0900 W/AUL_AMD (  812): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 2325
02-12 13:17:18.613+0900 W/AUL_AMD (  812): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 2325
02-12 13:17:18.613+0900 D/AUL_AMD (  812): amd_key.c: _unregister_key_event(179) > ===key stack===
02-12 13:17:18.613+0900 E/AUL_AMD (  812): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
02-12 13:17:18.613+0900 D/AUL_AMD (  812): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.tizen.lockscreen)
02-12 13:17:18.613+0900 D/AUL     (  812): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-12 13:17:18.613+0900 E/AUL     (  812): simple_util.c: __trm_app_info_send_socket(330) > access
02-12 13:17:18.623+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1023) >  menu box Pick touched
02-12 13:17:18.623+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1034) >  Long Tap Timer Start
02-12 13:17:18.623+0900 E/RESOURCED(  868): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.227
02-12 13:17:18.633+0900 D/VOLUME  (  910): control.c: _idle_lock_state_vconf_changed_cb(810) > [_idle_lock_state_vconf_changed_cb:810] idle lock state : 0
02-12 13:17:18.643+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 2325
02-12 13:17:18.643+0900 D/RESOURCED(  868): appinfo-list.c: resourced_appinfo_put(132) > appid org.tizen.lockscreen, pkgname = org.tizen.lockscreen, ref = 0
02-12 13:17:18.693+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1194) >  Box[0] pick ended by Up
02-12 13:17:18.693+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1199) >  Cancel Long Tap Timer
02-12 13:17:18.693+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1240) >  app launch state[1]
02-12 13:17:18.693+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1249) >  touch is moved upper position!!!
02-12 13:17:18.693+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1298) >  laundch!!!!! touch position is moved from[632.00][612.00] to[632.00][612.00]!
02-12 13:17:18.693+0900 D/cluster-view(  911): homescreen-view-manager.cpp: IsOverScrollThreshold(997) >  is Over Scrollview TreshHold?[0]
02-12 13:17:18.693+0900 D/INDICATOR(  886): util.c: util_signal_emit(84) > [SECURE_LOG] util_signal_emit[84]	 "emission clock.font.12"
02-12 13:17:18.693+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200082 
02-12 13:17:18.693+0900 D/cluster-home(  911): mainmenu-custom-box-impl.cpp: OnClicked(171) >  [29]MenuBox clicked
02-12 13:17:18.703+0900 D/cluster-home(  911): mainmenu-custom-box-impl.cpp: OnClicked(184) >  launch application via service(operation APP_CONTROL_OPERATION_DEFAULT)
02-12 13:17:18.703+0900 D/AUL     (  911): service.c: __set_bundle(186) > __set_bundle
02-12 13:17:18.703+0900 D/AUL     (  911): service.c: __get_alias_appid(548) > [SECURE_LOG] alias_id : (null)
02-12 13:17:18.703+0900 D/AUL     (  911): service.c: __set_bundle(186) > __set_bundle
02-12 13:17:18.703+0900 D/AUL     (  911): service.c: __run_svc_with_pkgname(276) > [SECURE_LOG] pkg_name : org.example.sqlite - no result
02-12 13:17:18.703+0900 D/AUL     (  911): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-12 13:17:18.703+0900 D/AUL     (  911): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-12 13:17:18.703+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 0
02-12 13:17:18.703+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-12 13:17:18.703+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2230) > [SECURE_LOG] caller appid : org.tizen.homescreen
02-12 13:17:18.703+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2232) > caller pid : 911
02-12 13:17:18.713+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2442) > win(a00002) ecore_x_pointer_grab(1)
02-12 13:17:18.713+0900 D/AUL_AMD (  812): amd_key.c: _key_grab(243) > _key_grab, win : a00002
02-12 13:17:18.713+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2447) > back key grab
02-12 13:17:18.713+0900 W/AUL_AMD (  812): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-12 13:17:18.713+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-12 13:17:18.713+0900 D/RESOURCED(  868): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 6
02-12 13:17:18.713+0900 E/RESOURCED(  868): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-12 13:17:18.723+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2516) > org.tizen.system.deviced.PmQos-AppLaunch : 0
02-12 13:17:18.723+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2646) > process_pool: false
02-12 13:17:18.723+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-12 13:17:18.723+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-12 13:17:18.723+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2663) > pad pid(-5)
02-12 13:17:18.723+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-12 13:17:18.723+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-12 13:17:18.723+0900 D/AUL     (  812): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-12 13:17:18.723+0900 D/AUL_PAD (  960): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-12 13:17:18.723+0900 W/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-12 13:17:18.723+0900 D/AUL     (  960): process_pool.c: __send_pkt_raw_data(219) > send(12) : 876 / 876
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 2340, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:17:18.723+0900 W/AUL_PAD (  960): launchpad.c: __send_result_to_caller(265) > Check app launching
02-12 13:17:18.723+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 876, pkt->len: 868
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-12 13:17:18.723+0900 D/AUL     ( 2340): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (2345) is sent.
02-12 13:17:18.723+0900 D/AUL     ( 2340): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 2345, signo: 10
02-12 13:17:18.723+0900 D/AUL     ( 2340): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __APP_SVC_OP_TYPE__##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : UgAAAAEEAAAUAAAAX19BUFBfU1ZDX09QX1RZUEVfXwAuAAAAaHR0cDovL3RpemVuLm9yZy9hcHBjb250cm9sL29wZXJhdGlvbi9kZWZhdWx0AA==##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __APP_SVC_PKG_NAME__##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : OAAAAAEEAAAVAAAAX19BUFBfU1ZDX1BLR19OQU1FX18AEwAAAG9yZy5leGFtcGxlLnNxbGl0ZQA=##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_STARTTIME__##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM3MTQ2MzgvNzEzMjU2AA==##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 8 : __AUL_CALLER_PID__##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 9 : JwAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAQAAAA5MTEA##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 10 : __AUL_CALLER_APPID__##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 11 : OgAAAAEEAAAVAAAAX19BVUxfQ0FMTEVSX0FQUElEX18AFQAAAG9yZy50aXplbi5ob21lc2NyZWVuAA==##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 12 : __AUL_INTERNAL_POOL__##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 13 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 14
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-12 13:17:18.723+0900 D/AUL_PAD ( 2340): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-12 13:17:18.733+0900 I/CAPI_APPFW_APPLICATION( 2340): app_main.c: ui_app_main(788) > app_efl_main
02-12 13:17:18.743+0900 D/LAUNCH  ( 2340): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-12 13:17:18.743+0900 D/APP_CORE( 2340): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-12 13:17:18.743+0900 D/APP_CORE( 2340): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-12 13:17:18.743+0900 D/APP_CORE( 2340): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-12 13:17:18.763+0900 D/APP_CORE( 2340): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-12 13:17:18.763+0900 D/AUL     ( 2340): app_sock.c: __create_server_sock(156) > pg path - already exists
02-12 13:17:18.763+0900 D/APP_CORE( 2340): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3ef9dd0
02-12 13:17:18.763+0900 D/LAUNCH  ( 2340): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-12 13:17:18.763+0900 I/CAPI_APPFW_APPLICATION( 2340): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-12 13:17:18.823+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-12 13:17:18.823+0900 W/AUL     (  812): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 2340, appid: org.example.sqlite
02-12 13:17:18.823+0900 D/AUL     (  812): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-12 13:17:18.823+0900 E/AUL     (  812): simple_util.c: __trm_app_info_send_socket(330) > access
02-12 13:17:18.823+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2698) > add app group info
02-12 13:17:18.823+0900 E/AUL     (  812): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-12 13:17:18.823+0900 D/AUL_AMD (  812): amd_status.c: _status_add_app_info_list(427) > pid(2340) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-12 13:17:18.823+0900 D/AUL     (  911): launch.c: app_request_to_launchpad(425) > launch request result : 2340
02-12 13:17:18.823+0900 E/cluster-home(  911): mainmenu-custom-box-impl.cpp: OnClicked(202) >  Success to launch [0][org.example.sqlite]
02-12 13:17:18.823+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-12 13:17:18.823+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 2340
02-12 13:17:18.823+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-12 13:17:19.053+0900 D/LAUNCH  ( 2340): appcore-efl.c: __before_loop(1154) > [sqlite:Application:create:done]
02-12 13:17:19.053+0900 E/E17     (  533): e_manager.c: _e_manager_cb_window_show_request(1134) > Show request(0x04600002)
02-12 13:17:19.053+0900 D/APP_CORE( 2340): appcore-efl.c: __check_wm_rotation_support(835) > Disable window manager rotation
02-12 13:17:19.063+0900 E/E17     (  533): e_border.c: e_border_show(2088) > BD_SHOW(0x04600002)
02-12 13:17:19.163+0900 W/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=2340
02-12 13:17:19.173+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:17:19.173+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:17:19.173+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:17:19.173+0900 D/INDICATOR(  886): main.c: _property_changed_cb(432) > UNSNIFF API 2400002
02-12 13:17:19.173+0900 D/INDICATOR(  886): util.c: util_signal_emit_by_win(116) > emission bg.opaque
02-12 13:17:19.173+0900 D/INDICATOR(  886): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:17:19.173+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:17:19.173+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:17:19.173+0900 D/INDICATOR(  886): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:17:19.183+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:17:19.183+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:17:19.183+0900 D/AUL_AMD (  812): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 2340 is org.example.sqlite
02-12 13:17:19.183+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 2340 : 0
02-12 13:17:19.183+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
02-12 13:17:19.413+0900 D/APP_CORE( 2340): appcore.c: __aul_handler(587) > [APP 2340]     AUL event: AUL_START
02-12 13:17:19.413+0900 I/APP_CORE( 2340): appcore-efl.c: __do_app(496) > [APP 2340] Event: RESET State: CREATED
02-12 13:17:19.413+0900 D/APP_CORE( 2340): appcore-efl.c: __do_app(527) > [APP 2340] RESET
02-12 13:17:19.413+0900 D/LAUNCH  ( 2340): appcore-efl.c: __do_app(529) > [sqlite:Application:reset:start]
02-12 13:17:19.413+0900 D/APP_CORE( 2340): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
02-12 13:17:19.413+0900 D/APP_CORE( 2340): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:17:19.413+0900 I/CAPI_APPFW_APPLICATION( 2340): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
02-12 13:17:19.413+0900 D/LAUNCH  ( 2340): appcore-efl.c: __do_app(544) > [sqlite:Application:reset:done]
02-12 13:17:19.413+0900 D/APP_CORE( 2340): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : org.tizen.homescreen
02-12 13:17:19.423+0900 E/EFL     ( 2340): edje<2340> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:17:19.423+0900 E/EFL     ( 2340): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:17:19.443+0900 E/EFL     ( 2340): edje<2340> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:17:19.443+0900 E/EFL     ( 2340): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:17:19.443+0900 E/EFL     ( 2340): edje<2340> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:17:19.443+0900 E/EFL     ( 2340): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:17:19.463+0900 W/APP_CORE( 2340): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4600002
02-12 13:17:19.463+0900 D/APP_CORE( 2340): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:4600002
02-12 13:17:19.463+0900 D/APP_CORE( 2340): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
02-12 13:17:19.463+0900 D/AUL     ( 2340): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
02-12 13:17:19.463+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 34
02-12 13:17:19.573+0900 D/APP_CORE( 2340): appcore.c: __prt_ltime(236) > [APP 2340] first idle after reset: 869 msec
02-12 13:17:19.644+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x122dfb8), gem(16), surface(0x127d330)
02-12 13:17:19.644+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x126e870), gem(10), surface(0x127d9f0)
02-12 13:17:19.644+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x122dfb8), gem(16), surface(0x12893e0)
02-12 13:17:19.654+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-12 13:17:19.654+0900 D/APP_CORE( 2340): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600002 fully_obscured 0
02-12 13:17:19.654+0900 D/APP_CORE( 2340): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
02-12 13:17:19.654+0900 D/APP_CORE( 2340): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:17:19.654+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-12 13:17:19.654+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:17:19.654+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:17:19.654+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: PAUSE State: RUNNING
02-12 13:17:19.654+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(565) > [APP 911] PAUSE
02-12 13:17:19.654+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:17:19.654+0900 E/cluster-home(  911): homescreen.cpp: OnPause(84) >  app pause
02-12 13:17:19.654+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-12 13:17:19.654+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(923) >  END
02-12 13:17:19.654+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:17:19.654+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:17:19.654+0900 I/APP_CORE( 2340): appcore-efl.c: __do_app(496) > [APP 2340] Event: RESUME State: CREATED
02-12 13:17:19.654+0900 D/LAUNCH  ( 2340): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-12 13:17:19.654+0900 D/APP_CORE( 2340): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:17:19.654+0900 D/APP_CORE( 2340): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:17:19.654+0900 D/APP_CORE( 2340): appcore-efl.c: __do_app(607) > [APP 2340] RESUME
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(911) status(4)
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-12 13:17:19.664+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-12 13:17:19.664+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: bg
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2887) > pid(2340) status(3)
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2893) > back key ungrab
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(2340) status(3)
02-12 13:17:19.664+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(2340) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-12 13:17:19.664+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-12 13:17:19.664+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 2340, appid: org.example.sqlite, status: fg
02-12 13:17:19.674+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 911 is paused
02-12 13:17:19.674+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:17:19.674+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_pause_cb(292) > widget obj was paused
02-12 13:17:19.674+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(142) > enter background group
02-12 13:17:19.674+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: bg
02-12 13:17:19.674+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 2340
02-12 13:17:19.674+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 2340, proc_name: ---, cg_name: foreground, oom_score_adj: 200
02-12 13:17:19.674+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 2340
02-12 13:17:19.684+0900 I/APP_CORE( 2340): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
02-12 13:17:19.684+0900 I/APP_CORE( 2340): appcore-efl.c: __do_app(614) > [APP 2340] Initial Launching, call the resume_cb
02-12 13:17:19.684+0900 I/CAPI_APPFW_APPLICATION( 2340): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:17:19.684+0900 D/LAUNCH  ( 2340): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-12 13:17:19.684+0900 D/LAUNCH  ( 2340): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-12 13:17:19.684+0900 D/APP_CORE( 2340): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:17:19.684+0900 E/APP_CORE( 2340): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:17:19.774+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
02-12 13:17:19.774+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
02-12 13:17:19.824+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
02-12 13:17:19.824+0900 D/AUL_PAD ( 2348): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
02-12 13:17:19.854+0900 D/AUL_PAD (  960): sigchild.h: __send_app_launch_signal(130) > send launch signal done
02-12 13:17:19.874+0900 D/RESOURCED(  868): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
02-12 13:17:19.874+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
02-12 13:17:19.894+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2906) > pid(2340) status(0)
02-12 13:17:19.894+0900 E/RESOURCED(  868): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.229
02-12 13:17:20.324+0900 D/AUL_AMD (  812): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:17:20.324+0900 D/RUA     (  812): rua.c: rua_add_history(179) > rua_add_history start
02-12 13:17:20.334+0900 D/RUA     (  812): rua.c: rua_add_history(247) > rua_add_history ok
02-12 13:17:20.835+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x1259b88), gem(4), surface(0x1288bf8)
02-12 13:17:20.845+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20086b 
02-12 13:17:20.945+0900 D/sqlite  ( 2340): DB Path: /opt/usr/apps/org.example.sqlite/data/test.db
02-12 13:17:20.985+0900 D/AUL_PAD ( 2348): launchpad_loader.c: main(588) > sleeping 1 sec...
02-12 13:17:20.985+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(52) > max_cmdline_size = 1053
02-12 13:17:21.005+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b7897768
02-12 13:17:21.005+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:17:21.005+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(73) > get shutdown function
02-12 13:17:21.015+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b7897a48
02-12 13:17:21.025+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b78995b0
02-12 13:17:21.025+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:17:21.025+0900 D/AUL_PAD ( 2348): preload.h: __preload_init(73) > get shutdown function
02-12 13:17:21.025+0900 D/AUL_PAD ( 2348): preexec.h: __preexec_init(76) > preexec start
02-12 13:17:21.025+0900 D/AUL_PAD ( 2348): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
02-12 13:17:21.025+0900 D/AUL     ( 2348): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
02-12 13:17:21.025+0900 D/AUL     ( 2348): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
02-12 13:17:21.025+0900 D/AUL     ( 2348): process_pool.c: __connect_to_launchpad(132) > send(2348) : 4
02-12 13:17:21.025+0900 D/AUL     ( 2348): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
02-12 13:17:21.025+0900 D/AUL_PAD (  960): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 2348
02-12 13:17:21.325+0900 D/AUL_PAD ( 2348): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
02-12 13:17:21.365+0900 D/AUL_PAD ( 2348): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
02-12 13:17:21.365+0900 D/AUL_PAD ( 2348): launchpad_loader.c: main(693) > [candidate] ecore handler add
02-12 13:17:21.365+0900 D/AUL_PAD ( 2348): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
02-12 13:17:21.465+0900 W/CRASH_MANAGER( 2352): worker.c: worker_job(1204) > 110234073716c142371464
