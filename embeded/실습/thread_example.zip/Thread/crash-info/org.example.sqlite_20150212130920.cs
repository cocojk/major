S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1129
Date: 2015-02-12 13:09:20+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x62006104

Register Information
r0   = 0x62006100, r1   = 0x00000000
r2   = 0x00000000, r3   = 0x00000000
r4   = 0xb7df24ec, r5   = 0xb7df24b0
r6   = 0xb7df24ec, r7   = 0xb16bd138
r8   = 0x00000000, r9   = 0xb7df2720
r10  = 0xb16bd240, fp   = 0x00000000
ip   = 0xb686b328, sp   = 0xb16bd120
lr   = 0xb6b934b7, pc   = 0xb6b9300c
cpsr = 0x42000030

Memory Information
MemTotal:   987264 KB
MemFree:    572312 KB
Buffers:     14776 KB
Cached:     129704 KB
VmPeak:     136772 KB
VmSize:     136768 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       21392 KB
VmRSS:       21392 KB
VmData:      43332 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22324 KB
VmPTE:          84 KB
VmSwap:          0 KB

Threads Information
Threads: 5
PID = 1129 TID = 1469
1129 1158 1468 1469 1470 

Maps Information
afae3000 b02e2000 rw-p [stack:1470]
b0ec1000 b16c0000 rw-p [stack:1469]
b1a61000 b2260000 rw-p [stack:1468]
b2f50000 b2f55000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2fe1000 b2fe9000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b2ffa000 b2ffb000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b300b000 b3012000 r-xp /usr/lib/libfeedback.so.0.1.4
b3036000 b3049000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b305d000 b3062000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b3072000 b3073000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b3083000 b3086000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b3097000 b3098000 r-xp /usr/lib/libxshmfence.so.1.0.0
b30a8000 b30aa000 r-xp /usr/lib/libxcb-present.so.0.0.0
b30ba000 b30bc000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b30cc000 b30d4000 r-xp /usr/lib/libdrm.so.2.4.0
b30e4000 b30e6000 r-xp /usr/lib/libdri2.so.0.0.0
b30f6000 b30fe000 r-xp /usr/lib/libtbm.so.1.0.0
b310e000 b310f000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b3121000 b3122000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b3132000 b313e000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b314f000 b3156000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3168000 b3178000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b3280000 b3284000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3295000 b3375000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b338b000 b338f000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b3397000 b33be000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33d1000 b3bd0000 rw-p [stack:1158]
b3bd0000 b3bd2000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3de2000 b3deb000 r-xp /lib/libnss_files-2.20-2014.11.so
b3dfc000 b3e05000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e16000 b3e27000 r-xp /lib/libnsl-2.20-2014.11.so
b3e3a000 b3e40000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e51000 b3e6b000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e7c000 b3e7d000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e8d000 b3e8f000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ea0000 b3ea5000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3eb5000 b3eb8000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ec9000 b3ed0000 r-xp /usr/lib/libsensord-share.so
b3ee0000 b3ef1000 r-xp /usr/lib/libsensor.so.1.2.0
b3f02000 b3f08000 r-xp /usr/lib/libappcore-common.so.1.1
b3f2b000 b3f30000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f46000 b3f48000 r-xp /usr/lib/libXau.so.6.0.0
b3f58000 b3f6c000 r-xp /usr/lib/libxcb.so.1.1.0
b3f7c000 b3f83000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fbb000 b3fbd000 r-xp /usr/lib/libiri.so
b3fce000 b3fe3000 r-xp /lib/libexpat.so.1.5.2
b3ff5000 b4043000 r-xp /usr/lib/libssl.so.1.0.0
b4058000 b4061000 r-xp /usr/lib/libethumb.so.1.13.0
b4072000 b4075000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4085000 b423c000 r-xp /usr/lib/libcrypto.so.1.0.0
b57d3000 b57dc000 r-xp /usr/lib/libXi.so.6.1.0
b57ed000 b57ef000 r-xp /usr/lib/libXgesture.so.7.0.0
b57ff000 b5803000 r-xp /usr/lib/libXtst.so.6.1.0
b5813000 b5819000 r-xp /usr/lib/libXrender.so.1.3.0
b5829000 b582f000 r-xp /usr/lib/libXrandr.so.2.2.0
b583f000 b5841000 r-xp /usr/lib/libXinerama.so.1.0.0
b5851000 b5854000 r-xp /usr/lib/libXfixes.so.3.1.0
b5865000 b5870000 r-xp /usr/lib/libXext.so.6.4.0
b5880000 b5882000 r-xp /usr/lib/libXdamage.so.1.1.0
b5892000 b5894000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58a4000 b5987000 r-xp /usr/lib/libX11.so.6.3.0
b599a000 b59a1000 r-xp /usr/lib/libXcursor.so.1.0.2
b59b2000 b59ca000 r-xp /usr/lib/libudev.so.1.6.0
b59cc000 b59cf000 r-xp /lib/libattr.so.1.1.0
b59df000 b59ff000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a00000 b5a05000 r-xp /usr/lib/libffi.so.6.0.2
b5a15000 b5a2d000 r-xp /lib/libz.so.1.2.8
b5a3d000 b5a3f000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a4f000 b5b24000 r-xp /usr/lib/libxml2.so.2.9.2
b5b39000 b5bd4000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bf0000 b5bf3000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c03000 b5c1d000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c2d000 b5c3e000 r-xp /lib/libresolv-2.20-2014.11.so
b5c52000 b5c69000 r-xp /usr/lib/liblzma.so.5.0.3
b5c79000 b5c7b000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c8b000 b5c92000 r-xp /usr/lib/libembryo.so.1.13.0
b5ca2000 b5cba000 r-xp /usr/lib/libpng12.so.0.50.0
b5ccb000 b5cee000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d0e000 b5d14000 r-xp /lib/librt-2.20-2014.11.so
b5d25000 b5d39000 r-xp /usr/lib/libector.so.1.13.0
b5d4a000 b5d62000 r-xp /usr/lib/liblua-5.1.so
b5d73000 b5dca000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dde000 b5e06000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e17000 b5e2a000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e3b000 b5e75000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e86000 b5ef1000 r-xp /lib/libm-2.20-2014.11.so
b5f02000 b5f0f000 r-xp /usr/lib/libeio.so.1.13.0
b5f1f000 b5f21000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f31000 b5f36000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f46000 b5f5d000 r-xp /usr/lib/libefreet.so.1.13.0
b5f6f000 b5f8f000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f9f000 b5fbf000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fc1000 b5fc7000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fd7000 b5fde000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fee000 b5ffc000 r-xp /usr/lib/libeo.so.1.13.0
b600c000 b601e000 r-xp /usr/lib/libecore_input.so.1.13.0
b602f000 b6034000 r-xp /usr/lib/libecore_file.so.1.13.0
b6044000 b605c000 r-xp /usr/lib/libecore_evas.so.1.13.0
b606d000 b608a000 r-xp /usr/lib/libeet.so.1.13.0
b60a3000 b60eb000 r-xp /usr/lib/libeina.so.1.13.0
b60fc000 b610c000 r-xp /usr/lib/libefl.so.1.13.0
b611d000 b6202000 r-xp /usr/lib/libicuuc.so.51.1
b621f000 b635f000 r-xp /usr/lib/libicui18n.so.51.1
b6376000 b63ae000 r-xp /usr/lib/libecore_x.so.1.13.0
b63c0000 b63c3000 r-xp /lib/libcap.so.2.21
b63d3000 b63fc000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b640d000 b6414000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6426000 b645c000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b646d000 b6555000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6569000 b65df000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65f1000 b65f4000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6604000 b660f000 r-xp /usr/lib/libvconf.so.0.2.45
b661f000 b6621000 r-xp /usr/lib/libvasum.so.0.3.1
b6631000 b6633000 r-xp /usr/lib/libttrace.so.1.1
b6643000 b6646000 r-xp /usr/lib/libiniparser.so.0
b6656000 b6679000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6689000 b668e000 r-xp /usr/lib/libxdgmime.so.1.1.0
b669f000 b66b6000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66c7000 b66d4000 r-xp /usr/lib/libunwind.so.8.0.1
b670a000 b682e000 r-xp /lib/libc-2.20-2014.11.so
b6843000 b685c000 r-xp /lib/libgcc_s-4.9.so.1
b686c000 b694e000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b695f000 b6993000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69a3000 b69dd000 r-xp /usr/lib/libsystemd.so.0.4.0
b69df000 b6a5f000 r-xp /usr/lib/libedje.so.1.13.0
b6a62000 b6a80000 r-xp /usr/lib/libecore.so.1.13.0
b6aa0000 b6c02000 r-xp /usr/lib/libevas.so.1.13.0
b6c39000 b6c4d000 r-xp /lib/libpthread-2.20-2014.11.so
b6c61000 b6e85000 r-xp /usr/lib/libelementary.so.1.13.0
b6eb3000 b6eb7000 r-xp /usr/lib/libsmack.so.1.0.0
b6ec7000 b6ecd000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ede000 b6ee0000 r-xp /usr/lib/libdlog.so.0.0.0
b6ef0000 b6ef3000 r-xp /usr/lib/libbundle.so.0.1.22
b6f03000 b6f05000 r-xp /lib/libdl-2.20-2014.11.so
b6f16000 b6f2f000 r-xp /usr/lib/libaul.so.0.1.0
b6f41000 b6f43000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f54000 b6f58000 r-xp /usr/lib/libsys-assert.so
b6f69000 b6f89000 r-xp /lib/ld-2.20-2014.11.so
b6f9a000 b6fa0000 r-xp /usr/bin/launchpad-loader
b7bbf000 b7e37000 rw-p [heap]
bea39000 bea5a000 rw-p [stack]
b7bbf000 b7e37000 rw-p [heap]
bea39000 bea5a000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1129)
Call Stack Count: 1
 0: (0xb6b9300c) [/usr/lib/libevas.so.1] + 0xf300c
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
State: 2, (3:lcdoff, 4:sleep)
02-12 13:08:44.931+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(177) > LCD is dimmed
02-12 13:08:46.593+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:08:46.593+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:08:46.593+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:08:46.593+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:08:46.593+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:08:46.593+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:08:46.593+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:08:46.623+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(169) > LCD is on
02-12 13:08:46.733+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: _OnScrollStart(1488) >  on appsview scroll started[1] xPos[-0] 
02-12 13:08:47.063+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200082 
02-12 13:08:47.063+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-12 13:08:47.314+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1505) >  Horizontal Apps scrollview is stopped normally.
02-12 13:08:47.314+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1508) >  mMenuScrollView.GetCurrentPage(0)
02-12 13:08:47.314+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1510) >  on appsview scroll completed[1] xPos[-0]
02-12 13:08:47.314+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: SetAppsViewFocusedPage(834) >  page [1]
02-12 13:08:47.314+0900 D/test-log(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1114) >  page change updated, get new page map
02-12 13:08:47.314+0900 D/test-log(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1115) >  focused page!!!!!!!!!!!!!![1]
02-12 13:08:47.314+0900 D/cluster-view(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1155) >  Current View state[1]
02-12 13:08:47.314+0900 D/cluster-view(  911): cluster-home-accessibility.cpp: SetCurrentGroup(62) >  Focus Group changed [12]->[12] Block[0]
02-12 13:08:47.314+0900 D/cluster-view(  911): mainmenu-view-manager-impl.cpp: _UpdateScreenReader(2054) >  [TTS] For Home update type[1], group[12]
02-12 13:08:47.314+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:08:47.314+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:08:47.314+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:08:47.314+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:08:47.314+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[60010]
02-12 13:08:47.314+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[60010]
02-12 13:08:47.314+0900 W/cluster-view(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1550) >  booster timer is still running on apps-view, Stop boost timer!!!
02-12 13:08:48.074+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x2400002
02-12 13:08:53.079+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200082 bd->visible=1
02-12 13:08:58.525+0900 D/RESOURCED(  868): logging.c: logging_send_signal_to_data(1097) > logging timer callback function start
02-12 13:08:58.525+0900 I/RESOURCED(  868): logging.c: logging_send_signal_to_data(1106) > send signal to logging data thread
02-12 13:08:58.525+0900 D/RESOURCED(  868): logging.c: logging_send_signal_to_update(1177) > logging timer callback function start
02-12 13:08:58.525+0900 I/RESOURCED(  868): logging.c: logging_send_signal_to_update(1186) > send signal to logging update thread
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_get_apm_by_region(666) > indicator_get_apm_by_region[666]	 "TimeZone is Asia/Seoul"
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(780) > indicator_get_time_by_region[780]	 "BestPattern is h"
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(781) > indicator_get_time_by_region[781]	 "TimeZone is Asia/Seoul"
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(801) > indicator_get_time_by_region[801]	 "DATE & TIME is en_US 1:09 4 h"
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(803) > indicator_get_time_by_region[803]	 "24H :: Before change 1:09"
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(810) > indicator_get_time_by_region[810]	 "24H :: After change 1&#x2236;09"
02-12 13:09:00.477+0900 D/INDICATOR(  886): clock.c: indicator_clock_changed_cb(295) > [CLOCK MODULE] Timer Status : -2147139422 Time: <font_size=33>1&#x2236;09</font_size> <font_size=32>PM</font_size></font>
02-12 13:09:02.619+0900 E/AUL_AMD (  812): amd_main.c: __platform_ready_handler(429) > [Info]__platform_ready_handler
02-12 13:09:04.450+0900 D/ALARM_MANAGER( 1107): alarm-lib.c: alarmmgr_fini(481) > [SECURE_LOG] Enter
02-12 13:09:04.450+0900 D/ALARM_MANAGER( 1107): alarm-lib.c: alarmmgr_fini(503) > [SECURE_LOG] Leave
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: _exclude_list_change_cb(577) > [SECURE_LOG] file /opt/usr/etc/resourced_proc_exclude.ini changed, path: /opt/usr/etc/resourced_proc_exclude.ini, event: 6 
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.app-tray to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.cluster-home to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.data-provider-slave to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.lockscreen to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.pwlock to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.admin-data to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.quickpanel to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.volume to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.indicator to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append nas9xepmna.context-service to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append popup to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append testmode to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append wakeup-servic to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append sqlite to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append sqlite to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: _exclude_list_change_cb(577) > [SECURE_LOG] file /opt/usr/etc/resourced_proc_exclude.ini changed, path: /opt/usr/etc/resourced_proc_exclude.ini, event: 7 
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.app-tray to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.cluster-home to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.data-provider-slave to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.lockscreen to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.pwlock to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.admin-data to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.quickpanel to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.volume to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append com.samsung.indicator to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append nas9xepmna.context-service to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append popup to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append testmode to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append wakeup-servic to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append sqlite to proc exclude list
02-12 13:09:04.500+0900 D/RESOURCED(  868): proc-main.c: fill_exclude_list_by_path(551) > [SECURE_LOG] append sqlite to proc exclude list
02-12 13:09:04.681+0900 D/AUL     ( 1461): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-12 13:09:04.681+0900 D/AUL     ( 1461): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-12 13:09:04.691+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 0
02-12 13:09:04.691+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-12 13:09:04.691+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:09:04.691+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:09:04.691+0900 I/AUL     (  812): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : launch_app, ret : 0
02-12 13:09:04.691+0900 D/AUL     (  812): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 1360, pid = 1461
02-12 13:09:04.691+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/da_manager' and package_app_info.app_disable IN ('false','False')
02-12 13:09:04.691+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/da_manager' and package_app_info.app_disable IN ('false','False')
02-12 13:09:04.701+0900 I/AUL     (  812): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/da_manager, ret : 0
02-12 13:09:04.701+0900 E/AUL_AMD (  812): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-12 13:09:04.701+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2232) > caller pid : 1461
02-12 13:09:04.701+0900 E/AUL_AMD (  812): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-12 13:09:04.711+0900 W/AUL_AMD (  812): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-12 13:09:04.711+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2646) > process_pool: false
02-12 13:09:04.711+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-12 13:09:04.711+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-12 13:09:04.711+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2663) > pad pid(-5)
02-12 13:09:04.711+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-12 13:09:04.711+0900 D/AUL_AMD (  812): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-12 13:09:04.711+0900 D/AUL     (  812): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-12 13:09:04.711+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-12 13:09:04.711+0900 D/RESOURCED(  868): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 1
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-12 13:09:04.711+0900 D/AUL_PAD (  960): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-12 13:09:04.711+0900 W/AUL_PAD (  960): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-12 13:09:04.711+0900 D/AUL     (  960): process_pool.c: __send_pkt_raw_data(219) > send(12) : 616 / 616
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 1129, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:09:04.711+0900 W/AUL_PAD (  960): launchpad.c: __send_result_to_caller(265) > Check app launching
02-12 13:09:04.711+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-12 13:09:04.711+0900 E/RESOURCED(  868): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-12 13:09:04.711+0900 D/AUL     ( 1129): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (1158) is sent.
02-12 13:09:04.711+0900 D/AUL     ( 1129): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 1158, signo: 10
02-12 13:09:04.711+0900 D/AUL     ( 1129): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM3MTQxNDQvNjkwMDYzAA==##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAxNDYxAA==##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-12 13:09:04.711+0900 D/AUL_PAD ( 1129): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-12 13:09:04.721+0900 I/CAPI_APPFW_APPLICATION( 1129): app_main.c: ui_app_main(788) > app_efl_main
02-12 13:09:04.721+0900 D/LAUNCH  ( 1129): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-12 13:09:04.721+0900 D/APP_CORE( 1129): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-12 13:09:04.731+0900 D/APP_CORE( 1129): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-12 13:09:04.731+0900 D/APP_CORE( 1129): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-12 13:09:04.771+0900 D/APP_CORE( 1129): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-12 13:09:04.771+0900 D/AUL     ( 1129): app_sock.c: __create_server_sock(156) > pg path - already exists
02-12 13:09:04.771+0900 D/APP_CORE( 1129): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3f17dd0
02-12 13:09:04.771+0900 D/LAUNCH  ( 1129): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-12 13:09:04.771+0900 I/CAPI_APPFW_APPLICATION( 1129): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-12 13:09:04.801+0900 D/AUL_PAD (  960): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-12 13:09:04.801+0900 W/AUL     (  812): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 1129, appid: org.example.sqlite
02-12 13:09:04.801+0900 D/AUL     (  812): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-12 13:09:04.801+0900 E/AUL     (  812): simple_util.c: __trm_app_info_send_socket(330) > access
02-12 13:09:04.801+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2698) > add app group info
02-12 13:09:04.801+0900 E/AUL     (  812): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-12 13:09:04.801+0900 D/AUL_AMD (  812): amd_status.c: _status_add_app_info_list(427) > pid(1129) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-12 13:09:04.801+0900 D/AUL     ( 1461): launch.c: app_request_to_launchpad(425) > launch request result : 1129
02-12 13:09:04.801+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 1129
02-12 13:09:04.801+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-12 13:09:05.802+0900 D/AUL_AMD (  812): amd_launch.c: __grab_timeout_handler(1444) > pid(1129) ecore_x_pointer_ungrab
02-12 13:09:05.802+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:09:05.802+0900 W/AUL_AMD (  812): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:09:05.802+0900 W/AUL_AMD (  812): amd_launch.c: __grab_timeout_handler(1446) > back key ungrab error
02-12 13:09:05.812+0900 D/AUL_PAD (  960): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
02-12 13:09:05.812+0900 D/AUL_PAD ( 1463): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
02-12 13:09:05.822+0900 D/AUL_PAD (  960): sigchild.h: __send_app_launch_signal(130) > send launch signal done
02-12 13:09:06.302+0900 D/AUL_AMD (  812): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:09:06.302+0900 D/RUA     (  812): rua.c: rua_add_history(179) > rua_add_history start
02-12 13:09:06.312+0900 D/RUA     (  812): rua.c: rua_add_history(247) > rua_add_history ok
02-12 13:09:06.943+0900 D/AUL_PAD ( 1463): launchpad_loader.c: main(588) > sleeping 1 sec...
02-12 13:09:06.943+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(52) > max_cmdline_size = 1053
02-12 13:09:06.963+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b8251768
02-12 13:09:06.963+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:09:06.963+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(73) > get shutdown function
02-12 13:09:06.963+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b8251a48
02-12 13:09:06.973+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b82535b0
02-12 13:09:06.973+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:09:06.973+0900 D/AUL_PAD ( 1463): preload.h: __preload_init(73) > get shutdown function
02-12 13:09:06.973+0900 D/AUL_PAD ( 1463): preexec.h: __preexec_init(76) > preexec start
02-12 13:09:06.973+0900 D/AUL_PAD ( 1463): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
02-12 13:09:06.973+0900 D/AUL     ( 1463): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
02-12 13:09:06.973+0900 D/AUL     ( 1463): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
02-12 13:09:06.973+0900 D/AUL     ( 1463): process_pool.c: __connect_to_launchpad(132) > send(1463) : 4
02-12 13:09:06.973+0900 D/AUL     ( 1463): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
02-12 13:09:06.973+0900 D/AUL_PAD (  960): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 1463
02-12 13:09:07.253+0900 D/AUL_PAD ( 1463): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
02-12 13:09:07.283+0900 D/AUL_PAD ( 1463): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
02-12 13:09:07.283+0900 D/AUL_PAD ( 1463): launchpad_loader.c: main(693) > [candidate] ecore handler add
02-12 13:09:07.283+0900 D/AUL_PAD ( 1463): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
02-12 13:09:09.806+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1129) status(4)
02-12 13:09:09.806+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1129) appid(org.example.sqlite) pkgid(org.example.sqlite) status(4)
02-12 13:09:09.806+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.example.sqlite
02-12 13:09:09.806+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1129, appid: org.example.sqlite, status: bg
02-12 13:09:09.806+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1129, proc_name: ---, cg_name: previous, oom_score_adj: 300
02-12 13:09:09.806+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 1129
02-12 13:09:09.996+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:09:09.996+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:09:09.996+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:09:09.996+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:09:09.996+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:09:09.996+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:09:09.996+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 2, (3:lcdoff, 4:sleep)
02-12 13:09:09.996+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(177) > LCD is dimmed
02-12 13:09:11.527+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:09:11.527+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:09:11.527+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:09:11.527+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:09:11.527+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:09:11.527+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:09:11.527+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:09:11.537+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(169) > LCD is on
02-12 13:09:11.607+0900 D/LAUNCH  ( 1129): appcore-efl.c: __before_loop(1154) > [sqlite:Application:create:done]
02-12 13:09:11.607+0900 E/E17     (  533): e_manager.c: _e_manager_cb_window_show_request(1134) > Show request(0x04600002)
02-12 13:09:11.617+0900 D/APP_CORE( 1129): appcore-efl.c: __check_wm_rotation_support(835) > Disable window manager rotation
02-12 13:09:11.627+0900 E/E17     (  533): e_border.c: e_border_show(2088) > BD_SHOW(0x04600002)
02-12 13:09:11.728+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: _OnScrollStart(1488) >  on appsview scroll started[1] xPos[-0] 
02-12 13:09:11.738+0900 W/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=1129
02-12 13:09:11.748+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:09:11.748+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:09:11.758+0900 D/INDICATOR(  886): main.c: _property_changed_cb(432) > UNSNIFF API 2400002
02-12 13:09:11.758+0900 D/INDICATOR(  886): util.c: util_signal_emit_by_win(116) > emission bg.opaque
02-12 13:09:11.768+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:09:11.778+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:09:11.778+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:09:11.778+0900 D/AUL_AMD (  812): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 1129 is org.example.sqlite
02-12 13:09:11.778+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 1129 : 0
02-12 13:09:11.778+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
02-12 13:09:11.848+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-12 13:09:11.848+0900 D/INDICATOR(  886): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:09:11.848+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:09:11.848+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:09:11.848+0900 D/INDICATOR(  886): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:09:11.848+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11ee928), gem(10), surface(0x1258300)
02-12 13:09:11.858+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x11503b8), gem(12), surface(0x11e4f40)
02-12 13:09:11.868+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200547 
02-12 13:09:11.868+0900 I/MALI    (  911): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:09:12.028+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1505) >  Horizontal Apps scrollview is stopped normally.
02-12 13:09:12.028+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1508) >  mMenuScrollView.GetCurrentPage(0)
02-12 13:09:12.028+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1510) >  on appsview scroll completed[1] xPos[-0]
02-12 13:09:12.028+0900 D/cluster-view(  911): mainmenu-apps-view-impl.cpp: SetAppsViewFocusedPage(834) >  page [1]
02-12 13:09:12.028+0900 D/test-log(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1114) >  page change updated, get new page map
02-12 13:09:12.028+0900 D/test-log(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1115) >  focused page!!!!!!!!!!!!!![1]
02-12 13:09:12.028+0900 D/cluster-view(  911): mainmenu-view-manager-impl.cpp: OnAppsViewPageChangeCompleted(1155) >  Current View state[1]
02-12 13:09:12.028+0900 D/cluster-view(  911): cluster-home-accessibility.cpp: SetCurrentGroup(62) >  Focus Group changed [12]->[12] Block[0]
02-12 13:09:12.028+0900 D/cluster-view(  911): mainmenu-view-manager-impl.cpp: _UpdateScreenReader(2054) >  [TTS] For Home update type[1], group[12]
02-12 13:09:12.028+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:09:12.028+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:09:12.028+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:09:12.028+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:09:12.028+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[60010]
02-12 13:09:12.028+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[60010]
02-12 13:09:12.028+0900 W/cluster-view(  911): mainmenu-apps-view-impl.cpp: _OnScrollComplete(1550) >  booster timer is still running on apps-view, Stop boost timer!!!
02-12 13:09:12.448+0900 D/APP_CORE( 1129): appcore.c: __aul_handler(587) > [APP 1129]     AUL event: AUL_START
02-12 13:09:12.448+0900 I/APP_CORE( 1129): appcore-efl.c: __do_app(496) > [APP 1129] Event: RESET State: CREATED
02-12 13:09:12.448+0900 D/APP_CORE( 1129): appcore-efl.c: __do_app(527) > [APP 1129] RESET
02-12 13:09:12.448+0900 D/LAUNCH  ( 1129): appcore-efl.c: __do_app(529) > [sqlite:Application:reset:start]
02-12 13:09:12.448+0900 D/APP_CORE( 1129): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
02-12 13:09:12.448+0900 D/APP_CORE( 1129): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:09:12.448+0900 I/CAPI_APPFW_APPLICATION( 1129): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
02-12 13:09:12.448+0900 D/AUL     ( 1129): service.c: __set_bundle(186) > __set_bundle
02-12 13:09:12.448+0900 D/LAUNCH  ( 1129): appcore-efl.c: __do_app(544) > [sqlite:Application:reset:done]
02-12 13:09:12.448+0900 D/APP_CORE( 1129): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : (null)
02-12 13:09:12.488+0900 E/EFL     ( 1129): edje<1129> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:09:12.488+0900 E/EFL     ( 1129): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:09:12.869+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x4600002
02-12 13:09:13.159+0900 E/EFL     ( 1129): edje<1129> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:09:13.159+0900 E/EFL     ( 1129): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:09:13.850+0900 E/EFL     ( 1129): edje<1129> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:09:13.850+0900 E/EFL     ( 1129): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:09:14.010+0900 W/APP_CORE( 1129): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4600002
02-12 13:09:14.010+0900 D/APP_CORE( 1129): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:4600002
02-12 13:09:14.010+0900 D/APP_CORE( 1129): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
02-12 13:09:14.010+0900 D/AUL     ( 1129): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
02-12 13:09:14.010+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 34
02-12 13:09:15.802+0900 D/APP_CORE( 1129): appcore.c: __prt_ltime(236) > [APP 1129] first idle after reset: 11121 msec
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:138 _ecore_evas_idle_enter() stuck async render: time=3.360530, ee=0xb7be67e0, engine=software_x11, geometry=(0, 0, 720, 1280), visible=1, shaped=0, alpha=0, transparent=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:140 _ecore_evas_idle_enter() delayed.avoid_damage=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:141 _ecore_evas_idle_enter() delayed.resize_shape=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:142 _ecore_evas_idle_enter() delayed.shaped=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:143 _ecore_evas_idle_enter() delayed.shaped_changed=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:144 _ecore_evas_idle_enter() delayed.alpha=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:145 _ecore_evas_idle_enter() delayed.alpha_changed=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:146 _ecore_evas_idle_enter() delayed.transparent=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:147 _ecore_evas_idle_enter() delayed.transparent_changed=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:148 _ecore_evas_idle_enter() delayed.rotation=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:149 _ecore_evas_idle_enter() delayed.rotation_resize=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:150 _ecore_evas_idle_enter() delayed.rotation_changed=0
02-12 13:09:15.812+0900 E/EFL     ( 1129): ecore_evas<1129> lib/ecore_evas/ecore_evas.c:152 _ecore_evas_idle_enter() reset in_async_render of ee=0xb7be67e0
02-12 13:09:15.852+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1239d08), gem(16), surface(0x11e6cc8)
02-12 13:09:15.862+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11ee928), gem(10), surface(0x11e9440)
02-12 13:09:15.862+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1239d08), gem(16), surface(0x11eb290)
02-12 13:09:15.872+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-12 13:09:15.872+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-12 13:09:15.872+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:09:15.872+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:09:15.872+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: PAUSE State: RUNNING
02-12 13:09:15.872+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(565) > [APP 911] PAUSE
02-12 13:09:15.872+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:09:15.882+0900 E/cluster-home(  911): homescreen.cpp: OnPause(84) >  app pause
02-12 13:09:15.882+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-12 13:09:15.882+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(923) >  END
02-12 13:09:15.882+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:09:15.882+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:09:15.882+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(911) status(4)
02-12 13:09:15.882+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-12 13:09:15.882+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-12 13:09:15.882+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: bg
02-12 13:09:15.882+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2887) > pid(1129) status(3)
02-12 13:09:15.882+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:09:15.882+0900 W/AUL_AMD (  812): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:09:15.882+0900 W/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-12 13:09:15.882+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1129) status(3)
02-12 13:09:15.882+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1129) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-12 13:09:15.882+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-12 13:09:15.882+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1129, appid: org.example.sqlite, status: fg
02-12 13:09:15.882+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1129
02-12 13:09:15.882+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1129, proc_name: ---, cg_name: foreground, oom_score_adj: 200
02-12 13:09:15.882+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 1129
02-12 13:09:15.892+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200547 bd->visible=1
02-12 13:09:15.892+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 911 is paused
02-12 13:09:15.892+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:09:15.892+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(370) > [PROCESSMGR] pointed_win=0x200547 cwin=0x200547 
02-12 13:09:15.892+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(373) > [PROCESSMGR] pointed_win=0x200547 is not response!
02-12 13:09:15.892+0900 E/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_dbus_msg_send(308) > [PROCESSMGR] pointed_win=0x4600002 Send kill command to the ResourceD! PID=1129
02-12 13:09:15.942+0900 D/APP_CORE( 1129): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600002 fully_obscured 0
02-12 13:09:15.942+0900 D/APP_CORE( 1129): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
02-12 13:09:15.942+0900 D/APP_CORE( 1129): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:09:15.952+0900 I/APP_CORE( 1129): appcore-efl.c: __do_app(496) > [APP 1129] Event: RESUME State: CREATED
02-12 13:09:15.952+0900 D/LAUNCH  ( 1129): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-12 13:09:15.952+0900 D/APP_CORE( 1129): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:09:15.952+0900 D/APP_CORE( 1129): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:09:15.952+0900 D/APP_CORE( 1129): appcore-efl.c: __do_app(607) > [APP 1129] RESUME
02-12 13:09:16.062+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2906) > pid(1129) status(0)
02-12 13:09:16.442+0900 I/APP_CORE( 1129): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
02-12 13:09:16.442+0900 I/APP_CORE( 1129): appcore-efl.c: __do_app(614) > [APP 1129] Initial Launching, call the resume_cb
02-12 13:09:16.442+0900 I/CAPI_APPFW_APPLICATION( 1129): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:09:16.442+0900 D/LAUNCH  ( 1129): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-12 13:09:16.442+0900 D/LAUNCH  ( 1129): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-12 13:09:16.442+0900 D/APP_CORE( 1129): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:09:16.442+0900 E/APP_CORE( 1129): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:09:18.804+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200547 
02-12 13:09:19.405+0900 D/sqlite  ( 1129): DB Path: /opt/usr/apps/org.example.sqlite/data/test.db
02-12 13:09:20.436+0900 D/sqlite  ( 1129): -0: 
02-12 13:09:20.476+0900 D/sqlite  ( 1129): DATA = yRh6I9kyEUb6aJlKvFyCOQ== | 
02-12 13:09:20.506+0900 D/sqlite  ( 1129): ENCRYPTED = 1 | 
02-12 13:09:20.786+0900 W/CRASH_MANAGER( 1471): worker.c: worker_job(1204) > 110112973716c142371416
