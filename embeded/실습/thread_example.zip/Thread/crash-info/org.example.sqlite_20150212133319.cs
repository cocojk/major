S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 2142
Date: 2015-02-12 13:33:18+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x98761237

Register Information
r0   = 0x98761237, r1   = 0xb7754ec8
r2   = 0xb6046ed4, r3   = 0xb7755390
r4   = 0x98761237, r5   = 0x8001e2f2
r6   = 0xb774e988, r7   = 0x8001e2f2
r8   = 0x000003c2, r9   = 0x000002d0
r10  = 0xb19fe530, fp   = 0x00000000
ip   = 0xb6c4f098, sp   = 0xb19fe47c
lr   = 0xb6b56d2b, pc   = 0xb6106966
cpsr = 0xa0000030

Memory Information
MemTotal:   987264 KB
MemFree:    564672 KB
Buffers:     16760 KB
Cached:     130072 KB
VmPeak:     100572 KB
VmSize:     100568 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       20700 KB
VmRSS:       20700 KB
VmData:      36020 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22316 KB
VmPTE:          64 KB
VmSwap:          0 KB

Threads Information
Threads: 4
PID = 2142 TID = 2341
2142 2143 2339 2341 

Maps Information
b1201000 b1a00000 rw-p [stack:2341]
b1b69000 b2368000 rw-p [stack:2339]
b2f8b000 b2f90000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b301c000 b3024000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b3035000 b3036000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3046000 b304d000 r-xp /usr/lib/libfeedback.so.0.1.4
b3071000 b3084000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b3098000 b309d000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b30ad000 b30ae000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b30be000 b30c1000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b30d2000 b30d3000 r-xp /usr/lib/libxshmfence.so.1.0.0
b30e3000 b30e5000 r-xp /usr/lib/libxcb-present.so.0.0.0
b30f5000 b30f7000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b3107000 b310f000 r-xp /usr/lib/libdrm.so.2.4.0
b311f000 b3121000 r-xp /usr/lib/libdri2.so.0.0.0
b3131000 b3139000 r-xp /usr/lib/libtbm.so.1.0.0
b3149000 b314a000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b315c000 b315d000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b316d000 b3179000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b318a000 b3191000 r-xp /usr/lib/libefl-extension.so.0.1.0
b31a3000 b31b3000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b32bb000 b32bf000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32d0000 b33b0000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33c7000 b33c9000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b33d2000 b33f9000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b340c000 b3c0b000 rw-p [stack:2143]
b3c0b000 b3c0d000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3e1d000 b3e26000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e37000 b3e40000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e51000 b3e62000 r-xp /lib/libnsl-2.20-2014.11.so
b3e75000 b3e7b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e8c000 b3ea6000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3eb7000 b3eb8000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ec8000 b3eca000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3edb000 b3ee0000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ef0000 b3ef3000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3f04000 b3f0b000 r-xp /usr/lib/libsensord-share.so
b3f1b000 b3f2c000 r-xp /usr/lib/libsensor.so.1.2.0
b3f3d000 b3f43000 r-xp /usr/lib/libappcore-common.so.1.1
b3f66000 b3f6b000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f81000 b3f83000 r-xp /usr/lib/libXau.so.6.0.0
b3f93000 b3fa7000 r-xp /usr/lib/libxcb.so.1.1.0
b3fb7000 b3fbe000 r-xp /lib/libcrypt-2.20-2014.11.so
b3ff6000 b3ff8000 r-xp /usr/lib/libiri.so
b4009000 b401e000 r-xp /lib/libexpat.so.1.5.2
b4030000 b407e000 r-xp /usr/lib/libssl.so.1.0.0
b4093000 b409c000 r-xp /usr/lib/libethumb.so.1.13.0
b40ad000 b40b0000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40c0000 b4277000 r-xp /usr/lib/libcrypto.so.1.0.0
b580e000 b5817000 r-xp /usr/lib/libXi.so.6.1.0
b5828000 b582a000 r-xp /usr/lib/libXgesture.so.7.0.0
b583a000 b583e000 r-xp /usr/lib/libXtst.so.6.1.0
b584e000 b5854000 r-xp /usr/lib/libXrender.so.1.3.0
b5864000 b586a000 r-xp /usr/lib/libXrandr.so.2.2.0
b587a000 b587c000 r-xp /usr/lib/libXinerama.so.1.0.0
b588c000 b588f000 r-xp /usr/lib/libXfixes.so.3.1.0
b58a0000 b58ab000 r-xp /usr/lib/libXext.so.6.4.0
b58bb000 b58bd000 r-xp /usr/lib/libXdamage.so.1.1.0
b58cd000 b58cf000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58df000 b59c2000 r-xp /usr/lib/libX11.so.6.3.0
b59d5000 b59dc000 r-xp /usr/lib/libXcursor.so.1.0.2
b59ed000 b5a05000 r-xp /usr/lib/libudev.so.1.6.0
b5a07000 b5a0a000 r-xp /lib/libattr.so.1.1.0
b5a1a000 b5a3a000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a3b000 b5a40000 r-xp /usr/lib/libffi.so.6.0.2
b5a50000 b5a68000 r-xp /lib/libz.so.1.2.8
b5a78000 b5a7a000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a8a000 b5b5f000 r-xp /usr/lib/libxml2.so.2.9.2
b5b74000 b5c0f000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c2b000 b5c2e000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c3e000 b5c58000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c68000 b5c79000 r-xp /lib/libresolv-2.20-2014.11.so
b5c8d000 b5ca4000 r-xp /usr/lib/liblzma.so.5.0.3
b5cb4000 b5cb6000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5cc6000 b5ccd000 r-xp /usr/lib/libembryo.so.1.13.0
b5cdd000 b5cf5000 r-xp /usr/lib/libpng12.so.0.50.0
b5d06000 b5d29000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d49000 b5d4f000 r-xp /lib/librt-2.20-2014.11.so
b5d60000 b5d74000 r-xp /usr/lib/libector.so.1.13.0
b5d85000 b5d9d000 r-xp /usr/lib/liblua-5.1.so
b5dae000 b5e05000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e19000 b5e41000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e52000 b5e65000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e76000 b5eb0000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ec1000 b5f2c000 r-xp /lib/libm-2.20-2014.11.so
b5f3d000 b5f4a000 r-xp /usr/lib/libeio.so.1.13.0
b5f5a000 b5f5c000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f6c000 b5f71000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f81000 b5f98000 r-xp /usr/lib/libefreet.so.1.13.0
b5faa000 b5fca000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fda000 b5ffa000 r-xp /usr/lib/libecore_con.so.1.13.0
b5ffc000 b6002000 r-xp /usr/lib/libecore_imf.so.1.13.0
b6012000 b6019000 r-xp /usr/lib/libethumb_client.so.1.13.0
b6029000 b6037000 r-xp /usr/lib/libeo.so.1.13.0
b6047000 b6059000 r-xp /usr/lib/libecore_input.so.1.13.0
b606a000 b606f000 r-xp /usr/lib/libecore_file.so.1.13.0
b607f000 b6097000 r-xp /usr/lib/libecore_evas.so.1.13.0
b60a8000 b60c5000 r-xp /usr/lib/libeet.so.1.13.0
b60de000 b6126000 r-xp /usr/lib/libeina.so.1.13.0
b6137000 b6147000 r-xp /usr/lib/libefl.so.1.13.0
b6158000 b623d000 r-xp /usr/lib/libicuuc.so.51.1
b625a000 b639a000 r-xp /usr/lib/libicui18n.so.51.1
b63b1000 b63e9000 r-xp /usr/lib/libecore_x.so.1.13.0
b63fb000 b63fe000 r-xp /lib/libcap.so.2.21
b640e000 b6437000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6448000 b644f000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6461000 b6497000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b64a8000 b6590000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b65a4000 b661a000 r-xp /usr/lib/libsqlite3.so.0.8.6
b662c000 b662f000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b663f000 b664a000 r-xp /usr/lib/libvconf.so.0.2.45
b665a000 b665c000 r-xp /usr/lib/libvasum.so.0.3.1
b666c000 b666e000 r-xp /usr/lib/libttrace.so.1.1
b667e000 b6681000 r-xp /usr/lib/libiniparser.so.0
b6691000 b66b4000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66c4000 b66c9000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66da000 b66f1000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6702000 b670f000 r-xp /usr/lib/libunwind.so.8.0.1
b6745000 b6869000 r-xp /lib/libc-2.20-2014.11.so
b687e000 b6897000 r-xp /lib/libgcc_s-4.9.so.1
b68a7000 b6989000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b699a000 b69ce000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69de000 b6a18000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a1a000 b6a9a000 r-xp /usr/lib/libedje.so.1.13.0
b6a9d000 b6abb000 r-xp /usr/lib/libecore.so.1.13.0
b6adb000 b6c3d000 r-xp /usr/lib/libevas.so.1.13.0
b6c74000 b6c88000 r-xp /lib/libpthread-2.20-2014.11.so
b6c9c000 b6ec0000 r-xp /usr/lib/libelementary.so.1.13.0
b6eee000 b6ef2000 r-xp /usr/lib/libsmack.so.1.0.0
b6f02000 b6f08000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6f19000 b6f1b000 r-xp /usr/lib/libdlog.so.0.0.0
b6f2b000 b6f2e000 r-xp /usr/lib/libbundle.so.0.1.22
b6f3e000 b6f40000 r-xp /lib/libdl-2.20-2014.11.so
b6f51000 b6f6a000 r-xp /usr/lib/libaul.so.0.1.0
b6f7c000 b6f7e000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f8f000 b6f93000 r-xp /usr/lib/libsys-assert.so
b6fa4000 b6fc4000 r-xp /lib/ld-2.20-2014.11.so
b6fd5000 b6fdb000 r-xp /usr/bin/launchpad-loader
b7575000 b77cb000 rw-p [heap]
beb55000 beb76000 rw-p [stack]
beb55000 beb76000 rw-p [stack]
End of Maps Information

Callstack Information (PID:2142)
Call Stack Count: 2
 0: eina_stringshare_del + 0x9 (0xb6106966) [/usr/lib/libeina.so.1] + 0x28966
 1: (0xb774f688) (null)
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
ta_inserted : 154] [SELECT count(*) FROM badge_data WHERE pkgname = 'org.example.sqlite'], count[0]
02-12 13:33:12.569+0900 E/cluster-home(  912): mainmenu-presenter.cpp: _ReorderAppsItems(618) >  Failed to get badge count [org.example.sqlite][-17956860][0]
02-12 13:33:12.569+0900 D/cluster-home(  912): mainmenu-presenter.cpp: _ReorderAppsItems(622) >  pageId[100001] appId[org.example.sqlite]
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: MoveMenuBox(768) >  MoveBox Name[sqlite] pos[4, 3] pageId[100001]
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[0]
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: MoveMenuBox(787) >  AddBoxToMenuView
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: AddBoxToMenuView(347) >  AddBox Name[sqlite] pageid[100001] pos[4, 3]
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: AddBoxToMenuView(354) >  menuPage.GetPageId() = 100001, boxPageId = 100001
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-page-impl.cpp: AddBoxToPage(112) >  void ClusterHome3D::Internal::CMainMenuPage::AddBoxToPage(std::shared_ptr<CMainMenuBoxData>) : 112
02-12 13:33:12.569+0900 D/cluster-view(  912): mainmenu-page-impl.cpp: AddBoxToPage(122) >  void ClusterHome3D::Internal::CMainMenuPage::AddBoxToPage(std::shared_ptr<CMainMenuBoxData>) : 122
02-12 13:33:12.569+0900 D/test-log(  912): mainmenu-page-impl.cpp: AddBoxToPage(123) >  create box[org.example.sqlite] [4,3]
02-12 13:33:12.569+0900 D/test-log(  912): mainmenu-box-impl.cpp: CMainMenuBox(148) >  create box
02-12 13:33:12.589+0900 D/test-log(  912): mainmenu-box-impl.cpp: SetPosition(459) >  cut Animation : sqlite
02-12 13:33:12.589+0900 D/test-log(  912): mainmenu-page-impl.cpp: AddBoxToPage(177) >  add created box
02-12 13:33:12.589+0900 E/cluster-home(  912): mainmenu-package-manager.cpp: GetAppInfo(523) >  Find a App Info AppId[org.tizen.videos] Name[Video] Icon[/usr/share/icons/default/small/org.tizen.videos.png] enable[1] system[1]
02-12 13:33:12.589+0900 D/BADGE   (  912): badge_internal.c: _badge_check_data_inserted(154) > [SECURE_LOG] [_badge_check_data_inserted : 154] [SELECT count(*) FROM badge_data WHERE pkgname = 'org.tizen.videos'], count[0]
02-12 13:33:12.589+0900 E/cluster-home(  912): mainmenu-presenter.cpp: _ReorderAppsItems(618) >  Failed to get badge count [org.tizen.videos][-17956860][0]
02-12 13:33:12.589+0900 D/cluster-home(  912): mainmenu-presenter.cpp: _ReorderAppsItems(622) >  pageId[100001] appId[org.tizen.videos]
02-12 13:33:12.589+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: MoveMenuBox(768) >  MoveBox Name[Video] pos[1, 4] pageId[100001]
02-12 13:33:12.589+0900 D/cluster-view(  912): mainmenu-page-impl.cpp: MoveMenuBox(976) >  Find box pageid[100001], boxid[12]
02-12 13:33:12.589+0900 D/cluster-view(  912): mainmenu-page-impl.cpp: MoveMenuBox(980) >  nBoxOrder[13], [1, 4]
02-12 13:33:12.589+0900 D/cluster-view(  912): mainmenu-page-impl.cpp: MoveMenuBox(1001) >  nOriBoxOrder[12], [4, 3]
02-12 13:33:12.589+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: MoveMenuBox(777) >  [1]th page, updated[1]
02-12 13:33:12.589+0900 D/cluster-view(  912): mainmenu-apps-view-impl.cpp: RearrangeItems(243) >  view type [1]
02-12 13:33:13.090+0900 D/rpm-installer( 2281): rpm-installer-privilege.c: __ri_privilege_perm_end(55) > [smack] perm_end, result=[0]
02-12 13:33:13.090+0900 D/rpm-installer( 2281): rpm-appcore-intf.c: main(259) > ------------------------------------------------
02-12 13:33:13.090+0900 D/rpm-installer( 2281): rpm-appcore-intf.c: main(260) >  [END] rpm-installer: result=[0]
02-12 13:33:13.090+0900 D/rpm-installer( 2281): rpm-appcore-intf.c: main(261) > ------------------------------------------------
02-12 13:33:13.090+0900 D/PKGMGR_SERVER( 2278): pkgmgr-server.c: sighandler(387) > child exit [2281]
02-12 13:33:13.090+0900 E/PKGMGR_SERVER( 2278): pkgmgr-server.c: sighandler(402) > child NORMAL exit [2281]
02-12 13:33:14.351+0900 E/PKGMGR_SERVER( 2278): pkgmgr-server.c: exit_server(1240) > exit_server Start [backend_status=1, queue_status=1, drm_status=1] 
02-12 13:33:14.351+0900 E/PKGMGR_SERVER( 2278): pkgmgr-server.c: main(2265) > package manager server terminated.
02-12 13:33:14.501+0900 D/eventsystem(  764): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:33:14.501+0900 D/eventsystem(  764): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:33:14.501+0900 D/eventsystem(  764): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:33:14.501+0900 D/eventsystem(  764): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:33:14.501+0900 D/eventsystem(  764): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:33:14.511+0900 D/DATA_PROVIDER_MASTER(  971): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:33:14.511+0900 E/DATA_PROVIDER_MASTER(  971): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 2, (3:lcdoff, 4:sleep)
02-12 13:33:14.531+0900 D/INDICATOR(  903): main.c: _indicator_notify_pm_state_cb(177) > LCD is dimmed
02-12 13:33:15.832+0900 D/eventsystem(  764): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:33:15.832+0900 D/eventsystem(  764): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:33:15.832+0900 D/eventsystem(  764): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:33:15.832+0900 D/eventsystem(  764): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:33:15.832+0900 D/eventsystem(  764): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:33:15.832+0900 D/DATA_PROVIDER_MASTER(  971): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:33:15.832+0900 E/DATA_PROVIDER_MASTER(  971): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:33:15.842+0900 D/INDICATOR(  903): main.c: _indicator_notify_pm_state_cb(169) > LCD is on
02-12 13:33:15.952+0900 D/test-log(  912): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-12 13:33:15.952+0900 D/PROCESSMGR(  537): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200033  register trigger_timer!  pointed_win=0x200075 
02-12 13:33:16.313+0900 D/AUL     ( 2336): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-12 13:33:16.313+0900 D/AUL     ( 2336): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-12 13:33:16.323+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(838) > __request_handler: 0
02-12 13:33:16.323+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-12 13:33:16.323+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:33:16.323+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/bin/launch_app' and package_app_info.app_disable IN ('false','False')
02-12 13:33:16.323+0900 I/AUL     (  804): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /usr/bin/launch_app, ret : 0
02-12 13:33:16.323+0900 D/AUL     (  804): pkginfo.c: aul_app_get_appid_bypid(255) > second change pgid = 2334, pid = 2336
02-12 13:33:16.323+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-12 13:33:16.323+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/bin/bash' and package_app_info.app_disable IN ('false','False')
02-12 13:33:16.333+0900 I/AUL     (  804): menu_db_util.h: _get_app_info_from_db_by_apppath(238) > path : /bin/bash, ret : 0
02-12 13:33:16.333+0900 E/AUL_AMD (  804): amd_launch.c: _start_app(2223) > no caller appid info, ret: -1
02-12 13:33:16.333+0900 W/AUL_AMD (  804): amd_launch.c: _start_app(2232) > caller pid : 2336
02-12 13:33:16.333+0900 E/AUL_AMD (  804): amd_appinfo.c: appinfo_get_value(881) > appinfo get value: Invalid argument, 17
02-12 13:33:16.333+0900 W/AUL_AMD (  804): amd_launch.c: __send_proc_prelaunch_signal(432) > [SECURE_LOG] send a prelaunch signal done: appid(org.example.sqlite) pkgid(org.example.sqlite) attribute(600)
02-12 13:33:16.343+0900 D/AUL_AMD (  804): amd_launch.c: _start_app(2646) > process_pool: false
02-12 13:33:16.343+0900 D/AUL_AMD (  804): amd_launch.c: _start_app(2649) > h/w acceleration: SYS
02-12 13:33:16.343+0900 D/AUL_AMD (  804): amd_launch.c: _start_app(2651) > [SECURE_LOG] appid: org.example.sqlite
02-12 13:33:16.343+0900 W/AUL_AMD (  804): amd_launch.c: _start_app(2663) > pad pid(-5)
02-12 13:33:16.343+0900 D/AUL_AMD (  804): amd_launch.c: __set_appinfo_for_launchpad(2947) > Add hwacc, taskmanage, app_path and pkg_type into bundle for sending those to launchpad.
02-12 13:33:16.343+0900 D/AUL_AMD (  804): amd_launch.c: __set_appinfo_for_launchpad(2950) > bundle_del error: -126
02-12 13:33:16.343+0900 D/AUL     (  804): app_sock.c: __app_send_raw(285) > pid(-5) : cmd(0)
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x1
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: main(696) > pfds[LAUNCH_PAD].revents & POLLIN
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __launchpad_main_loop(464) > [SECURE_LOG] pkg name : org.example.sqlite
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __launchpad_main_loop(488) > [SECURE_LOG] exec : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __launchpad_main_loop(490) > [SECURE_LOG] internal pool : false
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __launchpad_main_loop(491) > [SECURE_LOG] hwacc : SYS
02-12 13:33:16.343+0900 D/AUL_PAD (  956): process_pool.h: __get_launchpad_type(92) > [launchpad] launchpad type: COMMON(0)
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __modify_bundle(236) > parsing app_path: No arguments
02-12 13:33:16.343+0900 W/AUL_PAD (  956): launchpad.c: __launchpad_main_loop(510) > Launch on type-based process-pool
02-12 13:33:16.343+0900 D/AUL     (  956): process_pool.c: __send_pkt_raw_data(219) > send(12) : 616 / 616
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __send_launchpad_loader(413) > [SECURE_LOG] Request to candidate process, pid: 2142, bin path: /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:33:16.343+0900 W/AUL_PAD (  956): launchpad.c: __send_result_to_caller(265) > Check app launching
02-12 13:33:16.343+0900 D/AUL_PAD (  956): launchpad.c: __send_result_to_caller(297) > -- now wait cmdline changing --
02-12 13:33:16.343+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_proces_fd_handler(498) > [candidate] ECORE_FD_READ
02-12 13:33:16.343+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_proces_fd_handler(513) > [candidate] recv_ret: 616, pkt->len: 608
02-12 13:33:16.343+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(389) > [SECURE_LOG] app id: org.example.sqlite, launchpad type: 0
02-12 13:33:16.343+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __modify_bundle(276) > parsing app_path: No arguments
02-12 13:33:16.343+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(410) > [SECURE_LOG] app id: org.example.sqlite
02-12 13:33:16.343+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(425) > [SECURE_LOG] pkg id: org.example.sqlite
02-12 13:33:16.343+0900 D/AUL     ( 2142): smack_util.c: send_SIGUSR1_to_threads(127) > [SECURE_LOG] SIGUSR1 signal to the sub-thread (2143) is sent.
02-12 13:33:16.343+0900 D/AUL     ( 2142): smack_util.c: SIGUSR1_handler(75) > [SECURE_LOG] tid: 2143, signo: 10
02-12 13:33:16.343+0900 D/RESOURCED(  858): proc-monitor.c: proc_dbus_prelaunch_signal_handler(531) > call proc_dbus_prelaunch_handler: appid = org.example.sqlite, pkgid = org.example.sqlite, flags = 1536
02-12 13:33:16.343+0900 D/RESOURCED(  858): appinfo-list.c: resourced_appinfo_get(117) > appid org.example.sqlite, pkgname = org.example.sqlite, ref = 4
02-12 13:33:16.343+0900 E/RESOURCED(  858): heart-memory.c: heart_memory_get_data(601) > hashtable heart_memory_app_list is NULL
02-12 13:33:16.353+0900 D/AUL     ( 2142): smack_util.c: set_app_smack_label(198) > signal count: 1, launchpad type: 0
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_prepare_exec(297) > [SECURE_LOG] [candidata] pkg_name : org.example.sqlite / pkg_type : rpm / app_path : /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 0 : /opt/usr/apps/org.example.sqlite/bin/sqlite##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 1 : `zaybxcwdveuftgsh`##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 2 : __AUL_STARTTIME__##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 3 : NAAAAAEEAAASAAAAX19BVUxfU1RBUlRUSU1FX18AEgAAADE0MjM3MTU1OTYvMzI2MTc3AA==##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 4 : __AUL_CALLER_PID__##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 5 : KAAAAAEEAAATAAAAX19BVUxfQ0FMTEVSX1BJRF9fAAUAAAAyMzM2AA==##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 6 : __AUL_INTERNAL_POOL__##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_process_launchpad_main_loop(469) > [SECURE_LOG] input argument 7 : LAAAAAEEAAAWAAAAX19BVUxfSU5URVJOQUxfUE9PTF9fAAYAAABmYWxzZQA=##
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_proces_fd_handler(518) > [SECURE_LOG] [candidate] real app argv[0]: /opt/usr/apps/org.example.sqlite/bin/sqlite, real app argc: 8
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: __candidate_proces_fd_handler(522) > [candidate] ecore main loop quit
02-12 13:33:16.353+0900 D/AUL_PAD ( 2142): launchpad_loader.c: main(710) > [SECURE_LOG] [candidate] Launch real application (/opt/usr/apps/org.example.sqlite/bin/sqlite)
02-12 13:33:16.353+0900 I/CAPI_APPFW_APPLICATION( 2142): app_main.c: ui_app_main(788) > app_efl_main
02-12 13:33:16.353+0900 D/LAUNCH  ( 2142): appcore-efl.c: appcore_efl_main(1692) > [sqlite:Application:main:done]
02-12 13:33:16.353+0900 D/APP_CORE( 2142): appcore-efl.c: __before_loop(1114) > elm_config_preferred_engine_set is not called
02-12 13:33:16.353+0900 D/APP_CORE( 2142): appcore.c: appcore_init(738) > [SECURE_LOG] dir : /opt/usr/apps/org.example.sqlite/res/locale
02-12 13:33:16.353+0900 D/APP_CORE( 2142): appcore-i18n.c: update_region(94) > *****appcore setlocale=en_US.UTF-8
02-12 13:33:16.373+0900 D/APP_CORE( 2142): appcore.c: _appcore_init_suspend_dbus_handler(910) > [__SUSPEND__] suspend signal initialized
02-12 13:33:16.373+0900 D/AUL     ( 2142): app_sock.c: __create_server_sock(156) > pg path - already exists
02-12 13:33:16.373+0900 D/APP_CORE( 2142): appcore-efl.c: __before_loop(1134) > [SECURE_LOG] [__SUSPEND__] appcore initialized, appcore addr: 0xb3f52dd0
02-12 13:33:16.373+0900 D/LAUNCH  ( 2142): appcore-efl.c: __before_loop(1136) > [sqlite:Platform:appcore_init:done]
02-12 13:33:16.373+0900 I/CAPI_APPFW_APPLICATION( 2142): app_main.c: _ui_app_appcore_create(640) > app_appcore_create
02-12 13:33:16.443+0900 D/AUL_PAD (  956): launchpad.c: __send_result_to_caller(287) > -- now wait app mainloop creation --
02-12 13:33:16.443+0900 W/AUL     (  804): app_signal.c: aul_send_app_launch_request_signal(393) > send_app_launch_signal, pid: 2142, appid: org.example.sqlite
02-12 13:33:16.443+0900 D/AUL     (  804): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-12 13:33:16.443+0900 E/AUL     (  804): simple_util.c: __trm_app_info_send_socket(330) > access
02-12 13:33:16.443+0900 D/AUL_AMD (  804): amd_launch.c: _start_app(2698) > add app group info
02-12 13:33:16.443+0900 E/AUL     (  804): amd_app_group.c: app_group_start_app(1032) > app_group_start_app
02-12 13:33:16.443+0900 D/AUL_AMD (  804): amd_status.c: _status_add_app_info_list(427) > pid(2142) appid(org.example.sqlite) pkgid(org.example.sqlite) comp(uiapp)
02-12 13:33:16.443+0900 D/AUL     ( 2336): launch.c: app_request_to_launchpad(425) > launch request result : 2142
02-12 13:33:16.443+0900 D/RESOURCED(  858): proc-main.c: resourced_proc_status_change(876) > [SECURE_LOG] launch request org.example.sqlite, 2142
02-12 13:33:16.443+0900 D/RESOURCED(  858): proc-main.c: resourced_proc_status_change(878) > [SECURE_LOG] launch request org.example.sqlite with pkgname
02-12 13:33:16.573+0900 D/LAUNCH  ( 2142): appcore-efl.c: __before_loop(1154) > [sqlite:Application:create:done]
02-12 13:33:16.573+0900 E/E17     (  537): e_manager.c: _e_manager_cb_window_show_request(1134) > Show request(0x04800002)
02-12 13:33:16.573+0900 D/APP_CORE( 2142): appcore-efl.c: __check_wm_rotation_support(835) > Disable window manager rotation
02-12 13:33:16.583+0900 E/E17     (  537): e_border.c: e_border_show(2088) > BD_SHOW(0x04800002)
02-12 13:33:16.663+0900 W/PROCESSMGR(  537): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=2142
02-12 13:33:16.673+0900 E/EFL     (  537): eo<537> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:33:16.673+0900 E/EFL     (  537): eo<537> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:33:16.673+0900 D/APP_CORE( 2142): appcore.c: __aul_handler(587) > [APP 2142]     AUL event: AUL_START
02-12 13:33:16.673+0900 I/APP_CORE( 2142): appcore-efl.c: __do_app(496) > [APP 2142] Event: RESET State: CREATED
02-12 13:33:16.673+0900 D/APP_CORE( 2142): appcore-efl.c: __do_app(527) > [APP 2142] RESET
02-12 13:33:16.673+0900 D/LAUNCH  ( 2142): appcore-efl.c: __do_app(529) > [sqlite:Application:reset:start]
02-12 13:33:16.673+0900 D/APP_CORE( 2142): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
02-12 13:33:16.673+0900 D/APP_CORE( 2142): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:33:16.673+0900 I/CAPI_APPFW_APPLICATION( 2142): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
02-12 13:33:16.673+0900 D/AUL     ( 2142): service.c: __set_bundle(186) > __set_bundle
02-12 13:33:16.673+0900 D/LAUNCH  ( 2142): appcore-efl.c: __do_app(544) > [sqlite:Application:reset:done]
02-12 13:33:16.673+0900 D/APP_CORE( 2142): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : (null)
02-12 13:33:16.673+0900 E/EFL     ( 2142): edje<2142> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:33:16.673+0900 E/EFL     ( 2142): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:33:16.683+0900 E/EFL     ( 2142): edje<2142> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:33:16.683+0900 E/EFL     ( 2142): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:33:16.693+0900 D/INDICATOR(  903): main.c: _property_changed_cb(432) > UNSNIFF API 2400002
02-12 13:33:16.693+0900 E/EFL     ( 2142): edje<2142> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:33:16.693+0900 E/EFL     ( 2142): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:33:16.693+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:33:16.693+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:33:16.693+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:33:16.703+0900 D/AUL_AMD (  804): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 2142 is org.example.sqlite
02-12 13:33:16.703+0900 D/AUL     (  998): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
02-12 13:33:16.703+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 2142 : 0
02-12 13:33:16.763+0900 D/INDICATOR(  903): util.c: util_signal_emit_by_win(116) > emission bg.opaque
02-12 13:33:16.763+0900 D/INDICATOR(  903): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:33:16.763+0900 D/INDICATOR(  903): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:33:16.763+0900 D/INDICATOR(  903): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:33:16.763+0900 D/INDICATOR(  903): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:33:16.763+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xc484c0), gem(11), surface(0xcccbb0)
02-12 13:33:16.763+0900 W/APP_CORE( 2142): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4800002
02-12 13:33:16.763+0900 D/APP_CORE( 2142): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:4800002
02-12 13:33:16.763+0900 D/APP_CORE( 2142): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
02-12 13:33:16.763+0900 D/AUL     ( 2142): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
02-12 13:33:16.763+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(838) > __request_handler: 34
02-12 13:33:16.763+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xcc9368), gem(12), surface(0xd14e80)
02-12 13:33:16.783+0900 I/MALI    (  912): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
02-12 13:33:16.823+0900 D/APP_CORE( 2142): appcore.c: __prt_ltime(236) > [APP 2142] first idle after reset: 507 msec
02-12 13:33:16.843+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xcc3ea8), gem(14), surface(0xcf4e08)
02-12 13:33:16.843+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xcc9368), gem(12), surface(0xcf47f0)
02-12 13:33:16.843+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xcc3ea8), gem(14), surface(0xceb840)
02-12 13:33:16.853+0900 E/E17     (  537): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-12 13:33:16.853+0900 D/APP_CORE( 2142): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4800002 fully_obscured 0
02-12 13:33:16.853+0900 D/APP_CORE( 2142): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
02-12 13:33:16.853+0900 D/APP_CORE( 2142): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:33:16.853+0900 D/APP_CORE(  912): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-12 13:33:16.853+0900 D/APP_CORE(  912): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:33:16.853+0900 D/APP_CORE(  912): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:33:16.853+0900 I/APP_CORE(  912): appcore-efl.c: __do_app(496) > [APP 912] Event: PAUSE State: RUNNING
02-12 13:33:16.853+0900 D/APP_CORE(  912): appcore-efl.c: __do_app(565) > [APP 912] PAUSE
02-12 13:33:16.853+0900 I/CAPI_APPFW_APPLICATION(  912): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:33:16.853+0900 E/cluster-home(  912): homescreen.cpp: OnPause(84) >  app pause
02-12 13:33:16.853+0900 I/APP_CORE( 2142): appcore-efl.c: __do_app(496) > [APP 2142] Event: RESUME State: CREATED
02-12 13:33:16.853+0900 D/LAUNCH  ( 2142): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-12 13:33:16.853+0900 D/APP_CORE( 2142): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:33:16.853+0900 D/APP_CORE( 2142): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:33:16.853+0900 D/APP_CORE( 2142): appcore-efl.c: __do_app(607) > [APP 2142] RESUME
02-12 13:33:16.853+0900 D/cluster-view(  912): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-12 13:33:16.853+0900 D/cluster-view(  912): homescreen-view-manager.cpp: AppPause(923) >  END
02-12 13:33:16.853+0900 D/APP_CORE(  912): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:33:16.853+0900 E/APP_CORE(  912): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:33:16.853+0900 D/AUL_AMD (  804): amd_status.c: _status_update_app_info_list(456) > pid(912) status(4)
02-12 13:33:16.853+0900 D/AUL_AMD (  804): amd_status.c: _status_update_app_info_list(468) > pid(912) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-12 13:33:16.853+0900 D/AUL     (  804): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-12 13:33:16.853+0900 W/AUL     (  804): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 912, appid: org.tizen.homescreen, status: bg
02-12 13:33:16.863+0900 D/AUL_AMD (  804): amd_launch.c: __e17_status_handler(2887) > pid(2142) status(3)
02-12 13:33:16.863+0900 D/AUL_AMD (  804): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:33:16.863+0900 W/AUL_AMD (  804): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:33:16.863+0900 W/AUL_AMD (  804): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-12 13:33:16.863+0900 D/AUL_AMD (  804): amd_status.c: _status_update_app_info_list(456) > pid(2142) status(3)
02-12 13:33:16.863+0900 D/AUL_AMD (  804): amd_status.c: _status_update_app_info_list(468) > pid(2142) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-12 13:33:16.863+0900 D/AUL     (  804): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-12 13:33:16.863+0900 W/AUL     (  804): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 2142, appid: org.example.sqlite, status: fg
02-12 13:33:16.863+0900 D/RESOURCED(  858): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 2142
02-12 13:33:16.863+0900 D/RESOURCED(  858): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 2142, proc_name: ---, cg_name: foreground, oom_score_adj: 200
02-12 13:33:16.863+0900 D/RESOURCED(  858): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 2142
02-12 13:33:16.863+0900 D/DATA_PROVIDER_MASTER(  971): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 912 is paused
02-12 13:33:16.863+0900 D/DATA_PROVIDER_MASTER(  971): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:33:16.873+0900 I/APP_CORE( 2142): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
02-12 13:33:16.873+0900 I/APP_CORE( 2142): appcore-efl.c: __do_app(614) > [APP 2142] Initial Launching, call the resume_cb
02-12 13:33:16.873+0900 I/CAPI_APPFW_APPLICATION( 2142): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:33:16.873+0900 D/LAUNCH  ( 2142): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-12 13:33:16.873+0900 D/LAUNCH  ( 2142): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-12 13:33:16.873+0900 D/APP_CORE( 2142): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:33:16.873+0900 E/APP_CORE( 2142): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:33:16.983+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xbc5068), gem(10), surface(0xd0fb40)
02-12 13:33:17.053+0900 D/AUL_AMD (  804): amd_launch.c: __e17_status_handler(2906) > pid(2142) status(0)
02-12 13:33:17.053+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xc68410), gem(10), surface(0xcf9978)
02-12 13:33:17.444+0900 D/AUL_PAD (  956): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
02-12 13:33:17.464+0900 D/AUL_PAD ( 2338): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
02-12 13:33:17.474+0900 D/AUL_PAD (  956): sigchild.h: __send_app_launch_signal(130) > send launch signal done
02-12 13:33:17.484+0900 E/RESOURCED(  858): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.248
02-12 13:33:17.944+0900 D/AUL_AMD (  804): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:33:17.944+0900 D/RUA     (  804): rua.c: rua_add_history(179) > rua_add_history start
02-12 13:33:17.954+0900 D/RUA     (  804): rua.c: rua_add_history(247) > rua_add_history ok
02-12 13:33:18.495+0900 D/PROCESSMGR(  537): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200033  register trigger_timer!  pointed_win=0x2007f8 
02-12 13:33:18.565+0900 D/AUL_PAD ( 2338): launchpad_loader.c: main(588) > sleeping 1 sec...
02-12 13:33:18.565+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(52) > max_cmdline_size = 1053
02-12 13:33:18.585+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b80e0768
02-12 13:33:18.585+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:33:18.585+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(73) > get shutdown function
02-12 13:33:18.585+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b80e0a48
02-12 13:33:18.605+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b80e25b0
02-12 13:33:18.605+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(69) > get pre-initialization function
02-12 13:33:18.605+0900 D/AUL_PAD ( 2338): preload.h: __preload_init(73) > get shutdown function
02-12 13:33:18.605+0900 D/AUL_PAD ( 2338): preexec.h: __preexec_init(76) > preexec start
02-12 13:33:18.605+0900 D/AUL_PAD ( 2338): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
02-12 13:33:18.605+0900 D/AUL     ( 2338): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
02-12 13:33:18.605+0900 D/AUL     ( 2338): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
02-12 13:33:18.605+0900 D/AUL_PAD (  956): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 2338
02-12 13:33:18.605+0900 D/AUL     ( 2338): process_pool.c: __connect_to_launchpad(132) > send(2338) : 4
02-12 13:33:18.605+0900 D/AUL     ( 2338): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
02-12 13:33:18.825+0900 D/AUL_PAD ( 2338): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
02-12 13:33:18.855+0900 D/AUL_PAD ( 2338): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
02-12 13:33:18.855+0900 D/AUL_PAD ( 2338): launchpad_loader.c: main(693) > [candidate] ecore handler add
02-12 13:33:18.855+0900 D/AUL_PAD ( 2338): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
02-12 13:33:18.965+0900 D/AUL_PAD (  956): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
02-12 13:33:18.965+0900 I/AUL_PAD (  956): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 2142 pgid = 2142
02-12 13:33:18.965+0900 I/AUL_PAD (  956): sigchild.h: __sigchild_action(141) > dead_pid(2142)
02-12 13:33:18.965+0900 E/EFL     (  537): eo<537> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:33:18.995+0900 E/E17     (  537): e_border.c: e_border_show(2088) > BD_SHOW(0x02400002)
02-12 13:33:18.995+0900 E/E17     (  537): e_border.c: e_border_hide(2248) > BD_HIDE(0x04800002), visible:1
02-12 13:33:18.995+0900 D/INDICATOR(  903): main.c: _property_changed_cb(432) > UNSNIFF API 4800002
02-12 13:33:18.995+0900 D/INDICATOR(  903): util.c: util_signal_emit_by_win(116) > emission bg.translucent
02-12 13:33:19.005+0900 D/INDICATOR(  903): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:33:19.005+0900 D/INDICATOR(  903): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:33:19.005+0900 D/INDICATOR(  903): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:33:19.005+0900 D/INDICATOR(  903): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:33:19.005+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xcc9368), gem(12), surface(0xd14108)
02-12 13:33:19.005+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xcc3ea8), gem(14), surface(0xceec98)
02-12 13:33:19.015+0900 W/PROCESSMGR(  537): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=912
02-12 13:33:19.015+0900 D/PROCESSMGR(  537): e_mod_processmgr.c: _e_mod_processmgr_wininfo_del(160) > [PROCESSMGR] delete anr_trigger_timer!
02-12 13:33:19.025+0900 D/AUL_AMD (  804): amd_launch.c: __e17_status_handler(2887) > pid(912) status(3)
02-12 13:33:19.025+0900 D/AUL_AMD (  804): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:33:19.025+0900 W/AUL_AMD (  804): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:33:19.025+0900 W/AUL_AMD (  804): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-12 13:33:19.025+0900 D/AUL_AMD (  804): amd_status.c: _status_update_app_info_list(456) > pid(912) status(3)
02-12 13:33:19.025+0900 D/AUL_AMD (  804): amd_status.c: _status_update_app_info_list(468) > pid(912) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
02-12 13:33:19.025+0900 D/AUL     (  804): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
02-12 13:33:19.025+0900 W/AUL     (  804): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 912, appid: org.tizen.homescreen, status: fg
02-12 13:33:19.025+0900 D/RESOURCED(  858): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 912
02-12 13:33:19.025+0900 D/RESOURCED(  858): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 912, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
02-12 13:33:19.025+0900 D/RESOURCED(  858): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 912, appname = org.tizen.homescreen
02-12 13:33:19.025+0900 D/RESOURCED(  858): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 912
02-12 13:33:19.025+0900 E/RESOURCED(  858): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 912 foreground
02-12 13:33:19.025+0900 E/EFL     (  537): eo<537> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 0
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:33:19.025+0900 I/APP_CORE(  912): appcore-efl.c: __do_app(496) > [APP 912] Event: RESUME State: PAUSED
02-12 13:33:19.025+0900 D/LAUNCH  (  912): appcore-efl.c: __do_app(597) > [homescreen:Application:resume:start]
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __do_app(607) > [APP 912] RESUME
02-12 13:33:19.025+0900 I/CAPI_APPFW_APPLICATION(  912): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:33:19.025+0900 E/cluster-home(  912): homescreen.cpp: OnResume(66) >  app resume
02-12 13:33:19.025+0900 D/cluster-home(  912): widget-data-provider.cpp: SetBoxVisibility(1519) >  
02-12 13:33:19.025+0900 D/cluster-home(  912): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[1]
02-12 13:33:19.025+0900 D/WIDGET_VIEWER(  912): widget.c: widget_viewer_set_visibility(3865) > [SECURE_LOG] org.tizen.calendar.widget has no changes
02-12 13:33:19.025+0900 D/cluster-home(  912): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[2]
02-12 13:33:19.025+0900 D/cluster-home(  912): widget-data-provider.cpp: SetBoxVisibility(1528) >  No boxes in page[2]
02-12 13:33:19.025+0900 D/cluster-view(  912): homescreen-view-manager.cpp: AppResume(892) >  BEGIN
02-12 13:33:19.025+0900 D/cluster-view(  912): homescreen-view-manager.cpp: AppResume(910) >  END
02-12 13:33:19.025+0900 D/cluster-view(  912): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:33:19.025+0900 D/cluster-view(  912): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:33:19.025+0900 D/cluster-view(  912): homescreen-page-indicator.cpp: CancelOperation(300) >  CancelOperation
02-12 13:33:19.025+0900 D/cluster-view(  912): cluster-impl.cpp: ScrollToFitPage(466) >  ScrollToFitPage
02-12 13:33:19.025+0900 D/cluster-view(  912): cluster-impl.cpp: OnScrollSnapStart(613) >  TODO current page[1] new page[1]
02-12 13:33:19.025+0900 D/cluster-view(  912): cluster-impl.cpp: OnScrollSnapStart(623) >  TODO current page[1] new page[1]
02-12 13:33:19.025+0900 D/test-log(  912): cluster-impl.cpp: SetFocusedPage(791) >  Set mFocusedPage: 2
02-12 13:33:19.025+0900 D/test-log(  912): cluster-impl.cpp: GetFocusedPage(798) >  mFocusedPage: 2
02-12 13:33:19.025+0900 D/cluster-view(  912): cluster-view-controller.cpp: OnClusterChangeFocusedPage(1779) >  Cluster[0:] 2 page focused
02-12 13:33:19.025+0900 D/cluster-home(  912): widget-data-provider.cpp: OnCustomClusterFocusedPageChanged(2910) >  Cluster[0] page[2] focused
02-12 13:33:19.025+0900 D/LAUNCH  (  912): appcore-efl.c: __do_app(636) > [homescreen:Application:resume:done]
02-12 13:33:19.025+0900 D/LAUNCH  (  912): appcore-efl.c: __do_app(638) > [homescreen:Application:Launching:done]
02-12 13:33:19.025+0900 D/APP_CORE(  912): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:33:19.025+0900 E/APP_CORE(  912): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:33:19.035+0900 D/DATA_PROVIDER_MASTER(  971): xmonitor.c: xmonitor_resume(339) > [SECURE_LOG] 912 is resumed
02-12 13:33:19.035+0900 D/DATA_PROVIDER_MASTER(  971): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:33:19.045+0900 E/DATA_PROVIDER_MASTER(  971): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:33:19.065+0900 D/AUL_PAD (  956): sigchild.h: __send_app_dead_signal(90) > send dead signal done
02-12 13:33:19.065+0900 I/AUL_PAD (  956): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
02-12 13:33:19.065+0900 I/AUL_PAD (  956): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
02-12 13:33:19.065+0900 E/AUL_PAD (  956): launchpad.c: main(688) > error reading sigchld info
02-12 13:33:19.065+0900 I/TIZEN_N_SOUND_MANAGER(  998): sound_manager.c: sound_manager_get_volume(77) > returns : type=0, volume=9, ret=0x0
02-12 13:33:19.065+0900 E/TIZEN_N_SOUND_MANAGER(  998): sound_manager_private.c: __convert_sound_manager_error_code(70) > [sound_manager_get_volume(79)] ERROR_NONE(0x00000000) : core frameworks error code(0x00000000)
02-12 13:33:19.065+0900 I/TIZEN_N_SOUND_MANAGER(  998): sound_manager.c: sound_manager_get_volume(77) > returns : type=4, volume=7, ret=0x0
02-12 13:33:19.065+0900 E/TIZEN_N_SOUND_MANAGER(  998): sound_manager_private.c: __convert_sound_manager_error_code(70) > [sound_manager_get_volume(79)] ERROR_NONE(0x00000000) : core frameworks error code(0x00000000)
02-12 13:33:19.065+0900 I/ESD     (  989): esd_main.c: __esd_app_dead_handler(1771) > pid: 2142
02-12 13:33:19.065+0900 I/MALI    (  537): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xc484c0), gem(11), surface(0xcf4e08)
02-12 13:33:19.065+0900 D/STARTER (  860): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 2142 is termianted
02-12 13:33:19.065+0900 D/STARTER (  860): starter.c: _check_dead_signal(202) > [_check_dead_signal:202] Unknown process, ignore it
02-12 13:33:19.065+0900 W/AUL_AMD (  804): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 2142
02-12 13:33:19.065+0900 W/AUL_AMD (  804): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 2142
02-12 13:33:19.065+0900 D/AUL_AMD (  804): amd_key.c: _unregister_key_event(179) > ===key stack===
02-12 13:33:19.065+0900 E/AUL_AMD (  804): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
02-12 13:33:19.065+0900 D/AUL_AMD (  804): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.example.sqlite)
02-12 13:33:19.065+0900 D/AUL     (  804): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
02-12 13:33:19.065+0900 E/AUL     (  804): simple_util.c: __trm_app_info_send_socket(330) > access
02-12 13:33:19.065+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:33:19.065+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/apps/org.tizen.homescreen/bin/homescreen' and package_app_info.app_disable IN ('false','False')
02-12 13:33:19.065+0900 D/PKGMGR_INFO(  804): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/apps/org.tizen.homescreen/bin/homescreen' and package_app_info.app_disable IN ('false','False')
02-12 13:33:19.075+0900 E/RESOURCED(  858): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.253
02-12 13:33:19.075+0900 D/AUL_AMD (  804): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 912 is org.tizen.homescreen
02-12 13:33:19.075+0900 D/AUL_AMD (  804): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 912 : 0
02-12 13:33:19.075+0900 D/AUL     (  998): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 29
02-12 13:33:19.085+0900 D/RESOURCED(  858): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 2142
02-12 13:33:19.115+0900 W/CRASH_MANAGER( 2342): worker.c: worker_job(1204) > 110214273716c142371559
