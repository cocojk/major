S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: sqlite
PID: 1520
Date: 2015-02-12 13:12:10+0900
Executable File Path: /opt/usr/apps/org.example.sqlite/bin/sqlite
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x2f

Register Information
r0   = 0xb7b66390, r1   = 0x0000002f
r2   = 0xffffffff, r3   = 0x0000002f
r4   = 0x0000002f, r5   = 0x8001e2f2
r6   = 0x00000000, r7   = 0x00000012
r8   = 0x00000000, r9   = 0x000002d0
r10  = 0xb18fd240, fp   = 0x00000000
ip   = 0x00000002, sp   = 0xb18fd1c8
lr   = 0x00000000, pc   = 0xb6b2c8ec
cpsr = 0x60000030

Memory Information
MemTotal:   987264 KB
MemFree:    565904 KB
Buffers:     15704 KB
Cached:     132372 KB
VmPeak:     128944 KB
VmSize:     128940 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       21396 KB
VmRSS:       21396 KB
VmData:      43184 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       22324 KB
VmPTE:          78 KB
VmSwap:          0 KB

Threads Information
Threads: 5
PID = 1520 TID = 1765
1520 1523 1763 1765 1766 

Maps Information
af678000 afe77000 rw-p [stack:1766]
b1101000 b1900000 rw-p [stack:1765]
b1a69000 b2268000 rw-p [stack:1763]
b2f5d000 b2f62000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2fee000 b2ff6000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b3007000 b3008000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3018000 b301f000 r-xp /usr/lib/libfeedback.so.0.1.4
b3043000 b3056000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b306a000 b306f000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b307f000 b3080000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b3090000 b3093000 r-xp /usr/lib/libxcb-sync.so.1.0.0
b30a4000 b30a5000 r-xp /usr/lib/libxshmfence.so.1.0.0
b30b5000 b30b7000 r-xp /usr/lib/libxcb-present.so.0.0.0
b30c7000 b30c9000 r-xp /usr/lib/libxcb-dri3.so.0.0.0
b30d9000 b30e1000 r-xp /usr/lib/libdrm.so.2.4.0
b30f1000 b30f3000 r-xp /usr/lib/libdri2.so.0.0.0
b3103000 b310b000 r-xp /usr/lib/libtbm.so.1.0.0
b311b000 b311c000 r-xp /usr/lib/libgthread-2.0.so.0.4400.1
b312e000 b312f000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b313f000 b314b000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b315c000 b3163000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3175000 b3185000 r-xp /usr/lib/evas/modules/engines/software_x11/v-1.13/module.so
b328d000 b3291000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32a2000 b3382000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3398000 b339c000 r-xp /opt/usr/apps/org.example.sqlite/bin/sqlite
b33a4000 b33cb000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33de000 b3bdd000 rw-p [stack:1523]
b3bdd000 b3bdf000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3def000 b3df8000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e09000 b3e12000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e23000 b3e34000 r-xp /lib/libnsl-2.20-2014.11.so
b3e47000 b3e4d000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e5e000 b3e78000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e89000 b3e8a000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e9a000 b3e9c000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ead000 b3eb2000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ec2000 b3ec5000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ed6000 b3edd000 r-xp /usr/lib/libsensord-share.so
b3eed000 b3efe000 r-xp /usr/lib/libsensor.so.1.2.0
b3f0f000 b3f15000 r-xp /usr/lib/libappcore-common.so.1.1
b3f38000 b3f3d000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f53000 b3f55000 r-xp /usr/lib/libXau.so.6.0.0
b3f65000 b3f79000 r-xp /usr/lib/libxcb.so.1.1.0
b3f89000 b3f90000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fc8000 b3fca000 r-xp /usr/lib/libiri.so
b3fdb000 b3ff0000 r-xp /lib/libexpat.so.1.5.2
b4002000 b4050000 r-xp /usr/lib/libssl.so.1.0.0
b4065000 b406e000 r-xp /usr/lib/libethumb.so.1.13.0
b407f000 b4082000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4092000 b4249000 r-xp /usr/lib/libcrypto.so.1.0.0
b57e0000 b57e9000 r-xp /usr/lib/libXi.so.6.1.0
b57fa000 b57fc000 r-xp /usr/lib/libXgesture.so.7.0.0
b580c000 b5810000 r-xp /usr/lib/libXtst.so.6.1.0
b5820000 b5826000 r-xp /usr/lib/libXrender.so.1.3.0
b5836000 b583c000 r-xp /usr/lib/libXrandr.so.2.2.0
b584c000 b584e000 r-xp /usr/lib/libXinerama.so.1.0.0
b585e000 b5861000 r-xp /usr/lib/libXfixes.so.3.1.0
b5872000 b587d000 r-xp /usr/lib/libXext.so.6.4.0
b588d000 b588f000 r-xp /usr/lib/libXdamage.so.1.1.0
b589f000 b58a1000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58b1000 b5994000 r-xp /usr/lib/libX11.so.6.3.0
b59a7000 b59ae000 r-xp /usr/lib/libXcursor.so.1.0.2
b59bf000 b59d7000 r-xp /usr/lib/libudev.so.1.6.0
b59d9000 b59dc000 r-xp /lib/libattr.so.1.1.0
b59ec000 b5a0c000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a0d000 b5a12000 r-xp /usr/lib/libffi.so.6.0.2
b5a22000 b5a3a000 r-xp /lib/libz.so.1.2.8
b5a4a000 b5a4c000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a5c000 b5b31000 r-xp /usr/lib/libxml2.so.2.9.2
b5b46000 b5be1000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bfd000 b5c00000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c10000 b5c2a000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c3a000 b5c4b000 r-xp /lib/libresolv-2.20-2014.11.so
b5c5f000 b5c76000 r-xp /usr/lib/liblzma.so.5.0.3
b5c86000 b5c88000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c98000 b5c9f000 r-xp /usr/lib/libembryo.so.1.13.0
b5caf000 b5cc7000 r-xp /usr/lib/libpng12.so.0.50.0
b5cd8000 b5cfb000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d1b000 b5d21000 r-xp /lib/librt-2.20-2014.11.so
b5d32000 b5d46000 r-xp /usr/lib/libector.so.1.13.0
b5d57000 b5d6f000 r-xp /usr/lib/liblua-5.1.so
b5d80000 b5dd7000 r-xp /usr/lib/libfreetype.so.6.11.3
b5deb000 b5e13000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e24000 b5e37000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e48000 b5e82000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e93000 b5efe000 r-xp /lib/libm-2.20-2014.11.so
b5f0f000 b5f1c000 r-xp /usr/lib/libeio.so.1.13.0
b5f2c000 b5f2e000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f3e000 b5f43000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f53000 b5f6a000 r-xp /usr/lib/libefreet.so.1.13.0
b5f7c000 b5f9c000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fac000 b5fcc000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fce000 b5fd4000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fe4000 b5feb000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5ffb000 b6009000 r-xp /usr/lib/libeo.so.1.13.0
b6019000 b602b000 r-xp /usr/lib/libecore_input.so.1.13.0
b603c000 b6041000 r-xp /usr/lib/libecore_file.so.1.13.0
b6051000 b6069000 r-xp /usr/lib/libecore_evas.so.1.13.0
b607a000 b6097000 r-xp /usr/lib/libeet.so.1.13.0
b60b0000 b60f8000 r-xp /usr/lib/libeina.so.1.13.0
b6109000 b6119000 r-xp /usr/lib/libefl.so.1.13.0
b612a000 b620f000 r-xp /usr/lib/libicuuc.so.51.1
b622c000 b636c000 r-xp /usr/lib/libicui18n.so.51.1
b6383000 b63bb000 r-xp /usr/lib/libecore_x.so.1.13.0
b63cd000 b63d0000 r-xp /lib/libcap.so.2.21
b63e0000 b6409000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b641a000 b6421000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6433000 b6469000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b647a000 b6562000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6576000 b65ec000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65fe000 b6601000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6611000 b661c000 r-xp /usr/lib/libvconf.so.0.2.45
b662c000 b662e000 r-xp /usr/lib/libvasum.so.0.3.1
b663e000 b6640000 r-xp /usr/lib/libttrace.so.1.1
b6650000 b6653000 r-xp /usr/lib/libiniparser.so.0
b6663000 b6686000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6696000 b669b000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66ac000 b66c3000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66d4000 b66e1000 r-xp /usr/lib/libunwind.so.8.0.1
b6717000 b683b000 r-xp /lib/libc-2.20-2014.11.so
b6850000 b6869000 r-xp /lib/libgcc_s-4.9.so.1
b6879000 b695b000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b696c000 b69a0000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69b0000 b69ea000 r-xp /usr/lib/libsystemd.so.0.4.0
b69ec000 b6a6c000 r-xp /usr/lib/libedje.so.1.13.0
b6a6f000 b6a8d000 r-xp /usr/lib/libecore.so.1.13.0
b6aad000 b6c0f000 r-xp /usr/lib/libevas.so.1.13.0
b6c46000 b6c5a000 r-xp /lib/libpthread-2.20-2014.11.so
b6c6e000 b6e92000 r-xp /usr/lib/libelementary.so.1.13.0
b6ec0000 b6ec4000 r-xp /usr/lib/libsmack.so.1.0.0
b6ed4000 b6eda000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6eeb000 b6eed000 r-xp /usr/lib/libdlog.so.0.0.0
b6efd000 b6f00000 r-xp /usr/lib/libbundle.so.0.1.22
b6f10000 b6f12000 r-xp /lib/libdl-2.20-2014.11.so
b6f23000 b6f3c000 r-xp /usr/lib/libaul.so.0.1.0
b6f4e000 b6f50000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f61000 b6f65000 r-xp /usr/lib/libsys-assert.so
b6f76000 b6f96000 r-xp /lib/ld-2.20-2014.11.so
b6fa7000 b6fad000 r-xp /usr/bin/launchpad-loader
b7967000 b7bbe000 rw-p [heap]
be800000 be821000 rw-p [stack]
be800000 be821000 rw-p [stack]
End of Maps Information

Callstack Information (PID:1520)
Call Stack Count: 13
 0: (0xb6b2c8ec) [/usr/lib/libevas.so.1] + 0x7f8ec
 1: (0xb6b2db27) [/usr/lib/libevas.so.1] + 0x80b27
 2: evas_textblock_cursor_geometry_bidi_get + 0xd2 (0xb6b3024b) [/usr/lib/libevas.so.1] + 0x8324b
 3: (0xb6a370fd) [/usr/lib/libedje.so.1] + 0x4b0fd
 4: (0xb6a544cb) [/usr/lib/libedje.so.1] + 0x684cb
 5: (0xb6a56fe5) [/usr/lib/libedje.so.1] + 0x6afe5
 6: edje_obj_part_text_append + 0x62 (0xb6a48327) [/usr/lib/libedje.so.1] + 0x5c327
 7: edje_object_part_text_append + 0x2a (0xb6a4fde3) [/usr/lib/libedje.so.1] + 0x63de3
 8: elm_obj_entry_append + 0x5c (0xb6d3d081) [/usr/lib/libelementary.so.1] + 0xcf081
 9: elm_entry_entry_append + 0x26 (0xb6d47ecb) [/usr/lib/libelementary.so.1] + 0xd9ecb
10: _add_entry_text + 0x28 (0xb339986d) [/opt/usr/apps/org.example.sqlite/bin/sqlite] + 0x186d
11: (0xb3f2752b) (null)
12: (0xb65fd12c) [/usr/lib/libsqlite3.so.0] + 0xb65fd12c
End of Call Stack

Package Information
Package Name: org.example.sqlite
Package ID : org.example.sqlite
Version: 1.0.0
Package Type: tpk
App Name: sqlite
App ID: org.example.sqlite
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
) You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:11:42.705+0900 E/EFL     ( 1520): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:11:43.416+0900 E/EFL     ( 1520): edje<1520> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:11:43.416+0900 E/EFL     ( 1520): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:11:44.156+0900 E/EFL     ( 1520): edje<1520> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
02-12 13:11:44.156+0900 E/EFL     ( 1520): By the power of Grayskull, your previous Embryo stack is now broken!
02-12 13:11:44.326+0900 W/APP_CORE( 1520): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4600002
02-12 13:11:44.326+0900 D/APP_CORE( 1520): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:4600002
02-12 13:11:44.326+0900 D/APP_CORE( 1520): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
02-12 13:11:44.326+0900 D/AUL     ( 1520): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
02-12 13:11:44.326+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 34
02-12 13:11:46.248+0900 D/APP_CORE( 1520): appcore.c: __prt_ltime(236) > [APP 1520] first idle after reset: 12303 msec
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:138 _ecore_evas_idle_enter() stuck async render: time=3.587894, ee=0xb7a4a0a8, engine=software_x11, geometry=(0, 0, 720, 1280), visible=1, shaped=0, alpha=0, transparent=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:140 _ecore_evas_idle_enter() delayed.avoid_damage=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:141 _ecore_evas_idle_enter() delayed.resize_shape=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:142 _ecore_evas_idle_enter() delayed.shaped=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:143 _ecore_evas_idle_enter() delayed.shaped_changed=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:144 _ecore_evas_idle_enter() delayed.alpha=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:145 _ecore_evas_idle_enter() delayed.alpha_changed=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:146 _ecore_evas_idle_enter() delayed.transparent=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:147 _ecore_evas_idle_enter() delayed.transparent_changed=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:148 _ecore_evas_idle_enter() delayed.rotation=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:149 _ecore_evas_idle_enter() delayed.rotation_resize=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:150 _ecore_evas_idle_enter() delayed.rotation_changed=0
02-12 13:11:46.258+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:152 _ecore_evas_idle_enter() reset in_async_render of ee=0xb7a4a0a8
02-12 13:11:46.308+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1222080), gem(16), surface(0x125be20)
02-12 13:11:46.318+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11ee928), gem(10), surface(0x11d86b0)
02-12 13:11:46.318+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1222080), gem(16), surface(0x1252d20)
02-12 13:11:46.328+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-12 13:11:46.328+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-12 13:11:46.328+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:11:46.328+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:11:46.328+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: PAUSE State: RUNNING
02-12 13:11:46.328+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(565) > [APP 911] PAUSE
02-12 13:11:46.328+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:11:46.328+0900 E/cluster-home(  911): homescreen.cpp: OnPause(84) >  app pause
02-12 13:11:46.328+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-12 13:11:46.328+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(923) >  END
02-12 13:11:46.328+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:11:46.328+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:11:46.338+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(911) status(4)
02-12 13:11:46.338+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-12 13:11:46.338+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-12 13:11:46.338+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: bg
02-12 13:11:46.338+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2887) > pid(1520) status(3)
02-12 13:11:46.338+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:11:46.338+0900 W/AUL_AMD (  812): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:11:46.338+0900 W/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-12 13:11:46.338+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1520) status(3)
02-12 13:11:46.338+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1520) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-12 13:11:46.338+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-12 13:11:46.338+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1520, appid: org.example.sqlite, status: fg
02-12 13:11:46.338+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1520
02-12 13:11:46.338+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1520, proc_name: ---, cg_name: foreground, oom_score_adj: 200
02-12 13:11:46.338+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 1520
02-12 13:11:46.338+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 911 is paused
02-12 13:11:46.338+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:11:46.338+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_pause_cb(292) > widget obj was paused
02-12 13:11:46.338+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(142) > enter background group
02-12 13:11:46.338+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: bg
02-12 13:11:46.398+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
02-12 13:11:46.398+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
02-12 13:11:46.398+0900 D/APP_CORE( 1520): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600002 fully_obscured 0
02-12 13:11:46.398+0900 D/APP_CORE( 1520): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
02-12 13:11:46.398+0900 D/APP_CORE( 1520): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:11:46.398+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(496) > [APP 1520] Event: RESUME State: CREATED
02-12 13:11:46.398+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-12 13:11:46.398+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:11:46.398+0900 D/APP_CORE( 1520): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:11:46.398+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(607) > [APP 1520] RESUME
02-12 13:11:46.499+0900 D/RESOURCED(  868): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
02-12 13:11:46.499+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
02-12 13:11:46.529+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2906) > pid(1520) status(0)
02-12 13:11:46.929+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
02-12 13:11:46.929+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(614) > [APP 1520] Initial Launching, call the resume_cb
02-12 13:11:46.929+0900 I/CAPI_APPFW_APPLICATION( 1520): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:11:46.929+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-12 13:11:46.929+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-12 13:11:46.929+0900 D/APP_CORE( 1520): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:11:46.929+0900 E/APP_CORE( 1520): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:11:51.333+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
02-12 13:11:51.333+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: MEM_FLUSH State: PAUSED
02-12 13:11:51.333+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
02-12 13:11:51.333+0900 D/APP_CORE(  911): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 911
02-12 13:11:51.333+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
02-12 13:11:51.333+0900 D/RESOURCED(  868): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 911
02-12 13:11:52.314+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:11:52.314+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:11:52.314+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:11:52.314+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:11:52.314+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:11:52.314+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:11:52.364+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(177) > LCD is dimmed
02-12 13:11:54.336+0900 D/eventsystem(  770): eventsystem.c: eventsystem_send_system_event(1011) > event_name(tizen.system.event.display_state)
02-12 13:11:54.336+0900 D/eventsystem(  770): eventsystem.c: __get_member_name_from_eventname(259) > member_name(display_state)
02-12 13:11:54.336+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(851) > interface_name(tizen.system.event)
02-12 13:11:54.336+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(852) > object_path(/tizen/system/event)
02-12 13:11:54.336+0900 D/eventsystem(  770): eventsystem.c: __eventsystem_send_event(853) > member_name(display_state)
02-12 13:11:54.346+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:11:54.386+0900 D/INDICATOR(  886): main.c: _indicator_notify_pm_state_cb(169) > LCD is on
02-12 13:11:55.027+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20064d 
02-12 13:11:56.028+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x4600002
02-12 13:11:58.530+0900 D/RESOURCED(  868): logging.c: logging_send_signal_to_data(1097) > logging timer callback function start
02-12 13:11:58.530+0900 I/RESOURCED(  868): logging.c: logging_send_signal_to_data(1106) > send signal to logging data thread
02-12 13:11:58.530+0900 D/RESOURCED(  868): logging.c: logging_send_signal_to_update(1177) > logging timer callback function start
02-12 13:11:58.530+0900 I/RESOURCED(  868): logging.c: logging_send_signal_to_update(1186) > send signal to logging update thread
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: _wfd_exit_timeout_cb(60) > Enter
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: _wfd_exit_timeout_cb(74) > Terminate Wi-Fi Direct Manager
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: _wfd_exit_timeout_cb(78) > Stop exit timer. State [0]
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: _wfd_exit_timeout_cb(80) > Quit
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-client.c: wfd_client_handler_deinit(696) > Enter
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-client.c: wfd_client_handler_deinit(699) > server socket[12]
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-client.c: wfd_client_handler_deinit(732) > Quit
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: wfd_plugin_deinit(1475) > Enter
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: wfd_plugin_deinit(1486) > Quit
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: wfd_manager_deinit(1397) > Enter
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: _wfd_local_deinit_device(135) > Enter
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-util.c: wfd_util_unset_dev_name_notification(267) > Enter
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-util.c: wfd_util_unset_dev_name_notification(276) > Quit
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: _wfd_local_deinit_device(147) > Quit
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: wfd_manager_deinit(1413) > Quit
02-12 13:11:59.912+0900 D/WIFI_DIRECT_MANAGER( 1024): wifi-direct-manager.c: main(1549) > Quit
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_get_apm_by_region(666) > indicator_get_apm_by_region[666]	 "TimeZone is Asia/Seoul"
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(780) > indicator_get_time_by_region[780]	 "BestPattern is h"
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(781) > indicator_get_time_by_region[781]	 "TimeZone is Asia/Seoul"
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(801) > indicator_get_time_by_region[801]	 "DATE & TIME is en_US 1:12 4 h"
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(803) > indicator_get_time_by_region[803]	 "24H :: Before change 1:12"
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_get_time_by_region(810) > indicator_get_time_by_region[810]	 "24H :: After change 1&#x2236;12"
02-12 13:12:00.432+0900 D/INDICATOR(  886): clock.c: indicator_clock_changed_cb(295) > [CLOCK MODULE] Timer Status : -2147106590 Time: <font_size=33>1&#x2236;12</font_size> <font_size=32>PM</font_size></font>
02-12 13:12:01.033+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x20064d bd->visible=1
02-12 13:12:05.887+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2887) > pid(911) status(3)
02-12 13:12:05.887+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:12:05.897+0900 W/AUL_AMD (  812): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
02-12 13:12:05.897+0900 W/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
02-12 13:12:05.897+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(911) status(3)
02-12 13:12:05.897+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
02-12 13:12:05.897+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
02-12 13:12:05.897+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: fg
02-12 13:12:05.897+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 911
02-12 13:12:05.897+0900 D/RESOURCED(  868): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 911, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
02-12 13:12:05.897+0900 D/RESOURCED(  868): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 911, appname = org.tizen.homescreen
02-12 13:12:05.897+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 911
02-12 13:12:05.897+0900 E/RESOURCED(  868): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 911 foreground
02-12 13:12:05.907+0900 E/E17     (  533): e_border.c: e_border_show(2088) > BD_SHOW(0x02400002)
02-12 13:12:05.917+0900 D/APP_CORE( 1520): appcore-efl.c: __cmsg_cb(1011) > win_req_lower
02-12 13:12:05.917+0900 D/APP_CORE( 1520): appcore-group.c: appcore_group_lower(32) > appcore_group_lower
02-12 13:12:05.917+0900 D/AUL     ( 1520): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(35)
02-12 13:12:05.917+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 35
02-12 13:12:05.927+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11ee928), gem(10), surface(0x1255f60)
02-12 13:12:05.947+0900 D/INDICATOR(  886): main.c: _property_changed_cb(432) > UNSNIFF API 4600002
02-12 13:12:06.018+0900 D/INDICATOR(  886): util.c: util_signal_emit_by_win(116) > emission bg.translucent
02-12 13:12:06.018+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11e4fc8), gem(4), surface(0x11de0b0)
02-12 13:12:06.028+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11e4fc8), gem(4), surface(0x11d97b8)
02-12 13:12:06.028+0900 D/INDICATOR(  886): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:12:06.028+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:12:06.028+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:12:06.028+0900 D/INDICATOR(  886): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:12:06.028+0900 W/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=911
02-12 13:12:06.038+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:12:06.038+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:12:06.048+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x04600002), visible:1
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 0
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:12:06.058+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: RESUME State: PAUSED
02-12 13:12:06.058+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(597) > [homescreen:Application:resume:start]
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(607) > [APP 911] RESUME
02-12 13:12:06.058+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:12:06.058+0900 E/cluster-home(  911): homescreen.cpp: OnResume(66) >  app resume
02-12 13:12:06.058+0900 D/cluster-home(  911): widget-data-provider.cpp: SetBoxVisibility(1519) >  
02-12 13:12:06.058+0900 D/cluster-home(  911): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[1]
02-12 13:12:06.058+0900 D/WIDGET_VIEWER(  911): widget.c: widget_viewer_set_visibility(3865) > [SECURE_LOG] org.tizen.calendar.widget has no changes
02-12 13:12:06.058+0900 D/cluster-home(  911): cluster-data-list.cpp: GetWidgetListByPage(776) >  cluster[0] pageNum[2]
02-12 13:12:06.058+0900 D/cluster-home(  911): widget-data-provider.cpp: SetBoxVisibility(1528) >  No boxes in page[2]
02-12 13:12:06.058+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppResume(892) >  BEGIN
02-12 13:12:06.058+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppResume(910) >  END
02-12 13:12:06.058+0900 D/cluster-view(  911): cluster-view-controller.cpp: _OnTTSFocusChanged(1652) >  _OnTTSFocusChanged Order[0]
02-12 13:12:06.058+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnFocusChanged(5705) >  OnFocusChanged[0]
02-12 13:12:06.058+0900 D/cluster-view(  911): homescreen-page-indicator.cpp: CancelOperation(300) >  CancelOperation
02-12 13:12:06.058+0900 D/cluster-view(  911): cluster-impl.cpp: ScrollToFitPage(466) >  ScrollToFitPage
02-12 13:12:06.058+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollSnapStart(613) >  TODO current page[0] new page[0]
02-12 13:12:06.058+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollSnapStart(623) >  TODO current page[0] new page[0]
02-12 13:12:06.058+0900 D/test-log(  911): cluster-impl.cpp: SetFocusedPage(791) >  Set mFocusedPage: 1
02-12 13:12:06.058+0900 D/test-log(  911): cluster-impl.cpp: GetFocusedPage(798) >  mFocusedPage: 1
02-12 13:12:06.058+0900 D/cluster-view(  911): cluster-view-controller.cpp: OnClusterChangeFocusedPage(1779) >  Cluster[0:] 1 page focused
02-12 13:12:06.058+0900 D/cluster-home(  911): widget-data-provider.cpp: OnCustomClusterFocusedPageChanged(2910) >  Cluster[0] page[1] focused
02-12 13:12:06.058+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(636) > [homescreen:Application:resume:done]
02-12 13:12:06.058+0900 D/LAUNCH  (  911): appcore-efl.c: __do_app(638) > [homescreen:Application:Launching:done]
02-12 13:12:06.058+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:12:06.058+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:12:06.058+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1520) status(4)
02-12 13:12:06.058+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1520) appid(org.example.sqlite) pkgid(org.example.sqlite) status(4)
02-12 13:12:06.058+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.example.sqlite
02-12 13:12:06.058+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1520, appid: org.example.sqlite, status: bg
02-12 13:12:06.068+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_resume(339) > [SECURE_LOG] 911 is resumed
02-12 13:12:06.068+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 0
02-12 13:12:06.068+0900 D/RESOURCED(  868): proc-process.c: proc_backgrd_manage(105) > BACKGRD MANAGE : don't manage background application by 1520
02-12 13:12:06.068+0900 E/DATA_PROVIDER_MASTER(  982): setting.c: setting_is_lcd_off(95) > [SECURE_LOG] State: 1, (3:lcdoff, 4:sleep)
02-12 13:12:06.078+0900 I/TIZEN_N_SOUND_MANAGER( 1003): sound_manager.c: sound_manager_get_volume(77) > returns : type=0, volume=9, ret=0x0
02-12 13:12:06.078+0900 E/TIZEN_N_SOUND_MANAGER( 1003): sound_manager_private.c: __convert_sound_manager_error_code(70) > [sound_manager_get_volume(79)] ERROR_NONE(0x00000000) : core frameworks error code(0x00000000)
02-12 13:12:06.078+0900 I/TIZEN_N_SOUND_MANAGER( 1003): sound_manager.c: sound_manager_get_volume(77) > returns : type=4, volume=7, ret=0x0
02-12 13:12:06.078+0900 E/TIZEN_N_SOUND_MANAGER( 1003): sound_manager_private.c: __convert_sound_manager_error_code(70) > [sound_manager_get_volume(79)] ERROR_NONE(0x00000000) : core frameworks error code(0x00000000)
02-12 13:12:06.078+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:12:06.078+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_resume_cb(310) > widget obj was resumed
02-12 13:12:06.078+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(132) > enter foreground group
02-12 13:12:06.078+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: fg
02-12 13:12:06.078+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 966
02-12 13:12:06.078+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: foreground, oom_score_adj: 200
02-12 13:12:06.078+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 966
02-12 13:12:06.078+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/usr/apps/org.tizen.homescreen/bin/homescreen' and package_app_info.app_disable IN ('false','False')
02-12 13:12:06.088+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/usr/apps/org.tizen.homescreen/bin/homescreen' and package_app_info.app_disable IN ('false','False')
02-12 13:12:06.088+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x11ea410), gem(12), surface(0x1262980)
02-12 13:12:06.098+0900 D/AUL_AMD (  812): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 911 is org.tizen.homescreen
02-12 13:12:06.098+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 911 : 0
02-12 13:12:06.098+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 29
02-12 13:12:06.138+0900 D/RESOURCED(  868): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 966, appname = org.tizen.calendar.widget
02-12 13:12:06.138+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 966
02-12 13:12:06.178+0900 D/APP_CORE( 1520): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600002 fully_obscured 1
02-12 13:12:06.178+0900 D/APP_CORE( 1520): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:12:06.178+0900 D/APP_CORE( 1520): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:12:06.178+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(496) > [APP 1520] Event: PAUSE State: RUNNING
02-12 13:12:06.178+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(565) > [APP 1520] PAUSE
02-12 13:12:06.178+0900 I/CAPI_APPFW_APPLICATION( 1520): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:12:06.178+0900 D/APP_CORE( 1520): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:12:06.178+0900 E/APP_CORE( 1520): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:12:06.318+0900 D/cluster-view(  911): custom-cluster-impl.cpp: OnCustomScrollComplete(5141) >  ##################### scroll complete ########################### 
02-12 13:12:06.318+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollComplete(639) >  Horizontal Cluster scrollview is stopped normally, pos[0.00, 0.00]
02-12 13:12:06.318+0900 D/cluster-view(  911): cluster-impl.cpp: OnScrollComplete(653) >  scroll position x : -0.00 (page:0)
02-12 13:12:06.318+0900 D/test-log(  911): cluster-impl.cpp: SetFocusedPage(791) >  Set mFocusedPage: 1
02-12 13:12:06.318+0900 D/test-log(  911): cluster-impl.cpp: GetFocusedPage(798) >  mFocusedPage: 1
02-12 13:12:06.318+0900 D/cluster-view(  911): cluster-view-controller.cpp: OnClusterChangeFocusedPage(1779) >  Cluster[0:] 1 page focused
02-12 13:12:06.318+0900 D/cluster-home(  911): widget-data-provider.cpp: OnCustomClusterFocusedPageChanged(2910) >  Cluster[0] page[1] focused
02-12 13:12:07.139+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1023) >  menu box Pick touched
02-12 13:12:07.139+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1034) >  Long Tap Timer Start
02-12 13:12:07.189+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200082 
02-12 13:12:07.199+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1194) >  Box[0] pick ended by Up
02-12 13:12:07.199+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1199) >  Cancel Long Tap Timer
02-12 13:12:07.199+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1240) >  app launch state[1]
02-12 13:12:07.199+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1249) >  touch is moved upper position!!!
02-12 13:12:07.199+0900 D/test-log(  911): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1298) >  laundch!!!!! touch position is moved from[633.00][623.00] to[633.00][623.00]!
02-12 13:12:07.199+0900 D/cluster-view(  911): homescreen-view-manager.cpp: IsOverScrollThreshold(997) >  is Over Scrollview TreshHold?[0]
02-12 13:12:07.199+0900 D/cluster-home(  911): mainmenu-custom-box-impl.cpp: OnClicked(171) >  [28]MenuBox clicked
02-12 13:12:07.199+0900 D/cluster-home(  911): mainmenu-custom-box-impl.cpp: OnClicked(184) >  launch application via service(operation APP_CONTROL_OPERATION_DEFAULT)
02-12 13:12:07.199+0900 D/AUL     (  911): service.c: __set_bundle(186) > __set_bundle
02-12 13:12:07.209+0900 D/AUL     (  911): service.c: __get_alias_appid(548) > [SECURE_LOG] alias_id : (null)
02-12 13:12:07.209+0900 D/AUL     (  911): service.c: __set_bundle(186) > __set_bundle
02-12 13:12:07.209+0900 D/AUL     (  911): service.c: __run_svc_with_pkgname(276) > [SECURE_LOG] pkg_name : org.example.sqlite - no result
02-12 13:12:07.209+0900 D/AUL     (  911): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.sqlite
02-12 13:12:07.209+0900 D/AUL     (  911): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
02-12 13:12:07.209+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 0
02-12 13:12:07.209+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.sqlite
02-12 13:12:07.209+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2230) > [SECURE_LOG] caller appid : org.tizen.homescreen
02-12 13:12:07.209+0900 W/AUL_AMD (  812): amd_launch.c: _start_app(2232) > caller pid : 911
02-12 13:12:07.219+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2442) > win(a00002) ecore_x_pointer_grab(1)
02-12 13:12:07.219+0900 D/AUL_AMD (  812): amd_key.c: _key_grab(243) > _key_grab, win : a00002
02-12 13:12:07.219+0900 D/AUL_AMD (  812): amd_launch.c: _start_app(2447) > back key grab
02-12 13:12:07.219+0900 D/RESOURCED(  868): proc-noti.c: process_message(173) > process message caller pid 812
02-12 13:12:07.219+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_action(1043) > [SECURE_LOG] appid org.example.sqlite, pid 1520, status 5
02-12 13:12:07.219+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(914) > [SECURE_LOG] resume request 1520
02-12 13:12:07.219+0900 W/AUL_AMD (  812): amd_launch.c: __nofork_processing(1251) > __nofork_processing, cmd: 0, pid: 1520
02-12 13:12:07.219+0900 D/AUL_AMD (  812): amd_launch.c: __nofork_processing(1267) > fake launch pid : 1520
02-12 13:12:07.219+0900 D/AUL     (  812): app_sock.c: __app_send_raw_with_delay_reply(455) > pid(1520) : cmd(0)
02-12 13:12:07.219+0900 D/AUL_AMD (  812): amd_launch.c: __set_reply_handler(1014) > listen fd : 30, send fd : 29
02-12 13:12:07.219+0900 D/AUL_AMD (  812): amd_launch.c: __nofork_processing(1270) > fake launch done
02-12 13:12:07.219+0900 D/APP_CORE( 1520): appcore.c: __aul_handler(587) > [APP 1520]     AUL event: AUL_START
02-12 13:12:07.219+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(496) > [APP 1520] Event: RESET State: PAUSED
02-12 13:12:07.219+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(527) > [APP 1520] RESET
02-12 13:12:07.219+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(529) > [sqlite:Application:reset:start]
02-12 13:12:07.219+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
02-12 13:12:07.219+0900 D/APP_CORE( 1520): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:12:07.219+0900 I/CAPI_APPFW_APPLICATION( 1520): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
02-12 13:12:07.219+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(544) > [sqlite:Application:reset:done]
02-12 13:12:07.219+0900 W/AUL_AMD (  812): amd_launch.c: __reply_handler(912) > listen fd(30) , send fd(29), pid(1520), cmd(0)
02-12 13:12:07.219+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(548) > Legacy lifecycle: 0
02-12 13:12:07.219+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(550) > [APP 1520] App already running, raise the window
02-12 13:12:07.219+0900 D/AUL     (  911): launch.c: app_request_to_launchpad(425) > launch request result : 1520
02-12 13:12:07.219+0900 E/cluster-home(  911): mainmenu-custom-box-impl.cpp: OnClicked(202) >  Success to launch [0][org.example.sqlite]
02-12 13:12:07.219+0900 D/test-log(  911): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
02-12 13:12:07.359+0900 E/E17     (  533): e_manager.c: _e_manager_cb_client_message(1522) > ACTIVE REQUEST(0x04600002)
02-12 13:12:07.359+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2887) > pid(1520) status(3)
02-12 13:12:07.359+0900 D/AUL_AMD (  812): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
02-12 13:12:07.359+0900 D/APP_CORE( 1520): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : org.tizen.homescreen
02-12 13:12:07.369+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2893) > back key ungrab
02-12 13:12:07.369+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(1520) status(3)
02-12 13:12:07.369+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(1520) appid(org.example.sqlite) pkgid(org.example.sqlite) status(3)
02-12 13:12:07.369+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.sqlite
02-12 13:12:07.369+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1520, appid: org.example.sqlite, status: fg
02-12 13:12:07.369+0900 D/RESOURCED(  868): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1520
02-12 13:12:07.369+0900 E/RESOURCED(  868): freezer-process.c: freezer_process_pid_set(148) > Cant find process info for 1520
02-12 13:12:07.369+0900 E/RESOURCED(  868): freezer-process.c: freezer_process_pid_set(150) > freezer_process_pid_set 1520 foreground
02-12 13:12:07.389+0900 E/E17     (  533): e_border.c: e_border_show(2088) > BD_SHOW(0x04600002)
02-12 13:12:07.389+0900 W/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=1520
02-12 13:12:07.399+0900 D/INDICATOR(  886): main.c: _property_changed_cb(432) > UNSNIFF API 2400002
02-12 13:12:07.399+0900 D/INDICATOR(  886): util.c: util_signal_emit_by_win(116) > emission bg.opaque
02-12 13:12:07.399+0900 D/INDICATOR(  886): main.c: _rotate_window(229) > Indicator angle is 0 degree
02-12 13:12:07.399+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
02-12 13:12:07.399+0900 D/INDICATOR(  886): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
02-12 13:12:07.399+0900 D/INDICATOR(  886): main.c: _rotate_window(252) > port :: hide more icon
02-12 13:12:07.399+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11ee928), gem(10), surface(0x122c988)
02-12 13:12:07.409+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11e8f78), gem(16), surface(0x1265a18)
02-12 13:12:07.409+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:12:07.409+0900 E/EFL     (  533): eo<533> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
02-12 13:12:07.409+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(838) > __request_handler: 15
02-12 13:12:07.419+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:07.419+0900 D/PKGMGR_INFO(  812): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.sqlite/bin/sqlite' and package_app_info.app_disable IN ('false','False')
02-12 13:12:07.419+0900 E/E17     (  533): e_border.c: e_border_hide(2248) > BD_HIDE(0x02400002), visible:1
02-12 13:12:07.419+0900 D/APP_CORE(  911): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2400002 fully_obscured 1
02-12 13:12:07.419+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
02-12 13:12:07.419+0900 D/APP_CORE(  911): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
02-12 13:12:07.419+0900 I/APP_CORE(  911): appcore-efl.c: __do_app(496) > [APP 911] Event: PAUSE State: RUNNING
02-12 13:12:07.419+0900 D/APP_CORE(  911): appcore-efl.c: __do_app(565) > [APP 911] PAUSE
02-12 13:12:07.419+0900 I/CAPI_APPFW_APPLICATION(  911): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
02-12 13:12:07.419+0900 E/cluster-home(  911): homescreen.cpp: OnPause(84) >  app pause
02-12 13:12:07.429+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
02-12 13:12:07.429+0900 D/cluster-view(  911): homescreen-view-manager.cpp: AppPause(923) >  END
02-12 13:12:07.429+0900 D/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:12:07.429+0900 E/APP_CORE(  911): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:12:07.429+0900 D/AUL_AMD (  812): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 1520 is org.example.sqlite
02-12 13:12:07.429+0900 D/AUL_AMD (  812): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 1520 : 0
02-12 13:12:07.429+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
02-12 13:12:07.429+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(456) > pid(911) status(4)
02-12 13:12:07.429+0900 D/AUL_AMD (  812): amd_status.c: _status_update_app_info_list(468) > pid(911) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
02-12 13:12:07.429+0900 D/AUL     (  812): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
02-12 13:12:07.429+0900 W/AUL     (  812): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 911, appid: org.tizen.homescreen, status: bg
02-12 13:12:07.439+0900 D/DATA_PROVIDER_MASTER(  982): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 911 is paused
02-12 13:12:07.439+0900 D/DATA_PROVIDER_MASTER(  982): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
02-12 13:12:07.439+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_pause_cb(292) > widget obj was paused
02-12 13:12:07.439+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(142) > enter background group
02-12 13:12:07.439+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: bg
02-12 13:12:07.439+0900 D/RESOURCED(  868): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
02-12 13:12:07.439+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
02-12 13:12:07.469+0900 D/APP_CORE( 1520): appcore.c: __prt_ltime(236) > [APP 1520] first idle after reset: 33522 msec
02-12 13:12:07.509+0900 D/RESOURCED(  868): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
02-12 13:12:07.509+0900 D/RESOURCED(  868): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
02-12 13:12:07.619+0900 D/AUL_AMD (  812): amd_launch.c: __e17_status_handler(2906) > pid(1520) status(0)
02-12 13:12:07.619+0900 I/MALI    (  533): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x12663b0), gem(16), surface(0x122cad0)
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600002 fully_obscured 0
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
02-12 13:12:07.689+0900 I/APP_CORE( 1520): appcore-efl.c: __do_app(496) > [APP 1520] Event: RESUME State: PAUSED
02-12 13:12:07.689+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(597) > [sqlite:Application:resume:start]
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __do_app(607) > [APP 1520] RESUME
02-12 13:12:07.689+0900 I/CAPI_APPFW_APPLICATION( 1520): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
02-12 13:12:07.689+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(636) > [sqlite:Application:resume:done]
02-12 13:12:07.689+0900 D/LAUNCH  ( 1520): appcore-efl.c: __do_app(638) > [sqlite:Application:Launching:done]
02-12 13:12:07.689+0900 D/APP_CORE( 1520): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
02-12 13:12:07.689+0900 E/APP_CORE( 1520): appcore-efl.c: __trm_app_info_send_socket(242) > access
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:138 _ecore_evas_idle_enter() stuck async render: time=268.073494, ee=0xb7a4a0a8, engine=software_x11, geometry=(0, 0, 720, 1280), visible=1, shaped=0, alpha=0, transparent=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:140 _ecore_evas_idle_enter() delayed.avoid_damage=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:141 _ecore_evas_idle_enter() delayed.resize_shape=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:142 _ecore_evas_idle_enter() delayed.shaped=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:143 _ecore_evas_idle_enter() delayed.shaped_changed=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:144 _ecore_evas_idle_enter() delayed.alpha=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:145 _ecore_evas_idle_enter() delayed.alpha_changed=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:146 _ecore_evas_idle_enter() delayed.transparent=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:147 _ecore_evas_idle_enter() delayed.transparent_changed=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:148 _ecore_evas_idle_enter() delayed.rotation=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:149 _ecore_evas_idle_enter() delayed.rotation_resize=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:150 _ecore_evas_idle_enter() delayed.rotation_changed=0
02-12 13:12:07.699+0900 E/EFL     ( 1520): ecore_evas<1520> lib/ecore_evas/ecore_evas.c:152 _ecore_evas_idle_enter() reset in_async_render of ee=0xb7a4a0a8
02-12 13:12:08.540+0900 D/PROCESSMGR(  533): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20064d 
02-12 13:12:08.720+0900 D/AUL_AMD (  812): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.sqlite /opt/usr/apps/org.example.sqlite/bin/sqlite
02-12 13:12:08.720+0900 D/RUA     (  812): rua.c: rua_add_history(179) > rua_add_history start
02-12 13:12:08.730+0900 D/RUA     (  812): rua.c: rua_add_history(247) > rua_add_history ok
02-12 13:12:09.181+0900 D/sqlite  ( 1520): DB Path: /opt/usr/apps/org.example.sqlite/data/test.db
02-12 13:12:10.242+0900 D/sqlite  ( 1520): -0: 
02-12 13:12:10.282+0900 D/sqlite  ( 1520): DATA = QENXrHmUWylkZp5MRzbfUw== | 
02-12 13:12:10.322+0900 D/sqlite  ( 1520): ENCRYPTED = 1 | 
02-12 13:12:10.532+0900 W/CRASH_MANAGER( 1767): worker.c: worker_job(1204) > 110152073716c142371433
