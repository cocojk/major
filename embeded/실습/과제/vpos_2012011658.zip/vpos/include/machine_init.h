
#ifndef _VPOS_MACHINE_INIT_H_
#define _VPOS_MACHINE_INIT_H_

void vk_machine_init(void);

#endif //_VPOS_MACHINE_INIT_H_
