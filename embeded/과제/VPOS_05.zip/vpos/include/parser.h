#ifndef _VPOS_PARSER_H_
#define _VPOS_PARSER_H_

extern int parse_args(char *cmdline, char **argv);

#endif //_VPOS_PARSER_H_
