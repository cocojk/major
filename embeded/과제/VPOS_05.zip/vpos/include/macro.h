//for master Queue flag check
#define EMPTY			0x1
#define USE				0x2

//for stub flag
#define FREE			0x3
#define RECV_DATA		0x4

//for vk_stub_queue_t 
#define EMPTY_STUB_Q 	0x5	
#define FILL_STUB_Q		0x6

