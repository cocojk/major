S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 4054
Date: 2015-01-22 21:47:10+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 4054, uid 5000)

Register Information
r0   = 0x9a2a8008, r1   = 0x00000001
r2   = 0x00480cdc, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x00480cdc
r6   = 0x00480cdc, r7   = 0xae009588
r8   = 0xb8274438, r9   = 0xae009734
r10  = 0xb8279990, fp   = 0x0000000d
ip   = 0xb675e110, sp   = 0xae0094e8
lr   = 0xb3383c57, pc   = 0xb675e128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    397896 KB
Buffers:     21040 KB
Cached:     144360 KB
VmPeak:     599928 KB
VmSize:     599924 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       54044 KB
VmRSS:       54044 KB
VmData:     419768 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         302 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 4054 TID = 4559
4054 4057 4454 4455 4456 4457 4466 4509 4550 4551 4554 4558 4559 4560 4561 4562 4563 4564 4565 4566 4567 4568 4569 4570 4573 4574 4575 4576 4577 4578 4579 4580 4581 4582 4583 4584 4585 4586 4587 4588 4589 4590 4591 4592 4593 4596 4599 

Maps Information
926d1000 92ed0000 rwxp [stack:4596]
93ab1000 942b0000 rwxp [stack:4509]
99101000 99900000 rwxp [stack:4550]
99901000 9a100000 rwxp [stack:4551]
9a989000 9b188000 rwxp [stack:4554]
9b801000 9c000000 rwxp [stack:4599]
9c251000 9ca50000 rwxp [stack:4593]
9ca51000 9d250000 rwxp [stack:4561]
9d301000 9db00000 rwxp [stack:4560]
9e101000 9e900000 rwxp [stack:4592]
9e901000 9f100000 rwxp [stack:4591]
9f101000 9f900000 rwxp [stack:4590]
9f901000 a0100000 rwxp [stack:4589]
a0101000 a0900000 rwxp [stack:4588]
a0901000 a1100000 rwxp [stack:4587]
a1101000 a1900000 rwxp [stack:4586]
a1901000 a2100000 rwxp [stack:4585]
a2101000 a2900000 rwxp [stack:4584]
a2901000 a3100000 rwxp [stack:4583]
a3101000 a3900000 rwxp [stack:4582]
a3901000 a4100000 rwxp [stack:4581]
a4101000 a4900000 rwxp [stack:4580]
a4b01000 a5300000 rwxp [stack:4579]
a54f6000 a5cf5000 rwxp [stack:4578]
a5f17000 a6716000 rwxp [stack:4577]
a6717000 a6f16000 rwxp [stack:4576]
a71d6000 a79d5000 rwxp [stack:4575]
a7d01000 a8500000 rwxp [stack:4574]
a8501000 a8d00000 rwxp [stack:4573]
a8d01000 a9500000 rwxp [stack:4570]
a9501000 a9d00000 rwxp [stack:4569]
a9d01000 aa500000 rwxp [stack:4568]
aa501000 aad00000 rwxp [stack:4567]
aad01000 ab500000 rwxp [stack:4566]
ab501000 abd00000 rwxp [stack:4565]
abd01000 ac500000 rwxp [stack:4562]
ac501000 acd00000 rwxp [stack:4564]
acf01000 ad700000 rwxp [stack:4563]
ad80c000 ae00b000 rwxp [stack:4559]
ae00b000 ae00e000 r-xp /usr/lib/libXv.so.1.0.0
ae01e000 ae030000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae041000 ae078000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae08a000 ae889000 rwxp [stack:4558]
ae889000 ae8a6000 r-xp /usr/lib/libAl_Awb_Sp.so
ae8af000 ae8b2000 r-xp /usr/lib/libdeflicker.so
ae8ca000 ae8e0000 r-xp /usr/lib/libAl_Awb.so
ae8e8000 ae8f2000 r-xp /usr/lib/libcalibration.so
ae8fb000 ae90d000 r-xp /usr/lib/libaf_lib.so
ae915000 ae91b000 r-xp /usr/lib/libspaf.so
ae923000 ae92f000 r-xp /usr/lib/libae.so
ae937000 ae978000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae9bf000 aea9e000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aeefb000 aef37000 r-xp /usr/lib/libcamerahal.so.0.0.0
af10d000 af10e000 r-xp /usr/lib/libcamerahdr.so.0.0.0
af11f000 af91e000 rwxp [stack:4466]
af925000 af93d000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0501000 b0d00000 rwxp [stack:4457]
b0e00000 b0e06000 r-xp /usr/lib/liblsc.so
b0ead000 b16ac000 rwxp [stack:4456]
b16ad000 b1eac000 rwxp [stack:4455]
b1eac000 b1eb1000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f3d000 b1f45000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f56000 b1f57000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f67000 b1f6e000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f92000 b1f93000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1fa3000 b1fb6000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b200a000 b200f000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2020000 b281f000 rwxp [stack:4454]
b281f000 b297a000 r-xp /usr/lib/egl/libMali.so
b298f000 b2a18000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a31000 b2aff000 r-xp /usr/lib/libCOREGL.so.4.0
b2b1a000 b2b1d000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b2d000 b2b3a000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b4b000 b2b55000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b65000 b2b71000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b82000 b2b86000 r-xp /usr/lib/libogg.so.0.7.1
b2b96000 b2bb8000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bc8000 b2cac000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2cc8000 b2d0b000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d20000 b2d67000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d78000 b2d7f000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d8f000 b2dc4000 r-xp /usr/lib/libpulse.so.0.16.2
b2dd5000 b2dd8000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2de9000 b2dec000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2dfd000 b2e40000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e51000 b2e59000 r-xp /usr/lib/libdrm.so.2.4.0
b2e69000 b2e6b000 r-xp /usr/lib/libdri2.so.0.0.0
b2e7b000 b2e82000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e92000 b2e9d000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2eb1000 b2eb7000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2ec8000 b2ed0000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ee1000 b2ee6000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2ef6000 b2f0d000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f1d000 b2f3d000 r-xp /usr/lib/libexif.so.12.3.3
b2f49000 b2f51000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f61000 b2f90000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2fa3000 b2fab000 r-xp /usr/lib/libtbm.so.1.0.0
b2fbb000 b3074000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3088000 b308f000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b309f000 b30fd000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3112000 b3116000 r-xp /usr/lib/libstorage.so.0.1
b3126000 b312d000 r-xp /usr/lib/libefl-extension.so.0.1.0
b313d000 b314c000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3276000 b327a000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b328b000 b336b000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3380000 b3385000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b338d000 b33b4000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33c7000 b3bc6000 rwxp [stack:4057]
b3bc6000 b3bc8000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dd8000 b3de1000 r-xp /lib/libnss_files-2.20-2014.11.so
b3df2000 b3dfb000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e0c000 b3e1d000 r-xp /lib/libnsl-2.20-2014.11.so
b3e30000 b3e36000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e47000 b3e61000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e72000 b3e73000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e83000 b3e85000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e96000 b3e9b000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3eab000 b3eae000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ebf000 b3ec6000 r-xp /usr/lib/libsensord-share.so
b3ed6000 b3ee7000 r-xp /usr/lib/libsensor.so.1.2.0
b3ef8000 b3efe000 r-xp /usr/lib/libappcore-common.so.1.1
b3f21000 b3f26000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f3c000 b3f3e000 r-xp /usr/lib/libXau.so.6.0.0
b3f4e000 b3f62000 r-xp /usr/lib/libxcb.so.1.1.0
b3f72000 b3f79000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fb1000 b3fb3000 r-xp /usr/lib/libiri.so
b3fc4000 b3fd9000 r-xp /lib/libexpat.so.1.5.2
b3feb000 b4039000 r-xp /usr/lib/libssl.so.1.0.0
b404e000 b4057000 r-xp /usr/lib/libethumb.so.1.13.0
b4068000 b406b000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b407b000 b4232000 r-xp /usr/lib/libcrypto.so.1.0.0
b57c9000 b57d2000 r-xp /usr/lib/libXi.so.6.1.0
b57e3000 b57e5000 r-xp /usr/lib/libXgesture.so.7.0.0
b57f5000 b57f9000 r-xp /usr/lib/libXtst.so.6.1.0
b5809000 b580f000 r-xp /usr/lib/libXrender.so.1.3.0
b581f000 b5825000 r-xp /usr/lib/libXrandr.so.2.2.0
b5835000 b5837000 r-xp /usr/lib/libXinerama.so.1.0.0
b5847000 b584a000 r-xp /usr/lib/libXfixes.so.3.1.0
b585b000 b5866000 r-xp /usr/lib/libXext.so.6.4.0
b5876000 b5878000 r-xp /usr/lib/libXdamage.so.1.1.0
b5888000 b588a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b589a000 b597d000 r-xp /usr/lib/libX11.so.6.3.0
b5990000 b5997000 r-xp /usr/lib/libXcursor.so.1.0.2
b59a8000 b59c0000 r-xp /usr/lib/libudev.so.1.6.0
b59c2000 b59c5000 r-xp /lib/libattr.so.1.1.0
b59d5000 b59f5000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59f6000 b59fb000 r-xp /usr/lib/libffi.so.6.0.2
b5a0b000 b5a23000 r-xp /lib/libz.so.1.2.8
b5a33000 b5a35000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a45000 b5b1a000 r-xp /usr/lib/libxml2.so.2.9.2
b5b2f000 b5bca000 r-xp /usr/lib/libstdc++.so.6.0.20
b5be6000 b5be9000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bf9000 b5c13000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c23000 b5c34000 r-xp /lib/libresolv-2.20-2014.11.so
b5c48000 b5c5f000 r-xp /usr/lib/liblzma.so.5.0.3
b5c6f000 b5c71000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c81000 b5c88000 r-xp /usr/lib/libembryo.so.1.13.0
b5c98000 b5cb0000 r-xp /usr/lib/libpng12.so.0.50.0
b5cc1000 b5ce4000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d04000 b5d0a000 r-xp /lib/librt-2.20-2014.11.so
b5d1b000 b5d2f000 r-xp /usr/lib/libector.so.1.13.0
b5d40000 b5d58000 r-xp /usr/lib/liblua-5.1.so
b5d69000 b5dc0000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dd4000 b5dfc000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e0d000 b5e20000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e31000 b5e6b000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e7c000 b5ee7000 r-xp /lib/libm-2.20-2014.11.so
b5ef8000 b5f05000 r-xp /usr/lib/libeio.so.1.13.0
b5f15000 b5f17000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f27000 b5f2c000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f3c000 b5f53000 r-xp /usr/lib/libefreet.so.1.13.0
b5f65000 b5f85000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f95000 b5fb5000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fb7000 b5fbd000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fcd000 b5fd4000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fe4000 b5ff2000 r-xp /usr/lib/libeo.so.1.13.0
b6002000 b6014000 r-xp /usr/lib/libecore_input.so.1.13.0
b6025000 b602a000 r-xp /usr/lib/libecore_file.so.1.13.0
b603a000 b6052000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6063000 b6080000 r-xp /usr/lib/libeet.so.1.13.0
b6099000 b60e1000 r-xp /usr/lib/libeina.so.1.13.0
b60f2000 b6102000 r-xp /usr/lib/libefl.so.1.13.0
b6113000 b61f8000 r-xp /usr/lib/libicuuc.so.51.1
b6215000 b6355000 r-xp /usr/lib/libicui18n.so.51.1
b636c000 b63a4000 r-xp /usr/lib/libecore_x.so.1.13.0
b63b6000 b63b9000 r-xp /lib/libcap.so.2.21
b63c9000 b63f2000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6403000 b640a000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b641c000 b6452000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6463000 b654b000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b655f000 b65d5000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65e7000 b65ea000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65fa000 b6605000 r-xp /usr/lib/libvconf.so.0.2.45
b6615000 b6617000 r-xp /usr/lib/libvasum.so.0.3.1
b6627000 b6629000 r-xp /usr/lib/libttrace.so.1.1
b6639000 b663c000 r-xp /usr/lib/libiniparser.so.0
b664c000 b666f000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b667f000 b6684000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6695000 b66ac000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66bd000 b66ca000 r-xp /usr/lib/libunwind.so.8.0.1
b6700000 b6824000 r-xp /lib/libc-2.20-2014.11.so
b6839000 b6852000 r-xp /lib/libgcc_s-4.9.so.1
b6862000 b6944000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6955000 b6989000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6999000 b69d3000 r-xp /usr/lib/libsystemd.so.0.4.0
b69d5000 b6a55000 r-xp /usr/lib/libedje.so.1.13.0
b6a58000 b6a76000 r-xp /usr/lib/libecore.so.1.13.0
b6a96000 b6bf8000 r-xp /usr/lib/libevas.so.1.13.0
b6c2f000 b6c43000 r-xp /lib/libpthread-2.20-2014.11.so
b6c57000 b6e7b000 r-xp /usr/lib/libelementary.so.1.13.0
b6ea9000 b6ead000 r-xp /usr/lib/libsmack.so.1.0.0
b6ebd000 b6ec3000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ed4000 b6ed6000 r-xp /usr/lib/libdlog.so.0.0.0
b6ee6000 b6ee9000 r-xp /usr/lib/libbundle.so.0.1.22
b6ef9000 b6efb000 r-xp /lib/libdl-2.20-2014.11.so
b6f0c000 b6f25000 r-xp /usr/lib/libaul.so.0.1.0
b6f37000 b6f39000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f4a000 b6f4e000 r-xp /usr/lib/libsys-assert.so
b6f5f000 b6f7f000 r-xp /lib/ld-2.20-2014.11.so
b6f90000 b6f96000 r-xp /usr/bin/launchpad-loader
b7fc0000 b85ac000 rw-p [heap]
be925000 be946000 rwxp [stack]
b7fc0000 b85ac000 rw-p [heap]
be925000 be946000 rwxp [stack]
End of Maps Information

Callstack Information (PID:4054)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb675e128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb3383c57) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3c57
 2: (0xb3141abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb30c4865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb64285bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6434f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb643aa8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb643ac81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf92fcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf930459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb68b3157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c34cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
K]0
01-22 21:47:06.203+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4201.2
01-22 21:47:06.203+0900 D/alPrinter1( 4054): [HSC]Mix=0000c3d4,Csd=000108af ,(BV=-1.508,x=0.366,y=0.372)
01-22 21:47:06.203+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:4, 0x0000c3d4,0x0000c3d4
01-22 21:47:06.203+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.508102 in/out_0
01-22 21:47:06.203+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.144470,GGain=1.000000,BGain=1.592667,Dtct=0.365799,0.372162 ,Curr=0.365463,0.372070 ,CTmep: QC=4420, AL= 4420
01-22 21:47:06.213+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4e00), gem(37), surface(0xb84c6b90)
01-22 21:47:06.283+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:83, next_index:341, target_lum:85
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.283+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.283+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.93, detect:   0.37,   0.38 CTemp:4196.9
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [HSC]Mix=0000e28c,Csd=0000f44f ,(BV=-1.539,x=0.366,y=0.372)
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:3, 0x0000e28c,0x0000e28c
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.539185 in/out_0
01-22 21:47:06.283+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.144470,GGain=1.000000,BGain=1.592514,Dtct=0.365677,0.371826 ,Curr=0.365463,0.372070 ,CTmep: QC=4417, AL= 4417
01-22 21:47:06.313+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c5698), gem(38), surface(0xb84c6b90)
01-22 21:47:06.363+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:84, next_index:341, target_lum:85
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.363+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.363+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4174.7
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [HSC]Mix=00010144,Csd=ffffb36c ,(BV=-1.565,x=0.366,y=0.372)
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:4, 0x00010144,0x00010144
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.565079 in/out_0
01-22 21:47:06.363+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.142166,GGain=0.999985,BGain=1.592270,Dtct=0.366470,0.371704 ,Curr=0.365738,0.372009 ,CTmep: QC=4413, AL= 4413
01-22 21:47:06.383+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4a50), gem(37), surface(0xb84c6b90)
01-22 21:47:06.443+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:84, next_index:341, target_lum:85
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.443+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.443+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4147.4
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [HSC]Mix=00010144,Csd=fffebf2a ,(BV=-1.586,x=0.367,y=0.372)
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:3, 0x00010144,0x00010144
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.585587 in/out_0
01-22 21:47:06.443+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.139969,GGain=0.999985,BGain=1.592087,Dtct=0.367233,0.371613 ,Curr=0.365997,0.371948 ,CTmep: QC=4411, AL= 4411
01-22 21:47:06.463+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb83a6068), gem(38), surface(0xb84c6b90)
01-22 21:47:06.523+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:85, next_index:341, target_lum:85
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.523+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.523+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4146.4
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [HSC]Mix=0000e28c,Csd=fffe6c83 ,(BV=-1.601,x=0.367,y=0.372)
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:4, 0x0000e28c,0x0000e28c
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.600937 in/out_0
01-22 21:47:06.523+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.138000,GGain=0.999985,BGain=1.591766,Dtct=0.367157,0.371628 ,Curr=0.366226,0.371887 ,CTmep: QC=4407, AL= 4407
01-22 21:47:06.533+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82740b0), gem(37), surface(0xb84c6b90)
01-22 21:47:06.614+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:84, next_index:341, target_lum:85
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.614+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.614+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4175.9
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [HSC]Mix=0000c3d4,Csd=ffffa272 ,(BV=-1.612,x=0.366,y=0.372)
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:3, 0x0000c3d4,0x0000c3d4
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.611816 in/out_0
01-22 21:47:06.614+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.138000,GGain=0.999985,BGain=1.591583,Dtct=0.366379,0.371643 ,Curr=0.366226,0.371887 ,CTmep: QC=4403, AL= 4403
01-22 21:47:06.614+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c5698), gem(38), surface(0xb84c6b90)
01-22 21:47:06.684+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:84, next_index:341, target_lum:85
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.684+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.684+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.684+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4207.6
01-22 21:47:06.694+0900 D/alPrinter1( 4054): [HSC]Mix=0000c3d4,Csd=fffff05f ,(BV=-1.619,x=0.366,y=0.372)
01-22 21:47:06.694+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:4, 0x0000c3d4,0x0000c3d4
01-22 21:47:06.694+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.618912 in/out_0
01-22 21:47:06.694+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.138000,GGain=0.999985,BGain=1.591415,Dtct=0.365585,0.372025 ,Curr=0.366226,0.371887 ,CTmep: QC=4400, AL= 4400
01-22 21:47:06.714+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c1810), gem(37), surface(0xb84c0760)
01-22 21:47:06.764+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:84, next_index:341, target_lum:85
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.764+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.764+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.764+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.774+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4205.8
01-22 21:47:06.774+0900 D/alPrinter1( 4054): [HSC]Mix=0000c3d4,Csd=ffffb717 ,(BV=-1.623,x=0.366,y=0.372)
01-22 21:47:06.784+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:3, 0x0000c3d4,0x0000c3d4
01-22 21:47:06.784+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.623016 in/out_0
01-22 21:47:06.784+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.138000,GGain=0.999985,BGain=1.591232,Dtct=0.365829,0.372330 ,Curr=0.366226,0.371887 ,CTmep: QC=4397, AL= 4397
01-22 21:47:06.794+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82740b0), gem(38), surface(0xb84c6b90)
01-22 21:47:06.844+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:83, next_index:341, target_lum:85
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.844+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.844+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4212.0
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [HSC]Mix=0000c3d4,Csd=00000678 ,(BV=-1.625,x=0.365,y=0.372)
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:4, 0x0000c3d4,0x0000c3d4
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.624893 in/out_0
01-22 21:47:06.844+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.138000,GGain=0.999985,BGain=1.591125,Dtct=0.365356,0.371979 ,Curr=0.366226,0.371887 ,CTmep: QC=4394, AL= 4394
01-22 21:47:06.874+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x202b23 
01-22 21:47:06.884+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c12f8), gem(37), surface(0xb84c96e0)
01-22 21:47:06.924+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:83, next_index:341, target_lum:85
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:06.924+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:06.924+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.92, detect:   0.37,   0.38 CTemp:4208.8
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [HSC]Mix=0000c3d4,Csd=ffff7176 ,(BV=-1.625,x=0.365,y=0.372)
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:3, 0x0000c3d4,0x0000c3d4
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.625153 in/out_0
01-22 21:47:06.924+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.138000,GGain=0.999985,BGain=1.590973,Dtct=0.365295,0.371933 ,Curr=0.366226,0.371887 ,CTmep: QC=4391, AL= 4391
01-22 21:47:07.004+0900 I/ISP_AE  ( 4054): calc_iso=400,real_gain=129,iso=0
01-22 21:47:07.014+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:341, cur_lum:82, next_index:341, target_lum:85
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:07.014+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [CMD1][if=a53b3ac8,Wrap=a53b8ff8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:07.014+0900 D/awb_al_cmd1( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [CALL][0xa53b3ac8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [LOCK]0
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [SuperHighCTemp] Mapin:  0.93, detect:   0.37,   0.38 CTemp:4221.2
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [HSC]Mix=0000b997,Csd=0000f568 ,(BV=-1.624,x=0.365,y=0.371)
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [AlHscWrap_Main]:4, 0x0000b997,0x0000b997
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [AIS_WRAP]In BV=-1.613711 ,Awb Bv=-1.624390 in/out_0
01-22 21:47:07.014+0900 D/alPrinter1( 4054): [AIS_WRAP]RGain=1.136292,GGain=0.999985,BGain=1.590408,Dtct=0.364792,0.371460 ,Curr=0.366394,0.371796 ,CTmep: QC=4389, AL= 4389
01-22 21:47:07.024+0900 D/TIZEN_N_CAMERA( 4054): camera.c: camera_is_supported_face_detection(1193) > face detection NOT supported
01-22 21:47:07.024+0900 E/TIZEN_N_CAMERA( 4054): camera.c: camera_stop_face_detection(1315) > NOT_SUPPORTED(0xc0000002)
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): tunnig_param=263480
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): param_num=3
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): cur target lum=62, ev diff=0, level=4
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): AE VERSION : 0x20150828-00
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): cvg speed=0
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): target lum=62, target lum zone=8
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): lime time=134, min line=1
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): target_lum_ev0=62
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): highcount=19,lowcount=15
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): FDAE: failed open fdae_param.txt
01-22 21:47:07.244+0900 I/ISP_AE  ( 4054): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:47:07.244+0900 D/alPrinter0( 4054): LSC Size:20 16
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [LSC]TableSize=   320
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [LSC]TableSize=   320
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [LSC]TableSize=   320
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [OTP]module has otp data 0x9c0db3fc (nil) 20 16
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [LSC]TableSize=   320
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [LSC]TableSize=   320
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:47:07.244+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): work_mode=0 last mode=0
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): cvg speed=0
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): target lum=62, target lum zone=8
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): lime time=134, min line=1
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): target_lum_ev0=62
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): highcount=19,lowcount=15
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): is_quick=0
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): AE_TEST:-----------SET index:282
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:47:07.364+0900 I/ISP_AE  ( 4054): AE_TEST:-----------SET index:282
01-22 21:47:07.374+0900 I/ISP_AE  ( 4054): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:47:07.384+0900 I/ISP_AE  ( 4054): calc_iso=50,real_gain=19,iso=0
01-22 21:47:07.645+0900 I/ISP_AE  ( 4054): set_weight, table[0] = 1
01-22 21:47:07.645+0900 I/ISP_AE  ( 4054): set weight from 1 to 0, rtn=0
01-22 21:47:07.645+0900 I/ISP_AE  ( 4054): AE_TEST ----------------------change to fast
01-22 21:47:07.645+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:282, cur_lum:3, next_index:332, target_lum:62
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,cf,ac,00,00,00,00
01-22 21:47:07.655+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,cf,ac,00,00,00,00
01-22 21:47:07.655+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LineAdj] Mode -2147483647
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LineAdj]Tar RGB 557,733,473
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LineAdj]Ref RGB 557,750,487
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LED]LPF Disable
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.18, detect:   0.34,   0.37 CTemp:5186.9
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [CHROMA]START BV=0.427002 Ratio=1.000000
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [HSC]Mix=00000000,Csd=00011884 ,(BV= 0.427,x=0.355,y=0.385)
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=0.427010 ,Awb Bv=0.427002 in/out_0
01-22 21:47:07.655+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.287186,GGain=1.000000,BGain=1.587463,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:47:07.765+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c5af0), gem(37), surface(0xb83a6698)
01-22 21:47:07.775+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:332, cur_lum:13, next_index:368, target_lum:62
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:07.785+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:07.785+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [LED]LPF Disable
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.47, detect:   0.33,   0.36 CTemp:5456.2
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [HSC]Mix=00001eb8,Csd=0002edb8 ,(BV=-0.666,x=0.347,y=0.376)
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:47:07.785+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-0.666100 ,Awb Bv=-0.666092 in/out_0
01-22 21:47:07.795+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.282120,GGain=1.000000,BGain=1.537292,Dtct=0.347092,0.376434 ,Curr=0.347092,0.376434 ,CTmep: QC=5286, AL= 4993
01-22 21:47:07.805+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839d0c0), gem(38), surface(0xb8484980)
01-22 21:47:07.805+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839c358), gem(41), surface(0xb8492cf8)
01-22 21:47:07.855+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839cad0), gem(37), surface(0xb8479df0)
01-22 21:47:07.895+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:368, cur_lum:27, next_index:384, target_lum:62
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:07.895+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:07.895+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [LED]LPF Disable
01-22 21:47:07.895+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:07.905+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.77, detect:   0.33,   0.36 CTemp:5656.2
01-22 21:47:07.905+0900 D/alPrinter0( 4054): [HSC]Mix=00003d70,Csd=0003a5ba ,(BV=-1.251,x=0.341,y=0.370)
01-22 21:47:07.905+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:47:07.905+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.251062 ,Awb Bv=-1.251053 in/out_0
01-22 21:47:07.905+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.283630,GGain=1.000000,BGain=1.463501,Dtct=0.341324,0.369995 ,Curr=0.341324,0.369995 ,CTmep: QC=5510, AL= 5175
01-22 21:47:07.935+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839cb30), gem(38), surface(0xb8492cf8)
01-22 21:47:07.985+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb847c958), gem(37), surface(0xb84c5fd8)
01-22 21:47:08.015+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:384, cur_lum:41, next_index:389, target_lum:62
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.015+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.015+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [LED]LPF Enable
01-22 21:47:08.015+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.025+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.84, detect:   0.33,   0.36 CTemp:5545.2
01-22 21:47:08.035+0900 D/alPrinter0( 4054): [HSC]Mix=00005c28,Csd=000239cb ,(BV=-1.254,x=0.342,y=0.370)
01-22 21:47:08.035+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:47:08.035+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.394020 ,Awb Bv=-1.253906 in/out_0
01-22 21:47:08.035+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.283615,GGain=1.000000,BGain=1.463486,Dtct=0.342361,0.370361 ,Curr=0.341324,0.369995 ,CTmep: QC=5511, AL= 5176
01-22 21:47:08.035+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c99a0), gem(38), surface(0xb84c5fd8)
01-22 21:47:08.085+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8398cf8), gem(37), surface(0xb8484980)
01-22 21:47:08.135+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:389, cur_lum:45, next_index:394, target_lum:62
01-22 21:47:08.135+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.135+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.145+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.145+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.85, detect:   0.33,   0.36 CTemp:5504.1
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [HSC]Mix=00007ae0,Csd=0002d0b4 ,(BV=-1.267,x=0.343,y=0.370)
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.524081 ,Awb Bv=-1.266724 in/out_0
01-22 21:47:08.145+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.282837,GGain=1.000000,BGain=1.463730,Dtct=0.342972,0.369934 ,Curr=0.341415,0.370010 ,CTmep: QC=5510, AL= 5175
01-22 21:47:08.165+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4120), gem(38), surface(0xb8479df0)
01-22 21:47:08.205+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839d0c0), gem(37), surface(0xb8492cf8)
01-22 21:47:08.255+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:394, cur_lum:50, next_index:397, target_lum:62
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.255+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.255+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.255+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.265+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5463.8
01-22 21:47:08.265+0900 D/alPrinter0( 4054): [HSC]Mix=00009998,Csd=0001c042 ,(BV=-1.294,x=0.343,y=0.369)
01-22 21:47:08.275+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:47:08.275+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.596837 ,Awb Bv=-1.294434 in/out_0
01-22 21:47:08.275+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.281097,GGain=1.000000,BGain=1.463760,Dtct=0.343414,0.369339 ,Curr=0.341583,0.369995 ,CTmep: QC=5509, AL= 5174
01-22 21:47:08.295+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839d060), gem(38), surface(0xb84c5fd8)
01-22 21:47:08.345+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x202b23 
01-22 21:47:08.345+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8492bf8), gem(37), surface(0xb8492cf8)
01-22 21:47:08.375+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:397, cur_lum:53, next_index:398, target_lum:62
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.375+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.375+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.375+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.385+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5412.6
01-22 21:47:08.385+0900 D/alPrinter0( 4054): [HSC]Mix=0000b850,Csd=0000ee44 ,(BV=-1.335,x=0.344,y=0.369)
01-22 21:47:08.385+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:3, 0x0000b850,0x0000b850
01-22 21:47:08.385+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.620296 ,Awb Bv=-1.335495 in/out_0
01-22 21:47:08.385+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.278198,GGain=1.000000,BGain=1.463547,Dtct=0.344299,0.369308 ,Curr=0.341843,0.369949 ,CTmep: QC=5506, AL= 5172
01-22 21:47:08.395+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c0e68), gem(38), surface(0xb8492cf8)
01-22 21:47:08.445+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839c178), gem(37), surface(0xb8492cf8)
01-22 21:47:08.495+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:398, cur_lum:54, next_index:399, target_lum:62
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.505+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.505+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.87, detect:   0.34,   0.36 CTemp:5367.7
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [HSC]Mix=0000d708,Csd=00005f9f ,(BV=-1.385,x=0.345,y=0.369)
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:4, 0x0000d708,0x0000d708
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.643380 ,Awb Bv=-1.384674 in/out_0
01-22 21:47:08.505+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.273773,GGain=1.000000,BGain=1.462860,Dtct=0.345001,0.368896 ,Curr=0.342209,0.369843 ,CTmep: QC=5504, AL= 5170
01-22 21:47:08.525+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8492ae8), gem(38), surface(0xb8492cf8)
01-22 21:47:08.575+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4050), gem(37), surface(0xb8484980)
01-22 21:47:08.615+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:399, cur_lum:54, next_index:400, target_lum:62
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.625+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.625+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5360.2
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [HSC]Mix=0000d708,Csd=0000c9f6 ,(BV=-1.437,x=0.345,y=0.369)
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:3, 0x0000d708,0x0000d708
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.666100 ,Awb Bv=-1.436966 in/out_0
01-22 21:47:08.625+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.268906,GGain=1.000000,BGain=1.462097,Dtct=0.345062,0.368896 ,Curr=0.342621,0.369720 ,CTmep: QC=5500, AL= 5167
01-22 21:47:08.645+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc128), gem(38), surface(0xb8492cf8)
01-22 21:47:08.696+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc188), gem(37), surface(0xb8492cf8)
01-22 21:47:08.736+0900 I/ISP_AE  ( 4054): AE_TEST:----cur_index:400, cur_lum:56, next_index:401, target_lum:62
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:47:08.746+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [CMD0][if=9c0e61a0,Wrap=9c0eb6d0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:47:08.746+0900 D/awb_al_cmd0( 4054): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [CALL][0x9c0e61a0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [AIS_WRAP]msiFlash_state=0
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [LOCK]0
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5339.4
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [HSC]Mix=0000ea3b,Csd=0000b655 ,(BV=-1.489,x=0.345,y=0.369)
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [AlHscWrap_Main]:4, 0x0000ea3b,0x0000ea3b
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [AIS_WRAP]In BV=-1.710494 ,Awb Bv=-1.489319 in/out_0
01-22 21:47:08.746+0900 D/alPrinter0( 4054): [AIS_WRAP]RGain=1.262970,GGain=1.000000,BGain=1.460968,Dtct=0.345413,0.368515 ,Curr=0.343109,0.369553 ,CTmep: QC=5495, AL= 5163
01-22 21:47:08.746+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8492a48), gem(38), surface(0xb8492cf8)
01-22 21:47:08.786+0900 I/ISP_AE  ( 4054): ae_state=3
01-22 21:47:08.836+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c51e0), gem(37), surface(0xb8492cf8)
01-22 21:47:08.876+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839c1d8), gem(38), surface(0xb8492cf8)
01-22 21:47:08.936+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c0e68), gem(37), surface(0xb8492cf8)
01-22 21:47:09.006+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82740b0), gem(38), surface(0xb8492cf8)
01-22 21:47:09.056+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8492ae8), gem(37), surface(0xb8492cf8)
01-22 21:47:09.126+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc188), gem(38), surface(0xb8492cf8)
01-22 21:47:09.176+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4120), gem(37), surface(0xb8492cf8)
01-22 21:47:09.186+0900 I/ISP_AE  ( 4054): FDAE: ->disable, frame_idx=30
01-22 21:47:09.226+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839c178), gem(38), surface(0xb8492cf8)
01-22 21:47:09.306+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc128), gem(37), surface(0xb8492cf8)
01-22 21:47:09.356+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839c1d8), gem(38), surface(0xb8492cf8)
01-22 21:47:09.406+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c51e0), gem(37), surface(0xb8492cf8)
01-22 21:47:09.476+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb83a6068), gem(38), surface(0xb8492cf8)
01-22 21:47:09.536+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8398740), gem(37), surface(0xb8492cf8)
01-22 21:47:09.606+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82740b0), gem(38), surface(0xb8492cf8)
01-22 21:47:09.656+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8492ae8), gem(37), surface(0xb8492cf8)
01-22 21:47:09.707+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc188), gem(38), surface(0xb8492cf8)
01-22 21:47:09.787+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4120), gem(37), surface(0xb8492cf8)
01-22 21:47:09.837+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb839c178), gem(38), surface(0xb8492cf8)
01-22 21:47:09.897+0900 I/ISP_AE  ( 4054): calc_iso=410,real_gain=132,iso=0
01-22 21:47:09.897+0900 I/ISP_AE  ( 4054): calc_iso=410,real_gain=132,iso=0
01-22 21:47:09.917+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc188), gem(37), surface(0xb8492cf8)
01-22 21:47:10.137+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8398740), gem(38), surface(0xb8492cf8)
01-22 21:47:10.147+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c5af0), gem(41), surface(0xb8492cf8)
01-22 21:47:10.187+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84cc128), gem(37), surface(0xb8492cf8)
01-22 21:47:10.267+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb83ac788), gem(38), surface(0xb8492cf8)
01-22 21:47:10.317+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb847cc90), gem(37), surface(0xb8492cf8)
01-22 21:47:10.347+0900 D/camera  ( 4054): Writing image to file.
01-22 21:47:10.367+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c4050), gem(38), surface(0xb8492cf8)
01-22 21:47:10.447+0900 I/MALI    ( 4054): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84c0e68), gem(37), surface(0xb8492cf8)
01-22 21:47:10.477+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:47:10.497+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:47:10.497+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:47:10.497+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:47:10.497+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:47:10.497+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:47:10.497+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:47:10.497+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:47:10.497+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:47:10.507+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xfe6e10), gem(11), surface(0x105b7a0)
01-22 21:47:10.517+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:47:10.517+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:47:10.537+0900 W/CRASH_MANAGER( 4604): worker.c: worker_job(1204) > 110405463616d142193083
