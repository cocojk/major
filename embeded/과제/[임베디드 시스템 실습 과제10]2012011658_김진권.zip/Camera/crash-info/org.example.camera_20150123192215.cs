S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 1249
Date: 2015-01-23 19:22:15+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 1249, uid 5000)

Register Information
r0   = 0x92393008, r1   = 0x00000001
r2   = 0x004fc7e8, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x004fc7e8
r6   = 0x004fc7e8, r7   = 0xad6a2588
r8   = 0xb75f47e0, r9   = 0xad6a2734
r10  = 0xb75fb588, fp   = 0x0000000d
ip   = 0xb6733110, sp   = 0xad6a24e8
lr   = 0xb3358c2f, pc   = 0xb6733128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    450644 KB
Buffers:     12596 KB
Cached:     115292 KB
VmPeak:     609312 KB
VmSize:     609308 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       51780 KB
VmRSS:       51780 KB
VmData:     431592 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         316 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 1249 TID = 1437
1249 1250 1427 1428 1429 1430 1431 1434 1436 1437 1438 1439 1440 1441 1442 1443 1444 1445 1446 1447 1450 1451 1452 1453 1454 1455 1456 1457 1458 1459 1460 1461 1462 1463 1464 1465 1466 1467 1468 1469 1470 1471 1473 1474 1475 1477 1478 1483 

Maps Information
92d8e000 9358d000 rwxp [stack:1483]
9367f000 93e7e000 rwxp [stack:1478]
93e7f000 9467e000 rwxp [stack:1477]
98d81000 99580000 rwxp [stack:1475]
99581000 99d80000 rwxp [stack:1474]
9bc81000 9c480000 rwxp [stack:1473]
9c518000 9cd17000 rwxp [stack:1471]
9cd18000 9d517000 rwxp [stack:1470]
9d518000 9dd17000 rwxp [stack:1469]
9e403000 9ec02000 rwxp [stack:1468]
9ec03000 9f402000 rwxp [stack:1467]
9f403000 9fc02000 rwxp [stack:1466]
9fc03000 a0402000 rwxp [stack:1465]
a0403000 a0c02000 rwxp [stack:1464]
a0c03000 a1402000 rwxp [stack:1463]
a1403000 a1c02000 rwxp [stack:1462]
a1c03000 a2402000 rwxp [stack:1461]
a2403000 a2c02000 rwxp [stack:1460]
a2c03000 a3402000 rwxp [stack:1459]
a3403000 a3c02000 rwxp [stack:1458]
a3c03000 a4402000 rwxp [stack:1457]
a4403000 a4c02000 rwxp [stack:1456]
a4c03000 a5402000 rwxp [stack:1455]
a5403000 a5c02000 rwxp [stack:1454]
a5c03000 a6402000 rwxp [stack:1453]
a66a5000 a6ea4000 rwxp [stack:1452]
a6ea5000 a76a4000 rwxp [stack:1451]
a76a5000 a7ea4000 rwxp [stack:1450]
a7ea5000 a86a4000 rwxp [stack:1447]
a86a5000 a8ea4000 rwxp [stack:1446]
a8ea5000 a96a4000 rwxp [stack:1445]
a96a5000 a9ea4000 rwxp [stack:1444]
a9ea5000 aa6a4000 rwxp [stack:1443]
aa6a5000 aaea4000 rwxp [stack:1442]
aaea5000 ab6a4000 rwxp [stack:1441]
ab6a5000 abea4000 rwxp [stack:1440]
abea5000 ac6a4000 rwxp [stack:1439]
ac6a5000 acea4000 rwxp [stack:1438]
acea5000 ad6a4000 rwxp [stack:1437]
ad6a4000 ad6a7000 r-xp /usr/lib/libXv.so.1.0.0
ad6b7000 ad6c9000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad6da000 ad711000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad723000 adf22000 rwxp [stack:1436]
adf22000 adf3f000 r-xp /usr/lib/libAl_Awb_Sp.so
adf48000 adf4b000 r-xp /usr/lib/libdeflicker.so
adf63000 adf79000 r-xp /usr/lib/libAl_Awb.so
adf81000 adf8b000 r-xp /usr/lib/libcalibration.so
adf94000 adfa6000 r-xp /usr/lib/libaf_lib.so
adfae000 adfb4000 r-xp /usr/lib/libspaf.so
adfbc000 adffd000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae044000 ae123000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae702000 ae70e000 r-xp /usr/lib/libae.so
ae716000 ae752000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae79c000 aef9b000 rwxp [stack:1434]
aef9c000 aefa2000 r-xp /usr/lib/liblsc.so
aefab000 aefac000 r-xp /usr/lib/libcamerahdr.so.0.0.0
af013000 af02b000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afd01000 b0500000 rwxp [stack:1431]
b0501000 b0d00000 rwxp [stack:1430]
b0e82000 b1681000 rwxp [stack:1429]
b1682000 b1e81000 rwxp [stack:1428]
b1e81000 b1e86000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f12000 b1f1a000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f2b000 b1f2c000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f3c000 b1f43000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f67000 b1f68000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f78000 b1f8b000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fdf000 b1fe4000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1ff5000 b27f4000 rwxp [stack:1427]
b27f4000 b294f000 r-xp /usr/lib/egl/libMali.so
b2964000 b29ed000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a06000 b2ad4000 r-xp /usr/lib/libCOREGL.so.4.0
b2aef000 b2af2000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b02000 b2b0f000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b20000 b2b2a000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b3a000 b2b46000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b57000 b2b5b000 r-xp /usr/lib/libogg.so.0.7.1
b2b6b000 b2b8d000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b9d000 b2c81000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c9d000 b2ce0000 r-xp /usr/lib/libsndfile.so.1.0.25
b2cf5000 b2d3c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d4d000 b2d54000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d64000 b2d99000 r-xp /usr/lib/libpulse.so.0.16.2
b2daa000 b2dad000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2dbe000 b2dc1000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2dd2000 b2e15000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e26000 b2e2e000 r-xp /usr/lib/libdrm.so.2.4.0
b2e3e000 b2e40000 r-xp /usr/lib/libdri2.so.0.0.0
b2e50000 b2e57000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e67000 b2e72000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e86000 b2e8c000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e9d000 b2ea5000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2eb6000 b2ebb000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2ecb000 b2ee2000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2ef2000 b2f12000 r-xp /usr/lib/libexif.so.12.3.3
b2f1e000 b2f26000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f36000 b2f65000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f78000 b2f80000 r-xp /usr/lib/libtbm.so.1.0.0
b2f90000 b3049000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b305d000 b3064000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b3074000 b30d2000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30e7000 b30eb000 r-xp /usr/lib/libstorage.so.0.1
b30fb000 b3102000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3112000 b3121000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b324b000 b324f000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3260000 b3340000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3355000 b335a000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3362000 b3389000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b339c000 b3b9b000 rwxp [stack:1250]
b3b9b000 b3b9d000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dad000 b3db6000 r-xp /lib/libnss_files-2.20-2014.11.so
b3dc7000 b3dd0000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3de1000 b3df2000 r-xp /lib/libnsl-2.20-2014.11.so
b3e05000 b3e0b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e1c000 b3e36000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e47000 b3e48000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e58000 b3e5a000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e6b000 b3e70000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e80000 b3e83000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e94000 b3e9b000 r-xp /usr/lib/libsensord-share.so
b3eab000 b3ebc000 r-xp /usr/lib/libsensor.so.1.2.0
b3ecd000 b3ed3000 r-xp /usr/lib/libappcore-common.so.1.1
b3ef6000 b3efb000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f11000 b3f13000 r-xp /usr/lib/libXau.so.6.0.0
b3f23000 b3f37000 r-xp /usr/lib/libxcb.so.1.1.0
b3f47000 b3f4e000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f86000 b3f88000 r-xp /usr/lib/libiri.so
b3f99000 b3fae000 r-xp /lib/libexpat.so.1.5.2
b3fc0000 b400e000 r-xp /usr/lib/libssl.so.1.0.0
b4023000 b402c000 r-xp /usr/lib/libethumb.so.1.13.0
b403d000 b4040000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4050000 b4207000 r-xp /usr/lib/libcrypto.so.1.0.0
b579e000 b57a7000 r-xp /usr/lib/libXi.so.6.1.0
b57b8000 b57ba000 r-xp /usr/lib/libXgesture.so.7.0.0
b57ca000 b57ce000 r-xp /usr/lib/libXtst.so.6.1.0
b57de000 b57e4000 r-xp /usr/lib/libXrender.so.1.3.0
b57f4000 b57fa000 r-xp /usr/lib/libXrandr.so.2.2.0
b580a000 b580c000 r-xp /usr/lib/libXinerama.so.1.0.0
b581c000 b581f000 r-xp /usr/lib/libXfixes.so.3.1.0
b5830000 b583b000 r-xp /usr/lib/libXext.so.6.4.0
b584b000 b584d000 r-xp /usr/lib/libXdamage.so.1.1.0
b585d000 b585f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b586f000 b5952000 r-xp /usr/lib/libX11.so.6.3.0
b5965000 b596c000 r-xp /usr/lib/libXcursor.so.1.0.2
b597d000 b5995000 r-xp /usr/lib/libudev.so.1.6.0
b5997000 b599a000 r-xp /lib/libattr.so.1.1.0
b59aa000 b59ca000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59cb000 b59d0000 r-xp /usr/lib/libffi.so.6.0.2
b59e0000 b59f8000 r-xp /lib/libz.so.1.2.8
b5a08000 b5a0a000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a1a000 b5aef000 r-xp /usr/lib/libxml2.so.2.9.2
b5b04000 b5b9f000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bbb000 b5bbe000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bce000 b5be8000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bf8000 b5c09000 r-xp /lib/libresolv-2.20-2014.11.so
b5c1d000 b5c34000 r-xp /usr/lib/liblzma.so.5.0.3
b5c44000 b5c46000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c56000 b5c5d000 r-xp /usr/lib/libembryo.so.1.13.0
b5c6d000 b5c85000 r-xp /usr/lib/libpng12.so.0.50.0
b5c96000 b5cb9000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cd9000 b5cdf000 r-xp /lib/librt-2.20-2014.11.so
b5cf0000 b5d04000 r-xp /usr/lib/libector.so.1.13.0
b5d15000 b5d2d000 r-xp /usr/lib/liblua-5.1.so
b5d3e000 b5d95000 r-xp /usr/lib/libfreetype.so.6.11.3
b5da9000 b5dd1000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5de2000 b5df5000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e06000 b5e40000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e51000 b5ebc000 r-xp /lib/libm-2.20-2014.11.so
b5ecd000 b5eda000 r-xp /usr/lib/libeio.so.1.13.0
b5eea000 b5eec000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5efc000 b5f01000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f11000 b5f28000 r-xp /usr/lib/libefreet.so.1.13.0
b5f3a000 b5f5a000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f6a000 b5f8a000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f8c000 b5f92000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fa2000 b5fa9000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fb9000 b5fc7000 r-xp /usr/lib/libeo.so.1.13.0
b5fd7000 b5fe9000 r-xp /usr/lib/libecore_input.so.1.13.0
b5ffa000 b5fff000 r-xp /usr/lib/libecore_file.so.1.13.0
b600f000 b6027000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6038000 b6055000 r-xp /usr/lib/libeet.so.1.13.0
b606e000 b60b6000 r-xp /usr/lib/libeina.so.1.13.0
b60c7000 b60d7000 r-xp /usr/lib/libefl.so.1.13.0
b60e8000 b61cd000 r-xp /usr/lib/libicuuc.so.51.1
b61ea000 b632a000 r-xp /usr/lib/libicui18n.so.51.1
b6341000 b6379000 r-xp /usr/lib/libecore_x.so.1.13.0
b638b000 b638e000 r-xp /lib/libcap.so.2.21
b639e000 b63c7000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63d8000 b63df000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63f1000 b6427000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6438000 b6520000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6534000 b65aa000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65bc000 b65bf000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65cf000 b65da000 r-xp /usr/lib/libvconf.so.0.2.45
b65ea000 b65ec000 r-xp /usr/lib/libvasum.so.0.3.1
b65fc000 b65fe000 r-xp /usr/lib/libttrace.so.1.1
b660e000 b6611000 r-xp /usr/lib/libiniparser.so.0
b6621000 b6644000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6654000 b6659000 r-xp /usr/lib/libxdgmime.so.1.1.0
b666a000 b6681000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6692000 b669f000 r-xp /usr/lib/libunwind.so.8.0.1
b66d5000 b67f9000 r-xp /lib/libc-2.20-2014.11.so
b680e000 b6827000 r-xp /lib/libgcc_s-4.9.so.1
b6837000 b6919000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b692a000 b695e000 r-xp /usr/lib/libdbus-1.so.3.8.11
b696e000 b69a8000 r-xp /usr/lib/libsystemd.so.0.4.0
b69aa000 b6a2a000 r-xp /usr/lib/libedje.so.1.13.0
b6a2d000 b6a4b000 r-xp /usr/lib/libecore.so.1.13.0
b6a6b000 b6bcd000 r-xp /usr/lib/libevas.so.1.13.0
b6c04000 b6c18000 r-xp /lib/libpthread-2.20-2014.11.so
b6c2c000 b6e50000 r-xp /usr/lib/libelementary.so.1.13.0
b6e7e000 b6e82000 r-xp /usr/lib/libsmack.so.1.0.0
b6e92000 b6e98000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ea9000 b6eab000 r-xp /usr/lib/libdlog.so.0.0.0
b6ebb000 b6ebe000 r-xp /usr/lib/libbundle.so.0.1.22
b6ece000 b6ed0000 r-xp /lib/libdl-2.20-2014.11.so
b6ee1000 b6efa000 r-xp /usr/lib/libaul.so.0.1.0
b6f0c000 b6f0e000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f1f000 b6f23000 r-xp /usr/lib/libsys-assert.so
b6f34000 b6f54000 r-xp /lib/ld-2.20-2014.11.so
b6f65000 b6f6b000 r-xp /usr/bin/launchpad-loader
b7340000 b78e3000 rw-p [heap]
beeb4000 beed5000 rwxp [stack]
beeb4000 beed5000 rwxp [stack]
End of Maps Information

Callstack Information (PID:1249)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6733128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb3358c2f) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3c2f
 2: (0xb3116abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3099865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63fd5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6409f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb640fa8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb640fc81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf01dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf01e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6888157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c09cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
R(  888): main.c: _rotate_window(252) > port :: hide more icon
01-23 19:22:09.851+0900 E/EFL     ( 1249): edje<1249> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
01-23 19:22:09.851+0900 E/EFL     ( 1249): By the power of Grayskull, your previous Embryo stack is now broken!
01-23 19:22:09.851+0900 D/AUL_AMD (  818): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 1249 is org.example.camera
01-23 19:22:09.851+0900 D/AUL     ( 1003): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
01-23 19:22:09.851+0900 D/AUL_AMD (  818): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 1249 : 0
01-23 19:22:09.861+0900 E/EFL     ( 1249): edje<1249> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
01-23 19:22:09.861+0900 E/EFL     ( 1249): By the power of Grayskull, your previous Embryo stack is now broken!
01-23 19:22:09.861+0900 W/APP_CORE( 1249): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4600003
01-23 19:22:09.861+0900 D/APP_CORE( 1249): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:4600003
01-23 19:22:09.861+0900 D/APP_CORE( 1249): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
01-23 19:22:09.861+0900 D/AUL     ( 1249): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
01-23 19:22:09.861+0900 D/AUL_AMD (  818): amd_request.c: __request_handler(838) > __request_handler: 34
01-23 19:22:09.891+0900 I/MALI    ( 1249): tizen_buffer.c: tizen_dri2_get_buffers(624) > Allocated private data for surface(0xb745edb0)
01-23 19:22:09.951+0900 I/MALI    (  524): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x14b2f00), gem(23), surface(0x14a75c8)
01-23 19:22:09.951+0900 I/MALI    ( 1249): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:22:09.951+0900 I/MALI    (  524): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1498a20), gem(16), surface(0x14a74d8)
01-23 19:22:09.961+0900 I/MALI    (  524): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x14b2f00), gem(23), surface(0x14b7970)
01-23 19:22:09.961+0900 D/APP_CORE( 1249): appcore.c: __prt_ltime(236) > [APP 1249] first idle after reset: 717 msec
01-23 19:22:09.971+0900 I/MALI    (  524): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x1497458), gem(20), surface(0x14d3f70)
01-23 19:22:09.971+0900 E/E17     (  524): e_border.c: e_border_hide(2248) > BD_HIDE(0x02600002), visible:1
01-23 19:22:09.971+0900 D/APP_CORE( 1249): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600003 fully_obscured 0
01-23 19:22:09.971+0900 D/APP_CORE( 1249): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
01-23 19:22:09.971+0900 D/APP_CORE(  914): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2600002 fully_obscured 1
01-23 19:22:09.971+0900 D/APP_CORE( 1249): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
01-23 19:22:09.971+0900 D/APP_CORE(  914): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
01-23 19:22:09.971+0900 D/APP_CORE(  914): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
01-23 19:22:09.971+0900 I/APP_CORE(  914): appcore-efl.c: __do_app(496) > [APP 914] Event: PAUSE State: RUNNING
01-23 19:22:09.971+0900 D/APP_CORE(  914): appcore-efl.c: __do_app(565) > [APP 914] PAUSE
01-23 19:22:09.971+0900 I/CAPI_APPFW_APPLICATION(  914): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
01-23 19:22:09.971+0900 E/cluster-home(  914): homescreen.cpp: OnPause(84) >  app pause
01-23 19:22:09.971+0900 I/APP_CORE( 1249): appcore-efl.c: __do_app(496) > [APP 1249] Event: RESUME State: CREATED
01-23 19:22:09.971+0900 D/cluster-view(  914): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
01-23 19:22:09.971+0900 D/cluster-view(  914): homescreen-view-manager.cpp: AppPause(923) >  END
01-23 19:22:09.971+0900 D/APP_CORE(  914): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-23 19:22:09.971+0900 D/LAUNCH  ( 1249): appcore-efl.c: __do_app(597) > [camera:Application:resume:start]
01-23 19:22:09.971+0900 D/APP_CORE( 1249): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
01-23 19:22:09.971+0900 D/APP_CORE( 1249): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-23 19:22:09.971+0900 E/APP_CORE(  914): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-23 19:22:09.971+0900 D/APP_CORE( 1249): appcore-efl.c: __do_app(607) > [APP 1249] RESUME
01-23 19:22:09.971+0900 D/AUL_AMD (  818): amd_status.c: _status_update_app_info_list(456) > pid(914) status(4)
01-23 19:22:09.971+0900 D/AUL_AMD (  818): amd_status.c: _status_update_app_info_list(468) > pid(914) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
01-23 19:22:09.971+0900 D/AUL     (  818): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
01-23 19:22:09.971+0900 W/AUL     (  818): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 914, appid: org.tizen.homescreen, status: bg
01-23 19:22:09.971+0900 D/AUL_AMD (  818): amd_launch.c: __e17_status_handler(2887) > pid(1249) status(3)
01-23 19:22:09.971+0900 D/AUL_AMD (  818): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-23 19:22:09.981+0900 D/AUL_AMD (  818): amd_launch.c: __e17_status_handler(2893) > back key ungrab
01-23 19:22:09.981+0900 D/AUL_AMD (  818): amd_status.c: _status_update_app_info_list(456) > pid(1249) status(3)
01-23 19:22:09.981+0900 D/AUL_AMD (  818): amd_status.c: _status_update_app_info_list(468) > pid(1249) appid(org.example.camera) pkgid(org.example.camera) status(3)
01-23 19:22:09.981+0900 D/AUL     (  818): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.camera
01-23 19:22:09.981+0900 W/AUL     (  818): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1249, appid: org.example.camera, status: fg
01-23 19:22:09.981+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1249
01-23 19:22:09.981+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1249, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-23 19:22:09.981+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 1249
01-23 19:22:09.981+0900 D/DATA_PROVIDER_MASTER(  977): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 914 is paused
01-23 19:22:09.981+0900 D/DATA_PROVIDER_MASTER(  977): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
01-23 19:22:09.981+0900 I/CAPI_WIDGET_APPLICATION(  973): widget_app.c: __provider_pause_cb(292) > widget obj was paused
01-23 19:22:09.981+0900 I/CAPI_WIDGET_APPLICATION(  973): widget_app.c: __check_status_for_cgroup(142) > enter background group
01-23 19:22:09.981+0900 W/AUL     (  973): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 973, appid: org.tizen.calendar.widget, status: bg
01-23 19:22:09.981+0900 I/APP_CORE( 1249): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
01-23 19:22:09.981+0900 I/APP_CORE( 1249): appcore-efl.c: __do_app(614) > [APP 1249] Initial Launching, call the resume_cb
01-23 19:22:09.981+0900 I/CAPI_APPFW_APPLICATION( 1249): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-23 19:22:09.981+0900 D/LAUNCH  ( 1249): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-23 19:22:09.981+0900 D/LAUNCH  ( 1249): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-23 19:22:09.981+0900 D/APP_CORE( 1249): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-23 19:22:09.991+0900 E/APP_CORE( 1249): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-23 19:22:10.101+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 1249, appname = org.example.camera, pkgname = org.example.camera
01-23 19:22:10.101+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 1249, appname = org.example.camera
01-23 19:22:10.101+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 1249
01-23 19:22:10.101+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 1249 foreground
01-23 19:22:10.101+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 973, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
01-23 19:22:10.101+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 973
01-23 19:22:10.161+0900 D/AUL_AMD (  818): amd_launch.c: __e17_status_handler(2906) > pid(1249) status(0)
01-23 19:22:10.271+0900 D/RESOURCED(  870): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 973, appname = org.tizen.calendar.widget
01-23 19:22:10.271+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 973
01-23 19:22:10.361+0900 D/AUL_PAD (  962): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
01-23 19:22:10.371+0900 D/AUL_PAD ( 1433): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
01-23 19:22:10.381+0900 D/AUL_PAD (  962): sigchild.h: __send_app_launch_signal(130) > send launch signal done
01-23 19:22:10.401+0900 E/RESOURCED(  870): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.158
01-23 19:22:10.602+0900 D/APP_CORE( 1151): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
01-23 19:22:10.602+0900 I/APP_CORE( 1151): appcore-efl.c: __do_app(496) > [APP 1151] Event: MEM_FLUSH State: PAUSED
01-23 19:22:10.602+0900 D/APP_CORE( 1151): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
01-23 19:22:10.602+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 1151
01-23 19:22:10.602+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 1151 background
01-23 19:22:10.862+0900 D/AUL_AMD (  818): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.camera /opt/usr/apps/org.example.camera/bin/camera
01-23 19:22:10.862+0900 D/RUA     (  818): rua.c: rua_add_history(179) > rua_add_history start
01-23 19:22:10.872+0900 D/RUA     (  818): rua.c: rua_add_history(247) > rua_add_history ok
01-23 19:22:11.412+0900 I/MALI    (  524): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x13fefe0), gem(20), surface(0x14b8db8)
01-23 19:22:11.483+0900 D/AUL_PAD ( 1433): launchpad_loader.c: main(588) > sleeping 1 sec...
01-23 19:22:11.483+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(52) > max_cmdline_size = 1053
01-23 19:22:11.483+0900 D/PROCESSMGR(  524): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200033  register trigger_timer!  pointed_win=0x2003cc 
01-23 19:22:11.513+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b72c9768
01-23 19:22:11.513+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(69) > get pre-initialization function
01-23 19:22:11.513+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(73) > get shutdown function
01-23 19:22:11.513+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b72c9a48
01-23 19:22:11.523+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b72cb5b0
01-23 19:22:11.523+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(69) > get pre-initialization function
01-23 19:22:11.523+0900 D/AUL_PAD ( 1433): preload.h: __preload_init(73) > get shutdown function
01-23 19:22:11.533+0900 D/AUL_PAD ( 1433): preexec.h: __preexec_init(76) > preexec start
01-23 19:22:11.533+0900 D/AUL_PAD ( 1433): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
01-23 19:22:11.533+0900 D/AUL     ( 1433): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
01-23 19:22:11.533+0900 D/AUL     ( 1433): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
01-23 19:22:11.533+0900 D/AUL_PAD (  962): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 1433
01-23 19:22:11.533+0900 D/AUL     ( 1433): process_pool.c: __connect_to_launchpad(132) > send(1433) : 4
01-23 19:22:11.533+0900 D/AUL     ( 1433): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): tunnig_param=263480
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): param_num=3
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): cur target lum=62, ev diff=0, level=4
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): AE VERSION : 0x20150828-00
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): cvg speed=0
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): target lum=62, target lum zone=8
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): lime time=134, min line=1
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): cvgn_param[0] error!!!  set default cvgn_param
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): target_lum_ev0=62
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): highcount=19,lowcount=15
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): FDAE: failed open fdae_param.txt
01-23 19:22:11.793+0900 I/ISP_AE  ( 1249): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-23 19:22:11.793+0900 D/alPrinter0( 1249): LSC Size:20 16
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [LSC]TableSize=   320
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [LSC]TableSize=   320
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [LSC]TableSize=   320
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [OTP]module has otp data 0xb0d17044 (nil) 20 16
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [LSC]TableSize=   320
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [LSC]TableSize=   320
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-23 19:22:11.793+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-23 19:22:11.803+0900 D/AUL_PAD ( 1433): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
01-23 19:22:11.843+0900 D/AUL_PAD ( 1433): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
01-23 19:22:11.843+0900 D/AUL_PAD ( 1433): launchpad_loader.c: main(693) > [candidate] ecore handler add
01-23 19:22:11.843+0900 D/AUL_PAD ( 1433): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): work_mode=0 last mode=0
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): cvg speed=0
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): target lum=62, target lum zone=8
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): lime time=134, min line=1
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): target_lum_ev0=62
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): highcount=19,lowcount=15
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): is_quick=0
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): AE_TEST:-----------SET index:282
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): AE_TEST: get index:282, exp:300000, line:2238
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): AE_TEST:-----------SET index:282
01-23 19:22:11.923+0900 I/ISP_AE  ( 1249): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-23 19:22:11.933+0900 I/ISP_AE  ( 1249): calc_iso=50,real_gain=19,iso=0
01-23 19:22:12.063+0900 D/APP_CORE(  914): appcore-rotation.c: __changed_cb(121) > [APP 914] Rotation: 1 -> 3
01-23 19:22:12.063+0900 D/APP_CORE(  914): appcore-rotation.c: __changed_cb(124) > [APP 914] Rotation: 1 -> 3
01-23 19:22:12.063+0900 I/CAPI_APPFW_APPLICATION(  914): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-23 19:22:12.203+0900 I/ISP_AE  ( 1249): set_weight, table[0] = 1
01-23 19:22:12.203+0900 I/ISP_AE  ( 1249): set weight from 1 to 0, rtn=0
01-23 19:22:12.203+0900 I/ISP_AE  ( 1249): AE_TEST ----------------------change to fast
01-23 19:22:12.203+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:282, cur_lum:2, next_index:332, target_lum:62
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,6a,a9,00,00,00,00
01-23 19:22:12.203+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,6a,a9,00,00,00,00
01-23 19:22:12.203+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [LineAdj] Mode -2147483647
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [LineAdj]Tar RGB 557,733,473
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [LineAdj]Ref RGB 557,750,487
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-23 19:22:12.203+0900 D/alPrinter0( 1249): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [LED]LPF Disable
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.15, detect:   0.34,   0.37 CTemp:5325.8
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [CHROMA]START BV=0.427002 Ratio=1.000000
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [HSC]Mix=00000000,Csd=0000cfae ,(BV= 0.427,x=0.355,y=0.385)
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=0.427010 ,Awb Bv=0.427002 in/out_0
01-23 19:22:12.213+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.287186,GGain=1.000000,BGain=1.499344,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-23 19:22:12.263+0900 D/APP_CORE(  914): appcore-rotation.c: __changed_cb(121) > [APP 914] Rotation: 3 -> 1
01-23 19:22:12.263+0900 D/APP_CORE(  914): appcore-rotation.c: __changed_cb(124) > [APP 914] Rotation: 3 -> 1
01-23 19:22:12.263+0900 I/CAPI_APPFW_APPLICATION(  914): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-23 19:22:12.313+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:332, cur_lum:12, next_index:368, target_lum:62
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:12.313+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:12.313+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [LED]LPF Disable
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.69, detect:   0.35,   0.37 CTemp:5036.3
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [HSC]Mix=00001333,Csd=0003c9e3 ,(BV=-0.666,x=0.350,y=0.377)
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:4, 0x00001333,0x00001333
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-0.666100 ,Awb Bv=-0.666092 in/out_0
01-23 19:22:12.313+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.265701,GGain=1.000000,BGain=1.537888,Dtct=0.350113,0.377426 ,Curr=0.350113,0.377426 ,CTmep: QC=5166, AL= 4897
01-23 19:22:12.373+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7713d70), gem(46), surface(0xb781ad08)
01-23 19:22:12.383+0900 E/EFL     ( 1249): evas_main<1249> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-23 19:22:12.393+0900 I/MALI    ( 1249): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:22:12.413+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:368, cur_lum:27, next_index:384, target_lum:62
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:12.413+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:12.413+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [LED]LPF Disable
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.413+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.90, detect:   0.34,   0.37 CTemp:5290.6
01-23 19:22:12.423+0900 D/alPrinter0( 1249): [HSC]Mix=000031eb,Csd=000453f2 ,(BV=-1.251,x=0.345,y=0.373)
01-23 19:22:12.423+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:3, 0x000031eb,0x000031eb
01-23 19:22:12.423+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.251062 ,Awb Bv=-1.251053 in/out_0
01-23 19:22:12.423+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.275146,GGain=1.000000,BGain=1.502686,Dtct=0.345093,0.373367 ,Curr=0.345093,0.373367 ,CTmep: QC=5359, AL= 5052
01-23 19:22:12.443+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(47), surface(0xb78471e0)
01-23 19:22:12.453+0900 I/MALI    ( 1249): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:22:12.484+0900 D/PROCESSMGR(  524): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x4600003
01-23 19:22:12.504+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(46), surface(0xb78471e0)
01-23 19:22:12.504+0900 I/MALI    ( 1249): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:22:12.534+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:384, cur_lum:41, next_index:389, target_lum:62
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:12.534+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:12.534+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [LED]LPF Enable
01-23 19:22:12.534+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.544+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5395.6
01-23 19:22:12.544+0900 D/alPrinter0( 1249): [HSC]Mix=000050a3,Csd=000398a6 ,(BV=-1.254,x=0.345,y=0.373)
01-23 19:22:12.544+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:4, 0x000050a3,0x000050a3
01-23 19:22:12.544+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.394020 ,Awb Bv=-1.253906 in/out_0
01-23 19:22:12.544+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.275146,GGain=1.000000,BGain=1.502686,Dtct=0.345352,0.373215 ,Curr=0.345093,0.373367 ,CTmep: QC=5359, AL= 5052
01-23 19:22:12.554+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb78471e0)
01-23 19:22:12.604+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(46), surface(0xb78471e0)
01-23 19:22:12.654+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:389, cur_lum:42, next_index:394, target_lum:62
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:12.654+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:12.654+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.654+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.94, detect:   0.33,   0.36 CTemp:5446.1
01-23 19:22:12.664+0900 D/alPrinter0( 1249): [HSC]Mix=00006f5b,Csd=000384a2 ,(BV=-1.267,x=0.344,y=0.371)
01-23 19:22:12.664+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:3, 0x00006f5b,0x00006f5b
01-23 19:22:12.664+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.524081 ,Awb Bv=-1.266724 in/out_0
01-23 19:22:12.664+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.274887,GGain=1.000000,BGain=1.502045,Dtct=0.343948,0.371368 ,Curr=0.345062,0.373306 ,CTmep: QC=5359, AL= 5052
01-23 19:22:12.674+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb78471e0)
01-23 19:22:12.724+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75e6b50), gem(46), surface(0xb78471e0)
01-23 19:22:12.774+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:394, cur_lum:46, next_index:397, target_lum:62
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:12.774+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:12.774+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.774+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.784+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5540.4
01-23 19:22:12.784+0900 D/alPrinter0( 1249): [HSC]Mix=00008e13,Csd=0003578e ,(BV=-1.294,x=0.343,y=0.370)
01-23 19:22:12.784+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:4, 0x00008e13,0x00008e13
01-23 19:22:12.784+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.596837 ,Awb Bv=-1.294434 in/out_0
01-23 19:22:12.784+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.274399,GGain=1.000000,BGain=1.500275,Dtct=0.343033,0.369537 ,Curr=0.344971,0.373138 ,CTmep: QC=5359, AL= 5052
01-23 19:22:12.804+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(47), surface(0xb78471e0)
01-23 19:22:12.854+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(46), surface(0xb78471e0)
01-23 19:22:12.894+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:397, cur_lum:50, next_index:400, target_lum:62
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:12.894+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:12.894+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:12.894+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5559.2
01-23 19:22:12.904+0900 D/alPrinter0( 1249): [HSC]Mix=0000accb,Csd=000231f9 ,(BV=-1.336,x=0.343,y=0.369)
01-23 19:22:12.904+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:3, 0x0000accb,0x0000accb
01-23 19:22:12.904+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.666100 ,Awb Bv=-1.336426 in/out_0
01-23 19:22:12.904+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.273407,GGain=1.000000,BGain=1.496155,Dtct=0.343094,0.368713 ,Curr=0.344742,0.372742 ,CTmep: QC=5360, AL= 5053
01-23 19:22:12.934+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb78471e0)
01-23 19:22:12.984+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75e6b50), gem(46), surface(0xb78471e0)
01-23 19:22:13.014+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:400, cur_lum:53, next_index:401, target_lum:62
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:13.014+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:13.014+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:13.014+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.36 CTemp:5541.4
01-23 19:22:13.024+0900 D/alPrinter0( 1249): [HSC]Mix=0000cb83,Csd=0000d2a5 ,(BV=-1.389,x=0.343,y=0.368)
01-23 19:22:13.024+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:4, 0x0000cb83,0x0000cb83
01-23 19:22:13.024+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.710494 ,Awb Bv=-1.389297 in/out_0
01-23 19:22:13.024+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.271240,GGain=1.000000,BGain=1.490158,Dtct=0.342896,0.367584 ,Curr=0.344482,0.372162 ,CTmep: QC=5363, AL= 5055
01-23 19:22:13.034+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(47), surface(0xb78471e0)
01-23 19:22:13.074+0900 D/AUL_AMD (  818): amd_status.c: __app_terminate_timer_cb(442) > pid(975)
01-23 19:22:13.074+0900 W/AUL_AMD (  818): amd_status.c: __app_terminate_timer_cb(446) > send SIGKILL: No such process
01-23 19:22:13.084+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7726568), gem(46), surface(0xb7847070)
01-23 19:22:13.134+0900 D/PROCESSMGR(  524): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200033  register trigger_timer!  pointed_win=0x2003cc 
01-23 19:22:13.134+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:401, cur_lum:56, next_index:402, target_lum:62
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:13.134+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:13.134+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:13.134+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.35 CTemp:5577.7
01-23 19:22:13.144+0900 D/alPrinter0( 1249): [HSC]Mix=0000deb6,Csd=ffff671f ,(BV=-1.449,x=0.343,y=0.367)
01-23 19:22:13.144+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:3, 0x0000deb6,0x0000deb6
01-23 19:22:13.144+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.753562 ,Awb Bv=-1.448975 in/out_0
01-23 19:22:13.144+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.268356,GGain=1.000000,BGain=1.482590,Dtct=0.342560,0.366882 ,Curr=0.344162,0.371414 ,CTmep: QC=5364, AL= 5056
01-23 19:22:13.164+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(47), surface(0xb75a6678)
01-23 19:22:13.204+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(46), surface(0xb75eb738)
01-23 19:22:13.254+0900 I/ISP_AE  ( 1249): AE_TEST:----cur_index:402, cur_lum:58, next_index:403, target_lum:62
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:22:13.254+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [CMD0][if=b0d20cf0,Wrap=b0d26220]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:22:13.254+0900 D/awb_al_cmd0( 1249): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [CALL][0xb0d20cf0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [AIS_WRAP]msiFlash_state=0
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [LOCK]0
01-23 19:22:13.254+0900 D/alPrinter0( 1249): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.35 CTemp:5626.4
01-23 19:22:13.264+0900 D/alPrinter0( 1249): [HSC]Mix=0000d479,Csd=fffef3ea ,(BV=-1.512,x=0.342,y=0.367)
01-23 19:22:13.264+0900 D/alPrinter0( 1249): [AlHscWrap_Main]:4, 0x0000d479,0x0000d479
01-23 19:22:13.264+0900 D/alPrinter0( 1249): [AIS_WRAP]In BV=-1.795382 ,Awb Bv=-1.511673 in/out_0
01-23 19:22:13.264+0900 D/alPrinter0( 1249): [AIS_WRAP]RGain=1.264954,GGain=1.000000,BGain=1.474228,Dtct=0.341583,0.366516 ,Curr=0.343826,0.370575 ,CTmep: QC=5366, AL= 5058
01-23 19:22:13.284+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb75eb738)
01-23 19:22:13.344+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(46), surface(0xb7847070)
01-23 19:22:13.364+0900 I/ISP_AE  ( 1249): ae_state=3
01-23 19:22:13.384+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb784a668), gem(47), surface(0xb75eb738)
01-23 19:22:13.484+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(46), surface(0xb7847070)
01-23 19:22:13.525+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb75eb738)
01-23 19:22:13.575+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(46), surface(0xb7847070)
01-23 19:22:13.645+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb75a6678)
01-23 19:22:13.695+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(46), surface(0xb7847070)
01-23 19:22:13.745+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb7847070)
01-23 19:22:13.765+0900 I/ISP_AE  ( 1249): FDAE: ->disable, frame_idx=30
01-23 19:22:13.815+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(46), surface(0xb7847070)
01-23 19:22:13.865+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb784a668), gem(47), surface(0xb7847070)
01-23 19:22:13.945+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(46), surface(0xb7847070)
01-23 19:22:13.995+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75e6b50), gem(47), surface(0xb7847070)
01-23 19:22:14.045+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(46), surface(0xb7847070)
01-23 19:22:14.125+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(47), surface(0xb7847070)
01-23 19:22:14.175+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb784a668), gem(46), surface(0xb7847070)
01-23 19:22:14.225+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb7847070)
01-23 19:22:14.295+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75e6b50), gem(46), surface(0xb7847070)
01-23 19:22:14.345+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb750fdb0), gem(47), surface(0xb7847070)
01-23 19:22:14.425+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75966a8), gem(46), surface(0xb7847070)
01-23 19:22:14.475+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb784a668), gem(47), surface(0xb7847070)
01-23 19:22:14.526+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(46), surface(0xb7847070)
01-23 19:22:14.596+0900 I/ISP_AE  ( 1249): calc_iso=430,real_gain=140,iso=0
01-23 19:22:14.596+0900 I/ISP_AE  ( 1249): calc_iso=430,real_gain=140,iso=0
01-23 19:22:14.606+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77117c8), gem(47), surface(0xb7847070)
01-23 19:22:14.826+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76f1898), gem(46), surface(0xb7847070)
01-23 19:22:14.856+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(47), surface(0xb7847070)
01-23 19:22:14.906+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77117c8), gem(46), surface(0xb7847070)
01-23 19:22:14.956+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76f1898), gem(47), surface(0xb77139e0)
01-23 19:22:14.976+0900 D/APP_CORE(  914): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
01-23 19:22:14.976+0900 I/APP_CORE(  914): appcore-efl.c: __do_app(496) > [APP 914] Event: MEM_FLUSH State: PAUSED
01-23 19:22:14.976+0900 D/APP_CORE(  914): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
01-23 19:22:14.976+0900 D/APP_CORE(  914): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 914
01-23 19:22:14.976+0900 D/APP_CORE(  914): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
01-23 19:22:14.976+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 914
01-23 19:22:14.996+0900 D/camera  ( 1249): Writing image to file.
01-23 19:22:15.006+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7845a48), gem(46), surface(0xb7847070)
01-23 19:22:15.086+0900 I/MALI    ( 1249): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77117c8), gem(47), surface(0xb7847070)
01-23 19:22:15.116+0900 E/EFL     (  524): eo<524> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-23 19:22:15.136+0900 E/E17     (  524): e_border.c: e_border_show(2088) > BD_SHOW(0x02600002)
01-23 19:22:15.146+0900 E/E17     (  524): e_border.c: e_border_hide(2248) > BD_HIDE(0x04600003), visible:1
01-23 19:22:15.146+0900 D/INDICATOR(  888): main.c: _property_changed_cb(432) > UNSNIFF API 4600003
01-23 19:22:15.146+0900 D/INDICATOR(  888): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-23 19:22:15.146+0900 D/INDICATOR(  888): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-23 19:22:15.156+0900 D/INDICATOR(  888): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-23 19:22:15.156+0900 D/INDICATOR(  888): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-23 19:22:15.156+0900 D/INDICATOR(  888): main.c: _rotate_window(252) > port :: hide more icon
01-23 19:22:15.156+0900 I/MALI    (  524): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1498a20), gem(16), surface(0x14aa3c8)
01-23 19:22:15.156+0900 D/AUL_AMD (  818): amd_launch.c: __e17_status_handler(2887) > pid(914) status(3)
01-23 19:22:15.156+0900 D/AUL_AMD (  818): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-23 19:22:15.156+0900 W/AUL_AMD (  818): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-23 19:22:15.156+0900 W/AUL_AMD (  818): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-23 19:22:15.156+0900 D/AUL_AMD (  818): amd_status.c: _status_update_app_info_list(456) > pid(914) status(3)
01-23 19:22:15.156+0900 D/AUL_AMD (  818): amd_status.c: _status_update_app_info_list(468) > pid(914) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-23 19:22:15.156+0900 D/AUL     (  818): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-23 19:22:15.156+0900 W/AUL     (  818): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 914, appid: org.tizen.homescreen, status: fg
01-23 19:22:15.156+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 914
01-23 19:22:15.156+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 914, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
01-23 19:22:15.156+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 914, appname = org.tizen.homescreen
01-23 19:22:15.156+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 914
01-23 19:22:15.156+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 914 foreground
01-23 19:22:15.186+0900 W/CRASH_MANAGER( 1486): worker.c: worker_job(1204) > 110124963616d142200853
