S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 1824
Date: 2015-01-22 21:29:24+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 1824, uid 5000)

Register Information
r0   = 0xac42bc00, r1   = 0x00000001
r2   = 0x0002527b, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0002527b
r6   = 0x0002527b, r7   = 0xad6b0588
r8   = 0xb795d100, r9   = 0xad6b0734
r10  = 0xb7961ac8, fp   = 0x0000000d
ip   = 0xb66f9110, sp   = 0xad6b04f0
lr   = 0xb331ed13, pc   = 0xb66f9128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    421156 KB
Buffers:     17704 KB
Cached:     127052 KB
VmPeak:     593760 KB
VmSize:     535244 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       43616 KB
VmRSS:       43616 KB
VmData:     417964 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         226 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 1824 TID = 1957
1824 1867 1884 1885 1886 1887 1888 1893 1932 1933 1934 1938 1956 1957 1958 1959 1960 1961 1965 1966 1967 1968 1969 1970 1971 1974 1975 1976 1977 1978 1979 1980 1981 1982 1983 1984 1985 1986 1987 1988 1989 1990 1991 1992 1993 1994 2000 2004 

Maps Information
9323c000 93a3b000 rwxp [stack:1938]
988fd000 990fc000 rwxp [stack:1934]
990fd000 998fc000 rwxp [stack:1933]
9a001000 9a800000 rwxp [stack:2000]
9affd000 9b7fc000 rwxp [stack:2004]
9b7fd000 9bffc000 rwxp [stack:1932]
9c094000 9c893000 rwxp [stack:1958]
9c901000 9d100000 rwxp [stack:1994]
9d101000 9d900000 rwxp [stack:1993]
9d901000 9e100000 rwxp [stack:1992]
9e101000 9e900000 rwxp [stack:1991]
9e901000 9f100000 rwxp [stack:1990]
9f101000 9f900000 rwxp [stack:1989]
9f901000 a0100000 rwxp [stack:1988]
a0101000 a0900000 rwxp [stack:1987]
a0901000 a1100000 rwxp [stack:1986]
a1101000 a1900000 rwxp [stack:1985]
a1901000 a2100000 rwxp [stack:1984]
a2101000 a2900000 rwxp [stack:1983]
a2901000 a3100000 rwxp [stack:1982]
a3101000 a3900000 rwxp [stack:1981]
a3901000 a4100000 rwxp [stack:1980]
a4101000 a4900000 rwxp [stack:1979]
a4b7f000 a537e000 rwxp [stack:1978]
a537f000 a5b7e000 rwxp [stack:1977]
a605f000 a685e000 rwxp [stack:1976]
a6b01000 a7300000 rwxp [stack:1975]
a7301000 a7b00000 rwxp [stack:1974]
a7b01000 a8300000 rwxp [stack:1971]
a8301000 a8b00000 rwxp [stack:1970]
a8b01000 a9300000 rwxp [stack:1969]
a9301000 a9b00000 rwxp [stack:1968]
a9b01000 aa300000 rwxp [stack:1967]
aa301000 aab00000 rwxp [stack:1966]
aab01000 ab300000 rwxp [stack:1965]
ab301000 abb00000 rwxp [stack:1960]
abb01000 ac300000 rwxp [stack:1961]
ac501000 acd00000 rwxp [stack:1959]
aceb3000 ad6b2000 rwxp [stack:1957]
ad6b2000 ad6b5000 r-xp /usr/lib/libXv.so.1.0.0
ad6c5000 ad6d7000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad6e8000 ad71f000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad731000 adf30000 rwxp [stack:1956]
adf30000 adf4d000 r-xp /usr/lib/libAl_Awb_Sp.so
adf56000 adf59000 r-xp /usr/lib/libdeflicker.so
adf71000 adf87000 r-xp /usr/lib/libAl_Awb.so
adf8f000 adf99000 r-xp /usr/lib/libcalibration.so
adfa2000 adfb4000 r-xp /usr/lib/libaf_lib.so
adfbc000 adffd000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae044000 ae123000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae704000 ae740000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae78a000 aef89000 rwxp [stack:1893]
aef89000 aef8f000 r-xp /usr/lib/libspaf.so
aef97000 aefa3000 r-xp /usr/lib/libae.so
aefab000 aefac000 r-xp /usr/lib/libcamerahdr.so.0.0.0
afc04000 afc1c000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afd01000 b0500000 rwxp [stack:1888]
b0501000 b0d00000 rwxp [stack:1887]
b0e00000 b0e06000 r-xp /usr/lib/liblsc.so
b0e48000 b1647000 rwxp [stack:1886]
b1648000 b1e47000 rwxp [stack:1885]
b1e47000 b1e4c000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1ed8000 b1ee0000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1ef1000 b1ef2000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f02000 b1f09000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f2d000 b1f2e000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f3e000 b1f51000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fa5000 b1faa000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1fbb000 b27ba000 rwxp [stack:1884]
b27ba000 b2915000 r-xp /usr/lib/egl/libMali.so
b292a000 b29b3000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b29cc000 b2a9a000 r-xp /usr/lib/libCOREGL.so.4.0
b2ab5000 b2ab8000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2ac8000 b2ad5000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2ae6000 b2af0000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b00000 b2b0c000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b1d000 b2b21000 r-xp /usr/lib/libogg.so.0.7.1
b2b31000 b2b53000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b63000 b2c47000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c63000 b2ca6000 r-xp /usr/lib/libsndfile.so.1.0.25
b2cbb000 b2d02000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d13000 b2d1a000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d2a000 b2d5f000 r-xp /usr/lib/libpulse.so.0.16.2
b2d70000 b2d73000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2d84000 b2d87000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2d98000 b2ddb000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2dec000 b2df4000 r-xp /usr/lib/libdrm.so.2.4.0
b2e04000 b2e06000 r-xp /usr/lib/libdri2.so.0.0.0
b2e16000 b2e1d000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e2d000 b2e38000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e4c000 b2e52000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e63000 b2e6b000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2e7c000 b2e81000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2e91000 b2ea8000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2eb8000 b2ed8000 r-xp /usr/lib/libexif.so.12.3.3
b2ee4000 b2eec000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2efc000 b2f2b000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f3e000 b2f46000 r-xp /usr/lib/libtbm.so.1.0.0
b2f56000 b300f000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3023000 b302a000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b303a000 b3098000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30ad000 b30b1000 r-xp /usr/lib/libstorage.so.0.1
b30c1000 b30c8000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30d8000 b30e7000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3211000 b3215000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3226000 b3306000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b331b000 b3320000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3328000 b334f000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3362000 b3b61000 rwxp [stack:1867]
b3b61000 b3b63000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d73000 b3d7c000 r-xp /lib/libnss_files-2.20-2014.11.so
b3d8d000 b3d96000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3da7000 b3db8000 r-xp /lib/libnsl-2.20-2014.11.so
b3dcb000 b3dd1000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3de2000 b3dfc000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e0d000 b3e0e000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e1e000 b3e20000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e31000 b3e36000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e46000 b3e49000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e5a000 b3e61000 r-xp /usr/lib/libsensord-share.so
b3e71000 b3e82000 r-xp /usr/lib/libsensor.so.1.2.0
b3e93000 b3e99000 r-xp /usr/lib/libappcore-common.so.1.1
b3ebc000 b3ec1000 r-xp /usr/lib/libappcore-efl.so.1.1
b3ed7000 b3ed9000 r-xp /usr/lib/libXau.so.6.0.0
b3ee9000 b3efd000 r-xp /usr/lib/libxcb.so.1.1.0
b3f0d000 b3f14000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f4c000 b3f4e000 r-xp /usr/lib/libiri.so
b3f5f000 b3f74000 r-xp /lib/libexpat.so.1.5.2
b3f86000 b3fd4000 r-xp /usr/lib/libssl.so.1.0.0
b3fe9000 b3ff2000 r-xp /usr/lib/libethumb.so.1.13.0
b4003000 b4006000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4016000 b41cd000 r-xp /usr/lib/libcrypto.so.1.0.0
b5764000 b576d000 r-xp /usr/lib/libXi.so.6.1.0
b577e000 b5780000 r-xp /usr/lib/libXgesture.so.7.0.0
b5790000 b5794000 r-xp /usr/lib/libXtst.so.6.1.0
b57a4000 b57aa000 r-xp /usr/lib/libXrender.so.1.3.0
b57ba000 b57c0000 r-xp /usr/lib/libXrandr.so.2.2.0
b57d0000 b57d2000 r-xp /usr/lib/libXinerama.so.1.0.0
b57e2000 b57e5000 r-xp /usr/lib/libXfixes.so.3.1.0
b57f6000 b5801000 r-xp /usr/lib/libXext.so.6.4.0
b5811000 b5813000 r-xp /usr/lib/libXdamage.so.1.1.0
b5823000 b5825000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5835000 b5918000 r-xp /usr/lib/libX11.so.6.3.0
b592b000 b5932000 r-xp /usr/lib/libXcursor.so.1.0.2
b5943000 b595b000 r-xp /usr/lib/libudev.so.1.6.0
b595d000 b5960000 r-xp /lib/libattr.so.1.1.0
b5970000 b5990000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5991000 b5996000 r-xp /usr/lib/libffi.so.6.0.2
b59a6000 b59be000 r-xp /lib/libz.so.1.2.8
b59ce000 b59d0000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59e0000 b5ab5000 r-xp /usr/lib/libxml2.so.2.9.2
b5aca000 b5b65000 r-xp /usr/lib/libstdc++.so.6.0.20
b5b81000 b5b84000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5b94000 b5bae000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bbe000 b5bcf000 r-xp /lib/libresolv-2.20-2014.11.so
b5be3000 b5bfa000 r-xp /usr/lib/liblzma.so.5.0.3
b5c0a000 b5c0c000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c1c000 b5c23000 r-xp /usr/lib/libembryo.so.1.13.0
b5c33000 b5c4b000 r-xp /usr/lib/libpng12.so.0.50.0
b5c5c000 b5c7f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5c9f000 b5ca5000 r-xp /lib/librt-2.20-2014.11.so
b5cb6000 b5cca000 r-xp /usr/lib/libector.so.1.13.0
b5cdb000 b5cf3000 r-xp /usr/lib/liblua-5.1.so
b5d04000 b5d5b000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d6f000 b5d97000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5da8000 b5dbb000 r-xp /usr/lib/libfribidi.so.0.3.1
b5dcc000 b5e06000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e17000 b5e82000 r-xp /lib/libm-2.20-2014.11.so
b5e93000 b5ea0000 r-xp /usr/lib/libeio.so.1.13.0
b5eb0000 b5eb2000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5ec2000 b5ec7000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5ed7000 b5eee000 r-xp /usr/lib/libefreet.so.1.13.0
b5f00000 b5f20000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f30000 b5f50000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f52000 b5f58000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f68000 b5f6f000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f7f000 b5f8d000 r-xp /usr/lib/libeo.so.1.13.0
b5f9d000 b5faf000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fc0000 b5fc5000 r-xp /usr/lib/libecore_file.so.1.13.0
b5fd5000 b5fed000 r-xp /usr/lib/libecore_evas.so.1.13.0
b5ffe000 b601b000 r-xp /usr/lib/libeet.so.1.13.0
b6034000 b607c000 r-xp /usr/lib/libeina.so.1.13.0
b608d000 b609d000 r-xp /usr/lib/libefl.so.1.13.0
b60ae000 b6193000 r-xp /usr/lib/libicuuc.so.51.1
b61b0000 b62f0000 r-xp /usr/lib/libicui18n.so.51.1
b6307000 b633f000 r-xp /usr/lib/libecore_x.so.1.13.0
b6351000 b6354000 r-xp /lib/libcap.so.2.21
b6364000 b638d000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b639e000 b63a5000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63b7000 b63ed000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b63fe000 b64e6000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b64fa000 b6570000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6582000 b6585000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6595000 b65a0000 r-xp /usr/lib/libvconf.so.0.2.45
b65b0000 b65b2000 r-xp /usr/lib/libvasum.so.0.3.1
b65c2000 b65c4000 r-xp /usr/lib/libttrace.so.1.1
b65d4000 b65d7000 r-xp /usr/lib/libiniparser.so.0
b65e7000 b660a000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b661a000 b661f000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6630000 b6647000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6658000 b6665000 r-xp /usr/lib/libunwind.so.8.0.1
b669b000 b67bf000 r-xp /lib/libc-2.20-2014.11.so
b67d4000 b67ed000 r-xp /lib/libgcc_s-4.9.so.1
b67fd000 b68df000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b68f0000 b6924000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6934000 b696e000 r-xp /usr/lib/libsystemd.so.0.4.0
b6970000 b69f0000 r-xp /usr/lib/libedje.so.1.13.0
b69f3000 b6a11000 r-xp /usr/lib/libecore.so.1.13.0
b6a31000 b6b93000 r-xp /usr/lib/libevas.so.1.13.0
b6bca000 b6bde000 r-xp /lib/libpthread-2.20-2014.11.so
b6bf2000 b6e16000 r-xp /usr/lib/libelementary.so.1.13.0
b6e44000 b6e48000 r-xp /usr/lib/libsmack.so.1.0.0
b6e58000 b6e5e000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e6f000 b6e71000 r-xp /usr/lib/libdlog.so.0.0.0
b6e81000 b6e84000 r-xp /usr/lib/libbundle.so.0.1.22
b6e94000 b6e96000 r-xp /lib/libdl-2.20-2014.11.so
b6ea7000 b6ec0000 r-xp /usr/lib/libaul.so.0.1.0
b6ed2000 b6ed4000 r-xp /usr/lib/libappsvc.so.0.1.0
b6ee5000 b6ee9000 r-xp /usr/lib/libsys-assert.so
b6efa000 b6f1a000 r-xp /lib/ld-2.20-2014.11.so
b6f2b000 b6f31000 r-xp /usr/bin/launchpad-loader
b75c8000 b7b6b000 rw-p [heap]
befce000 befef000 rwxp [stack]
b75c8000 b7b6b000 rw-p [heap]
befce000 befef000 rwxp [stack]
End of Maps Information

Callstack Information (PID:1824)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb66f9128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb331ed13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb30dcabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb305f865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63c35bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb63cff67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb63d5a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb63d5c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xafc0ecf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xafc0f459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb684e157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6bcfcf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
D (  819): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.camera /opt/usr/apps/org.example.camera/bin/camera
01-22 21:29:21.054+0900 D/RUA     (  819): rua.c: rua_add_history(179) > rua_add_history start
01-22 21:29:21.064+0900 D/RUA     (  819): rua.c: rua_add_history(247) > rua_add_history ok
01-22 21:29:21.084+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200aa6 
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): tunnig_param=263480
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): param_num=3
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): cur target lum=62, ev diff=0, level=4
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): AE VERSION : 0x20150828-00
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): cvg speed=0
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): target lum=62, target lum zone=8
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): lime time=134, min line=1
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): target_lum_ev0=62
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): highcount=19,lowcount=15
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): FDAE: failed open fdae_param.txt
01-22 21:29:21.334+0900 I/ISP_AE  ( 1824): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:29:21.334+0900 D/alPrinter0( 1824): LSC Size:20 16
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [LSC]TableSize=   320
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [LSC]TableSize=   320
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [LSC]TableSize=   320
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [OTP]module has otp data 0xa49165fc (nil) 20 16
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [LSC]TableSize=   320
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [LSC]TableSize=   320
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:29:21.334+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): work_mode=0 last mode=0
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): cvg speed=0
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): target lum=62, target lum zone=8
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): lime time=134, min line=1
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): target_lum_ev0=62
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): highcount=19,lowcount=15
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): is_quick=0
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): AE_TEST:-----------SET index:282
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): AE_TEST:-----------SET index:282
01-22 21:29:21.454+0900 I/ISP_AE  ( 1824): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:29:21.464+0900 I/ISP_AE  ( 1824): calc_iso=50,real_gain=19,iso=0
01-22 21:29:21.645+0900 D/AUL_PAD ( 1891): launchpad_loader.c: main(588) > sleeping 1 sec...
01-22 21:29:21.645+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(52) > max_cmdline_size = 1053
01-22 21:29:21.655+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b8ab2768
01-22 21:29:21.655+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(69) > get pre-initialization function
01-22 21:29:21.655+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(73) > get shutdown function
01-22 21:29:21.655+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b8ab2a48
01-22 21:29:21.665+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b8ab45b0
01-22 21:29:21.665+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(69) > get pre-initialization function
01-22 21:29:21.665+0900 D/AUL_PAD ( 1891): preload.h: __preload_init(73) > get shutdown function
01-22 21:29:21.665+0900 D/AUL_PAD ( 1891): preexec.h: __preexec_init(76) > preexec start
01-22 21:29:21.665+0900 D/AUL_PAD ( 1891): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
01-22 21:29:21.665+0900 D/AUL     ( 1891): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
01-22 21:29:21.665+0900 D/AUL     ( 1891): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
01-22 21:29:21.665+0900 D/AUL     ( 1891): process_pool.c: __connect_to_launchpad(132) > send(1891) : 4
01-22 21:29:21.665+0900 D/AUL     ( 1891): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
01-22 21:29:21.665+0900 D/AUL_PAD (  958): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 1891
01-22 21:29:21.735+0900 I/ISP_AE  ( 1824): set_weight, table[0] = 1
01-22 21:29:21.735+0900 I/ISP_AE  ( 1824): set weight from 1 to 0, rtn=0
01-22 21:29:21.735+0900 I/ISP_AE  ( 1824): AE_TEST ----------------------change to fast
01-22 21:29:21.735+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:282, cur_lum:25, next_index:298, target_lum:62
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,2f,a8,00,00,00,00
01-22 21:29:21.735+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,2f,a8,00,00,00,00
01-22 21:29:21.735+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LineAdj] Mode -2147483647
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LineAdj]Tar RGB 557,733,473
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LineAdj]Ref RGB 557,750,487
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LED]LPF Disable
01-22 21:29:21.735+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:21.745+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.43, detect:   0.30,   0.34 CTemp:6902.9
01-22 21:29:21.745+0900 D/alPrinter0( 1824): [CHROMA]START BV=1.475906 Ratio=1.000000
01-22 21:29:21.745+0900 D/alPrinter0( 1824): [HSC]Mix=00000000,Csd=00007eb8 ,(BV= 1.476,x=0.310,y=0.342)
01-22 21:29:21.745+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:29:21.745+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=1.475919 ,Awb Bv=1.475906 in/out_0
01-22 21:29:21.745+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.396271,GGain=1.000000,BGain=1.240356,Dtct=0.309555,0.341705 ,Curr=0.309555,0.341705 ,CTmep: QC=6926, AL= 6577
01-22 21:29:21.835+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:298, cur_lum:40, next_index:306, target_lum:62
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:21.835+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:21.835+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [LED]LPF Disable
01-22 21:29:21.835+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:21.845+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.50, detect:   0.31,   0.34 CTemp:6798.7
01-22 21:29:21.845+0900 D/alPrinter0( 1824): [HSC]Mix=00000a3d,Csd=00013667 ,(BV= 1.246,x=0.308,y=0.341)
01-22 21:29:21.845+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:4, 0x00000a3d,0x00000a3d
01-22 21:29:21.845+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=1.246438 ,Awb Bv=1.246429 in/out_0
01-22 21:29:21.845+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.407913,GGain=1.000000,BGain=1.239319,Dtct=0.308441,0.341415 ,Curr=0.308441,0.341415 ,CTmep: QC=6968, AL= 6636
01-22 21:29:21.895+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(47), surface(0xb7aca6b0)
01-22 21:29:21.905+0900 E/EFL     ( 1824): evas_main<1824> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:29:21.915+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(49), surface(0xb7ac6f18)
01-22 21:29:21.925+0900 D/AUL_PAD ( 1891): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
01-22 21:29:21.935+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:306, cur_lum:48, next_index:309, target_lum:62
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:21.935+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:21.935+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [LED]LPF Disable
01-22 21:29:21.935+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:21.945+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.54, detect:   0.31,   0.34 CTemp:6674.5
01-22 21:29:21.945+0900 D/alPrinter0( 1824): [HSC]Mix=000028f5,Csd=00008d1e ,(BV= 1.124,x=0.309,y=0.341)
01-22 21:29:21.945+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:3, 0x000028f5,0x000028f5
01-22 21:29:21.945+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=1.124447 ,Awb Bv=1.124435 in/out_0
01-22 21:29:21.945+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.388382,GGain=1.000000,BGain=1.233902,Dtct=0.309464,0.340698 ,Curr=0.309464,0.340698 ,CTmep: QC=6935, AL= 6589
01-22 21:29:21.975+0900 D/AUL_PAD ( 1891): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
01-22 21:29:21.975+0900 D/AUL_PAD ( 1891): launchpad_loader.c: main(693) > [candidate] ecore handler add
01-22 21:29:21.975+0900 D/AUL_PAD ( 1891): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
01-22 21:29:21.985+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(47), surface(0xb7aca6b0)
01-22 21:29:22.005+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a9c2c0), gem(50), surface(0xb7b48bc0)
01-22 21:29:22.035+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(47), surface(0xb7ac6f18)
01-22 21:29:22.035+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:309, cur_lum:52, next_index:310, target_lum:62
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.035+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.035+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [LED]LPF Enable
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.035+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.56, detect:   0.31,   0.34 CTemp:6630.7
01-22 21:29:22.045+0900 D/alPrinter0( 1824): [HSC]Mix=00003332,Csd=0000a76f ,(BV= 1.124,x=0.310,y=0.340)
01-22 21:29:22.045+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:4, 0x00003332,0x00003332
01-22 21:29:22.045+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=1.085973 ,Awb Bv=1.123642 in/out_0
01-22 21:29:22.045+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.388382,GGain=1.000000,BGain=1.233902,Dtct=0.309647,0.340103 ,Curr=0.309464,0.340698 ,CTmep: QC=6935, AL= 6589
01-22 21:29:22.045+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a9c2c0), gem(49), surface(0xb7aca6b0)
01-22 21:29:22.085+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x5400003
01-22 21:29:22.115+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(47), surface(0xb7b48bc0)
01-22 21:29:22.115+0900 E/RESOURCED(  870): heart-abnormal.c: heart_abnormal_process_crashed(77) > Failed: dbus_message_get_args()
01-22 21:29:22.125+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(50), surface(0xb7aca6b0)
01-22 21:29:22.135+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:310, cur_lum:54, next_index:311, target_lum:62
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.135+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.135+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.58, detect:   0.31,   0.34 CTemp:6548.1
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [HSC]Mix=00004665,Csd=0000623d ,(BV= 1.120,x=0.310,y=0.340)
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:3, 0x00004665,0x00004665
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=1.048498 ,Awb Bv=1.120117 in/out_0
01-22 21:29:22.135+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.388382,GGain=1.000000,BGain=1.233902,Dtct=0.310242,0.339783 ,Curr=0.309464,0.340698 ,CTmep: QC=6935, AL= 6589
01-22 21:29:22.155+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(47), surface(0xb7aca6b0)
01-22 21:29:22.175+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb781bec8), gem(49), surface(0xb7aca6b0)
01-22 21:29:22.235+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:311, cur_lum:56, next_index:312, target_lum:62
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.235+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.235+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.235+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.58, detect:   0.31,   0.34 CTemp:6544.6
01-22 21:29:22.235+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aca128), gem(47), surface(0xb7ac6f18)
01-22 21:29:22.245+0900 D/alPrinter0( 1824): [HSC]Mix=00004665,Csd=ffffebf2 ,(BV= 1.112,x=0.310,y=0.340)
01-22 21:29:22.245+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:4, 0x00004665,0x00004665
01-22 21:29:22.245+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=1.011972 ,Awb Bv=1.112122 in/out_0
01-22 21:29:22.245+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.388367,GGain=1.000000,BGain=1.233871,Dtct=0.310410,0.339767 ,Curr=0.309464,0.340698 ,CTmep: QC=6934, AL= 6588
01-22 21:29:22.255+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76d08c8), gem(50), surface(0xb7ac6f18)
01-22 21:29:22.275+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aca128), gem(47), surface(0xb7ac6f18)
01-22 21:29:22.325+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aca128), gem(49), surface(0xb7aca6b0)
01-22 21:29:22.335+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:312, cur_lum:57, next_index:313, target_lum:62
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.335+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.335+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.335+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.58, detect:   0.31,   0.34 CTemp:6552.8
01-22 21:29:22.345+0900 D/alPrinter0( 1824): [HSC]Mix=00004665,Csd=ffffe81c ,(BV= 1.099,x=0.310,y=0.339)
01-22 21:29:22.345+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:3, 0x00004665,0x00004665
01-22 21:29:22.345+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=0.976348 ,Awb Bv=1.098938 in/out_0
01-22 21:29:22.345+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.388123,GGain=1.000000,BGain=1.233688,Dtct=0.310196,0.339340 ,Curr=0.309464,0.340668 ,CTmep: QC=6934, AL= 6588
01-22 21:29:22.355+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aca128), gem(47), surface(0xb7ac6f18)
01-22 21:29:22.375+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a9c2c0), gem(49), surface(0xb7aca6b0)
01-22 21:29:22.435+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:313, cur_lum:58, next_index:314, target_lum:62
01-22 21:29:22.435+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a24f70), gem(47), surface(0xb7ac6f18)
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.435+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.435+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.435+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.445+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.59, detect:   0.31,   0.34 CTemp:6543.3
01-22 21:29:22.445+0900 D/alPrinter0( 1824): [HSC]Mix=00004665,Csd=00001f2a ,(BV= 1.081,x=0.310,y=0.339)
01-22 21:29:22.445+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:4, 0x00004665,0x00004665
01-22 21:29:22.445+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=0.941583 ,Awb Bv=1.080643 in/out_0
01-22 21:29:22.445+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.386597,GGain=1.000000,BGain=1.232986,Dtct=0.310013,0.338913 ,Curr=0.309509,0.340561 ,CTmep: QC=6933, AL= 6587
01-22 21:29:22.465+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a9c2c0), gem(49), surface(0xb77a27e0)
01-22 21:29:22.495+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a60808), gem(47), surface(0xb7ac6f18)
01-22 21:29:22.525+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200aa6 
01-22 21:29:22.535+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:314, cur_lum:60, next_index:314, target_lum:62
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.535+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.535+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.59, detect:   0.31,   0.34 CTemp:6540.5
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [HSC]Mix=00004665,Csd=0000081f ,(BV= 1.058,x=0.310,y=0.339)
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:3, 0x00004665,0x00004665
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=0.941583 ,Awb Bv=1.058395 in/out_0
01-22 21:29:22.535+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.383759,GGain=1.000000,BGain=1.231537,Dtct=0.310257,0.338913 ,Curr=0.309586,0.340347 ,CTmep: QC=6933, AL= 6586
01-22 21:29:22.555+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76d08c8), gem(49), surface(0xb7ac6f18)
01-22 21:29:22.555+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ac9f80), gem(50), surface(0xb7a91d58)
01-22 21:29:22.605+0900 I/ISP_AE  ( 1824): AE_TEST ----------------------change to smooth
01-22 21:29:22.605+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:314, cur_lum:59, next_index:314, target_lum:62
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:22.605+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [CMD0][if=a49202a8,Wrap=a49257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:22.605+0900 D/awb_al_cmd0( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [CALL][0xa49202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [LOCK]0
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [SuperHighCTemp] Mapin:  0.59, detect:   0.31,   0.34 CTemp:6557.5
01-22 21:29:22.605+0900 I/ISP_AE  ( 1824): calc_iso=130,real_gain=42,iso=0
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [HSC]Mix=00004665,Csd=00003a2a ,(BV= 1.035,x=0.310,y=0.339)
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [AlHscWrap_Main]:4, 0x00004665,0x00004665
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [AIS_WRAP]In BV=0.941583 ,Awb Bv=1.034760 in/out_0
01-22 21:29:22.605+0900 D/alPrinter0( 1824): [AIS_WRAP]RGain=1.380814,GGain=1.000000,BGain=1.230072,Dtct=0.309921,0.338699 ,Curr=0.309662,0.340118 ,CTmep: QC=6932, AL= 6585
01-22 21:29:22.645+0900 D/TIZEN_N_CAMERA( 1824): camera.c: camera_is_supported_face_detection(1193) > face detection NOT supported
01-22 21:29:22.645+0900 E/TIZEN_N_CAMERA( 1824): camera.c: camera_stop_face_detection(1315) > NOT_SUPPORTED(0xc0000002)
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): tunnig_param=263480
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): param_num=3
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): cur target lum=61, ev diff=0, level=4
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): AE VERSION : 0x20150828-00
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): cvg speed=0
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): target lum=61, target lum zone=16
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): lime time=164, min line=1
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): target_lum_ev0=61
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): highcount=19,lowcount=15
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): FDAE: failed open fdae_param.txt
01-22 21:29:22.996+0900 I/ISP_AE  ( 1824): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceInit :mode=-1 ins=0x00000074
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038000
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e3d7
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x270f0000
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:29:22.996+0900 D/alPrinter1( 1824): LSC Size:24 19
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [LSC]TableSize=   456
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [LSC]TableSize=   456
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [LSC]TableSize=   456
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [LSC]OTP Disable
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:29:22.996+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.232086,GGain=1.000000,BGain=1.304459,Dtct=0.000000,0.000000 ,Curr=0.319992,0.335999 ,CTmep: QC=6085, AL= 6085
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): work_mode=0 last mode=0
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): cvg speed=0
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): target lum=61, target lum zone=16
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): lime time=164, min line=1
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): target_lum_ev0=61
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): highcount=19,lowcount=15
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): is_quick=0
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): AE_TEST:-----------SET index:230
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): AE_TEST: get index:230, exp:200000, line:1219
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): AE_TEST:-----------SET index:230
01-22 21:29:23.126+0900 I/ISP_AE  ( 1824): info x=8,y=6,w=2560,h=1920, block_size.w=80,block_size.h=60
01-22 21:29:23.136+0900 I/ISP_AE  ( 1824): calc_iso=50,real_gain=19,iso=0
01-22 21:29:23.386+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:230, cur_lum:6, next_index:274, target_lum:61
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,2f,ab,00,00,00,00
01-22 21:29:23.386+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,2f,ab,00,00,00,00
01-22 21:29:23.386+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [LED]LPF Disable
01-22 21:29:23.386+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:23.396+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.68, detect:   0.39,   0.42 CTemp:4037.4
01-22 21:29:23.396+0900 D/alPrinter1( 1824): [CHROMA]START BV=0.789566 Ratio=1.000000
01-22 21:29:23.396+0900 D/alPrinter1( 1824): [HSC]Mix=00000000,Csd=00013fb4 ,(BV= 0.790,x=0.367,y=0.394)
01-22 21:29:23.396+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:29:23.396+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=0.789580 ,Awb Bv=0.789566 in/out_0
01-22 21:29:23.396+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.277771,GGain=1.000000,BGain=1.807327,Dtct=0.367432,0.394089 ,Curr=0.367432,0.394089 ,CTmep: QC=4448, AL= 4448
01-22 21:29:23.496+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:274, cur_lum:16, next_index:306, target_lum:61
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:23.496+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:23.496+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [LED]LPF Disable
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.98, detect:   0.37,   0.38 CTemp:4355.4
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [HSC]Mix=00001eb8,Csd=00014255 ,(BV=-0.573,x=0.361,y=0.376)
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-0.572990 ,Awb Bv=-0.572983 in/out_0
01-22 21:29:23.496+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.201111,GGain=0.999985,BGain=1.624908,Dtct=0.361206,0.376266 ,Curr=0.361206,0.376266 ,CTmep: QC=4545, AL= 4545
01-22 21:29:23.506+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a66b50), gem(44), surface(0xb7a91b30)
01-22 21:29:23.536+0900 I/MALI    ( 1824): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:29:23.546+0900 I/MALI    ( 1824): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:29:23.556+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a66bb8), gem(45), surface(0xb7a66aa0)
01-22 21:29:23.556+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77a2688), gem(46), surface(0xb7ad33e8)
01-22 21:29:23.566+0900 I/MALI    ( 1824): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:29:23.616+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:306, cur_lum:32, next_index:316, target_lum:61
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:23.616+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:23.616+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [LED]LPF Disable
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.96, detect:   0.37,   0.38 CTemp:4401.8
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [HSC]Mix=00003d70,Csd=fffeef82 ,(BV=-1.012,x=0.359,y=0.371)
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-1.011874 ,Awb Bv=-1.011871 in/out_0
01-22 21:29:23.616+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.179016,GGain=1.000000,BGain=1.576797,Dtct=0.359390,0.370911 ,Curr=0.359390,0.370911 ,CTmep: QC=4576, AL= 4576
01-22 21:29:23.656+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a67738), gem(44), surface(0xb7a9a618)
01-22 21:29:23.707+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a9a4b0), gem(45), surface(0xb7ac3ef0)
01-22 21:29:23.777+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:316, cur_lum:41, next_index:321, target_lum:61
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:23.777+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:23.777+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [LED]LPF Disable
01-22 21:29:23.777+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:23.787+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.96, detect:   0.36,   0.38 CTemp:4449.5
01-22 21:29:23.787+0900 D/alPrinter1( 1824): [HSC]Mix=00001eb8,Csd=0000ff1d ,(BV=-1.190,x=0.358,y=0.371)
01-22 21:29:23.787+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:29:23.787+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-1.189661 ,Awb Bv=-1.189651 in/out_0
01-22 21:29:23.787+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.189316,GGain=1.000000,BGain=1.578491,Dtct=0.358246,0.371353 ,Curr=0.358246,0.371353 ,CTmep: QC=4614, AL= 4614
01-22 21:29:23.807+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a66bb8), gem(44), surface(0xb7a25ce0)
01-22 21:29:23.887+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a91b30), gem(45), surface(0xb7b483e0)
01-22 21:29:23.937+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:321, cur_lum:44, next_index:326, target_lum:61
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:23.947+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:23.947+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [LED]LPF Disable
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.95, detect:   0.37,   0.37 CTemp:4413.1
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [HSC]Mix=00003d70,Csd=ffffd3fb ,(BV=-1.456,x=0.360,y=0.372)
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-1.456176 ,Awb Bv=-1.456161 in/out_0
01-22 21:29:23.947+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.182251,GGain=1.000000,BGain=1.582245,Dtct=0.359512,0.371552 ,Curr=0.359512,0.371552 ,CTmep: QC=4575, AL= 4575
01-22 21:29:23.957+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77a2688), gem(44), surface(0xb7a91b30)
01-22 21:29:24.037+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ac3f50), gem(45), surface(0xb7ad33e8)
01-22 21:29:24.097+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:326, cur_lum:50, next_index:327, target_lum:61
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:24.097+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:24.097+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [LED]LPF Disable
01-22 21:29:24.097+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:24.107+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.95, detect:   0.37,   0.37 CTemp:4421.1
01-22 21:29:24.107+0900 D/alPrinter1( 1824): [HSC]Mix=00003d70,Csd=0000f7d1 ,(BV=-1.491,x=0.360,y=0.372)
01-22 21:29:24.107+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:4, 0x00003d70,0x00003d70
01-22 21:29:24.107+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-1.490528 ,Awb Bv=-1.490524 in/out_0
01-22 21:29:24.107+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.182327,GGain=1.000000,BGain=1.582245,Dtct=0.359695,0.372238 ,Curr=0.359512,0.371552 ,CTmep: QC=4572, AL= 4572
01-22 21:29:24.127+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a66bb8), gem(44), surface(0xb7ad3178)
01-22 21:29:24.137+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200aa6 
01-22 21:29:24.177+0900 E/TIZEN_N_CAMERA( 1824): camera.c: __convert_camera_error_code(196) > [camera_start_focusing] ERROR_NOT_SUPPORTED(0xc0000002) : core frameworks error code(0x8000081a)
01-22 21:29:24.177+0900 I/camera  ( 1824): Focusing is not supported on this device. The picture will be taken without focusing.
01-22 21:29:24.207+0900 I/ISP_AE  ( 1824): calc_iso=260,real_gain=85,iso=0
01-22 21:29:24.207+0900 I/ISP_AE  ( 1824): calc_iso=260,real_gain=85,iso=0
01-22 21:29:24.217+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a25f80), gem(45), surface(0xb7a25ce0)
01-22 21:29:24.257+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:327, cur_lum:50, next_index:328, target_lum:61
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:24.267+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:24.267+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [LED]LPF Enable
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.94, detect:   0.37,   0.37 CTemp:4383.8
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [HSC]Mix=00005c28,Csd=00006247 ,(BV=-1.491,x=0.360,y=0.372)
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:3, 0x00005c28,0x00005c28
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-1.524080 ,Awb Bv=-1.491165 in/out_0
01-22 21:29:24.267+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.182327,GGain=1.000000,BGain=1.582245,Dtct=0.360489,0.371841 ,Curr=0.359512,0.371552 ,CTmep: QC=4572, AL= 4572
01-22 21:29:24.287+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a66bb8), gem(44), surface(0xb7a99878)
01-22 21:29:24.367+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a60a48), gem(45), surface(0xb7a25ce0)
01-22 21:29:24.417+0900 I/ISP_AE  ( 1824): AE_TEST:----cur_index:328, cur_lum:52, next_index:329, target_lum:61
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:24.427+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [CMD1][if=a492b470,Wrap=a49309a0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:24.427+0900 D/awb_al_cmd1( 1824): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [CALL][0xa492b470][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [AIS_WRAP]msiFlash_state=0
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [LOCK]0
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [SuperHighCTemp] Mapin:  0.95, detect:   0.37,   0.37 CTemp:4380.7
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [HSC]Mix=00005c28,Csd=000052e7 ,(BV=-1.495,x=0.361,y=0.372)
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [AIS_WRAP]In BV=-1.588932 ,Awb Bv=-1.494843 in/out_0
01-22 21:29:24.427+0900 D/alPrinter1( 1824): [AIS_WRAP]RGain=1.182220,GGain=1.000000,BGain=1.582260,Dtct=0.360657,0.371994 ,Curr=0.359528,0.371552 ,CTmep: QC=4572, AL= 4572
01-22 21:29:24.447+0900 D/camera  ( 1824): Writing image to file.
01-22 21:29:24.447+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a67738), gem(44), surface(0xb7b48b30)
01-22 21:29:24.527+0900 I/MALI    ( 1824): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7a67f08), gem(45), surface(0xb7ad5bf8)
01-22 21:29:24.577+0900 W/CRASH_MANAGER( 1695): worker.c: worker_job(1204) > 110182463616d142192976
