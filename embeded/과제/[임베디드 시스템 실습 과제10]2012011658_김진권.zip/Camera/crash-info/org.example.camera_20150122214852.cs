S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 4650
Date: 2015-01-22 21:48:52+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 4650, uid 5000)

Register Information
r0   = 0x92933008, r1   = 0x00000001
r2   = 0x003e2b9e, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x003e2b9e
r6   = 0x003e2b9e, r7   = 0xadfb1588
r8   = 0xb7234358, r9   = 0xadfb1734
r10  = 0xb72398b0, fp   = 0x0000000d
ip   = 0xb66fb110, sp   = 0xadfb14e8
lr   = 0xb3320d3f, pc   = 0xb66fb128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    397720 KB
Buffers:     21548 KB
Cached:     144868 KB
VmPeak:     602984 KB
VmSize:     602980 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       49852 KB
VmRSS:       49852 KB
VmData:     425264 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         288 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 4650 TID = 4849
4650 4652 4835 4836 4837 4839 4847 4848 4849 4850 4851 4852 4853 4854 4855 4856 4859 4860 4861 4862 4863 4864 4865 4866 4867 4868 4869 4870 4871 4872 4873 4874 4875 4876 4877 4878 4879 4880 4881 4882 4883 4885 4886 4887 4889 4890 4894 

Maps Information
930fa000 938f9000 rwxp [stack:4894]
93a22000 94221000 rwxp [stack:4890]
94222000 94a21000 rwxp [stack:4889]
99001000 99800000 rwxp [stack:4887]
99801000 9a000000 rwxp [stack:4886]
9c0fd000 9c8fc000 rwxp [stack:4885]
9c994000 9d193000 rwxp [stack:4883]
9d194000 9d993000 rwxp [stack:4882]
9d994000 9e193000 rwxp [stack:4881]
9e75f000 9ef5e000 rwxp [stack:4880]
9ef5f000 9f75e000 rwxp [stack:4879]
9f75f000 9ff5e000 rwxp [stack:4878]
9ff5f000 a075e000 rwxp [stack:4877]
a075f000 a0f5e000 rwxp [stack:4876]
a0f5f000 a175e000 rwxp [stack:4875]
a175f000 a1f5e000 rwxp [stack:4874]
a1f5f000 a275e000 rwxp [stack:4873]
a275f000 a2f5e000 rwxp [stack:4872]
a2f5f000 a375e000 rwxp [stack:4871]
a375f000 a3f5e000 rwxp [stack:4870]
a3f5f000 a475e000 rwxp [stack:4869]
a475f000 a4f5e000 rwxp [stack:4868]
a5401000 a5c00000 rwxp [stack:4867]
a5c01000 a6400000 rwxp [stack:4866]
a6401000 a6c00000 rwxp [stack:4865]
a6c01000 a7400000 rwxp [stack:4864]
a7401000 a7c00000 rwxp [stack:4863]
a7c01000 a8400000 rwxp [stack:4862]
a8401000 a8c00000 rwxp [stack:4861]
a8c01000 a9400000 rwxp [stack:4860]
a9401000 a9c00000 rwxp [stack:4859]
a9c01000 aa400000 rwxp [stack:4856]
aa401000 aac00000 rwxp [stack:4855]
aac01000 ab400000 rwxp [stack:4854]
ab401000 abc00000 rwxp [stack:4853]
abc01000 ac400000 rwxp [stack:4852]
ac401000 acc00000 rwxp [stack:4851]
ace01000 ad600000 rwxp [stack:4850]
ad7b4000 adfb3000 rwxp [stack:4849]
adfb3000 adfb6000 r-xp /usr/lib/libXv.so.1.0.0
adfc6000 adfd8000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
adfe9000 ae020000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae032000 ae831000 rwxp [stack:4848]
ae831000 ae84e000 r-xp /usr/lib/libAl_Awb_Sp.so
ae857000 ae85a000 r-xp /usr/lib/libdeflicker.so
ae872000 ae888000 r-xp /usr/lib/libAl_Awb.so
ae890000 ae89a000 r-xp /usr/lib/libcalibration.so
ae8a3000 ae8b5000 r-xp /usr/lib/libaf_lib.so
ae8bd000 ae8c3000 r-xp /usr/lib/libspaf.so
ae8cb000 ae8d1000 r-xp /usr/lib/liblsc.so
ae8da000 ae8e6000 r-xp /usr/lib/libae.so
ae8ee000 ae92f000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae976000 aea55000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aeeb2000 aeeee000 r-xp /usr/lib/libcamerahal.so.0.0.0
af0b8000 af8b7000 rwxp [stack:4847]
af8c0000 af8d8000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0501000 b0d00000 rwxp [stack:4839]
b0e00000 b0e01000 r-xp /usr/lib/libcamerahdr.so.0.0.0
b0e4a000 b1649000 rwxp [stack:4837]
b164a000 b1e49000 rwxp [stack:4836]
b1e49000 b1e4e000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1eda000 b1ee2000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1ef3000 b1ef4000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f04000 b1f0b000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f2f000 b1f30000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f40000 b1f53000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fa7000 b1fac000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1fbd000 b27bc000 rwxp [stack:4835]
b27bc000 b2917000 r-xp /usr/lib/egl/libMali.so
b292c000 b29b5000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b29ce000 b2a9c000 r-xp /usr/lib/libCOREGL.so.4.0
b2ab7000 b2aba000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2aca000 b2ad7000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2ae8000 b2af2000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b02000 b2b0e000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b1f000 b2b23000 r-xp /usr/lib/libogg.so.0.7.1
b2b33000 b2b55000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b65000 b2c49000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c65000 b2ca8000 r-xp /usr/lib/libsndfile.so.1.0.25
b2cbd000 b2d04000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d15000 b2d1c000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d2c000 b2d61000 r-xp /usr/lib/libpulse.so.0.16.2
b2d72000 b2d75000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2d86000 b2d89000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2d9a000 b2ddd000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2dee000 b2df6000 r-xp /usr/lib/libdrm.so.2.4.0
b2e06000 b2e08000 r-xp /usr/lib/libdri2.so.0.0.0
b2e18000 b2e1f000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e2f000 b2e3a000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e4e000 b2e54000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e65000 b2e6d000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2e7e000 b2e83000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2e93000 b2eaa000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2eba000 b2eda000 r-xp /usr/lib/libexif.so.12.3.3
b2ee6000 b2eee000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2efe000 b2f2d000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f40000 b2f48000 r-xp /usr/lib/libtbm.so.1.0.0
b2f58000 b3011000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3025000 b302c000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b303c000 b309a000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30af000 b30b3000 r-xp /usr/lib/libstorage.so.0.1
b30c3000 b30ca000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30da000 b30e9000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3213000 b3217000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3228000 b3308000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b331d000 b3322000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b332a000 b3351000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3364000 b3b63000 rwxp [stack:4652]
b3b63000 b3b65000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d75000 b3d7e000 r-xp /lib/libnss_files-2.20-2014.11.so
b3d8f000 b3d98000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3da9000 b3dba000 r-xp /lib/libnsl-2.20-2014.11.so
b3dcd000 b3dd3000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3de4000 b3dfe000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e0f000 b3e10000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e20000 b3e22000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e33000 b3e38000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e48000 b3e4b000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e5c000 b3e63000 r-xp /usr/lib/libsensord-share.so
b3e73000 b3e84000 r-xp /usr/lib/libsensor.so.1.2.0
b3e95000 b3e9b000 r-xp /usr/lib/libappcore-common.so.1.1
b3ebe000 b3ec3000 r-xp /usr/lib/libappcore-efl.so.1.1
b3ed9000 b3edb000 r-xp /usr/lib/libXau.so.6.0.0
b3eeb000 b3eff000 r-xp /usr/lib/libxcb.so.1.1.0
b3f0f000 b3f16000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f4e000 b3f50000 r-xp /usr/lib/libiri.so
b3f61000 b3f76000 r-xp /lib/libexpat.so.1.5.2
b3f88000 b3fd6000 r-xp /usr/lib/libssl.so.1.0.0
b3feb000 b3ff4000 r-xp /usr/lib/libethumb.so.1.13.0
b4005000 b4008000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4018000 b41cf000 r-xp /usr/lib/libcrypto.so.1.0.0
b5766000 b576f000 r-xp /usr/lib/libXi.so.6.1.0
b5780000 b5782000 r-xp /usr/lib/libXgesture.so.7.0.0
b5792000 b5796000 r-xp /usr/lib/libXtst.so.6.1.0
b57a6000 b57ac000 r-xp /usr/lib/libXrender.so.1.3.0
b57bc000 b57c2000 r-xp /usr/lib/libXrandr.so.2.2.0
b57d2000 b57d4000 r-xp /usr/lib/libXinerama.so.1.0.0
b57e4000 b57e7000 r-xp /usr/lib/libXfixes.so.3.1.0
b57f8000 b5803000 r-xp /usr/lib/libXext.so.6.4.0
b5813000 b5815000 r-xp /usr/lib/libXdamage.so.1.1.0
b5825000 b5827000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5837000 b591a000 r-xp /usr/lib/libX11.so.6.3.0
b592d000 b5934000 r-xp /usr/lib/libXcursor.so.1.0.2
b5945000 b595d000 r-xp /usr/lib/libudev.so.1.6.0
b595f000 b5962000 r-xp /lib/libattr.so.1.1.0
b5972000 b5992000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5993000 b5998000 r-xp /usr/lib/libffi.so.6.0.2
b59a8000 b59c0000 r-xp /lib/libz.so.1.2.8
b59d0000 b59d2000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59e2000 b5ab7000 r-xp /usr/lib/libxml2.so.2.9.2
b5acc000 b5b67000 r-xp /usr/lib/libstdc++.so.6.0.20
b5b83000 b5b86000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5b96000 b5bb0000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bc0000 b5bd1000 r-xp /lib/libresolv-2.20-2014.11.so
b5be5000 b5bfc000 r-xp /usr/lib/liblzma.so.5.0.3
b5c0c000 b5c0e000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c1e000 b5c25000 r-xp /usr/lib/libembryo.so.1.13.0
b5c35000 b5c4d000 r-xp /usr/lib/libpng12.so.0.50.0
b5c5e000 b5c81000 r-xp /usr/lib/libjpeg.so.8.0.2
b5ca1000 b5ca7000 r-xp /lib/librt-2.20-2014.11.so
b5cb8000 b5ccc000 r-xp /usr/lib/libector.so.1.13.0
b5cdd000 b5cf5000 r-xp /usr/lib/liblua-5.1.so
b5d06000 b5d5d000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d71000 b5d99000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5daa000 b5dbd000 r-xp /usr/lib/libfribidi.so.0.3.1
b5dce000 b5e08000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e19000 b5e84000 r-xp /lib/libm-2.20-2014.11.so
b5e95000 b5ea2000 r-xp /usr/lib/libeio.so.1.13.0
b5eb2000 b5eb4000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5ec4000 b5ec9000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5ed9000 b5ef0000 r-xp /usr/lib/libefreet.so.1.13.0
b5f02000 b5f22000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f32000 b5f52000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f54000 b5f5a000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f6a000 b5f71000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f81000 b5f8f000 r-xp /usr/lib/libeo.so.1.13.0
b5f9f000 b5fb1000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fc2000 b5fc7000 r-xp /usr/lib/libecore_file.so.1.13.0
b5fd7000 b5fef000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6000000 b601d000 r-xp /usr/lib/libeet.so.1.13.0
b6036000 b607e000 r-xp /usr/lib/libeina.so.1.13.0
b608f000 b609f000 r-xp /usr/lib/libefl.so.1.13.0
b60b0000 b6195000 r-xp /usr/lib/libicuuc.so.51.1
b61b2000 b62f2000 r-xp /usr/lib/libicui18n.so.51.1
b6309000 b6341000 r-xp /usr/lib/libecore_x.so.1.13.0
b6353000 b6356000 r-xp /lib/libcap.so.2.21
b6366000 b638f000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63a0000 b63a7000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63b9000 b63ef000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6400000 b64e8000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b64fc000 b6572000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6584000 b6587000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6597000 b65a2000 r-xp /usr/lib/libvconf.so.0.2.45
b65b2000 b65b4000 r-xp /usr/lib/libvasum.so.0.3.1
b65c4000 b65c6000 r-xp /usr/lib/libttrace.so.1.1
b65d6000 b65d9000 r-xp /usr/lib/libiniparser.so.0
b65e9000 b660c000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b661c000 b6621000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6632000 b6649000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b665a000 b6667000 r-xp /usr/lib/libunwind.so.8.0.1
b669d000 b67c1000 r-xp /lib/libc-2.20-2014.11.so
b67d6000 b67ef000 r-xp /lib/libgcc_s-4.9.so.1
b67ff000 b68e1000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b68f2000 b6926000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6936000 b6970000 r-xp /usr/lib/libsystemd.so.0.4.0
b6972000 b69f2000 r-xp /usr/lib/libedje.so.1.13.0
b69f5000 b6a13000 r-xp /usr/lib/libecore.so.1.13.0
b6a33000 b6b95000 r-xp /usr/lib/libevas.so.1.13.0
b6bcc000 b6be0000 r-xp /lib/libpthread-2.20-2014.11.so
b6bf4000 b6e18000 r-xp /usr/lib/libelementary.so.1.13.0
b6e46000 b6e4a000 r-xp /usr/lib/libsmack.so.1.0.0
b6e5a000 b6e60000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e71000 b6e73000 r-xp /usr/lib/libdlog.so.0.0.0
b6e83000 b6e86000 r-xp /usr/lib/libbundle.so.0.1.22
b6e96000 b6e98000 r-xp /lib/libdl-2.20-2014.11.so
b6ea9000 b6ec2000 r-xp /usr/lib/libaul.so.0.1.0
b6ed4000 b6ed6000 r-xp /usr/lib/libappsvc.so.0.1.0
b6ee7000 b6eeb000 r-xp /usr/lib/libsys-assert.so
b6efc000 b6f1c000 r-xp /lib/ld-2.20-2014.11.so
b6f2d000 b6f33000 r-xp /usr/bin/launchpad-loader
b6f80000 b7521000 rw-p [heap]
be99a000 be9bb000 rwxp [stack]
be99a000 be9bb000 rwxp [stack]
End of Maps Information

Callstack Information (PID:4650)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb66fb128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb3320d3f) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d3f
 2: (0xb30deabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3061865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63c55bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb63d1f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb63d7a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb63d7c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf8cacf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf8cb459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6850157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6bd1cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
ore-efl.c: __do_app(496) > [APP 4650] Event: RESUME State: CREATED
01-22 21:48:48.853+0900 D/LAUNCH  ( 4650): appcore-efl.c: __do_app(597) > [camera:Application:resume:start]
01-22 21:48:48.853+0900 D/APP_CORE( 4650): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
01-22 21:48:48.853+0900 D/APP_CORE( 4650): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-22 21:48:48.853+0900 D/APP_CORE( 4650): appcore-efl.c: __do_app(607) > [APP 4650] RESUME
01-22 21:48:48.853+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(4650) status(3)
01-22 21:48:48.853+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:48:48.853+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:48:48.853+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:48:48.853+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(4650) status(3)
01-22 21:48:48.853+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(4650) appid(org.example.camera) pkgid(org.example.camera) status(3)
01-22 21:48:48.853+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.camera
01-22 21:48:48.853+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 4650, appid: org.example.camera, status: fg
01-22 21:48:48.853+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 4650
01-22 21:48:48.853+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 4650, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-22 21:48:48.853+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 4650
01-22 21:48:48.853+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.opaque
01-22 21:48:48.853+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:48:48.853+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:48:48.863+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:48:48.863+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:48:48.863+0900 I/APP_CORE( 4650): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
01-22 21:48:48.863+0900 I/APP_CORE( 4650): appcore-efl.c: __do_app(614) > [APP 4650] Initial Launching, call the resume_cb
01-22 21:48:48.863+0900 I/CAPI_APPFW_APPLICATION( 4650): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-22 21:48:48.863+0900 D/LAUNCH  ( 4650): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-22 21:48:48.863+0900 D/LAUNCH  ( 4650): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-22 21:48:48.863+0900 D/APP_CORE( 4650): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-22 21:48:48.863+0900 E/APP_CORE( 4650): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-22 21:48:48.883+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(838) > __request_handler: 15
01-22 21:48:48.883+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:48:48.883+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:48:48.883+0900 D/AUL_AMD (  819): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 4650 is org.example.camera
01-22 21:48:48.883+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 4650 : 0
01-22 21:48:48.883+0900 D/AUL     ( 1005): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
01-22 21:48:48.893+0900 I/MALI    ( 4459): egl_platform_x11.c: __egl_platform_terminate(333) > [EGL-X11] ################################################
01-22 21:48:48.893+0900 I/MALI    ( 4459): egl_platform_x11.c: __egl_platform_terminate(334) > [EGL-X11] PID=4459   close drm_fd=31 
01-22 21:48:48.893+0900 I/MALI    ( 4459): egl_platform_x11.c: __egl_platform_terminate(335) > [EGL-X11] ################################################
01-22 21:48:48.943+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 4650, appname = org.example.camera, pkgname = org.example.camera
01-22 21:48:48.943+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 4650, appname = org.example.camera
01-22 21:48:48.943+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 4650
01-22 21:48:48.943+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 4650 foreground
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-22 21:48:49.073+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-22 21:48:49.073+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 4459 pgid = 4459
01-22 21:48:49.073+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(141) > dead_pid(4459)
01-22 21:48:49.114+0900 D/AUL_PAD (  958): sigchild.h: __send_app_dead_signal(90) > send dead signal done
01-22 21:48:49.114+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
01-22 21:48:49.114+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
01-22 21:48:49.114+0900 E/AUL_PAD (  958): launchpad.c: main(688) > error reading sigchld info
01-22 21:48:49.114+0900 I/ESD     (  993): esd_main.c: __esd_app_dead_handler(1771) > pid: 4459
01-22 21:48:49.114+0900 D/STARTER (  872): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 4459 is termianted
01-22 21:48:49.114+0900 D/STARTER (  872): starter.c: _check_dead_signal(199) > [_check_dead_signal:199] lockscreen is dead
01-22 21:48:49.114+0900 E/STARTER (  872): lock_pwd_util.c: lock_pwd_util_win_visible_get(71) > [lock_pwd_util_win_visible_get:71] (!s_lock_pwd_util.lock_pwd_win) -> lock_pwd_util_win_visible_get() return
01-22 21:48:49.114+0900 D/STARTER (  872): lock_mgr.c: lock_mgr_unlock(339) > [lock_mgr_unlock:339] pwd win visible(0), lock type(1)
01-22 21:48:49.114+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 4459
01-22 21:48:49.114+0900 D/STARTER (  872): lock_mgr.c: lock_mgr_idle_lock_state_set(253) > [lock_mgr_idle_lock_state_set:253] lock state : 0
01-22 21:48:49.114+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 4459
01-22 21:48:49.114+0900 D/AUL_AMD (  819): amd_key.c: _unregister_key_event(179) > ===key stack===
01-22 21:48:49.114+0900 E/AUL_AMD (  819): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
01-22 21:48:49.114+0900 D/AUL_AMD (  819): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.tizen.lockscreen)
01-22 21:48:49.114+0900 D/AUL     (  819): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
01-22 21:48:49.114+0900 E/AUL     (  819): simple_util.c: __trm_app_info_send_socket(330) > access
01-22 21:48:49.114+0900 W/STARTER (  872): window_mgr.c: _pwd_transient_unset(159) > [_pwd_transient_unset:159] 0x4200007 is not transient
01-22 21:48:49.124+0900 D/INDICATOR(  893): util.c: util_signal_emit(84) > [SECURE_LOG] util_signal_emit[84]	 "emission clock.font.12"
01-22 21:48:49.124+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 4459
01-22 21:48:49.124+0900 D/RESOURCED(  870): appinfo-list.c: resourced_appinfo_put(132) > appid org.tizen.lockscreen, pkgname = org.tizen.lockscreen, ref = 0
01-22 21:48:49.144+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x202c63 
01-22 21:48:49.164+0900 D/VOLUME  (  912): control.c: _idle_lock_state_vconf_changed_cb(810) > [_idle_lock_state_vconf_changed_cb:810] idle lock state : 0
01-22 21:48:49.374+0900 I/ISP_AE  ( 4650): tunnig_param=263480
01-22 21:48:49.374+0900 I/ISP_AE  ( 4650): param_num=3
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): cur target lum=62, ev diff=0, level=4
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): AE VERSION : 0x20150828-00
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): cvg speed=0
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): target lum=62, target lum zone=8
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): lime time=134, min line=1
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): target_lum_ev0=62
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): highcount=19,lowcount=15
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): FDAE: failed open fdae_param.txt
01-22 21:48:49.384+0900 I/ISP_AE  ( 4650): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:48:49.384+0900 D/alPrinter0( 4650): LSC Size:20 16
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [LSC]TableSize=   320
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [LSC]TableSize=   320
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [LSC]TableSize=   320
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [OTP]module has otp data 0xa52165fc (nil) 20 16
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [LSC]TableSize=   320
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [LSC]TableSize=   320
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:48:49.384+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:48:49.444+0900 D/RESOURCED(  870): logging.c: logging_send_signal_to_data(1097) > logging timer callback function start
01-22 21:48:49.444+0900 I/RESOURCED(  870): logging.c: logging_send_signal_to_data(1106) > send signal to logging data thread
01-22 21:48:49.444+0900 D/RESOURCED(  870): logging.c: logging_send_signal_to_update(1177) > logging timer callback function start
01-22 21:48:49.444+0900 I/RESOURCED(  870): logging.c: logging_send_signal_to_update(1186) > send signal to logging update thread
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930269 2363 584 913 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930297 49 9 3111 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930299 57 9 3111 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930300 91 19 3206 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930301 3043 724 913 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930301 91 20 3206 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930304 61 11 3205 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930304 94 21 3206 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930305 67 12 3205 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930305 3135 740 913 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930305 98 22 3206 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930308 60 9 3221 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930309 100 22 3206 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930309 64 10 3221 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930317 3243 757 913 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930352 46 10 3227 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930501 73 23 3227 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930501 71 17 3368 1
01-22 21:48:49.444+0900 I/RESOURCED(  870): logging.c: logging_save_to_storage(978) > battery cache is empty
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930506 3891 890 913 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930540 39 13 3568 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930565 70 22 3568 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930565 81 8 3670 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930570 4519 1039 913 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930581 53 10 3859 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421930584 59 10 3859 2
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930584 97 15 3953 1
01-22 21:48:49.444+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930589 4806 1097 913 1
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930623 55 9 3952 1
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930719 5425 1226 913 1
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930818 97 21 3952 2
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930818 89 14 4054 1
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421930830 6817 1523 913 1
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930863 50 6 4459 1
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421930928 86 20 4459 2
01-22 21:48:49.454+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421930928 79 13 4650 1
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): work_mode=0 last mode=0
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): cvg speed=0
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): target lum=62, target lum zone=8
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): lime time=134, min line=1
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): target_lum_ev0=62
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): highcount=19,lowcount=15
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): is_quick=0
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): AE_TEST:-----------SET index:282
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:48:49.504+0900 I/ISP_AE  ( 4650): AE_TEST:-----------SET index:282
01-22 21:48:49.514+0900 I/ISP_AE  ( 4650): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:48:49.524+0900 I/ISP_AE  ( 4650): calc_iso=50,real_gain=19,iso=0
01-22 21:48:49.784+0900 I/ISP_AE  ( 4650): set_weight, table[0] = 1
01-22 21:48:49.784+0900 I/ISP_AE  ( 4650): set weight from 1 to 0, rtn=0
01-22 21:48:49.784+0900 I/ISP_AE  ( 4650): AE_TEST ----------------------change to fast
01-22 21:48:49.784+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:282, cur_lum:0, next_index:340, target_lum:62
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,bf,a8,00,00,00,00
01-22 21:48:49.794+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,bf,a8,00,00,00,00
01-22 21:48:49.794+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LineAdj] Mode -2147483647
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LineAdj]Tar RGB 557,733,473
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LineAdj]Ref RGB 557,750,487
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LED]LPF Disable
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [CHROMA]START BV=0.137497 Ratio=0.250000
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [HSC]Mix=00000000,Csd=00000000 ,(BV= 0.137,x=0.355,y=0.385)
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=0.137504 ,Awb Bv=0.137497 in/out_0
01-22 21:48:49.794+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.286407,GGain=1.000000,BGain=1.292862,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:48:49.904+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:340, cur_lum:7, next_index:384, target_lum:62
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:49.904+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:49.904+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [LED]LPF Disable
01-22 21:48:49.904+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:49.914+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  0.84, detect:   0.35,   0.38 CTemp:4782.0
01-22 21:48:49.914+0900 D/alPrinter0( 4650): [HSC]Mix=00000000,Csd=00069bc0 ,(BV=-1.251,x=0.354,y=0.378)
01-22 21:48:49.914+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:48:49.914+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.251062 ,Awb Bv=-1.251053 in/out_0
01-22 21:48:49.914+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.235748,GGain=1.000000,BGain=1.545898,Dtct=0.353516,0.377686 ,Curr=0.353516,0.377686 ,CTmep: QC=5029, AL= 4789
01-22 21:48:49.974+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b398), gem(56), surface(0xb736e400)
01-22 21:48:49.974+0900 E/EFL     ( 4650): evas_main<4650> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:48:50.014+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:384, cur_lum:33, next_index:394, target_lum:62
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.014+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.014+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [LED]LPF Disable
01-22 21:48:50.014+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.024+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4633.3
01-22 21:48:50.024+0900 D/alPrinter0( 4650): [HSC]Mix=00001eb8,Csd=00091dca ,(BV=-1.524,x=0.359,y=0.386)
01-22 21:48:50.024+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:3, 0x00001eb8,0x00001eb8
01-22 21:48:50.024+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.524081 ,Awb Bv=-1.524078 in/out_0
01-22 21:48:50.024+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.247650,GGain=1.000000,BGain=1.629593,Dtct=0.359451,0.386246 ,Curr=0.359451,0.386246 ,CTmep: QC=4839, AL= 4640
01-22 21:48:50.034+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(57), surface(0xb6fa1508)
01-22 21:48:50.094+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(56), surface(0xb7129030)
01-22 21:48:50.135+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:394, cur_lum:52, next_index:395, target_lum:62
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.145+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.145+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [LED]LPF Enable
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4621.0
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [HSC]Mix=00003d70,Csd=00093207 ,(BV=-1.525,x=0.360,y=0.388)
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:4, 0x00003d70,0x00003d70
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.548743 ,Awb Bv=-1.524536 in/out_0
01-22 21:48:50.145+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.247757,GGain=1.000000,BGain=1.629745,Dtct=0.359940,0.387573 ,Curr=0.359451,0.386261 ,CTmep: QC=4840, AL= 4641
01-22 21:48:50.145+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x1600003
01-22 21:48:50.165+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb7129030)
01-22 21:48:50.215+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(56), surface(0xb7129030)
01-22 21:48:50.255+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:395, cur_lum:81, next_index:393, target_lum:62
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.265+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.265+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4662.0
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [HSC]Mix=00005c28,Csd=000853f6 ,(BV=-1.525,x=0.358,y=0.386)
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:3, 0x00005c28,0x00005c28
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.498990 ,Awb Bv=-1.525284 in/out_0
01-22 21:48:50.265+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.248367,GGain=1.000000,BGain=1.630325,Dtct=0.358185,0.385803 ,Curr=0.359436,0.386322 ,CTmep: QC=4839, AL= 4640
01-22 21:48:50.265+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(57), surface(0xb6fa1508)
01-22 21:48:50.325+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 1 -> 3
01-22 21:48:50.325+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 1 -> 3
01-22 21:48:50.325+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:48:50.345+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(56), surface(0xb6fa1508)
01-22 21:48:50.375+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:393, cur_lum:101, next_index:385, target_lum:62
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.375+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.375+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.375+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.385+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.38 CTemp:4714.3
01-22 21:48:50.385+0900 D/alPrinter0( 4650): [HSC]Mix=00007ae0,Csd=0004f575 ,(BV=-1.520,x=0.356,y=0.384)
01-22 21:48:50.385+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:4, 0x00007ae0,0x00007ae0
01-22 21:48:50.385+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.280809 ,Awb Bv=-1.520248 in/out_0
01-22 21:48:50.385+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.249100,GGain=1.000000,BGain=1.630096,Dtct=0.356140,0.383591 ,Curr=0.359344,0.386307 ,CTmep: QC=4840, AL= 4641
01-22 21:48:50.395+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(57), surface(0xb6fa1508)
01-22 21:48:50.445+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(56), surface(0xb6fa1508)
01-22 21:48:50.495+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:385, cur_lum:88, next_index:381, target_lum:62
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.495+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.495+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.495+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.505+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.38 CTemp:4882.5
01-22 21:48:50.505+0900 D/alPrinter0( 4650): [HSC]Mix=00009998,Csd=000230a2 ,(BV=-1.500,x=0.356,y=0.382)
01-22 21:48:50.505+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:3, 0x00009998,0x00009998
01-22 21:48:50.505+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.157953 ,Awb Bv=-1.499680 in/out_0
01-22 21:48:50.505+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.250244,GGain=1.000000,BGain=1.627441,Dtct=0.355957,0.381683 ,Curr=0.359024,0.386063 ,CTmep: QC=4841, AL= 4642
01-22 21:48:50.525+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb6fa1508)
01-22 21:48:50.575+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(56), surface(0xb6fa1508)
01-22 21:48:50.615+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:381, cur_lum:79, next_index:379, target_lum:62
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.625+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.625+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:4958.8
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [HSC]Mix=0000b850,Csd=00013152 ,(BV=-1.460,x=0.354,y=0.379)
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:4, 0x0000b850,0x0000b850
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.092364 ,Awb Bv=-1.460159 in/out_0
01-22 21:48:50.625+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.250748,GGain=1.000000,BGain=1.622055,Dtct=0.353912,0.378662 ,Curr=0.358551,0.385544 ,CTmep: QC=4844, AL= 4644
01-22 21:48:50.645+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(57), surface(0xb6fa1508)
01-22 21:48:50.695+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(56), surface(0xb6fa1508)
01-22 21:48:50.725+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 3 -> 1
01-22 21:48:50.725+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 3 -> 1
01-22 21:48:50.725+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:48:50.735+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:379, cur_lum:72, next_index:378, target_lum:62
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.745+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.745+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.745+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  0.97, detect:   0.35,   0.37 CTemp:4983.2
01-22 21:48:50.745+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(57), surface(0xb6fa1508)
01-22 21:48:50.765+0900 D/alPrinter0( 4650): [HSC]Mix=0000d708,Csd=00002d83 ,(BV=-1.406,x=0.352,y=0.376)
01-22 21:48:50.765+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:3, 0x0000d708,0x0000d708
01-22 21:48:50.765+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.058417 ,Awb Bv=-1.405884 in/out_0
01-22 21:48:50.765+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.250275,GGain=1.000000,BGain=1.612839,Dtct=0.351883,0.375916 ,Curr=0.357864,0.384644 ,CTmep: QC=4848, AL= 4647
01-22 21:48:50.825+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(56), surface(0xb6fa1508)
01-22 21:48:50.855+0900 I/ISP_AE  ( 4650): AE_TEST:----cur_index:378, cur_lum:70, next_index:377, target_lum:62
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:48:50.865+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:48:50.865+0900 D/awb_al_cmd0( 4650): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [AIS_WRAP]msiFlash_state=0
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [LOCK]0
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [SuperHighCTemp] Mapin:  0.97, detect:   0.35,   0.37 CTemp:5007.6
01-22 21:48:50.865+0900 D/alPrinter0( 4650): [HSC]Mix=0000d708,Csd=00006bd8 ,(BV=-1.343,x=0.351,y=0.375)
01-22 21:48:50.875+0900 D/alPrinter0( 4650): [AlHscWrap_Main]:4, 0x0000d708,0x0000d708
01-22 21:48:50.875+0900 D/alPrinter0( 4650): [AIS_WRAP]In BV=-1.023652 ,Awb Bv=-1.343124 in/out_0
01-22 21:48:50.875+0900 D/alPrinter0( 4650): [AIS_WRAP]RGain=1.249298,GGain=1.000000,BGain=1.600403,Dtct=0.350952,0.375107 ,Curr=0.356949,0.383408 ,CTmep: QC=4853, AL= 4651
01-22 21:48:50.875+0900 I/MALI    ( 4650): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:48:50.875+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x202c63 
01-22 21:48:50.885+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb736e498), gem(57), surface(0xb7128e40)
01-22 21:48:50.905+0900 I/MALI    ( 4650): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:48:50.945+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(56), surface(0xb735ca80)
01-22 21:48:50.945+0900 I/MALI    ( 4650): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:48:50.965+0900 I/ISP_AE  ( 4650): ae_state=3
01-22 21:48:51.005+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(57), surface(0xb735ca80)
01-22 21:48:51.055+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b680), gem(56), surface(0xb73560f0)
01-22 21:48:51.125+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb735ca80)
01-22 21:48:51.176+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(56), surface(0xb735c6e0)
01-22 21:48:51.226+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb735ca80)
01-22 21:48:51.306+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb736aef0), gem(56), surface(0xb7471748)
01-22 21:48:51.356+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb735ca80)
01-22 21:48:51.366+0900 I/ISP_AE  ( 4650): FDAE: ->disable, frame_idx=30
01-22 21:48:51.406+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(56), surface(0xb735ca80)
01-22 21:48:51.486+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb6fa1508)
01-22 21:48:51.536+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(56), surface(0xb6fa1508)
01-22 21:48:51.606+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b680), gem(57), surface(0xb6fa1508)
01-22 21:48:51.656+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(56), surface(0xb6fa1508)
01-22 21:48:51.716+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(57), surface(0xb6fa1508)
01-22 21:48:51.786+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb736aef0), gem(56), surface(0xb6fa1508)
01-22 21:48:51.836+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(57), surface(0xb6fa1508)
01-22 21:48:51.886+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b680), gem(56), surface(0xb6fa1508)
01-22 21:48:51.966+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7225c80), gem(57), surface(0xb6fa1508)
01-22 21:48:52.016+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb714ac38), gem(56), surface(0xb6fa1508)
01-22 21:48:52.066+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb736aef0), gem(57), surface(0xb6fa1508)
01-22 21:48:52.146+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b7a0), gem(56), surface(0xb6fa1508)
01-22 21:48:52.197+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb747b680), gem(57), surface(0xb6fa1508)
01-22 21:48:52.257+0900 I/ISP_AE  ( 4650): calc_iso=250,real_gain=82,iso=0
01-22 21:48:52.257+0900 I/ISP_AE  ( 4650): calc_iso=250,real_gain=82,iso=0
01-22 21:48:52.277+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7361e38), gem(56), surface(0xb7421f40)
01-22 21:48:52.497+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7361998), gem(57), surface(0xb6fa1508)
01-22 21:48:52.527+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb735d1d8), gem(58), surface(0xb7421f40)
01-22 21:48:52.577+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb735d2e0), gem(56), surface(0xb6fa1508)
01-22 21:48:52.627+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb735cf70), gem(57), surface(0xb7421f40)
01-22 21:48:52.627+0900 D/camera  ( 4650): Writing image to file.
01-22 21:48:52.677+0900 I/MALI    ( 4650): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb735bfe0), gem(56), surface(0xb6fa1508)
01-22 21:48:52.757+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:48:52.777+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:48:52.787+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:48:52.787+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:48:52.787+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:48:52.787+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:48:52.787+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:48:52.787+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:48:52.787+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:48:52.787+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(3)
01-22 21:48:52.787+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-22 21:48:52.787+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-22 21:48:52.787+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: fg
01-22 21:48:52.787+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:48:52.787+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:48:52.787+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:48:52.787+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:48:52.787+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 913
01-22 21:48:52.797+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 913, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
01-22 21:48:52.797+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 913, appname = org.tizen.homescreen
01-22 21:48:52.797+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 913
01-22 21:48:52.797+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 913 foreground
01-22 21:48:52.797+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1072778), gem(13), surface(0x105e7b8)
01-22 21:48:52.817+0900 W/CRASH_MANAGER( 4899): worker.c: worker_job(1204) > 110465063616d142193093
