S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 1537
Date: 2015-01-22 21:28:36+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 1537, uid 5000)

Register Information
r0   = 0x9a0f4008, r1   = 0x00000001
r2   = 0x00284557, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x00284557
r6   = 0x00284557, r7   = 0xad820588
r8   = 0xb84b97e0, r9   = 0xad820734
r10  = 0xb84c0588, fp   = 0x0000000d
ip   = 0xb675d110, sp   = 0xad8204f0
lr   = 0xb3382d13, pc   = 0xb675d128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    419976 KB
Buffers:     17612 KB
Cached:     124200 KB
VmPeak:     598956 KB
VmSize:     598952 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       50544 KB
VmRSS:       50544 KB
VmData:     418856 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         288 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 1537 TID = 1649
1537 1539 1541 1542 1543 1544 1545 1552 1595 1636 1637 1640 1648 1649 1650 1651 1652 1653 1654 1655 1656 1657 1658 1659 1660 1663 1664 1665 1666 1667 1668 1669 1670 1671 1672 1673 1674 1675 1676 1677 1678 1679 1680 1681 1682 1683 1686 1689 

Maps Information
9241d000 92c1c000 rwxp [stack:1686]
937fd000 93ffc000 rwxp [stack:1595]
97cca000 984c9000 rwxp [stack:1640]
9a5ff000 9adfe000 rwxp [stack:1689]
9adff000 9b5fe000 rwxp [stack:1683]
9b5ff000 9bdfe000 rwxp [stack:1682]
9bdff000 9c5fe000 rwxp [stack:1650]
9c696000 9ce95000 rwxp [stack:1651]
9ce97000 9d696000 rwxp [stack:1637]
9d697000 9de96000 rwxp [stack:1636]
9e601000 9ee00000 rwxp [stack:1681]
9f018000 9f817000 rwxp [stack:1680]
9f818000 a0017000 rwxp [stack:1679]
a0018000 a0817000 rwxp [stack:1678]
a0818000 a1017000 rwxp [stack:1677]
a1018000 a1817000 rwxp [stack:1676]
a1818000 a2017000 rwxp [stack:1675]
a2018000 a2817000 rwxp [stack:1674]
a2818000 a3017000 rwxp [stack:1673]
a3018000 a3817000 rwxp [stack:1672]
a3818000 a4017000 rwxp [stack:1671]
a4018000 a4817000 rwxp [stack:1670]
a4818000 a5017000 rwxp [stack:1669]
a5018000 a5817000 rwxp [stack:1668]
a5818000 a6017000 rwxp [stack:1667]
a6018000 a6817000 rwxp [stack:1666]
a6cf8000 a74f7000 rwxp [stack:1665]
a7823000 a8022000 rwxp [stack:1664]
a8023000 a8822000 rwxp [stack:1663]
a8823000 a9022000 rwxp [stack:1660]
a9023000 a9822000 rwxp [stack:1659]
a9823000 aa022000 rwxp [stack:1658]
aa023000 aa822000 rwxp [stack:1657]
aa823000 ab022000 rwxp [stack:1656]
ab023000 ab822000 rwxp [stack:1655]
ab823000 ac022000 rwxp [stack:1652]
ac023000 ac822000 rwxp [stack:1654]
ac823000 ad022000 rwxp [stack:1653]
ad023000 ad822000 rwxp [stack:1649]
ad822000 ad825000 r-xp /usr/lib/libXv.so.1.0.0
ad835000 ad847000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad858000 ad88f000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad8a1000 ae0a0000 rwxp [stack:1648]
ae0a0000 ae0bd000 r-xp /usr/lib/libAl_Awb_Sp.so
ae0c6000 ae0c9000 r-xp /usr/lib/libdeflicker.so
ae0e1000 ae0f7000 r-xp /usr/lib/libAl_Awb.so
ae0ff000 ae109000 r-xp /usr/lib/libcalibration.so
ae112000 ae124000 r-xp /usr/lib/libaf_lib.so
ae12c000 ae138000 r-xp /usr/lib/libae.so
ae140000 ae181000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae1c8000 ae2a7000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae704000 ae740000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae80a000 af009000 rwxp [stack:1552]
af013000 af02b000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afc04000 afc0a000 r-xp /usr/lib/libspaf.so
afd01000 b0500000 rwxp [stack:1545]
b0501000 b0d00000 rwxp [stack:1544]
b0e01000 b0e07000 r-xp /usr/lib/liblsc.so
b0e10000 b0e11000 r-xp /usr/lib/libcamerahdr.so.0.0.0
b0eac000 b16ab000 rwxp [stack:1543]
b16ac000 b1eab000 rwxp [stack:1542]
b1eab000 b1eb0000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f3c000 b1f44000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f55000 b1f56000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f66000 b1f6d000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f91000 b1f92000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1fa2000 b1fb5000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2009000 b200e000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b201f000 b281e000 rwxp [stack:1541]
b281e000 b2979000 r-xp /usr/lib/egl/libMali.so
b298e000 b2a17000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a30000 b2afe000 r-xp /usr/lib/libCOREGL.so.4.0
b2b19000 b2b1c000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b2c000 b2b39000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b4a000 b2b54000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b64000 b2b70000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b81000 b2b85000 r-xp /usr/lib/libogg.so.0.7.1
b2b95000 b2bb7000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bc7000 b2cab000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2cc7000 b2d0a000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d1f000 b2d66000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d77000 b2d7e000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d8e000 b2dc3000 r-xp /usr/lib/libpulse.so.0.16.2
b2dd4000 b2dd7000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2de8000 b2deb000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2dfc000 b2e3f000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e50000 b2e58000 r-xp /usr/lib/libdrm.so.2.4.0
b2e68000 b2e6a000 r-xp /usr/lib/libdri2.so.0.0.0
b2e7a000 b2e81000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e91000 b2e9c000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2eb0000 b2eb6000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2ec7000 b2ecf000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ee0000 b2ee5000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2ef5000 b2f0c000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f1c000 b2f3c000 r-xp /usr/lib/libexif.so.12.3.3
b2f48000 b2f50000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f60000 b2f8f000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2fa2000 b2faa000 r-xp /usr/lib/libtbm.so.1.0.0
b2fba000 b3073000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3087000 b308e000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b309e000 b30fc000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3111000 b3115000 r-xp /usr/lib/libstorage.so.0.1
b3125000 b312c000 r-xp /usr/lib/libefl-extension.so.0.1.0
b313c000 b314b000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3275000 b3279000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b328a000 b336a000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b337f000 b3384000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b338c000 b33b3000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33c6000 b3bc5000 rwxp [stack:1539]
b3bc5000 b3bc7000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dd7000 b3de0000 r-xp /lib/libnss_files-2.20-2014.11.so
b3df1000 b3dfa000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e0b000 b3e1c000 r-xp /lib/libnsl-2.20-2014.11.so
b3e2f000 b3e35000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e46000 b3e60000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e71000 b3e72000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e82000 b3e84000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e95000 b3e9a000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3eaa000 b3ead000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ebe000 b3ec5000 r-xp /usr/lib/libsensord-share.so
b3ed5000 b3ee6000 r-xp /usr/lib/libsensor.so.1.2.0
b3ef7000 b3efd000 r-xp /usr/lib/libappcore-common.so.1.1
b3f20000 b3f25000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f3b000 b3f3d000 r-xp /usr/lib/libXau.so.6.0.0
b3f4d000 b3f61000 r-xp /usr/lib/libxcb.so.1.1.0
b3f71000 b3f78000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fb0000 b3fb2000 r-xp /usr/lib/libiri.so
b3fc3000 b3fd8000 r-xp /lib/libexpat.so.1.5.2
b3fea000 b4038000 r-xp /usr/lib/libssl.so.1.0.0
b404d000 b4056000 r-xp /usr/lib/libethumb.so.1.13.0
b4067000 b406a000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b407a000 b4231000 r-xp /usr/lib/libcrypto.so.1.0.0
b57c8000 b57d1000 r-xp /usr/lib/libXi.so.6.1.0
b57e2000 b57e4000 r-xp /usr/lib/libXgesture.so.7.0.0
b57f4000 b57f8000 r-xp /usr/lib/libXtst.so.6.1.0
b5808000 b580e000 r-xp /usr/lib/libXrender.so.1.3.0
b581e000 b5824000 r-xp /usr/lib/libXrandr.so.2.2.0
b5834000 b5836000 r-xp /usr/lib/libXinerama.so.1.0.0
b5846000 b5849000 r-xp /usr/lib/libXfixes.so.3.1.0
b585a000 b5865000 r-xp /usr/lib/libXext.so.6.4.0
b5875000 b5877000 r-xp /usr/lib/libXdamage.so.1.1.0
b5887000 b5889000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5899000 b597c000 r-xp /usr/lib/libX11.so.6.3.0
b598f000 b5996000 r-xp /usr/lib/libXcursor.so.1.0.2
b59a7000 b59bf000 r-xp /usr/lib/libudev.so.1.6.0
b59c1000 b59c4000 r-xp /lib/libattr.so.1.1.0
b59d4000 b59f4000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59f5000 b59fa000 r-xp /usr/lib/libffi.so.6.0.2
b5a0a000 b5a22000 r-xp /lib/libz.so.1.2.8
b5a32000 b5a34000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a44000 b5b19000 r-xp /usr/lib/libxml2.so.2.9.2
b5b2e000 b5bc9000 r-xp /usr/lib/libstdc++.so.6.0.20
b5be5000 b5be8000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bf8000 b5c12000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c22000 b5c33000 r-xp /lib/libresolv-2.20-2014.11.so
b5c47000 b5c5e000 r-xp /usr/lib/liblzma.so.5.0.3
b5c6e000 b5c70000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c80000 b5c87000 r-xp /usr/lib/libembryo.so.1.13.0
b5c97000 b5caf000 r-xp /usr/lib/libpng12.so.0.50.0
b5cc0000 b5ce3000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d03000 b5d09000 r-xp /lib/librt-2.20-2014.11.so
b5d1a000 b5d2e000 r-xp /usr/lib/libector.so.1.13.0
b5d3f000 b5d57000 r-xp /usr/lib/liblua-5.1.so
b5d68000 b5dbf000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dd3000 b5dfb000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e0c000 b5e1f000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e30000 b5e6a000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e7b000 b5ee6000 r-xp /lib/libm-2.20-2014.11.so
b5ef7000 b5f04000 r-xp /usr/lib/libeio.so.1.13.0
b5f14000 b5f16000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f26000 b5f2b000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f3b000 b5f52000 r-xp /usr/lib/libefreet.so.1.13.0
b5f64000 b5f84000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f94000 b5fb4000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fb6000 b5fbc000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fcc000 b5fd3000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fe3000 b5ff1000 r-xp /usr/lib/libeo.so.1.13.0
b6001000 b6013000 r-xp /usr/lib/libecore_input.so.1.13.0
b6024000 b6029000 r-xp /usr/lib/libecore_file.so.1.13.0
b6039000 b6051000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6062000 b607f000 r-xp /usr/lib/libeet.so.1.13.0
b6098000 b60e0000 r-xp /usr/lib/libeina.so.1.13.0
b60f1000 b6101000 r-xp /usr/lib/libefl.so.1.13.0
b6112000 b61f7000 r-xp /usr/lib/libicuuc.so.51.1
b6214000 b6354000 r-xp /usr/lib/libicui18n.so.51.1
b636b000 b63a3000 r-xp /usr/lib/libecore_x.so.1.13.0
b63b5000 b63b8000 r-xp /lib/libcap.so.2.21
b63c8000 b63f1000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6402000 b6409000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b641b000 b6451000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6462000 b654a000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b655e000 b65d4000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65e6000 b65e9000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65f9000 b6604000 r-xp /usr/lib/libvconf.so.0.2.45
b6614000 b6616000 r-xp /usr/lib/libvasum.so.0.3.1
b6626000 b6628000 r-xp /usr/lib/libttrace.so.1.1
b6638000 b663b000 r-xp /usr/lib/libiniparser.so.0
b664b000 b666e000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b667e000 b6683000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6694000 b66ab000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66bc000 b66c9000 r-xp /usr/lib/libunwind.so.8.0.1
b66ff000 b6823000 r-xp /lib/libc-2.20-2014.11.so
b6838000 b6851000 r-xp /lib/libgcc_s-4.9.so.1
b6861000 b6943000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6954000 b6988000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6998000 b69d2000 r-xp /usr/lib/libsystemd.so.0.4.0
b69d4000 b6a54000 r-xp /usr/lib/libedje.so.1.13.0
b6a57000 b6a75000 r-xp /usr/lib/libecore.so.1.13.0
b6a95000 b6bf7000 r-xp /usr/lib/libevas.so.1.13.0
b6c2e000 b6c42000 r-xp /lib/libpthread-2.20-2014.11.so
b6c56000 b6e7a000 r-xp /usr/lib/libelementary.so.1.13.0
b6ea8000 b6eac000 r-xp /usr/lib/libsmack.so.1.0.0
b6ebc000 b6ec2000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ed3000 b6ed5000 r-xp /usr/lib/libdlog.so.0.0.0
b6ee5000 b6ee8000 r-xp /usr/lib/libbundle.so.0.1.22
b6ef8000 b6efa000 r-xp /lib/libdl-2.20-2014.11.so
b6f0b000 b6f24000 r-xp /usr/lib/libaul.so.0.1.0
b6f36000 b6f38000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f49000 b6f4d000 r-xp /usr/lib/libsys-assert.so
b6f5e000 b6f7e000 r-xp /lib/ld-2.20-2014.11.so
b6f8f000 b6f95000 r-xp /usr/bin/launchpad-loader
b8205000 b8814000 rw-p [heap]
bec05000 bec26000 rwxp [stack]
bec05000 bec26000 rwxp [stack]
End of Maps Information

Callstack Information (PID:1537)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb675d128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb3382d13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb3140abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb30c3865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb64275bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6433f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb6439a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb6439c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf01dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf01e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb68b2157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c33cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
HSC]Mix=00008f5b,Csd=ffffe7ac ,(BV= 1.280,x=0.322,y=0.349)
01-22 21:28:34.288+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:3, 0x00008f5b,0x00008f5b
01-22 21:28:34.288+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=1.432171 ,Awb Bv=1.280106 in/out_0
01-22 21:28:34.288+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.343475,GGain=1.000000,BGain=1.295853,Dtct=0.321976,0.348984 ,Curr=0.320435,0.351105 ,CTmep: QC=6430, AL= 6002
01-22 21:28:34.308+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c34f8), gem(41), surface(0xb85b1b38)
01-22 21:28:34.308+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86a5240), gem(42), surface(0xb85b1b38)
01-22 21:28:34.328+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb846bb58), gem(41), surface(0xb85a6ac0)
01-22 21:28:34.378+0900 I/ISP_AE  ( 1537): FDAE: ->disable, frame_idx=30
01-22 21:28:34.388+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:326, cur_lum:70, next_index:334, target_lum:112
01-22 21:28:34.388+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85c4f60), gem(42), surface(0xb86c7150)
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:34.388+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:34.388+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.75, detect:   0.32,   0.35 CTemp:5926.5
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [HSC]Mix=00008f5b,Csd=ffff9b22 ,(BV= 1.281,x=0.322,y=0.350)
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:4, 0x00008f5b,0x00008f5b
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=1.202166 ,Awb Bv=1.280914 in/out_0
01-22 21:28:34.388+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.335297,GGain=1.000000,BGain=1.289917,Dtct=0.322388,0.349594 ,Curr=0.320541,0.350281 ,CTmep: QC=6430, AL= 6002
01-22 21:28:34.408+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84669a0), gem(41), surface(0xb86d4470)
01-22 21:28:34.418+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200869 
01-22 21:28:34.428+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c51f8), gem(42), surface(0xb86c7150)
01-22 21:28:34.479+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c2cd8), gem(41), surface(0xb870d5e0)
01-22 21:28:34.499+0900 I/ISP_AE  ( 1537): cur target lum=62, ev diff=86, level=7
01-22 21:28:34.499+0900 I/ISP_AE  ( 1537): ev_test cur_ev =7
01-22 21:28:34.499+0900 I/ISP_AE  ( 1537): ev_test target_lum=148
01-22 21:28:34.499+0900 I/ISP_AE  ( 1537): set ev level 7, target lum from 148 to 148, rtn=0
01-22 21:28:34.499+0900 I/ISP_AE  ( 1537): AE_TEST ----------------------change to fast
01-22 21:28:34.499+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:334, cur_lum:77, next_index:348, target_lum:148
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:34.499+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:34.499+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:34.499+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:34.509+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.76, detect:   0.32,   0.34 CTemp:5943.6
01-22 21:28:34.509+0900 D/alPrinter0( 1537): [HSC]Mix=00008f5b,Csd=ffff4c31 ,(BV= 1.279,x=0.323,y=0.349)
01-22 21:28:34.509+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:3, 0x00008f5b,0x00008f5b
01-22 21:28:34.509+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=1.151752 ,Awb Bv=1.278671 in/out_0
01-22 21:28:34.509+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.328049,GGain=1.000000,BGain=1.285492,Dtct=0.322525,0.348648 ,Curr=0.320740,0.349670 ,CTmep: QC=6429, AL= 6001
01-22 21:28:34.529+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86bee68), gem(42), surface(0xb870d5e0)
01-22 21:28:34.559+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200869 
01-22 21:28:34.579+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85f4970), gem(41), surface(0xb85b3f80)
01-22 21:28:34.599+0900 I/ISP_AE  ( 1537): cur target lum=62, ev diff=115, level=8
01-22 21:28:34.599+0900 I/ISP_AE  ( 1537): ev_test cur_ev =8
01-22 21:28:34.599+0900 I/ISP_AE  ( 1537): ev_test target_lum=177
01-22 21:28:34.599+0900 I/ISP_AE  ( 1537): set ev level 8, target lum from 177 to 177, rtn=0
01-22 21:28:34.599+0900 I/ISP_AE  ( 1537): AE_TEST ----------------------change to fast
01-22 21:28:34.599+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:348, cur_lum:89, next_index:362, target_lum:177
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:34.599+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:34.599+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:34.599+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:34.609+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.80, detect:   0.32,   0.34 CTemp:5924.4
01-22 21:28:34.609+0900 D/alPrinter0( 1537): [HSC]Mix=00007c28,Csd=ffffbf3d ,(BV= 1.265,x=0.323,y=0.348)
01-22 21:28:34.609+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:4, 0x00007c28,0x00007c28
01-22 21:28:34.609+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=0.989328 ,Awb Bv=1.264801 in/out_0
01-22 21:28:34.609+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.321060,GGain=1.000000,BGain=1.281937,Dtct=0.322601,0.347641 ,Curr=0.321014,0.349182 ,CTmep: QC=6428, AL= 6000
01-22 21:28:34.629+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86be9c0), gem(42), surface(0xb85b1da0)
01-22 21:28:34.679+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86ea910), gem(41), surface(0xb865d9d8)
01-22 21:28:34.709+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:362, cur_lum:102, next_index:372, target_lum:177
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:34.709+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:34.709+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:34.709+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:34.719+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.77, detect:   0.32,   0.34 CTemp:5861.0
01-22 21:28:34.719+0900 D/alPrinter0( 1537): [HSC]Mix=00007c28,Csd=ffff0892 ,(BV= 1.231,x=0.325,y=0.351)
01-22 21:28:34.719+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:3, 0x00007c28,0x00007c28
01-22 21:28:34.719+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=0.677384 ,Awb Bv=1.230743 in/out_0
01-22 21:28:34.719+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.314636,GGain=1.000000,BGain=1.279343,Dtct=0.324570,0.350708 ,Curr=0.321350,0.348831 ,CTmep: QC=6426, AL= 5998
01-22 21:28:34.729+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86e8310), gem(42), surface(0xb86c63e8)
01-22 21:28:34.779+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c07e8), gem(41), surface(0xb865d9d8)
01-22 21:28:34.829+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:372, cur_lum:114, next_index:380, target_lum:177
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:34.829+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:34.829+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:34.829+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:34.839+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.76, detect:   0.32,   0.34 CTemp:5879.1
01-22 21:28:34.839+0900 D/alPrinter0( 1537): [HSC]Mix=00005d70,Csd=ffffc52c ,(BV= 1.165,x=0.324,y=0.352)
01-22 21:28:34.839+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:4, 0x00005d70,0x00005d70
01-22 21:28:34.839+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=0.387878 ,Awb Bv=1.164886 in/out_0
01-22 21:28:34.839+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.309387,GGain=1.000000,BGain=1.278397,Dtct=0.323990,0.351807 ,Curr=0.321762,0.348709 ,CTmep: QC=6423, AL= 5995
01-22 21:28:34.859+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c0fd8), gem(42), surface(0xb86c63e8)
01-22 21:28:34.909+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85f44d8), gem(41), surface(0xb86c7150)
01-22 21:28:34.949+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:380, cur_lum:126, next_index:385, target_lum:177
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:34.959+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:34.959+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.76, detect:   0.32,   0.34 CTemp:5876.8
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [HSC]Mix=00005d70,Csd=000006c6 ,(BV= 1.063,x=0.324,y=0.352)
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:3, 0x00005d70,0x00005d70
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=0.232600 ,Awb Bv=1.062897 in/out_0
01-22 21:28:34.959+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.305588,GGain=1.000000,BGain=1.279236,Dtct=0.324112,0.352295 ,Curr=0.322235,0.348846 ,CTmep: QC=6419, AL= 5991
01-22 21:28:34.989+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85f4478), gem(42), surface(0xb86c63e8)
01-22 21:28:35.039+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85b6e10), gem(41), surface(0xb870d5e0)
01-22 21:28:35.059+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200869 
01-22 21:28:35.079+0900 I/ISP_AE  ( 1537): AE_TEST:----cur_index:385, cur_lum:134, next_index:388, target_lum:177
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:35.079+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [CMD0][if=b0d8ea90,Wrap=b0de1758]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:35.079+0900 D/awb_al_cmd0( 1537): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [CALL][0xb0d8ea90][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [AIS_WRAP]msiFlash_state=0
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [LOCK]0
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [SuperHighCTemp] Mapin:  0.75, detect:   0.32,   0.34 CTemp:5879.0
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [HSC]Mix=00005d70,Csd=00000482 ,(BV= 0.932,x=0.324,y=0.353)
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [AlHscWrap_Main]:4, 0x00005d70,0x00005d70
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [AIS_WRAP]In BV=0.146870 ,Awb Bv=0.932205 in/out_0
01-22 21:28:35.079+0900 D/alPrinter0( 1537): [AIS_WRAP]RGain=1.304443,GGain=1.000000,BGain=1.281830,Dtct=0.324081,0.352737 ,Curr=0.322647,0.349228 ,CTmep: QC=6413, AL= 5985
01-22 21:28:35.119+0900 I/ISP_AE  ( 1537): ae_state=3
01-22 21:28:35.119+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb84b60b0), gem(42), surface(0xb870d5e0)
01-22 21:28:35.159+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c1b58), gem(41), surface(0xb865ec78)
01-22 21:28:35.209+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86e8fe0), gem(42), surface(0xb85b1da0)
01-22 21:28:35.259+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86d1528), gem(41), surface(0xb865ec78)
01-22 21:28:35.339+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85b3db8), gem(42), surface(0xb865ec78)
01-22 21:28:35.389+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb870d3b0), gem(41), surface(0xb865ec78)
01-22 21:28:35.479+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb846bb58), gem(42), surface(0xb865ec78)
01-22 21:28:35.520+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85f4a80), gem(41), surface(0xb85b3f80)
01-22 21:28:35.560+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85b6e10), gem(42), surface(0xb85b3f80)
01-22 21:28:35.640+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c0fd8), gem(41), surface(0xb865ec78)
01-22 21:28:35.690+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85f4970), gem(42), surface(0xb865ec78)
01-22 21:28:35.740+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c1378), gem(41), surface(0xb865ec78)
01-22 21:28:35.820+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86e8fe0), gem(42), surface(0xb865ec78)
01-22 21:28:35.870+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8466720), gem(41), surface(0xb865ec78)
01-22 21:28:35.940+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86e7150), gem(42), surface(0xb865ec78)
01-22 21:28:35.990+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86e72b0), gem(41), surface(0xb865ec78)
01-22 21:28:36.040+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85b5bf8), gem(42), surface(0xb865ec78)
01-22 21:28:36.060+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x4c00003
01-22 21:28:36.120+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c77a8), gem(41), surface(0xb865ec78)
01-22 21:28:36.170+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb870e070), gem(42), surface(0xb865ec78)
01-22 21:28:36.220+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85b5630), gem(41), surface(0xb865ec78)
01-22 21:28:36.290+0900 I/ISP_AE  ( 1537): calc_iso=320,real_gain=104,iso=0
01-22 21:28:36.290+0900 I/ISP_AE  ( 1537): calc_iso=320,real_gain=104,iso=0
01-22 21:28:36.300+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86c1b58), gem(42), surface(0xb86c8828)
01-22 21:28:36.340+0900 I/ISP_AE  ( 1537): ANTI_FLAG: =600000, 4477, 134, 1
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v_s :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v_s :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :1
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 10
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :2
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :10
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 -7
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 700
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :3
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :700
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 6
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :6
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 880
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :4
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :880
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 6
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 13
01-22 21:28:36.340+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :13
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 140
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :5
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :140
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 13
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 130
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :6
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :130
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 2
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :2
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 450
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :7
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :450
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 2
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 5
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :5
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1400
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1400
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 5
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 15
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :15
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 70
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :9
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :70
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 15
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 230
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :10
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :230
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 8
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 9
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :9
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 550
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :11
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :550
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 9
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 13
01-22 21:28:36.360+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :13
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 60
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :12
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :60
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 13
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 6
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :6
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 530
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :13
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :530
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 6
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 10
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :10
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 320
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :14
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :320
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 10
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 12
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :12
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 60
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :15
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :60
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 12
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 5
01-22 21:28:36.370+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :5
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :16
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 5
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 -5
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 120
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :17
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :120
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 -7
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 40
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :18
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :40
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 -7
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 50
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :19
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :50
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 -7
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 70
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :20
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :70
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 -7
01-22 21:28:36.380+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :0
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 390
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :21
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :390
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 0
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 2
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :2
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 320
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :22
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :320
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 2
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 4
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :4
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 420
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :23
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :420
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 4
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 7
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :7
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 160
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :24
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :160
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 7
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 4
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :4
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 320
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :25
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :320
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 4
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 6
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :6
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 330
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :26
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :330
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 6
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 8
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :8
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 170
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :27
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :170
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 8
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 6
01-22 21:28:36.390+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :6
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 340
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :28
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :340
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 6
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 8
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :8
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 310
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :29
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :310
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 8
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 10
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :10
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 530
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :30
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :530
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 10
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 14
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :14
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v_s :0
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v_s :0
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 160
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :31
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :160
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 14
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 11
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :11
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 70
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :32
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :70
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 11
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 4
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :4
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :33
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 4
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 5
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :5
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 640
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :34
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :640
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 5
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 10
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :10
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 690
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :35
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :690
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 10
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 15
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :15
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 470
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :36
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :470
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 15
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 18
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :18
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 780
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :37
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :780
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 18
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 24
01-22 21:28:36.400+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :24
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 770
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :38
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :770
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 24
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 30
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :30
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 120
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :39
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :120
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 30
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 23
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :23
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 250
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :40
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :250
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 23
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 24
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :24
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 830
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :41
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :830
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 24
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 31
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :31
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1120
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :42
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1120
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 31
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 41
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :41
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1180
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :43
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1180
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 41
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 51
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :51
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 560
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :44
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :560
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 51
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 55
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :55
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1160
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :45
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1160
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 55
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 65
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :65
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1100
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :46
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1100
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 65
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 75
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :75
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1400
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :47
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1400
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 75
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 85
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :85
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 1020
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :48
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :1020
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 85
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 95
01-22 21:28:36.410+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :95
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 590
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :49
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :590
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 95
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 99
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :99
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman frame_flicker_value = 730
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman still_f :50
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_f_v :730
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman b0 99
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman b1 200
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman b2 105
01-22 21:28:36.420+0900 I/ISP_DEFLICKER V3( 1537): hyman afl_v_v :105
01-22 21:28:36.520+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85f4970), gem(41), surface(0xb86c8828)
01-22 21:28:36.551+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86d1528), gem(43), surface(0xb86c8828)
01-22 21:28:36.601+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb86ea910), gem(41), surface(0xb86c8828)
01-22 21:28:36.651+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85b6e10), gem(42), surface(0xb86c8828)
01-22 21:28:36.691+0900 D/camera  ( 1537): Writing image to file.
01-22 21:28:36.701+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb846bb58), gem(41), surface(0xb86c8828)
01-22 21:28:36.781+0900 I/MALI    ( 1537): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85c4ea0), gem(42), surface(0xb86c8828)
01-22 21:28:36.821+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:28:36.841+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:28:36.841+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:28:36.841+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:28:36.841+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:28:36.841+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(3)
01-22 21:28:36.841+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-22 21:28:36.841+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-22 21:28:36.841+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: fg
01-22 21:28:36.841+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:28:36.851+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x04c00003), visible:1
01-22 21:28:36.851+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 4c00003
01-22 21:28:36.851+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:28:36.851+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:28:36.851+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:28:36.851+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:28:36.851+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:28:36.861+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xea9040), gem(21), surface(0xf88590)
01-22 21:28:36.861+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 913
01-22 21:28:36.861+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 913, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
01-22 21:28:36.861+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 913, appname = org.tizen.homescreen
01-22 21:28:36.861+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 913
01-22 21:28:36.861+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 913 foreground
01-22 21:28:36.891+0900 W/CRASH_MANAGER( 1695): worker.c: worker_job(1204) > 110153763616d142192971
