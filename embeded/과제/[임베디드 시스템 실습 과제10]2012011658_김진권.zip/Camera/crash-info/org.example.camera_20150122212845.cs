S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 1547
Date: 2015-01-22 21:28:45+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 1547, uid 5000)

Register Information
r0   = 0x9332e008, r1   = 0x00000001
r2   = 0x001cc4e3, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x001cc4e3
r6   = 0x001cc4e3, r7   = 0xad814588
r8   = 0xb72ee758, r9   = 0xad814734
r10  = 0xb72f5500, fp   = 0x0000000d
ip   = 0xb6763110, sp   = 0xad8144f0
lr   = 0xb3388d13, pc   = 0xb6763128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    419360 KB
Buffers:     17640 KB
Cached:     125268 KB
VmPeak:     594028 KB
VmSize:     593556 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       45964 KB
VmRSS:       45964 KB
VmData:     415840 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         282 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 1547 TID = 1738
1547 1548 1719 1723 1724 1731 1732 1736 1737 1738 1739 1740 1741 1742 1743 1744 1745 1748 1749 1750 1751 1752 1753 1754 1755 1756 1757 1758 1759 1760 1761 1762 1763 1764 1765 1766 1767 1768 1769 1770 1771 1772 1774 1775 1776 1779 1780 1783 

Maps Information
937f1000 93ff0000 rwxp [stack:1780]
93ff1000 947f0000 rwxp [stack:1779]
94832000 95031000 rwxp [stack:1783]
98ef3000 996f2000 rwxp [stack:1776]
996f3000 99ef2000 rwxp [stack:1775]
9bdf3000 9c5f2000 rwxp [stack:1774]
9c68a000 9ce89000 rwxp [stack:1772]
9ce8a000 9d689000 rwxp [stack:1771]
9d68a000 9de89000 rwxp [stack:1770]
9e575000 9ed74000 rwxp [stack:1769]
9ed75000 9f574000 rwxp [stack:1768]
9f575000 9fd74000 rwxp [stack:1767]
9fd75000 a0574000 rwxp [stack:1766]
a0575000 a0d74000 rwxp [stack:1765]
a0d75000 a1574000 rwxp [stack:1764]
a1575000 a1d74000 rwxp [stack:1763]
a1d75000 a2574000 rwxp [stack:1762]
a2575000 a2d74000 rwxp [stack:1761]
a2d75000 a3574000 rwxp [stack:1760]
a3575000 a3d74000 rwxp [stack:1759]
a3d75000 a4574000 rwxp [stack:1758]
a4575000 a4d74000 rwxp [stack:1757]
a4d75000 a5574000 rwxp [stack:1756]
a5817000 a6016000 rwxp [stack:1755]
a6017000 a6816000 rwxp [stack:1754]
a6817000 a7016000 rwxp [stack:1753]
a7017000 a7816000 rwxp [stack:1752]
a7817000 a8016000 rwxp [stack:1751]
a8017000 a8816000 rwxp [stack:1750]
a8817000 a9016000 rwxp [stack:1749]
a9017000 a9816000 rwxp [stack:1748]
a9817000 aa016000 rwxp [stack:1745]
aa017000 aa816000 rwxp [stack:1744]
aa817000 ab016000 rwxp [stack:1743]
ab017000 ab816000 rwxp [stack:1742]
ab817000 ac016000 rwxp [stack:1741]
ac017000 ac816000 rwxp [stack:1740]
ac817000 ad016000 rwxp [stack:1739]
ad017000 ad816000 rwxp [stack:1738]
ad816000 ad819000 r-xp /usr/lib/libXv.so.1.0.0
ad829000 ad83b000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad84c000 ad883000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad895000 ae094000 rwxp [stack:1737]
ae094000 ae0b1000 r-xp /usr/lib/libAl_Awb_Sp.so
ae0ba000 ae0bd000 r-xp /usr/lib/libdeflicker.so
ae0d5000 ae0eb000 r-xp /usr/lib/libAl_Awb.so
ae0f3000 ae0fd000 r-xp /usr/lib/libcalibration.so
ae106000 ae118000 r-xp /usr/lib/libaf_lib.so
ae120000 ae126000 r-xp /usr/lib/libspaf.so
ae12e000 ae13a000 r-xp /usr/lib/libae.so
ae142000 ae183000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae1ca000 ae2a9000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae706000 ae742000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae80c000 af00b000 rwxp [stack:1736]
af013000 af02b000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afc03000 afc09000 r-xp /usr/lib/liblsc.so
afd01000 b0500000 rwxp [stack:1732]
b0501000 b0d00000 rwxp [stack:1731]
b0e03000 b0e04000 r-xp /usr/lib/libcamerahdr.so.0.0.0
b0eb2000 b16b1000 rwxp [stack:1724]
b16b2000 b1eb1000 rwxp [stack:1723]
b1eb1000 b1eb6000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f42000 b1f4a000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f5b000 b1f5c000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f6c000 b1f73000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f97000 b1f98000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1fa8000 b1fbb000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b200f000 b2014000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2025000 b2824000 rwxp [stack:1719]
b2824000 b297f000 r-xp /usr/lib/egl/libMali.so
b2994000 b2a1d000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a36000 b2b04000 r-xp /usr/lib/libCOREGL.so.4.0
b2b1f000 b2b22000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b32000 b2b3f000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b50000 b2b5a000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b6a000 b2b76000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b87000 b2b8b000 r-xp /usr/lib/libogg.so.0.7.1
b2b9b000 b2bbd000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bcd000 b2cb1000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2ccd000 b2d10000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d25000 b2d6c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d7d000 b2d84000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d94000 b2dc9000 r-xp /usr/lib/libpulse.so.0.16.2
b2dda000 b2ddd000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2dee000 b2df1000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2e02000 b2e45000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e56000 b2e5e000 r-xp /usr/lib/libdrm.so.2.4.0
b2e6e000 b2e70000 r-xp /usr/lib/libdri2.so.0.0.0
b2e80000 b2e87000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e97000 b2ea2000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2eb6000 b2ebc000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2ecd000 b2ed5000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ee6000 b2eeb000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2efb000 b2f12000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f22000 b2f42000 r-xp /usr/lib/libexif.so.12.3.3
b2f4e000 b2f56000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f66000 b2f95000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2fa8000 b2fb0000 r-xp /usr/lib/libtbm.so.1.0.0
b2fc0000 b3079000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b308d000 b3094000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b30a4000 b3102000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3117000 b311b000 r-xp /usr/lib/libstorage.so.0.1
b312b000 b3132000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3142000 b3151000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b327b000 b327f000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3290000 b3370000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3385000 b338a000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3392000 b33b9000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33cc000 b3bcb000 rwxp [stack:1548]
b3bcb000 b3bcd000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3ddd000 b3de6000 r-xp /lib/libnss_files-2.20-2014.11.so
b3df7000 b3e00000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e11000 b3e22000 r-xp /lib/libnsl-2.20-2014.11.so
b3e35000 b3e3b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e4c000 b3e66000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e77000 b3e78000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e88000 b3e8a000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e9b000 b3ea0000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3eb0000 b3eb3000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ec4000 b3ecb000 r-xp /usr/lib/libsensord-share.so
b3edb000 b3eec000 r-xp /usr/lib/libsensor.so.1.2.0
b3efd000 b3f03000 r-xp /usr/lib/libappcore-common.so.1.1
b3f26000 b3f2b000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f41000 b3f43000 r-xp /usr/lib/libXau.so.6.0.0
b3f53000 b3f67000 r-xp /usr/lib/libxcb.so.1.1.0
b3f77000 b3f7e000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fb6000 b3fb8000 r-xp /usr/lib/libiri.so
b3fc9000 b3fde000 r-xp /lib/libexpat.so.1.5.2
b3ff0000 b403e000 r-xp /usr/lib/libssl.so.1.0.0
b4053000 b405c000 r-xp /usr/lib/libethumb.so.1.13.0
b406d000 b4070000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4080000 b4237000 r-xp /usr/lib/libcrypto.so.1.0.0
b57ce000 b57d7000 r-xp /usr/lib/libXi.so.6.1.0
b57e8000 b57ea000 r-xp /usr/lib/libXgesture.so.7.0.0
b57fa000 b57fe000 r-xp /usr/lib/libXtst.so.6.1.0
b580e000 b5814000 r-xp /usr/lib/libXrender.so.1.3.0
b5824000 b582a000 r-xp /usr/lib/libXrandr.so.2.2.0
b583a000 b583c000 r-xp /usr/lib/libXinerama.so.1.0.0
b584c000 b584f000 r-xp /usr/lib/libXfixes.so.3.1.0
b5860000 b586b000 r-xp /usr/lib/libXext.so.6.4.0
b587b000 b587d000 r-xp /usr/lib/libXdamage.so.1.1.0
b588d000 b588f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b589f000 b5982000 r-xp /usr/lib/libX11.so.6.3.0
b5995000 b599c000 r-xp /usr/lib/libXcursor.so.1.0.2
b59ad000 b59c5000 r-xp /usr/lib/libudev.so.1.6.0
b59c7000 b59ca000 r-xp /lib/libattr.so.1.1.0
b59da000 b59fa000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59fb000 b5a00000 r-xp /usr/lib/libffi.so.6.0.2
b5a10000 b5a28000 r-xp /lib/libz.so.1.2.8
b5a38000 b5a3a000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a4a000 b5b1f000 r-xp /usr/lib/libxml2.so.2.9.2
b5b34000 b5bcf000 r-xp /usr/lib/libstdc++.so.6.0.20
b5beb000 b5bee000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bfe000 b5c18000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c28000 b5c39000 r-xp /lib/libresolv-2.20-2014.11.so
b5c4d000 b5c64000 r-xp /usr/lib/liblzma.so.5.0.3
b5c74000 b5c76000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c86000 b5c8d000 r-xp /usr/lib/libembryo.so.1.13.0
b5c9d000 b5cb5000 r-xp /usr/lib/libpng12.so.0.50.0
b5cc6000 b5ce9000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d09000 b5d0f000 r-xp /lib/librt-2.20-2014.11.so
b5d20000 b5d34000 r-xp /usr/lib/libector.so.1.13.0
b5d45000 b5d5d000 r-xp /usr/lib/liblua-5.1.so
b5d6e000 b5dc5000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dd9000 b5e01000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e12000 b5e25000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e36000 b5e70000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e81000 b5eec000 r-xp /lib/libm-2.20-2014.11.so
b5efd000 b5f0a000 r-xp /usr/lib/libeio.so.1.13.0
b5f1a000 b5f1c000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f2c000 b5f31000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f41000 b5f58000 r-xp /usr/lib/libefreet.so.1.13.0
b5f6a000 b5f8a000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f9a000 b5fba000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fbc000 b5fc2000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fd2000 b5fd9000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fe9000 b5ff7000 r-xp /usr/lib/libeo.so.1.13.0
b6007000 b6019000 r-xp /usr/lib/libecore_input.so.1.13.0
b602a000 b602f000 r-xp /usr/lib/libecore_file.so.1.13.0
b603f000 b6057000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6068000 b6085000 r-xp /usr/lib/libeet.so.1.13.0
b609e000 b60e6000 r-xp /usr/lib/libeina.so.1.13.0
b60f7000 b6107000 r-xp /usr/lib/libefl.so.1.13.0
b6118000 b61fd000 r-xp /usr/lib/libicuuc.so.51.1
b621a000 b635a000 r-xp /usr/lib/libicui18n.so.51.1
b6371000 b63a9000 r-xp /usr/lib/libecore_x.so.1.13.0
b63bb000 b63be000 r-xp /lib/libcap.so.2.21
b63ce000 b63f7000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6408000 b640f000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6421000 b6457000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6468000 b6550000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6564000 b65da000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65ec000 b65ef000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65ff000 b660a000 r-xp /usr/lib/libvconf.so.0.2.45
b661a000 b661c000 r-xp /usr/lib/libvasum.so.0.3.1
b662c000 b662e000 r-xp /usr/lib/libttrace.so.1.1
b663e000 b6641000 r-xp /usr/lib/libiniparser.so.0
b6651000 b6674000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6684000 b6689000 r-xp /usr/lib/libxdgmime.so.1.1.0
b669a000 b66b1000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66c2000 b66cf000 r-xp /usr/lib/libunwind.so.8.0.1
b6705000 b6829000 r-xp /lib/libc-2.20-2014.11.so
b683e000 b6857000 r-xp /lib/libgcc_s-4.9.so.1
b6867000 b6949000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b695a000 b698e000 r-xp /usr/lib/libdbus-1.so.3.8.11
b699e000 b69d8000 r-xp /usr/lib/libsystemd.so.0.4.0
b69da000 b6a5a000 r-xp /usr/lib/libedje.so.1.13.0
b6a5d000 b6a7b000 r-xp /usr/lib/libecore.so.1.13.0
b6a9b000 b6bfd000 r-xp /usr/lib/libevas.so.1.13.0
b6c34000 b6c48000 r-xp /lib/libpthread-2.20-2014.11.so
b6c5c000 b6e80000 r-xp /usr/lib/libelementary.so.1.13.0
b6eae000 b6eb2000 r-xp /usr/lib/libsmack.so.1.0.0
b6ec2000 b6ec8000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ed9000 b6edb000 r-xp /usr/lib/libdlog.so.0.0.0
b6eeb000 b6eee000 r-xp /usr/lib/libbundle.so.0.1.22
b6efe000 b6f00000 r-xp /lib/libdl-2.20-2014.11.so
b6f11000 b6f2a000 r-xp /usr/lib/libaul.so.0.1.0
b6f3c000 b6f3e000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f4f000 b6f53000 r-xp /usr/lib/libsys-assert.so
b6f64000 b6f84000 r-xp /lib/ld-2.20-2014.11.so
b6f95000 b6f9b000 r-xp /usr/bin/launchpad-loader
b703a000 b75dd000 rw-p [heap]
be903000 be924000 rwxp [stack]
be903000 be924000 rwxp [stack]
End of Maps Information

Callstack Information (PID:1547)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6763128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb3388d13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb3146abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb30c9865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb642d5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6439f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb643fa8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb643fc81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf01dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf01e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb68b8157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c39cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.198+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.198+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.198+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.198+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.198+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.198+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.198+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.198+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.208+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.76, detect:   0.32,   0.35 CTemp:5994.0
01-22 21:28:44.208+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=ffffd436 ,(BV= 1.243,x=0.320,y=0.348)
01-22 21:28:44.208+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:3, 0x00008e13,0x00008e13
01-22 21:28:44.208+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.204618 ,Awb Bv=1.243057 in/out_0
01-22 21:28:44.208+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.333984,GGain=1.000000,BGain=1.286240,Dtct=0.319702,0.348251 ,Curr=0.320251,0.349762 ,CTmep: QC=6433, AL= 6005
01-22 21:28:44.218+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb75205f0)
01-22 21:28:44.238+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8de8), gem(48), surface(0xb75205f0)
01-22 21:28:44.268+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:307, cur_lum:59, next_index:307, target_lum:62
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.268+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.268+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.76, detect:   0.32,   0.35 CTemp:6023.6
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=ffffbb3f ,(BV= 1.228,x=0.319,y=0.348)
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:4, 0x00008e13,0x00008e13
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.204618 ,Awb Bv=1.228363 in/out_0
01-22 21:28:44.268+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.329941,GGain=1.000000,BGain=1.281937,Dtct=0.319275,0.348404 ,Curr=0.320145,0.349152 ,CTmep: QC=6434, AL= 6006
01-22 21:28:44.288+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb75205f0)
01-22 21:28:44.318+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8de8), gem(48), surface(0xb75205f0)
01-22 21:28:44.338+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:307, cur_lum:58, next_index:308, target_lum:62
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.338+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.338+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.76, detect:   0.32,   0.35 CTemp:6016.0
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=fffff667 ,(BV= 1.216,x=0.319,y=0.348)
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:3, 0x00008e13,0x00008e13
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.163975 ,Awb Bv=1.216202 in/out_0
01-22 21:28:44.338+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.330017,GGain=1.000000,BGain=1.281982,Dtct=0.319427,0.348160 ,Curr=0.320145,0.349152 ,CTmep: QC=6436, AL= 6008
01-22 21:28:44.368+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb75205f0)
01-22 21:28:44.398+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8de8), gem(49), surface(0xb75205f0)
01-22 21:28:44.418+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb75205f0)
01-22 21:28:44.438+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:308, cur_lum:59, next_index:308, target_lum:62
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.438+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.438+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.77, detect:   0.32,   0.35 CTemp:6020.2
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=ffffc866 ,(BV= 1.205,x=0.319,y=0.347)
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:4, 0x00008e13,0x00008e13
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.163975 ,Awb Bv=1.205002 in/out_0
01-22 21:28:44.438+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.327408,GGain=1.000000,BGain=1.278671,Dtct=0.319275,0.347122 ,Curr=0.320023,0.348679 ,CTmep: QC=6439, AL= 6011
01-22 21:28:44.448+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8de8), gem(48), surface(0xb75205f0)
01-22 21:28:44.498+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb75205f0)
01-22 21:28:44.498+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:308, cur_lum:59, next_index:308, target_lum:62
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.498+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.498+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.498+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.77, detect:   0.32,   0.35 CTemp:6013.7
01-22 21:28:44.508+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=ffffece4 ,(BV= 1.194,x=0.319,y=0.347)
01-22 21:28:44.508+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:3, 0x00008e13,0x00008e13
01-22 21:28:44.508+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.163975 ,Awb Bv=1.194489 in/out_0
01-22 21:28:44.508+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.325439,GGain=1.000000,BGain=1.275589,Dtct=0.319260,0.347061 ,Curr=0.319855,0.348236 ,CTmep: QC=6441, AL= 6013
01-22 21:28:44.518+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8de8), gem(48), surface(0xb75205f0)
01-22 21:28:44.548+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb75205f0)
01-22 21:28:44.568+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:308, cur_lum:59, next_index:308, target_lum:62
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.568+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.568+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.77, detect:   0.32,   0.35 CTemp:6018.1
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=ffffe26a ,(BV= 1.185,x=0.319,y=0.347)
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:4, 0x00008e13,0x00008e13
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.163975 ,Awb Bv=1.185303 in/out_0
01-22 21:28:44.568+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.323990,GGain=1.000000,BGain=1.273193,Dtct=0.319244,0.347076 ,Curr=0.319717,0.347885 ,CTmep: QC=6444, AL= 6016
01-22 21:28:44.588+0900 I/ISP_AE  ( 1547): warning call at out of rule!
01-22 21:28:44.598+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8de8), gem(48), surface(0xb75205f0)
01-22 21:28:44.628+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb751a7b8), gem(47), surface(0xb752b358)
01-22 21:28:44.638+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:308, cur_lum:58, next_index:309, target_lum:62
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.638+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.638+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.77, detect:   0.32,   0.35 CTemp:6007.6
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [HSC]Mix=00008e13,Csd=ffff748b ,(BV= 1.177,x=0.319,y=0.347)
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:3, 0x00008e13,0x00008e13
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.124447 ,Awb Bv=1.176865 in/out_0
01-22 21:28:44.638+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.324097,GGain=1.000000,BGain=1.273254,Dtct=0.319397,0.347244 ,Curr=0.319717,0.347885 ,CTmep: QC=6447, AL= 6019
01-22 21:28:44.658+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7542308), gem(48), surface(0xb7522d20)
01-22 21:28:44.678+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8890), gem(47), surface(0xb75205f0)
01-22 21:28:44.729+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x2009a9 
01-22 21:28:44.739+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:309, cur_lum:59, next_index:309, target_lum:62
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.739+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.739+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.78, detect:   0.32,   0.35 CTemp:6041.5
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [HSC]Mix=000083d6,Csd=0000a5d2 ,(BV= 1.168,x=0.319,y=0.346)
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:4, 0x000083d6,0x000083d6
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.124447 ,Awb Bv=1.168030 in/out_0
01-22 21:28:44.739+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.322983,GGain=1.000000,BGain=1.270966,Dtct=0.318680,0.346207 ,Curr=0.319565,0.347549 ,CTmep: QC=6450, AL= 6023
01-22 21:28:44.749+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7544c58), gem(48), surface(0xb7547ac0)
01-22 21:28:44.769+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb73df630), gem(49), surface(0xb75427f8)
01-22 21:28:44.779+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8890), gem(47), surface(0xb74e8fc0)
01-22 21:28:44.799+0900 I/ISP_AE  ( 1547): AE_TEST:----cur_index:309, cur_lum:59, next_index:309, target_lum:62
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:28:44.799+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:28:44.799+0900 D/awb_al_cmd0( 1547): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [AIS_WRAP]msiFlash_state=0
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [LOCK]0
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [SuperHighCTemp] Mapin:  0.78, detect:   0.32,   0.35 CTemp:6011.4
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [HSC]Mix=00009709,Csd=ffffc0a8 ,(BV= 1.159,x=0.319,y=0.346)
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [AlHscWrap_Main]:3, 0x00009709,0x00009709
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [AIS_WRAP]In BV=1.124447 ,Awb Bv=1.158844 in/out_0
01-22 21:28:44.799+0900 D/alPrinter0( 1547): [AIS_WRAP]RGain=1.322098,GGain=1.000000,BGain=1.268921,Dtct=0.319031,0.345779 ,Curr=0.319412,0.347244 ,CTmep: QC=6453, AL= 6026
01-22 21:28:44.819+0900 I/ISP_AE  ( 1547): ae_state=3
01-22 21:28:44.839+0900 I/ISP_AE  ( 1547): calc_iso=110,real_gain=37,iso=0
01-22 21:28:44.839+0900 I/ISP_AE  ( 1547): calc_iso=110,real_gain=37,iso=0
01-22 21:28:44.839+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7546548), gem(48), surface(0xb74e8fc0)
01-22 21:28:44.859+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75467e8), gem(49), surface(0xb74e95a8)
01-22 21:28:45.089+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75301f8), gem(47), surface(0xb74e95a8)
01-22 21:28:45.089+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7530300), gem(48), surface(0xb74e8fc0)
01-22 21:28:45.109+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7547978), gem(47), surface(0xb74e95a8)
01-22 21:28:45.169+0900 I/ISP_AE  ( 1547): ANTI_FLAG: =300000, 2238, 134, 1
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v_s :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v_s :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :1
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 570
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :2
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :570
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 4
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :4
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 470
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :3
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :470
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 4
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 7
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :7
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 230
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :4
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :230
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 7
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 8
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :8
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 380
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :5
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :380
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 8
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 10
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :10
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 120
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :6
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :120
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 10
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 3
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :3
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 240
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :7
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :240
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 3
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 4
01-22 21:28:45.169+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :4
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 170
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :8
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :170
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 4
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 2
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :2
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 350
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :9
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :350
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 2
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 4
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :4
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 120
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :10
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :120
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 4
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -3
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 370
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :11
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :370
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 2
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :2
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 110
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :12
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :110
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 2
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -5
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 90
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :13
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :90
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 60
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :14
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :60
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 80
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :15
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :80
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 80
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :16
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :80
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 230
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :17
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :230
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 1
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :1
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :18
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 1
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -6
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :19
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -10
01-22 21:28:45.179+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 130
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :20
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :130
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -6
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 210
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :21
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :210
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 1
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :1
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 190
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :22
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :190
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 1
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 1
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :1
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 160
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :23
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :160
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 1
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -2
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 120
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :24
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :120
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 30
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :25
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :30
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 130
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :26
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :130
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -6
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 140
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :27
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :140
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -5
01-22 21:28:45.189+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 60
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :28
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :60
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 10
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :29
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :10
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 70
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :30
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :70
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v_s :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v_s :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 80
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :31
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :80
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74e8890), gem(48), surface(0xb74e85a8)
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 90
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :32
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :90
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 10
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :33
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :10
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :34
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 290
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :35
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :290
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 1
01-22 21:28:45.199+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :1
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :36
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 1
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -9
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 320
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :37
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :320
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 2
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :2
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 260
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :38
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :260
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 2
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 3
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :3
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 290
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :39
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :290
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 3
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 4
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :4
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 460
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :40
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :460
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 4
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 7
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :7
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 90
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :41
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :90
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 7
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 50
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :42
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :50
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.209+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 30
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :43
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :30
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :44
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :45
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :46
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 50
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :47
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :50
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :48
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :49
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :20
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 D/camera  ( 1547): Writing image to file.
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 10
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :50
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :10
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 420
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :51
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :420
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 3
01-22 21:28:45.219+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :3
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 510
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :52
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :510
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 3
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 7
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :7
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 50
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :53
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :50
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 7
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 450
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :54
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :450
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 3
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :3
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 460
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :55
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :460
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 3
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 6
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :6
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 110
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :56
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :110
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 6
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -1
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.229+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7546548), gem(47), surface(0xb74e95a8)
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 100
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :57
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :100
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 50
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :58
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :50
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 100
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :59
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :100
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.229+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman frame_flicker_value = 50
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman still_f :60
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v :50
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman b0 0
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman b1 200
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman b2 -7
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v :0
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_f_v_s :0
01-22 21:28:45.239+0900 I/ISP_DEFLICKER V3( 1547): hyman afl_v_v_s :0
01-22 21:28:45.259+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7546888), gem(48), surface(0xb74e8fc0)
01-22 21:28:45.289+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75301f8), gem(47), surface(0xb74e8fc0)
01-22 21:28:45.309+0900 I/MALI    ( 1547): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7530140), gem(48), surface(0xb74e95a8)
01-22 21:28:45.329+0900 W/CRASH_MANAGER( 1695): worker.c: worker_job(1204) > 110154763616d142192972
