S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 1189
Date: 2015-01-23 19:43:21+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 1189, uid 5000)

Register Information
r0   = 0x92b58008, r1   = 0x00000001
r2   = 0x005935ff, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x005935ff
r6   = 0x005935ff, r7   = 0xad7cc588
r8   = 0xb79b5688, r9   = 0xad7cc734
r10  = 0xb79bc420, fp   = 0x0000000d
ip   = 0xb6712110, sp   = 0xad7cc4e8
lr   = 0xb3337c2f, pc   = 0xb6712128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    454456 KB
Buffers:     15132 KB
Cached:     112332 KB
VmPeak:     601224 KB
VmSize:     601220 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       52976 KB
VmRSS:       52976 KB
VmData:     423564 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         292 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 1189 TID = 1372
1189 1193 1268 1269 1270 1271 1272 1370 1371 1372 1373 1374 1375 1376 1377 1378 1379 1382 1383 1384 1385 1386 1387 1388 1389 1390 1391 1392 1393 1394 1395 1396 1397 1398 1399 1400 1401 1402 1403 1404 1405 1406 1411 1412 1413 1415 1416 1419 

Maps Information
937a9000 93fa8000 rwxp [stack:1416]
93fa9000 947a8000 rwxp [stack:1415]
947ea000 94fe9000 rwxp [stack:1419]
98eab000 996aa000 rwxp [stack:1413]
996ab000 99eaa000 rwxp [stack:1412]
9bdab000 9c5aa000 rwxp [stack:1411]
9c642000 9ce41000 rwxp [stack:1406]
9ce42000 9d641000 rwxp [stack:1405]
9d642000 9de41000 rwxp [stack:1404]
9e52d000 9ed2c000 rwxp [stack:1403]
9ed2d000 9f52c000 rwxp [stack:1402]
9f52d000 9fd2c000 rwxp [stack:1401]
9fd2d000 a052c000 rwxp [stack:1400]
a052d000 a0d2c000 rwxp [stack:1399]
a0d2d000 a152c000 rwxp [stack:1398]
a152d000 a1d2c000 rwxp [stack:1397]
a1d2d000 a252c000 rwxp [stack:1396]
a252d000 a2d2c000 rwxp [stack:1395]
a2d2d000 a352c000 rwxp [stack:1394]
a352d000 a3d2c000 rwxp [stack:1393]
a3d2d000 a452c000 rwxp [stack:1392]
a452d000 a4d2c000 rwxp [stack:1391]
a4fcf000 a57ce000 rwxp [stack:1390]
a57cf000 a5fce000 rwxp [stack:1389]
a5fcf000 a67ce000 rwxp [stack:1388]
a67cf000 a6fce000 rwxp [stack:1387]
a6fcf000 a77ce000 rwxp [stack:1386]
a77cf000 a7fce000 rwxp [stack:1385]
a7fcf000 a87ce000 rwxp [stack:1384]
a87cf000 a8fce000 rwxp [stack:1383]
a8fcf000 a97ce000 rwxp [stack:1382]
a97cf000 a9fce000 rwxp [stack:1379]
a9fcf000 aa7ce000 rwxp [stack:1378]
aa7cf000 aafce000 rwxp [stack:1377]
aafcf000 ab7ce000 rwxp [stack:1376]
ab7cf000 abfce000 rwxp [stack:1375]
abfcf000 ac7ce000 rwxp [stack:1374]
ac7cf000 acfce000 rwxp [stack:1373]
acfcf000 ad7ce000 rwxp [stack:1372]
ad7ce000 ad7d1000 r-xp /usr/lib/libXv.so.1.0.0
ad7e1000 ad7f3000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad804000 ad83b000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad84d000 ae04c000 rwxp [stack:1371]
ae04c000 ae069000 r-xp /usr/lib/libAl_Awb_Sp.so
ae072000 ae075000 r-xp /usr/lib/libdeflicker.so
ae08d000 ae0a3000 r-xp /usr/lib/libAl_Awb.so
ae0ab000 ae0b5000 r-xp /usr/lib/libcalibration.so
ae0be000 ae0d0000 r-xp /usr/lib/libaf_lib.so
ae0d8000 ae0de000 r-xp /usr/lib/libspaf.so
ae0e6000 ae0ec000 r-xp /usr/lib/liblsc.so
ae0f5000 ae101000 r-xp /usr/lib/libae.so
ae109000 ae14a000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae191000 ae270000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae6cd000 ae709000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae7d3000 aefd2000 rwxp [stack:1370]
aefdc000 aeff4000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afd01000 b0500000 rwxp [stack:1272]
b0501000 b0d00000 rwxp [stack:1271]
b0e05000 b0e06000 r-xp /usr/lib/libcamerahdr.so.0.0.0
b0e61000 b1660000 rwxp [stack:1270]
b1661000 b1e60000 rwxp [stack:1269]
b1e60000 b1e65000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1ef1000 b1ef9000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f0a000 b1f0b000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f1b000 b1f22000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f46000 b1f47000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f57000 b1f6a000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fbe000 b1fc3000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1fd4000 b27d3000 rwxp [stack:1268]
b27d3000 b292e000 r-xp /usr/lib/egl/libMali.so
b2943000 b29cc000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b29e5000 b2ab3000 r-xp /usr/lib/libCOREGL.so.4.0
b2ace000 b2ad1000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2ae1000 b2aee000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2aff000 b2b09000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b19000 b2b25000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b36000 b2b3a000 r-xp /usr/lib/libogg.so.0.7.1
b2b4a000 b2b6c000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b7c000 b2c60000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c7c000 b2cbf000 r-xp /usr/lib/libsndfile.so.1.0.25
b2cd4000 b2d1b000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d2c000 b2d33000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d43000 b2d78000 r-xp /usr/lib/libpulse.so.0.16.2
b2d89000 b2d8c000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2d9d000 b2da0000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2db1000 b2df4000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e05000 b2e0d000 r-xp /usr/lib/libdrm.so.2.4.0
b2e1d000 b2e1f000 r-xp /usr/lib/libdri2.so.0.0.0
b2e2f000 b2e36000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e46000 b2e51000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e65000 b2e6b000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e7c000 b2e84000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2e95000 b2e9a000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2eaa000 b2ec1000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2ed1000 b2ef1000 r-xp /usr/lib/libexif.so.12.3.3
b2efd000 b2f05000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f15000 b2f44000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f57000 b2f5f000 r-xp /usr/lib/libtbm.so.1.0.0
b2f6f000 b3028000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b303c000 b3043000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b3053000 b30b1000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30c6000 b30ca000 r-xp /usr/lib/libstorage.so.0.1
b30da000 b30e1000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30f1000 b3100000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b322a000 b322e000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b323f000 b331f000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3334000 b3339000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3341000 b3368000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b337b000 b3b7a000 rwxp [stack:1193]
b3b7a000 b3b7c000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d8c000 b3d95000 r-xp /lib/libnss_files-2.20-2014.11.so
b3da6000 b3daf000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3dc0000 b3dd1000 r-xp /lib/libnsl-2.20-2014.11.so
b3de4000 b3dea000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3dfb000 b3e15000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e26000 b3e27000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e37000 b3e39000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e4a000 b3e4f000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e5f000 b3e62000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e73000 b3e7a000 r-xp /usr/lib/libsensord-share.so
b3e8a000 b3e9b000 r-xp /usr/lib/libsensor.so.1.2.0
b3eac000 b3eb2000 r-xp /usr/lib/libappcore-common.so.1.1
b3ed5000 b3eda000 r-xp /usr/lib/libappcore-efl.so.1.1
b3ef0000 b3ef2000 r-xp /usr/lib/libXau.so.6.0.0
b3f02000 b3f16000 r-xp /usr/lib/libxcb.so.1.1.0
b3f26000 b3f2d000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f65000 b3f67000 r-xp /usr/lib/libiri.so
b3f78000 b3f8d000 r-xp /lib/libexpat.so.1.5.2
b3f9f000 b3fed000 r-xp /usr/lib/libssl.so.1.0.0
b4002000 b400b000 r-xp /usr/lib/libethumb.so.1.13.0
b401c000 b401f000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b402f000 b41e6000 r-xp /usr/lib/libcrypto.so.1.0.0
b577d000 b5786000 r-xp /usr/lib/libXi.so.6.1.0
b5797000 b5799000 r-xp /usr/lib/libXgesture.so.7.0.0
b57a9000 b57ad000 r-xp /usr/lib/libXtst.so.6.1.0
b57bd000 b57c3000 r-xp /usr/lib/libXrender.so.1.3.0
b57d3000 b57d9000 r-xp /usr/lib/libXrandr.so.2.2.0
b57e9000 b57eb000 r-xp /usr/lib/libXinerama.so.1.0.0
b57fb000 b57fe000 r-xp /usr/lib/libXfixes.so.3.1.0
b580f000 b581a000 r-xp /usr/lib/libXext.so.6.4.0
b582a000 b582c000 r-xp /usr/lib/libXdamage.so.1.1.0
b583c000 b583e000 r-xp /usr/lib/libXcomposite.so.1.0.0
b584e000 b5931000 r-xp /usr/lib/libX11.so.6.3.0
b5944000 b594b000 r-xp /usr/lib/libXcursor.so.1.0.2
b595c000 b5974000 r-xp /usr/lib/libudev.so.1.6.0
b5976000 b5979000 r-xp /lib/libattr.so.1.1.0
b5989000 b59a9000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59aa000 b59af000 r-xp /usr/lib/libffi.so.6.0.2
b59bf000 b59d7000 r-xp /lib/libz.so.1.2.8
b59e7000 b59e9000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59f9000 b5ace000 r-xp /usr/lib/libxml2.so.2.9.2
b5ae3000 b5b7e000 r-xp /usr/lib/libstdc++.so.6.0.20
b5b9a000 b5b9d000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bad000 b5bc7000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bd7000 b5be8000 r-xp /lib/libresolv-2.20-2014.11.so
b5bfc000 b5c13000 r-xp /usr/lib/liblzma.so.5.0.3
b5c23000 b5c25000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c35000 b5c3c000 r-xp /usr/lib/libembryo.so.1.13.0
b5c4c000 b5c64000 r-xp /usr/lib/libpng12.so.0.50.0
b5c75000 b5c98000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cb8000 b5cbe000 r-xp /lib/librt-2.20-2014.11.so
b5ccf000 b5ce3000 r-xp /usr/lib/libector.so.1.13.0
b5cf4000 b5d0c000 r-xp /usr/lib/liblua-5.1.so
b5d1d000 b5d74000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d88000 b5db0000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5dc1000 b5dd4000 r-xp /usr/lib/libfribidi.so.0.3.1
b5de5000 b5e1f000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e30000 b5e9b000 r-xp /lib/libm-2.20-2014.11.so
b5eac000 b5eb9000 r-xp /usr/lib/libeio.so.1.13.0
b5ec9000 b5ecb000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5edb000 b5ee0000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5ef0000 b5f07000 r-xp /usr/lib/libefreet.so.1.13.0
b5f19000 b5f39000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f49000 b5f69000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f6b000 b5f71000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f81000 b5f88000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f98000 b5fa6000 r-xp /usr/lib/libeo.so.1.13.0
b5fb6000 b5fc8000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fd9000 b5fde000 r-xp /usr/lib/libecore_file.so.1.13.0
b5fee000 b6006000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6017000 b6034000 r-xp /usr/lib/libeet.so.1.13.0
b604d000 b6095000 r-xp /usr/lib/libeina.so.1.13.0
b60a6000 b60b6000 r-xp /usr/lib/libefl.so.1.13.0
b60c7000 b61ac000 r-xp /usr/lib/libicuuc.so.51.1
b61c9000 b6309000 r-xp /usr/lib/libicui18n.so.51.1
b6320000 b6358000 r-xp /usr/lib/libecore_x.so.1.13.0
b636a000 b636d000 r-xp /lib/libcap.so.2.21
b637d000 b63a6000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63b7000 b63be000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63d0000 b6406000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6417000 b64ff000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6513000 b6589000 r-xp /usr/lib/libsqlite3.so.0.8.6
b659b000 b659e000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65ae000 b65b9000 r-xp /usr/lib/libvconf.so.0.2.45
b65c9000 b65cb000 r-xp /usr/lib/libvasum.so.0.3.1
b65db000 b65dd000 r-xp /usr/lib/libttrace.so.1.1
b65ed000 b65f0000 r-xp /usr/lib/libiniparser.so.0
b6600000 b6623000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6633000 b6638000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6649000 b6660000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6671000 b667e000 r-xp /usr/lib/libunwind.so.8.0.1
b66b4000 b67d8000 r-xp /lib/libc-2.20-2014.11.so
b67ed000 b6806000 r-xp /lib/libgcc_s-4.9.so.1
b6816000 b68f8000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6909000 b693d000 r-xp /usr/lib/libdbus-1.so.3.8.11
b694d000 b6987000 r-xp /usr/lib/libsystemd.so.0.4.0
b6989000 b6a09000 r-xp /usr/lib/libedje.so.1.13.0
b6a0c000 b6a2a000 r-xp /usr/lib/libecore.so.1.13.0
b6a4a000 b6bac000 r-xp /usr/lib/libevas.so.1.13.0
b6be3000 b6bf7000 r-xp /lib/libpthread-2.20-2014.11.so
b6c0b000 b6e2f000 r-xp /usr/lib/libelementary.so.1.13.0
b6e5d000 b6e61000 r-xp /usr/lib/libsmack.so.1.0.0
b6e71000 b6e77000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e88000 b6e8a000 r-xp /usr/lib/libdlog.so.0.0.0
b6e9a000 b6e9d000 r-xp /usr/lib/libbundle.so.0.1.22
b6ead000 b6eaf000 r-xp /lib/libdl-2.20-2014.11.so
b6ec0000 b6ed9000 r-xp /usr/lib/libaul.so.0.1.0
b6eeb000 b6eed000 r-xp /usr/lib/libappsvc.so.0.1.0
b6efe000 b6f02000 r-xp /usr/lib/libsys-assert.so
b6f13000 b6f33000 r-xp /lib/ld-2.20-2014.11.so
b6f44000 b6f4a000 r-xp /usr/bin/launchpad-loader
b7701000 b7ca3000 rw-p [heap]
bef9c000 befbd000 rwxp [stack]
bef9c000 befbd000 rwxp [stack]
End of Maps Information

Callstack Information (PID:1189)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6712128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb3337c2f) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3c2f
 2: (0xb30f5abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3078865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63dc5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb63e8f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb63eea8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb63eec81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaefe6cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaefe7459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6867157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6be8cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
/ Permission denied) retry(0) 
01-23 19:43:17.170+0900 E/VCONF   ( 1339): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
01-23 19:43:17.170+0900 E/VCONF   ( 1339): vconf.c: vconf_get_str(2887) > vconf_get_str(1339) : db/menu_widget/language error
01-23 19:43:17.170+0900 E/PKGMGR_INFO( 1339): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
01-23 19:43:17.170+0900 D/PKGMGR_INFO( 1339): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.origincamera/bin/origincamera' and package_app_info.app_disable IN ('false','False')
01-23 19:43:17.170+0900 D/PKGMGR_INFO( 1339): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'No Locale') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.origincamera/bin/origincamera' and package_app_info.app_disable IN ('false','False')
01-23 19:43:17.180+0900 E/VCONF   ( 1339): vconf.c: _vconf_check_retry_err(1368) > db/menu_widget/language : check retry err (-21/13).
01-23 19:43:17.180+0900 E/VCONF   ( 1339): vconf.c: _vconf_get_key_filesys(2371) > _vconf_get_key_filesys(db/menu_widget/language) step(-21) failed(13 / Permission denied) retry(0) 
01-23 19:43:17.180+0900 E/VCONF   ( 1339): vconf.c: _vconf_get_key(2407) > _vconf_get_key(db/menu_widget/language) step(-21) failed(13 / Permission denied)
01-23 19:43:17.180+0900 E/VCONF   ( 1339): vconf.c: vconf_get_str(2887) > vconf_get_str(1339) : db/menu_widget/language error
01-23 19:43:17.180+0900 E/PKGMGR_INFO( 1339): pkgmgrinfo_private.c: __convert_system_locale_to_manifest_locale(354) > syslocale is null
01-23 19:43:17.190+0900 D/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20008b 
01-23 19:43:17.190+0900 D/test-log(  937): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1194) >  Box[0] pick ended by Up
01-23 19:43:17.190+0900 D/test-log(  937): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1199) >  Cancel Long Tap Timer
01-23 19:43:17.190+0900 D/test-log(  937): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1240) >  app launch state[1]
01-23 19:43:17.190+0900 D/test-log(  937): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1249) >  touch is moved upper position!!!
01-23 19:43:17.190+0900 D/test-log(  937): mainmenu-box-impl.cpp: OnPickEventMenuBoxTouchEvent(1298) >  laundch!!!!! touch position is moved from[471.00][221.00] to[471.00][221.00]!
01-23 19:43:17.190+0900 D/cluster-view(  937): homescreen-view-manager.cpp: IsOverScrollThreshold(997) >  is Over Scrollview TreshHold?[0]
01-23 19:43:17.190+0900 D/cluster-home(  937): mainmenu-custom-box-impl.cpp: OnClicked(171) >  [15]MenuBox clicked
01-23 19:43:17.200+0900 D/cluster-home(  937): mainmenu-custom-box-impl.cpp: OnClicked(184) >  launch application via service(operation APP_CONTROL_OPERATION_DEFAULT)
01-23 19:43:17.200+0900 D/AUL     (  937): service.c: __set_bundle(186) > __set_bundle
01-23 19:43:17.200+0900 D/AUL     (  937): service.c: __get_alias_appid(548) > [SECURE_LOG] alias_id : (null)
01-23 19:43:17.200+0900 D/AUL     (  937): service.c: __set_bundle(186) > __set_bundle
01-23 19:43:17.200+0900 D/AUL     (  937): service.c: __run_svc_with_pkgname(276) > [SECURE_LOG] pkg_name : org.example.camera - no result
01-23 19:43:17.200+0900 D/AUL     (  937): launch.c: app_request_to_launchpad(396) > [SECURE_LOG] launch request : org.example.camera
01-23 19:43:17.200+0900 D/AUL     (  937): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(0)
01-23 19:43:17.200+0900 D/AUL_AMD (  827): amd_request.c: __request_handler(838) > __request_handler: 0
01-23 19:43:17.200+0900 D/AUL_AMD (  827): amd_request.c: __request_handler(882) > [SECURE_LOG] launch a single-instance appid: org.example.camera
01-23 19:43:17.200+0900 W/AUL_AMD (  827): amd_launch.c: _start_app(2230) > [SECURE_LOG] caller appid : org.tizen.homescreen
01-23 19:43:17.200+0900 W/AUL_AMD (  827): amd_launch.c: _start_app(2232) > caller pid : 937
01-23 19:43:17.200+0900 D/AUL_AMD (  827): amd_launch.c: _start_app(2442) > win(a00002) ecore_x_pointer_grab(1)
01-23 19:43:17.200+0900 D/AUL_AMD (  827): amd_key.c: _key_grab(243) > _key_grab, win : a00002
01-23 19:43:17.210+0900 D/AUL_AMD (  827): amd_launch.c: _start_app(2447) > back key grab
01-23 19:43:17.210+0900 D/RESOURCED(  873): proc-noti.c: process_message(173) > process message caller pid 827
01-23 19:43:17.210+0900 D/RESOURCED(  873): proc-main.c: resourced_proc_action(1043) > [SECURE_LOG] appid org.example.camera, pid 1189, status 5
01-23 19:43:17.210+0900 D/RESOURCED(  873): proc-main.c: resourced_proc_status_change(914) > [SECURE_LOG] resume request 1189
01-23 19:43:17.210+0900 D/RESOURCED(  873): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 1189, appname = org.example.camera
01-23 19:43:17.210+0900 D/RESOURCED(  873): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 1189
01-23 19:43:17.210+0900 D/RESOURCED(  873): proc-main.c: resourced_proc_status_change(934) > available memory = 594
01-23 19:43:17.210+0900 E/RESOURCED(  873): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 1189 foreground
01-23 19:43:17.210+0900 W/AUL_AMD (  827): amd_launch.c: __nofork_processing(1251) > __nofork_processing, cmd: 0, pid: 1189
01-23 19:43:17.210+0900 D/AUL_AMD (  827): amd_launch.c: __nofork_processing(1267) > fake launch pid : 1189
01-23 19:43:17.210+0900 D/AUL     (  827): app_sock.c: __app_send_raw_with_delay_reply(455) > pid(1189) : cmd(0)
01-23 19:43:17.210+0900 D/AUL_AMD (  827): amd_launch.c: __set_reply_handler(1014) > listen fd : 30, send fd : 29
01-23 19:43:17.210+0900 D/AUL_AMD (  827): amd_launch.c: __nofork_processing(1270) > fake launch done
01-23 19:43:17.210+0900 D/APP_CORE( 1189): appcore.c: __aul_handler(587) > [APP 1189]     AUL event: AUL_START
01-23 19:43:17.210+0900 I/APP_CORE( 1189): appcore-efl.c: __do_app(496) > [APP 1189] Event: RESET State: PAUSED
01-23 19:43:17.210+0900 D/APP_CORE( 1189): appcore-efl.c: __do_app(527) > [APP 1189] RESET
01-23 19:43:17.210+0900 D/LAUNCH  ( 1189): appcore-efl.c: __do_app(529) > [camera:Application:reset:start]
01-23 19:43:17.210+0900 D/APP_CORE( 1189): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
01-23 19:43:17.210+0900 D/APP_CORE( 1189): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-23 19:43:17.210+0900 I/CAPI_APPFW_APPLICATION( 1189): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
01-23 19:43:17.210+0900 D/LAUNCH  ( 1189): appcore-efl.c: __do_app(544) > [camera:Application:reset:done]
01-23 19:43:17.210+0900 I/APP_CORE( 1189): appcore-efl.c: __do_app(548) > Legacy lifecycle: 0
01-23 19:43:17.210+0900 I/APP_CORE( 1189): appcore-efl.c: __do_app(550) > [APP 1189] App already running, raise the window
01-23 19:43:17.210+0900 W/AUL_AMD (  827): amd_launch.c: __reply_handler(912) > listen fd(30) , send fd(29), pid(1189), cmd(0)
01-23 19:43:17.210+0900 D/AUL     (  937): launch.c: app_request_to_launchpad(425) > launch request result : 1189
01-23 19:43:17.210+0900 E/cluster-home(  937): mainmenu-custom-box-impl.cpp: OnClicked(202) >  Success to launch [0][org.example.camera]
01-23 19:43:17.210+0900 D/test-log(  937): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
01-23 19:43:17.220+0900 E/E17     (  532): e_manager.c: _e_manager_cb_client_message(1522) > ACTIVE REQUEST(0x04600003)
01-23 19:43:17.220+0900 D/APP_CORE( 1189): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : org.tizen.homescreen
01-23 19:43:17.220+0900 D/AUL_AMD (  827): amd_launch.c: __e17_status_handler(2887) > pid(1189) status(3)
01-23 19:43:17.220+0900 D/AUL_AMD (  827): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-23 19:43:17.220+0900 D/AUL_AMD (  827): amd_launch.c: __e17_status_handler(2893) > back key ungrab
01-23 19:43:17.220+0900 D/AUL_AMD (  827): amd_status.c: _status_update_app_info_list(456) > pid(1189) status(3)
01-23 19:43:17.220+0900 D/AUL_AMD (  827): amd_status.c: _status_update_app_info_list(468) > pid(1189) appid(org.example.camera) pkgid(org.example.camera) status(3)
01-23 19:43:17.220+0900 D/AUL     (  827): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.camera
01-23 19:43:17.220+0900 W/AUL     (  827): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 1189, appid: org.example.camera, status: fg
01-23 19:43:17.220+0900 D/RESOURCED(  873): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 1189
01-23 19:43:17.230+0900 D/RESOURCED(  873): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 1189, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-23 19:43:17.230+0900 D/RESOURCED(  873): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 1189
01-23 19:43:17.290+0900 D/APP_CORE( 1189): appcore.c: __prt_ltime(236) > [APP 1189] first idle after reset: 13159 msec
01-23 19:43:17.290+0900 D/RESOURCED(  873): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 1189, appname = org.example.camera, pkgname = org.example.camera
01-23 19:43:17.290+0900 D/RESOURCED(  873): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 1189, appname = org.example.camera
01-23 19:43:17.290+0900 D/RESOURCED(  873): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 1189
01-23 19:43:17.290+0900 I/MALI    ( 1189): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:43:17.290+0900 E/RESOURCED(  873): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 1189 foreground
01-23 19:43:17.340+0900 E/E17     (  532): e_border.c: e_border_show(2088) > BD_SHOW(0x04600003)
01-23 19:43:17.340+0900 W/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=1189
01-23 19:43:17.340+0900 D/INDICATOR(  910): main.c: _property_changed_cb(432) > UNSNIFF API 2200002
01-23 19:43:17.340+0900 D/INDICATOR(  910): util.c: util_signal_emit_by_win(116) > emission bg.opaque
01-23 19:43:17.340+0900 D/INDICATOR(  910): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-23 19:43:17.340+0900 D/INDICATOR(  910): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-23 19:43:17.340+0900 D/INDICATOR(  910): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-23 19:43:17.340+0900 D/INDICATOR(  910): main.c: _rotate_window(252) > port :: hide more icon
01-23 19:43:17.350+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11cf3d8), gem(22), surface(0x11dfa38)
01-23 19:43:17.350+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x11c62b0), gem(21), surface(0x126fcf0)
01-23 19:43:17.350+0900 E/EFL     (  532): eo<532> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-23 19:43:17.360+0900 E/EFL     (  532): eo<532> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-23 19:43:17.370+0900 E/E17     (  532): e_border.c: e_border_hide(2248) > BD_HIDE(0x02200002), visible:1
01-23 19:43:17.370+0900 D/APP_CORE(  937): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2200002 fully_obscured 1
01-23 19:43:17.370+0900 D/APP_CORE(  937): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
01-23 19:43:17.370+0900 D/APP_CORE(  937): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
01-23 19:43:17.370+0900 I/APP_CORE(  937): appcore-efl.c: __do_app(496) > [APP 937] Event: PAUSE State: RUNNING
01-23 19:43:17.370+0900 D/APP_CORE(  937): appcore-efl.c: __do_app(565) > [APP 937] PAUSE
01-23 19:43:17.370+0900 I/CAPI_APPFW_APPLICATION(  937): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
01-23 19:43:17.370+0900 E/cluster-home(  937): homescreen.cpp: OnPause(84) >  app pause
01-23 19:43:17.370+0900 D/cluster-view(  937): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
01-23 19:43:17.370+0900 D/cluster-view(  937): homescreen-view-manager.cpp: AppPause(923) >  END
01-23 19:43:17.370+0900 D/APP_CORE(  937): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-23 19:43:17.370+0900 E/APP_CORE(  937): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-23 19:43:17.370+0900 D/AUL_AMD (  827): amd_status.c: _status_update_app_info_list(456) > pid(937) status(4)
01-23 19:43:17.370+0900 D/AUL_AMD (  827): amd_status.c: _status_update_app_info_list(468) > pid(937) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
01-23 19:43:17.370+0900 D/AUL     (  827): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
01-23 19:43:17.370+0900 W/AUL     (  827): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 937, appid: org.tizen.homescreen, status: bg
01-23 19:43:17.380+0900 D/DATA_PROVIDER_MASTER(  999): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 937 is paused
01-23 19:43:17.380+0900 D/DATA_PROVIDER_MASTER(  999): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
01-23 19:43:17.380+0900 I/CAPI_WIDGET_APPLICATION(  985): widget_app.c: __provider_pause_cb(292) > widget obj was paused
01-23 19:43:17.380+0900 I/CAPI_WIDGET_APPLICATION(  985): widget_app.c: __check_status_for_cgroup(142) > enter background group
01-23 19:43:17.380+0900 W/AUL     (  985): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 985, appid: org.tizen.calendar.widget, status: bg
01-23 19:43:17.380+0900 D/AUL_AMD (  827): amd_request.c: __request_handler(838) > __request_handler: 15
01-23 19:43:17.380+0900 D/PKGMGR_INFO(  827): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-23 19:43:17.380+0900 D/PKGMGR_INFO(  827): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-23 19:43:17.390+0900 D/RESOURCED(  873): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 985, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
01-23 19:43:17.390+0900 D/RESOURCED(  873): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 985
01-23 19:43:17.390+0900 D/AUL_AMD (  827): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 1189 is org.example.camera
01-23 19:43:17.390+0900 D/AUL_AMD (  827): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 1189 : 0
01-23 19:43:17.390+0900 D/AUL     ( 1022): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4600003 fully_obscured 0
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
01-23 19:43:17.410+0900 I/APP_CORE( 1189): appcore-efl.c: __do_app(496) > [APP 1189] Event: RESUME State: PAUSED
01-23 19:43:17.410+0900 D/LAUNCH  ( 1189): appcore-efl.c: __do_app(597) > [camera:Application:resume:start]
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __do_app(607) > [APP 1189] RESUME
01-23 19:43:17.410+0900 I/CAPI_APPFW_APPLICATION( 1189): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-23 19:43:17.410+0900 D/LAUNCH  ( 1189): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-23 19:43:17.410+0900 D/LAUNCH  ( 1189): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-23 19:43:17.410+0900 D/APP_CORE( 1189): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-23 19:43:17.410+0900 E/APP_CORE( 1189): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-23 19:43:17.500+0900 D/RESOURCED(  873): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 985, appname = org.tizen.calendar.widget
01-23 19:43:17.500+0900 D/RESOURCED(  873): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 985
01-23 19:43:17.550+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x11d4858), gem(20), surface(0x1276ec0)
01-23 19:43:17.560+0900 D/AUL_AMD (  827): amd_launch.c: __e17_status_handler(2906) > pid(1189) status(0)
01-23 19:43:17.690+0900 E/RESOURCED(  873): heart-abnormal.c: heart_abnormal_process_crashed(77) > Failed: dbus_message_get_args()
01-23 19:43:18.221+0900 I/MALI    (  532): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0x11ce218), gem(21), surface(0x1276ec0)
01-23 19:43:18.311+0900 D/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200491 
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): tunnig_param=263480
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): param_num=3
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): cur target lum=62, ev diff=0, level=4
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): AE VERSION : 0x20150828-00
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): cvg speed=0
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): target lum=62, target lum zone=8
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): lime time=134, min line=1
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): cvgn_param[0] error!!!  set default cvgn_param
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): target_lum_ev0=62
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): highcount=19,lowcount=15
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): FDAE: failed open fdae_param.txt
01-23 19:43:18.541+0900 I/ISP_AE  ( 1189): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-23 19:43:18.541+0900 D/alPrinter0( 1189): LSC Size:20 16
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [LSC]TableSize=   320
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [LSC]TableSize=   320
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [LSC]TableSize=   320
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [OTP]module has otp data 0xb0d17b5c (nil) 20 16
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [LSC]TableSize=   320
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [LSC]TableSize=   320
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-23 19:43:18.541+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): work_mode=0 last mode=0
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): cvg speed=0
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): target lum=62, target lum zone=8
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): lime time=134, min line=1
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): target_lum_ev0=62
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): highcount=19,lowcount=15
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): is_quick=0
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): AE_TEST:-----------SET index:282
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): AE_TEST: get index:282, exp:300000, line:2238
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): AE_TEST:-----------SET index:282
01-23 19:43:18.671+0900 I/ISP_AE  ( 1189): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-23 19:43:18.681+0900 I/ISP_AE  ( 1189): calc_iso=50,real_gain=19,iso=0
01-23 19:43:18.701+0900 D/AUL_AMD (  827): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.camera /opt/usr/apps/org.example.camera/bin/camera
01-23 19:43:18.701+0900 D/RUA     (  827): rua.c: rua_add_history(179) > rua_add_history start
01-23 19:43:18.711+0900 D/RUA     (  827): rua.c: rua_add_history(247) > rua_add_history ok
01-23 19:43:18.952+0900 I/ISP_AE  ( 1189): set_weight, table[0] = 1
01-23 19:43:18.952+0900 I/ISP_AE  ( 1189): set weight from 1 to 0, rtn=0
01-23 19:43:18.952+0900 I/ISP_AE  ( 1189): AE_TEST ----------------------change to fast
01-23 19:43:18.952+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:282, cur_lum:1, next_index:332, target_lum:62
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,7c,a7,00,00,00,00
01-23 19:43:18.952+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,7c,a7,00,00,00,00
01-23 19:43:18.952+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LineAdj] Mode -2147483647
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LineAdj]Tar RGB 557,733,473
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LineAdj]Ref RGB 557,750,487
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LED]LPF Disable
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.04, detect:   0.35,   0.38 CTemp:4878.4
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [CHROMA]START BV=0.427002 Ratio=1.000000
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [HSC]Mix=00000000,Csd=000068f4 ,(BV= 0.427,x=0.355,y=0.385)
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=0.427010 ,Awb Bv=0.427002 in/out_0
01-23 19:43:18.952+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.287186,GGain=1.000000,BGain=1.613815,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-23 19:43:19.072+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:332, cur_lum:7, next_index:376, target_lum:62
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.072+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.072+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [LED]LPF Disable
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.50, detect:   0.35,   0.38 CTemp:4904.5
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [HSC]Mix=00000a3d,Csd=0005bfdc ,(BV=-0.988,x=0.353,y=0.380)
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:4, 0x00000a3d,0x00000a3d
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-0.988028 ,Awb Bv=-0.988022 in/out_0
01-23 19:43:19.072+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.263733,GGain=1.000000,BGain=1.568680,Dtct=0.352844,0.380386 ,Curr=0.352844,0.380386 ,CTmep: QC=5067, AL= 4819
01-23 19:43:19.122+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0b28), gem(42), surface(0xb7931388)
01-23 19:43:19.122+0900 E/EFL     ( 1189): evas_main<1189> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-23 19:43:19.162+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:376, cur_lum:21, next_index:408, target_lum:62
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.162+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.162+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [LED]LPF Disable
01-23 19:43:19.162+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.172+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.74, detect:   0.34,   0.37 CTemp:5140.6
01-23 19:43:19.172+0900 D/alPrinter0( 1189): [HSC]Mix=000028f5,Csd=0005a923 ,(BV=-1.988,x=0.350,y=0.378)
01-23 19:43:19.172+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:3, 0x000028f5,0x000028f5
01-23 19:43:19.172+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-1.988028 ,Awb Bv=-1.988022 in/out_0
01-23 19:43:19.172+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.271194,GGain=1.000000,BGain=1.544586,Dtct=0.349762,0.378281 ,Curr=0.349762,0.378281 ,CTmep: QC=5183, AL= 4911
01-23 19:43:19.202+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(43), surface(0xb7bc9d60)
01-23 19:43:19.252+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(42), surface(0xb7931388)
01-23 19:43:19.282+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:408, cur_lum:45, next_index:413, target_lum:62
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.282+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.282+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [LED]LPF Enable
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.89, detect:   0.34,   0.37 CTemp:5117.6
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [HSC]Mix=000047ad,Csd=00057255 ,(BV=-1.991,x=0.351,y=0.380)
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:4, 0x000047ad,0x000047ad
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.157952 ,Awb Bv=-1.991379 in/out_0
01-23 19:43:19.282+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.271271,GGain=1.000000,BGain=1.544876,Dtct=0.350723,0.379944 ,Curr=0.349777,0.378311 ,CTmep: QC=5183, AL= 4911
01-23 19:43:19.302+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(43), surface(0xb7931588)
01-23 19:43:19.312+0900 D/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x4600003
01-23 19:43:19.352+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(42), surface(0xb7931388)
01-23 19:43:19.402+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:413, cur_lum:51, next_index:414, target_lum:62
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.402+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.402+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.91, detect:   0.34,   0.37 CTemp:5087.1
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [HSC]Mix=00006665,Csd=00047bc8 ,(BV=-2.004,x=0.351,y=0.379)
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:3, 0x00006665,0x00006665
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.189662 ,Awb Bv=-2.004150 in/out_0
01-23 19:43:19.402+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.271378,GGain=1.000000,BGain=1.545715,Dtct=0.351105,0.379272 ,Curr=0.349838,0.378403 ,CTmep: QC=5183, AL= 4911
01-23 19:43:19.432+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a71a0), gem(43), surface(0xb7931588)
01-23 19:43:19.482+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(42), surface(0xb7931388)
01-23 19:43:19.522+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:414, cur_lum:51, next_index:415, target_lum:62
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.522+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.522+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.91, detect:   0.35,   0.37 CTemp:5029.9
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [HSC]Mix=0000851d,Csd=0004063f ,(BV=-2.027,x=0.352,y=0.379)
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:4, 0x0000851d,0x0000851d
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.220689 ,Awb Bv=-2.027191 in/out_0
01-23 19:43:19.522+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.270828,GGain=1.000000,BGain=1.547104,Dtct=0.351669,0.378693 ,Curr=0.350006,0.378540 ,CTmep: QC=5181, AL= 4909
01-23 19:43:19.532+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(43), surface(0xb7931588)
01-23 19:43:19.602+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(42), surface(0xb7931388)
01-23 19:43:19.642+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:415, cur_lum:52, next_index:416, target_lum:62
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.642+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.642+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.642+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.652+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.91, detect:   0.35,   0.37 CTemp:4975.3
01-23 19:43:19.652+0900 D/alPrinter0( 1189): [HSC]Mix=0000a3d5,Csd=00034062 ,(BV=-2.057,x=0.353,y=0.378)
01-23 19:43:19.652+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:3, 0x0000a3d5,0x0000a3d5
01-23 19:43:19.652+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.251062 ,Awb Bv=-2.057465 in/out_0
01-23 19:43:19.652+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.269409,GGain=1.000000,BGain=1.548096,Dtct=0.352676,0.378448 ,Curr=0.350220,0.378632 ,CTmep: QC=5179, AL= 4908
01-23 19:43:19.652+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a71a0), gem(43), surface(0xb7931588)
01-23 19:43:19.712+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(42), surface(0xb7931388)
01-23 19:43:19.762+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:416, cur_lum:53, next_index:417, target_lum:62
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.762+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.762+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.91, detect:   0.35,   0.37 CTemp:4938.4
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [HSC]Mix=0000c28d,Csd=00029a85 ,(BV=-2.092,x=0.353,y=0.378)
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:4, 0x0000c28d,0x0000c28d
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.280809 ,Awb Bv=-2.092392 in/out_0
01-23 19:43:19.762+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.266525,GGain=1.000000,BGain=1.548859,Dtct=0.353439,0.378189 ,Curr=0.350555,0.378677 ,CTmep: QC=5177, AL= 4906
01-23 19:43:19.792+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(43), surface(0xb7c3e2c8)
01-23 19:43:19.822+0900 D/PROCESSMGR(  532): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200491 
01-23 19:43:19.853+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(42), surface(0xb7c3e2c8)
01-23 19:43:19.883+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:417, cur_lum:55, next_index:418, target_lum:62
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:19.883+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:19.883+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.92, detect:   0.35,   0.37 CTemp:4904.7
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [HSC]Mix=0000e145,Csd=0000c86a ,(BV=-2.130,x=0.354,y=0.377)
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:3, 0x0000e145,0x0000e145
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.309956 ,Awb Bv=-2.129883 in/out_0
01-23 19:43:19.883+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.261871,GGain=1.000000,BGain=1.548843,Dtct=0.354126,0.377197 ,Curr=0.350998,0.378632 ,CTmep: QC=5174, AL= 4904
01-23 19:43:19.913+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(43), surface(0xb7c7de70)
01-23 19:43:19.963+0900 I/MALI    ( 1189): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:43:19.963+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(42), surface(0xb7bc1608)
01-23 19:43:19.973+0900 I/MALI    ( 1189): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:43:19.983+0900 I/MALI    ( 1189): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-23 19:43:20.003+0900 I/ISP_AE  ( 1189): AE_TEST:----cur_index:418, cur_lum:56, next_index:419, target_lum:62
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-23 19:43:20.003+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-23 19:43:20.003+0900 D/awb_al_cmd0( 1189): [alAisCmd_SetColorLock] muiAwblc:0 
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [AIS_WRAP]msiFlash_state=0
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [LOCK]0
01-23 19:43:20.003+0900 D/alPrinter0( 1189): [SuperHighCTemp] Mapin:  0.92, detect:   0.35,   0.37 CTemp:4873.1
01-23 19:43:20.013+0900 D/alPrinter0( 1189): [HSC]Mix=0000f478,Csd=00016e57 ,(BV=-2.168,x=0.355,y=0.377)
01-23 19:43:20.013+0900 D/alPrinter0( 1189): [AlHscWrap_Main]:4, 0x0000f478,0x0000f478
01-23 19:43:20.013+0900 D/alPrinter0( 1189): [AIS_WRAP]In BV=-2.338525 ,Awb Bv=-2.168350 in/out_0
01-23 19:43:20.013+0900 D/alPrinter0( 1189): [AIS_WRAP]RGain=1.256042,GGain=1.000000,BGain=1.548447,Dtct=0.354721,0.377182 ,Curr=0.351517,0.378525 ,CTmep: QC=5169, AL= 4900
01-23 19:43:20.013+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(43), surface(0xb78e0138)
01-23 19:43:20.093+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(42), surface(0xb7931588)
01-23 19:43:20.113+0900 I/ISP_AE  ( 1189): ae_state=3
01-23 19:43:20.143+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(43), surface(0xb78e0138)
01-23 19:43:20.203+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(42), surface(0xb7bc1608)
01-23 19:43:20.263+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(43), surface(0xb78e0138)
01-23 19:43:20.323+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a6fd0), gem(42), surface(0xb78e0138)
01-23 19:43:20.373+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79a71a0), gem(43), surface(0xb7c3e2c8)
01-23 19:43:20.443+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:20.493+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(43), surface(0xb78e0138)
01-23 19:43:20.513+0900 I/ISP_AE  ( 1189): FDAE: ->disable, frame_idx=30
01-23 19:43:20.573+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:20.623+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(43), surface(0xb78e0138)
01-23 19:43:20.673+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:20.743+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(43), surface(0xb78e0138)
01-23 19:43:20.803+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:20.854+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(43), surface(0xb78e0138)
01-23 19:43:20.924+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:20.974+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(43), surface(0xb78e0138)
01-23 19:43:21.054+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:21.104+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb772c218), gem(43), surface(0xb78e0138)
01-23 19:43:21.154+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:21.224+0900 I/ISP_AE  ( 1189): calc_iso=630,real_gain=204,iso=0
01-23 19:43:21.224+0900 I/ISP_AE  ( 1189): calc_iso=630,real_gain=204,iso=0
01-23 19:43:21.234+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aacd28), gem(43), surface(0xb78e0138)
01-23 19:43:21.454+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aad468), gem(42), surface(0xb78e0138)
01-23 19:43:21.484+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(43), surface(0xb78e0138)
01-23 19:43:21.534+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aacd28), gem(42), surface(0xb78e0138)
01-23 19:43:21.584+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aad468), gem(43), surface(0xb78e0138)
01-23 19:43:21.634+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c7c9c0), gem(42), surface(0xb78e0138)
01-23 19:43:21.634+0900 D/camera  ( 1189): Writing image to file.
01-23 19:43:21.714+0900 I/MALI    ( 1189): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7aacd28), gem(43), surface(0xb78e0138)
01-23 19:43:21.734+0900 W/CRASH_MANAGER( 1339): worker.c: worker_job(1204) > 110118963616d142200980
