S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2820
Date: 2015-01-22 21:36:00+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = (nil)

Register Information
r0   = 0x93572008, r1   = 0x00000001
r2   = 0x001d3362, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x001d3362
r6   = 0x001d3362, r7   = 0xae131578
r8   = 0xb777f030, r9   = 0xae131724
r10  = 0xb7784d90, fp   = 0x0000000d
ip   = 0xb69dd110, sp   = 0xae1314e0
lr   = 0xb6fc6d13, pc   = 0xb69dd128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    426960 KB
Buffers:     18364 KB
Cached:     128984 KB
VmPeak:     591752 KB
VmSize:     591748 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       46328 KB
VmRSS:       46328 KB
VmData:     413840 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       30868 KB
VmPTE:         286 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 2820 TID = 2831
2820 2822 2823 2825 2826 2827 2829 2830 2831 2832 2833 2834 2835 2836 2837 2838 2841 2842 2843 2844 2845 2846 2847 2848 2849 2850 2851 2852 2853 2854 2855 2856 2857 2858 2859 2860 2861 2862 2863 2864 2865 2867 2868 2869 2871 2872 2875 

Maps Information
93bb1000 943b0000 rwxp [stack:2872]
943b1000 94bb0000 rwxp [stack:2871]
94bb1000 953b0000 rwxp [stack:2875]
99201000 99a00000 rwxp [stack:2869]
99a01000 9a200000 rwxp [stack:2868]
9c2ba000 9cab9000 rwxp [stack:2867]
9cb51000 9d350000 rwxp [stack:2865]
9d351000 9db50000 rwxp [stack:2864]
9db51000 9e350000 rwxp [stack:2863]
9e95f000 9f15e000 rwxp [stack:2862]
9f15f000 9f95e000 rwxp [stack:2861]
9f95f000 a015e000 rwxp [stack:2860]
a015f000 a095e000 rwxp [stack:2859]
a095f000 a115e000 rwxp [stack:2858]
a115f000 a195e000 rwxp [stack:2857]
a195f000 a215e000 rwxp [stack:2856]
a215f000 a295e000 rwxp [stack:2855]
a295f000 a315e000 rwxp [stack:2854]
a315f000 a395e000 rwxp [stack:2853]
a3c01000 a4400000 rwxp [stack:2852]
a4401000 a4c00000 rwxp [stack:2851]
a4e01000 a5600000 rwxp [stack:2850]
a5601000 a5e00000 rwxp [stack:2849]
a5e01000 a6600000 rwxp [stack:2848]
a6601000 a6e00000 rwxp [stack:2847]
a6e01000 a7600000 rwxp [stack:2845]
a7601000 a7e00000 rwxp [stack:2846]
a7e01000 a8600000 rwxp [stack:2844]
a8601000 a8e00000 rwxp [stack:2843]
a8e01000 a9600000 rwxp [stack:2842]
a9601000 a9e00000 rwxp [stack:2841]
a9e01000 aa600000 rwxp [stack:2838]
aa601000 aae00000 rwxp [stack:2837]
aae01000 ab600000 rwxp [stack:2836]
ab601000 abe00000 rwxp [stack:2835]
abe01000 ac600000 rwxp [stack:2834]
ac601000 ace00000 rwxp [stack:2833]
ad001000 ad800000 rwxp [stack:2832]
ad934000 ae133000 rwxp [stack:2831]
ae133000 ae136000 r-xp /usr/lib/libXv.so.1.0.0
ae146000 ae158000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae169000 ae1a0000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae1b2000 ae9b1000 rwxp [stack:2830]
ae9b1000 ae9ce000 r-xp /usr/lib/libAl_Awb_Sp.so
ae9d7000 ae9da000 r-xp /usr/lib/libdeflicker.so
ae9f2000 aea08000 r-xp /usr/lib/libAl_Awb.so
aea10000 aea1a000 r-xp /usr/lib/libcalibration.so
aea23000 aea35000 r-xp /usr/lib/libaf_lib.so
aea3d000 aea43000 r-xp /usr/lib/libspaf.so
aea4b000 aea51000 r-xp /usr/lib/liblsc.so
aea5a000 aea66000 r-xp /usr/lib/libae.so
aea6e000 aeaaf000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
aeaf6000 aebd5000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
af032000 af06e000 r-xp /usr/lib/libcamerahal.so.0.0.0
af209000 af20a000 r-xp /usr/lib/libcamerahdr.so.0.0.0
af252000 afa51000 rwxp [stack:2829]
afa5c000 afa74000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0601000 b0e00000 rwxp [stack:2827]
b0fd5000 b17d4000 rwxp [stack:2826]
b17d5000 b1fd4000 rwxp [stack:2825]
b1fd4000 b1fd9000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2065000 b206d000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b207e000 b207f000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b208f000 b2096000 r-xp /usr/lib/libfeedback.so.0.1.4
b20ba000 b20bb000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b20cb000 b20de000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2239000 b223e000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b224f000 b2a4e000 rwxp [stack:2823]
b2a4e000 b2ba9000 r-xp /usr/lib/egl/libMali.so
b2bbe000 b2c47000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2c60000 b2d2e000 r-xp /usr/lib/libCOREGL.so.4.0
b2d49000 b2d4c000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2d5c000 b2d69000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2d7a000 b2d84000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2d94000 b2da0000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2db1000 b2dba000 r-xp /lib/libnss_files-2.20-2014.11.so
b2dcb000 b2dd4000 r-xp /lib/libnss_nis-2.20-2014.11.so
b2de5000 b2df6000 r-xp /lib/libnsl-2.20-2014.11.so
b2e09000 b2e0f000 r-xp /lib/libnss_compat-2.20-2014.11.so
b2e20000 b2e24000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b2e35000 b2f15000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b2f37000 b2f5e000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b2f71000 b3770000 rwxp [stack:2822]
b3770000 b3772000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3989000 b398d000 r-xp /usr/lib/libogg.so.0.7.1
b399d000 b39bf000 r-xp /usr/lib/libvorbis.so.0.4.3
b39cf000 b3ab3000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b3acf000 b3b12000 r-xp /usr/lib/libsndfile.so.1.0.25
b3b28000 b3b6f000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b3b80000 b3b87000 r-xp /usr/lib/libjson-c.so.2.0.1
b3b97000 b3b99000 r-xp /usr/lib/libXau.so.6.0.0
b3baa000 b3bdf000 r-xp /usr/lib/libpulse.so.0.16.2
b3bf0000 b3bf3000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b3c04000 b3c07000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b3c18000 b3c5b000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b3c6d000 b3c72000 r-xp /usr/lib/libffi.so.6.0.2
b3c82000 b3d57000 r-xp /usr/lib/libxml2.so.2.9.2
b3d6c000 b3d73000 r-xp /usr/lib/libsensord-share.so
b3d83000 b3d86000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b3d97000 b3db1000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b3dc1000 b3ddb000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3dec000 b3e01000 r-xp /lib/libexpat.so.1.5.2
b3e13000 b3e61000 r-xp /usr/lib/libssl.so.1.0.0
b3e77000 b3e80000 r-xp /usr/lib/libethumb.so.1.13.0
b3e90000 b3e93000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b3ea3000 b3ebb000 r-xp /lib/libz.so.1.2.8
b3ecb000 b4082000 r-xp /usr/lib/libcrypto.so.1.0.0
b561a000 b56b5000 r-xp /usr/lib/libstdc++.so.6.0.20
b56d1000 b56da000 r-xp /usr/lib/libXi.so.6.1.0
b56ea000 b56ec000 r-xp /usr/lib/libXgesture.so.7.0.0
b56fc000 b5700000 r-xp /usr/lib/libXtst.so.6.1.0
b5710000 b5716000 r-xp /usr/lib/libXrender.so.1.3.0
b5726000 b572c000 r-xp /usr/lib/libXrandr.so.2.2.0
b573d000 b573f000 r-xp /usr/lib/libXinerama.so.1.0.0
b574f000 b5752000 r-xp /usr/lib/libXfixes.so.3.1.0
b5762000 b576d000 r-xp /usr/lib/libXext.so.6.4.0
b577d000 b577f000 r-xp /usr/lib/libXdamage.so.1.1.0
b578f000 b5791000 r-xp /usr/lib/libXcomposite.so.1.0.0
b57a2000 b57a9000 r-xp /usr/lib/libXcursor.so.1.0.2
b57b9000 b57d1000 r-xp /usr/lib/libudev.so.1.6.0
b57d3000 b57e7000 r-xp /usr/lib/libxcb.so.1.1.0
b57f7000 b57f9000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5809000 b5810000 r-xp /usr/lib/libembryo.so.1.13.0
b5821000 b5832000 r-xp /lib/libresolv-2.20-2014.11.so
b5846000 b585d000 r-xp /usr/lib/liblzma.so.5.0.3
b586d000 b5875000 r-xp /usr/lib/libdrm.so.2.4.0
b5885000 b5887000 r-xp /usr/lib/libdri2.so.0.0.0
b5897000 b5899000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b58aa000 b58b1000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b58c1000 b58cc000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b58e0000 b58e6000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b58f7000 b58ff000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b5910000 b5915000 r-xp /usr/lib/libmmfsession.so.0.0.0
b5926000 b593d000 r-xp /usr/lib/libmmfsound.so.0.1.0
b594d000 b596d000 r-xp /usr/lib/libexif.so.12.3.3
b5979000 b5981000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b5991000 b59c0000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b59d3000 b5a09000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b5a1b000 b5b03000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b5b17000 b5b8d000 r-xp /usr/lib/libsqlite3.so.0.8.6
b5b9f000 b5ba2000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5bb2000 b5bb4000 r-xp /usr/lib/libvasum.so.0.3.1
b5bc4000 b5bc7000 r-xp /usr/lib/libiniparser.so.0
b5bd7000 b5bdb000 r-xp /usr/lib/libsmack.so.1.0.0
b5beb000 b5bf0000 r-xp /usr/lib/libxdgmime.so.1.1.0
b5c01000 b5c18000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5c29000 b5c3a000 r-xp /usr/lib/libsensor.so.1.2.0
b5c4b000 b5c7f000 r-xp /usr/lib/libdbus-1.so.3.8.11
b5c8f000 b5c91000 r-xp /usr/lib/libttrace.so.1.1
b5ca1000 b5cc4000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b5cd4000 b5cd7000 r-xp /usr/lib/libbundle.so.0.1.22
b5ce7000 b5ce8000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b5cf8000 b5cfa000 r-xp /usr/lib/libappsvc.so.0.1.0
b5d0a000 b5d22000 r-xp /usr/lib/libpng12.so.0.50.0
b5d33000 b5d56000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d76000 b5d8a000 r-xp /usr/lib/libector.so.1.13.0
b5d9b000 b5db3000 r-xp /usr/lib/liblua-5.1.so
b5dc4000 b5e1b000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e2f000 b5e57000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e68000 b5e7b000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e8c000 b5ec6000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ed7000 b5ee4000 r-xp /usr/lib/libeio.so.1.13.0
b5ef4000 b5ef6000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f06000 b5f0b000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f1b000 b5f32000 r-xp /usr/lib/libefreet.so.1.13.0
b5f44000 b5f64000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f74000 b5f94000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f96000 b5f9c000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fac000 b5fb3000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fc3000 b5fd5000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fe6000 b5feb000 r-xp /usr/lib/libecore_file.so.1.13.0
b5ffb000 b6013000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6024000 b6041000 r-xp /usr/lib/libeet.so.1.13.0
b605a000 b613f000 r-xp /usr/lib/libicuuc.so.51.1
b615c000 b629c000 r-xp /usr/lib/libicui18n.so.51.1
b62b3000 b62eb000 r-xp /usr/lib/libecore_x.so.1.13.0
b62fd000 b63e0000 r-xp /usr/lib/libX11.so.6.3.0
b63f3000 b6473000 r-xp /usr/lib/libedje.so.1.13.0
b6476000 b64e1000 r-xp /lib/libm-2.20-2014.11.so
b64f2000 b64f8000 r-xp /lib/librt-2.20-2014.11.so
b6509000 b6543000 r-xp /usr/lib/libsystemd.so.0.4.0
b6545000 b6553000 r-xp /usr/lib/libeo.so.1.13.0
b6563000 b6573000 r-xp /usr/lib/libefl.so.1.13.0
b6584000 b6666000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6677000 b6682000 r-xp /usr/lib/libvconf.so.0.2.45
b6692000 b669a000 r-xp /usr/lib/libtbm.so.1.0.0
b66aa000 b6763000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b6777000 b677e000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b678e000 b67ec000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b6801000 b6849000 r-xp /usr/lib/libeina.so.1.13.0
b685a000 b6873000 r-xp /usr/lib/libaul.so.0.1.0
b6885000 b688b000 r-xp /usr/lib/libappcore-common.so.1.1
b689b000 b68a0000 r-xp /usr/lib/libappcore-efl.so.1.1
b68b0000 b68b2000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b68c3000 b68c8000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b68d8000 b68da000 r-xp /lib/libdl-2.20-2014.11.so
b68eb000 b68f8000 r-xp /usr/lib/libunwind.so.8.0.1
b692e000 b6942000 r-xp /lib/libpthread-2.20-2014.11.so
b6956000 b696f000 r-xp /lib/libgcc_s-4.9.so.1
b697f000 b6aa3000 r-xp /lib/libc-2.20-2014.11.so
b6ab8000 b6abc000 r-xp /usr/lib/libstorage.so.0.1
b6acc000 b6c2e000 r-xp /usr/lib/libevas.so.1.13.0
b6c65000 b6e89000 r-xp /usr/lib/libelementary.so.1.13.0
b6eb7000 b6ebe000 r-xp /usr/lib/libefl-extension.so.0.1.0
b6ece000 b6eec000 r-xp /usr/lib/libecore.so.1.13.0
b6f0c000 b6f0e000 r-xp /usr/lib/libdlog.so.0.0.0
b6f1e000 b6f2d000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b6f3d000 b6f44000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6f56000 b6f59000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b6f7d000 b6f81000 r-xp /usr/lib/libsys-assert.so
b6f92000 b6fb2000 r-xp /lib/ld-2.20-2014.11.so
b6fc3000 b6fc8000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b74d4000 b7b24000 rw-p [heap]
bea08000 bea29000 rwxp [stack]
bea08000 bea29000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2820)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb69dd128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb6fc6d13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb6f22abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb67b3865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb59df5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb59ebf67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb59f1a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb59f1c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xafa66cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xafa67459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb65d5157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6933cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
0): [AIS_WRAP]msiFlash_state=0
01-22 21:35:58.922+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:58.922+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.87, detect:   0.34,   0.36 CTemp:5380.3
01-22 21:35:58.922+0900 D/alPrinter0( 2820): [HSC]Mix=0000d850,Csd=00001618 ,(BV=-0.303,x=0.331,y=0.356)
01-22 21:35:58.922+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:4, 0x0000d850,0x0000d850
01-22 21:35:58.922+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.309955 ,Awb Bv=-0.303345 in/out_0
01-22 21:35:58.922+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.275833,GGain=1.000000,BGain=1.326721,Dtct=0.331329,0.356369 ,Curr=0.330597,0.355804 ,CTmep: QC=5971, AL= 5568
01-22 21:35:58.952+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb799e9c8), gem(44), surface(0xb79d57a0)
01-22 21:35:58.972+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:354, cur_lum:60, next_index:354, target_lum:62
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:58.972+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:58.972+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5338.8
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [HSC]Mix=0000d850,Csd=ffff787a ,(BV=-0.308,x=0.332,y=0.356)
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:3, 0x0000d850,0x0000d850
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.309955 ,Awb Bv=-0.307861 in/out_0
01-22 21:35:58.972+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.276855,GGain=1.000000,BGain=1.328140,Dtct=0.331848,0.355698 ,Curr=0.330643,0.355988 ,CTmep: QC=5972, AL= 5569
01-22 21:35:58.992+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79cbbc0), gem(47), surface(0xb786e528)
01-22 21:35:59.022+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:354, cur_lum:61, next_index:354, target_lum:62
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.022+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.022+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5335.2
01-22 21:35:59.022+0900 D/alPrinter0( 2820): [HSC]Mix=0000ce13,Csd=ffff31e8 ,(BV=-0.311,x=0.332,y=0.355)
01-22 21:35:59.032+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20106c 
01-22 21:35:59.032+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:4, 0x0000ce13,0x0000ce13
01-22 21:35:59.032+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.309955 ,Awb Bv=-0.310928 in/out_0
01-22 21:35:59.032+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.276871,GGain=1.000000,BGain=1.328140,Dtct=0.331635,0.355484 ,Curr=0.330643,0.355988 ,CTmep: QC=5972, AL= 5569
01-22 21:35:59.052+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb776f950), gem(44), surface(0xb798d170)
01-22 21:35:59.072+0900 I/ISP_AE  ( 2820): cur target lum=62, ev diff=24, level=5
01-22 21:35:59.072+0900 I/ISP_AE  ( 2820): ev_test cur_ev =5
01-22 21:35:59.072+0900 I/ISP_AE  ( 2820): ev_test target_lum=86
01-22 21:35:59.072+0900 I/ISP_AE  ( 2820): set ev level 5, target lum from 86 to 86, rtn=0
01-22 21:35:59.072+0900 I/ISP_AE  ( 2820): AE_TEST ----------------------change to fast
01-22 21:35:59.072+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:354, cur_lum:61, next_index:359, target_lum:86
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.072+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.072+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.89, detect:   0.34,   0.36 CTemp:5364.1
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [HSC]Mix=0000bae0,Csd=ffffc9df ,(BV=-0.306,x=0.330,y=0.355)
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:3, 0x0000bae0,0x0000bae0
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=0.024609 ,Awb Bv=-0.306076 in/out_0
01-22 21:35:59.072+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.276794,GGain=1.000000,BGain=1.328934,Dtct=0.330490,0.354553 ,Curr=0.330734,0.356094 ,CTmep: QC=5971, AL= 5568
01-22 21:35:59.092+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79965f0), gem(47), surface(0xb7985548)
01-22 21:35:59.142+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb776f950), gem(44), surface(0xb79d5980)
01-22 21:35:59.182+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20106c 
01-22 21:35:59.182+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:359, cur_lum:66, next_index:362, target_lum:86
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.182+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.182+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.36 CTemp:5406.2
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [HSC]Mix=0000bae0,Csd=ffffcefb ,(BV=-0.285,x=0.330,y=0.354)
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:4, 0x0000bae0,0x0000bae0
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.052012 ,Awb Bv=-0.284683 in/out_0
01-22 21:35:59.182+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.275970,GGain=1.000000,BGain=1.328476,Dtct=0.329788,0.353867 ,Curr=0.330765,0.356033 ,CTmep: QC=5971, AL= 5568
01-22 21:35:59.232+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb798a718), gem(47), surface(0xb79849b8)
01-22 21:35:59.262+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79cba00), gem(44), surface(0xb79849b8)
01-22 21:35:59.302+0900 I/ISP_AE  ( 2820): cur target lum=62, ev diff=50, level=6
01-22 21:35:59.302+0900 I/ISP_AE  ( 2820): ev_test cur_ev =6
01-22 21:35:59.302+0900 I/ISP_AE  ( 2820): ev_test target_lum=112
01-22 21:35:59.302+0900 I/ISP_AE  ( 2820): set ev level 6, target lum from 112 to 112, rtn=0
01-22 21:35:59.302+0900 I/ISP_AE  ( 2820): AE_TEST ----------------------change to fast
01-22 21:35:59.302+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:362, cur_lum:68, next_index:370, target_lum:112
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.302+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.302+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.302+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.312+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.36 CTemp:5409.2
01-22 21:35:59.312+0900 D/alPrinter0( 2820): [HSC]Mix=0000bae0,Csd=00002403 ,(BV=-0.248,x=0.330,y=0.354)
01-22 21:35:59.312+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:3, 0x0000bae0,0x0000bae0
01-22 21:35:59.312+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=0.099596 ,Awb Bv=-0.247665 in/out_0
01-22 21:35:59.312+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.274796,GGain=1.000000,BGain=1.326950,Dtct=0.329559,0.353577 ,Curr=0.330719,0.355835 ,CTmep: QC=5971, AL= 5568
01-22 21:35:59.312+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7994fb8), gem(47), surface(0xb7986ae0)
01-22 21:35:59.363+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7994f58), gem(44), surface(0xb79849b8)
01-22 21:35:59.423+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:370, cur_lum:77, next_index:375, target_lum:112
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.423+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.423+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.423+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5376.2
01-22 21:35:59.433+0900 D/alPrinter0( 2820): [HSC]Mix=0000bae0,Csd=00001d63 ,(BV=-0.203,x=0.331,y=0.356)
01-22 21:35:59.433+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:4, 0x0000bae0,0x0000bae0
01-22 21:35:59.433+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.098343 ,Awb Bv=-0.203049 in/out_0
01-22 21:35:59.433+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.274689,GGain=1.000000,BGain=1.326950,Dtct=0.330917,0.356201 ,Curr=0.330719,0.355835 ,CTmep: QC=5971, AL= 5568
01-22 21:35:59.443+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb776f950), gem(47), surface(0xb79849b8)
01-22 21:35:59.493+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7994ef8), gem(44), surface(0xb799b180)
01-22 21:35:59.543+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:375, cur_lum:87, next_index:378, target_lum:112
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.543+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.543+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.87, detect:   0.34,   0.36 CTemp:5372.7
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [HSC]Mix=0000bae0,Csd=fffff99d ,(BV=-0.164,x=0.331,y=0.357)
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:3, 0x0000bae0,0x0000bae0
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.205258 ,Awb Bv=-0.164200 in/out_0
01-22 21:35:59.543+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.273529,GGain=1.000000,BGain=1.325089,Dtct=0.331436,0.357407 ,Curr=0.330627,0.355591 ,CTmep: QC=5972, AL= 5569
01-22 21:35:59.573+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79965f0), gem(47), surface(0xb7986ae0)
01-22 21:35:59.593+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20106c 
01-22 21:35:59.633+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb798a8b0), gem(44), surface(0xb799b318)
01-22 21:35:59.663+0900 I/ISP_AE  ( 2820): AE_TEST:----cur_index:378, cur_lum:92, next_index:381, target_lum:112
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:59.663+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [CMD0][if=a4c202a8,Wrap=a4c257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:59.663+0900 D/awb_al_cmd0( 2820): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [CALL][0xa4c202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [AIS_WRAP]msiFlash_state=0
01-22 21:35:59.663+0900 D/alPrinter0( 2820): [LOCK]0
01-22 21:35:59.673+0900 D/alPrinter0( 2820): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5385.8
01-22 21:35:59.673+0900 D/alPrinter0( 2820): [HSC]Mix=0000bae0,Csd=0000abdb ,(BV=-0.142,x=0.331,y=0.357)
01-22 21:35:59.673+0900 D/alPrinter0( 2820): [AlHscWrap_Main]:4, 0x0000bae0,0x0000bae0
01-22 21:35:59.673+0900 D/alPrinter0( 2820): [AIS_WRAP]In BV=-0.304794 ,Awb Bv=-0.142426 in/out_0
01-22 21:35:59.673+0900 D/alPrinter0( 2820): [AIS_WRAP]RGain=1.273239,GGain=1.000000,BGain=1.324432,Dtct=0.330780,0.356842 ,Curr=0.330582,0.355499 ,CTmep: QC=5972, AL= 5569
01-22 21:35:59.693+0900 I/ISP_AE  ( 2820): calc_iso=280,real_gain=90,iso=0
01-22 21:35:59.693+0900 I/ISP_AE  ( 2820): calc_iso=280,real_gain=90,iso=0
01-22 21:35:59.703+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7994f58), gem(47), surface(0xb7986ae0)
01-22 21:35:59.713+0900 I/ISP_AE  ( 2820): ae_state=3
01-22 21:35:59.913+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7986d00), gem(44), surface(0xb79d5980)
01-22 21:35:59.923+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb78b1cb0), gem(51), surface(0xb7986ae0)
01-22 21:35:59.963+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7994f58), gem(44), surface(0xb7986ae0)
01-22 21:36:00.023+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79965f0), gem(47), surface(0xb79d5980)
01-22 21:36:00.073+0900 D/camera  ( 2820): Writing image to file.
01-22 21:36:00.073+0900 I/ISP_AE  ( 2820): ANTI_FLAG: =600000, 4477, 134, 1
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v_s :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v_s :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :1
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :2
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.073+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :3
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -10
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 10
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :4
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :10
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 90
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :5
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :90
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 230
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :6
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :230
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 1520
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :1520
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 11
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :11
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 150
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :8
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :150
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 11
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 80
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :9
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :80
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :10
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 210
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :11
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :210
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 170
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :12
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :170
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -1
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 10
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :13
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :10
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 40
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :14
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :40
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.083+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 90
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :15
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :90
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 410
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :16
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :410
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 3
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :3
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 380
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :17
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :380
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 3
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 5
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :5
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 280
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :18
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :280
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 5
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 6
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :6
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 410
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :19
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :410
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 6
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 9
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :9
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 250
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :20
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :250
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 9
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 10
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :10
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 80
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :21
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :80
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 10
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 3
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :3
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 50
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :22
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :50
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 3
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -4
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 260
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :23
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :260
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 1
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :1
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 430
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :24
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :430
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 1
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 4
01-22 21:36:00.093+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :4
01-22 21:36:00.093+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb79cbbc0), gem(44), surface(0xb7986ae0)
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 220
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :25
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :220
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 4
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 5
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :5
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :26
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 5
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -5
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 360
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :27
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :360
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 2
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :2
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :28
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 2
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -5
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :29
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 210
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :30
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :210
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 1
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :1
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v_s :0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v_s :0
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 50
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :31
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :50
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 1
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -6
01-22 21:36:00.103+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :32
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -7
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 150
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :33
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :150
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 -4
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :0
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 270
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :34
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :270
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 0
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 1
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :1
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 340
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :35
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :340
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 1
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 3
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :3
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 270
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :36
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :270
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 3
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 4
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :4
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 760
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :37
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :760
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 4
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 10
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :10
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_get_apm_by_region(666) > indicator_get_apm_by_region[666]	 "TimeZone is Asia/Seoul"
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 770
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :38
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :770
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 10
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 16
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :16
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(780) > indicator_get_time_by_region[780]	 "BestPattern is h"
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(781) > indicator_get_time_by_region[781]	 "TimeZone is Asia/Seoul"
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 190
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :39
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :190
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 16
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 16
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :16
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(801) > indicator_get_time_by_region[801]	 "DATE & TIME is en_US 9:36 4 h"
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(803) > indicator_get_time_by_region[803]	 "24H :: Before change 9:36"
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(810) > indicator_get_time_by_region[810]	 "24H :: After change 9&#x2236;36"
01-22 21:36:00.113+0900 D/INDICATOR(  893): clock.c: indicator_clock_changed_cb(295) > [CLOCK MODULE] Timer Status : -2146934220 Time: <font_size=33>9&#x2236;36</font_size> <font_size=32>PM</font_size></font>
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 230
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :40
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :230
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 16
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 17
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :17
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 220
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :41
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :220
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 17
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 18
01-22 21:36:00.113+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :18
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 610
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :42
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :610
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 18
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 23
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :23
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 210
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :43
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :210
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 23
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 24
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :24
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 480
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :44
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :480
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 24
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 27
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :27
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 380
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :45
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :380
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 27
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 29
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :29
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 650
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :46
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :650
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 29
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 34
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :34
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 500
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :47
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :500
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 34
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 38
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :38
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :48
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 38
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 31
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :31
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :49
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 31
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 24
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :24
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 70
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :50
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :70
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 24
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 17
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :17
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 270
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :51
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :270
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 17
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 18
01-22 21:36:00.123+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :18
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 360
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :52
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :360
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 18
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 20
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :20
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 210
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :53
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :210
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 20
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 21
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :21
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 420
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :54
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :420
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 21
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 24
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :24
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 100
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :55
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :100
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 24
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 17
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :17
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 360
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :56
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :360
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 17
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 19
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :19
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 520
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :57
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :520
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 19
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 23
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :23
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 730
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :58
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :730
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 23
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 29
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :29
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 1120
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :59
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :1120
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 29
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 39
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :39
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman frame_flicker_value = 1120
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman still_f :60
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v :1120
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b0 39
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b1 200
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman b2 49
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v :49
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_f_v_s :30
01-22 21:36:00.133+0900 I/ISP_DEFLICKER V3( 2820): hyman afl_v_v_s :30
01-22 21:36:00.143+0900 I/MALI    ( 2820): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb78b6800), gem(47), surface(0xb79d5980)
01-22 21:36:00.173+0900 W/CRASH_MANAGER( 2783): worker.c: worker_job(1204) > 110282063616d142193016
