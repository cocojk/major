S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 3670
Date: 2015-01-22 21:42:50+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3670, uid 5000)

Register Information
r0   = 0x93803008, r1   = 0x00000001
r2   = 0x001f258e, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x001f258e
r6   = 0x001f258e, r7   = 0xae01c588
r8   = 0xb7b9a460, r9   = 0xae01c734
r10  = 0xb7b9f9b0, fp   = 0x0000000d
ip   = 0xb67ab110, sp   = 0xae01c4e8
lr   = 0xb33d0d5f, pc   = 0xb67ab128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    421272 KB
Buffers:     20048 KB
Cached:     131276 KB
VmPeak:     588876 KB
VmSize:     588872 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       45832 KB
VmRSS:       45832 KB
VmData:     411156 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         284 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 3670 TID = 3865
3670 3672 3854 3855 3856 3857 3863 3864 3865 3866 3867 3868 3869 3870 3871 3872 3875 3876 3877 3878 3879 3880 3881 3882 3883 3884 3885 3886 3887 3888 3889 3890 3891 3892 3893 3894 3895 3896 3897 3898 3899 3901 3902 3903 3905 3906 3909 

Maps Information
93cdb000 944da000 rwxp [stack:3906]
944db000 94cda000 rwxp [stack:3905]
94d1c000 9551b000 rwxp [stack:3909]
993dd000 99bdc000 rwxp [stack:3903]
99bdd000 9a3dc000 rwxp [stack:3902]
9c2dd000 9cadc000 rwxp [stack:3901]
9cb74000 9d373000 rwxp [stack:3899]
9d374000 9db73000 rwxp [stack:3898]
9db74000 9e373000 rwxp [stack:3897]
9ea5f000 9f25e000 rwxp [stack:3896]
9f25f000 9fa5e000 rwxp [stack:3895]
9fa5f000 a025e000 rwxp [stack:3894]
a025f000 a0a5e000 rwxp [stack:3893]
a0a5f000 a125e000 rwxp [stack:3892]
a125f000 a1a5e000 rwxp [stack:3891]
a1a5f000 a225e000 rwxp [stack:3890]
a225f000 a2a5e000 rwxp [stack:3889]
a2a5f000 a325e000 rwxp [stack:3888]
a325f000 a3a5e000 rwxp [stack:3887]
a3a5f000 a425e000 rwxp [stack:3886]
a425f000 a4a5e000 rwxp [stack:3885]
a4a5f000 a525e000 rwxp [stack:3884]
a5501000 a5d00000 rwxp [stack:3883]
a5d01000 a6500000 rwxp [stack:3882]
a6501000 a6d00000 rwxp [stack:3881]
a6d01000 a7500000 rwxp [stack:3879]
a7501000 a7d00000 rwxp [stack:3880]
a7d01000 a8500000 rwxp [stack:3878]
a8501000 a8d00000 rwxp [stack:3877]
a8d01000 a9500000 rwxp [stack:3876]
a9501000 a9d00000 rwxp [stack:3875]
a9d01000 aa500000 rwxp [stack:3872]
aa501000 aad00000 rwxp [stack:3871]
aad01000 ab500000 rwxp [stack:3870]
ab501000 abd00000 rwxp [stack:3869]
abd01000 ac500000 rwxp [stack:3868]
ac501000 acd00000 rwxp [stack:3867]
acf01000 ad700000 rwxp [stack:3866]
ad81f000 ae01e000 rwxp [stack:3865]
ae01e000 ae021000 r-xp /usr/lib/libXv.so.1.0.0
ae031000 ae043000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae054000 ae08b000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae09d000 ae89c000 rwxp [stack:3864]
ae89c000 ae8b9000 r-xp /usr/lib/libAl_Awb_Sp.so
ae8c2000 ae8c5000 r-xp /usr/lib/libdeflicker.so
ae8dd000 ae8f3000 r-xp /usr/lib/libAl_Awb.so
ae8fb000 ae905000 r-xp /usr/lib/libcalibration.so
ae90e000 ae920000 r-xp /usr/lib/libaf_lib.so
ae928000 ae92e000 r-xp /usr/lib/libspaf.so
ae936000 ae942000 r-xp /usr/lib/libae.so
ae94a000 ae98b000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae9d2000 aeab1000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aef0e000 aef0f000 r-xp /usr/lib/libcamerahdr.so.0.0.0
aef1f000 aef5b000 r-xp /usr/lib/libcamerahal.so.0.0.0
af100000 af106000 r-xp /usr/lib/liblsc.so
af147000 af946000 rwxp [stack:3863]
af993000 af9ab000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0501000 b0d00000 rwxp [stack:3857]
b0efa000 b16f9000 rwxp [stack:3856]
b16fa000 b1ef9000 rwxp [stack:3855]
b1ef9000 b1efe000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f8a000 b1f92000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1fa3000 b1fa4000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1fb4000 b1fbb000 r-xp /usr/lib/libfeedback.so.0.1.4
b1fdf000 b1fe0000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1ff0000 b2003000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2057000 b205c000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b206d000 b286c000 rwxp [stack:3854]
b286c000 b29c7000 r-xp /usr/lib/egl/libMali.so
b29dc000 b2a65000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a7e000 b2b4c000 r-xp /usr/lib/libCOREGL.so.4.0
b2b67000 b2b6a000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b7a000 b2b87000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b98000 b2ba2000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2bb2000 b2bbe000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2bcf000 b2bd3000 r-xp /usr/lib/libogg.so.0.7.1
b2be3000 b2c05000 r-xp /usr/lib/libvorbis.so.0.4.3
b2c15000 b2cf9000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2d15000 b2d58000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d6d000 b2db4000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2dc5000 b2dcc000 r-xp /usr/lib/libjson-c.so.2.0.1
b2ddc000 b2e11000 r-xp /usr/lib/libpulse.so.0.16.2
b2e22000 b2e25000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2e36000 b2e39000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2e4a000 b2e8d000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e9e000 b2ea6000 r-xp /usr/lib/libdrm.so.2.4.0
b2eb6000 b2eb8000 r-xp /usr/lib/libdri2.so.0.0.0
b2ec8000 b2ecf000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2edf000 b2eea000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2efe000 b2f04000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2f15000 b2f1d000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2f2e000 b2f33000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2f43000 b2f5a000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f6a000 b2f8a000 r-xp /usr/lib/libexif.so.12.3.3
b2f96000 b2f9e000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2fae000 b2fdd000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2ff0000 b2ff8000 r-xp /usr/lib/libtbm.so.1.0.0
b3008000 b30c1000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b30d5000 b30dc000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b30ec000 b314a000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b315f000 b3163000 r-xp /usr/lib/libstorage.so.0.1
b3173000 b317a000 r-xp /usr/lib/libefl-extension.so.0.1.0
b318a000 b3199000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b32c3000 b32c7000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32d8000 b33b8000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33cd000 b33d2000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b33da000 b3401000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3414000 b3c13000 rwxp [stack:3672]
b3c13000 b3c15000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3e25000 b3e2e000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e3f000 b3e48000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e59000 b3e6a000 r-xp /lib/libnsl-2.20-2014.11.so
b3e7d000 b3e83000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e94000 b3eae000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3ebf000 b3ec0000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ed0000 b3ed2000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ee3000 b3ee8000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ef8000 b3efb000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3f0c000 b3f13000 r-xp /usr/lib/libsensord-share.so
b3f23000 b3f34000 r-xp /usr/lib/libsensor.so.1.2.0
b3f45000 b3f4b000 r-xp /usr/lib/libappcore-common.so.1.1
b3f6e000 b3f73000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f89000 b3f8b000 r-xp /usr/lib/libXau.so.6.0.0
b3f9b000 b3faf000 r-xp /usr/lib/libxcb.so.1.1.0
b3fbf000 b3fc6000 r-xp /lib/libcrypt-2.20-2014.11.so
b3ffe000 b4000000 r-xp /usr/lib/libiri.so
b4011000 b4026000 r-xp /lib/libexpat.so.1.5.2
b4038000 b4086000 r-xp /usr/lib/libssl.so.1.0.0
b409b000 b40a4000 r-xp /usr/lib/libethumb.so.1.13.0
b40b5000 b40b8000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40c8000 b427f000 r-xp /usr/lib/libcrypto.so.1.0.0
b5816000 b581f000 r-xp /usr/lib/libXi.so.6.1.0
b5830000 b5832000 r-xp /usr/lib/libXgesture.so.7.0.0
b5842000 b5846000 r-xp /usr/lib/libXtst.so.6.1.0
b5856000 b585c000 r-xp /usr/lib/libXrender.so.1.3.0
b586c000 b5872000 r-xp /usr/lib/libXrandr.so.2.2.0
b5882000 b5884000 r-xp /usr/lib/libXinerama.so.1.0.0
b5894000 b5897000 r-xp /usr/lib/libXfixes.so.3.1.0
b58a8000 b58b3000 r-xp /usr/lib/libXext.so.6.4.0
b58c3000 b58c5000 r-xp /usr/lib/libXdamage.so.1.1.0
b58d5000 b58d7000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58e7000 b59ca000 r-xp /usr/lib/libX11.so.6.3.0
b59dd000 b59e4000 r-xp /usr/lib/libXcursor.so.1.0.2
b59f5000 b5a0d000 r-xp /usr/lib/libudev.so.1.6.0
b5a0f000 b5a12000 r-xp /lib/libattr.so.1.1.0
b5a22000 b5a42000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a43000 b5a48000 r-xp /usr/lib/libffi.so.6.0.2
b5a58000 b5a70000 r-xp /lib/libz.so.1.2.8
b5a80000 b5a82000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a92000 b5b67000 r-xp /usr/lib/libxml2.so.2.9.2
b5b7c000 b5c17000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c33000 b5c36000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c46000 b5c60000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c70000 b5c81000 r-xp /lib/libresolv-2.20-2014.11.so
b5c95000 b5cac000 r-xp /usr/lib/liblzma.so.5.0.3
b5cbc000 b5cbe000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5cce000 b5cd5000 r-xp /usr/lib/libembryo.so.1.13.0
b5ce5000 b5cfd000 r-xp /usr/lib/libpng12.so.0.50.0
b5d0e000 b5d31000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d51000 b5d57000 r-xp /lib/librt-2.20-2014.11.so
b5d68000 b5d7c000 r-xp /usr/lib/libector.so.1.13.0
b5d8d000 b5da5000 r-xp /usr/lib/liblua-5.1.so
b5db6000 b5e0d000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e21000 b5e49000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e5a000 b5e6d000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e7e000 b5eb8000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ec9000 b5f34000 r-xp /lib/libm-2.20-2014.11.so
b5f45000 b5f52000 r-xp /usr/lib/libeio.so.1.13.0
b5f62000 b5f64000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f74000 b5f79000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f89000 b5fa0000 r-xp /usr/lib/libefreet.so.1.13.0
b5fb2000 b5fd2000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fe2000 b6002000 r-xp /usr/lib/libecore_con.so.1.13.0
b6004000 b600a000 r-xp /usr/lib/libecore_imf.so.1.13.0
b601a000 b6021000 r-xp /usr/lib/libethumb_client.so.1.13.0
b6031000 b603f000 r-xp /usr/lib/libeo.so.1.13.0
b604f000 b6061000 r-xp /usr/lib/libecore_input.so.1.13.0
b6072000 b6077000 r-xp /usr/lib/libecore_file.so.1.13.0
b6087000 b609f000 r-xp /usr/lib/libecore_evas.so.1.13.0
b60b0000 b60cd000 r-xp /usr/lib/libeet.so.1.13.0
b60e6000 b612e000 r-xp /usr/lib/libeina.so.1.13.0
b613f000 b614f000 r-xp /usr/lib/libefl.so.1.13.0
b6160000 b6245000 r-xp /usr/lib/libicuuc.so.51.1
b6262000 b63a2000 r-xp /usr/lib/libicui18n.so.51.1
b63b9000 b63f1000 r-xp /usr/lib/libecore_x.so.1.13.0
b6403000 b6406000 r-xp /lib/libcap.so.2.21
b6416000 b643f000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6450000 b6457000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6469000 b649f000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b64b0000 b6598000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b65ac000 b6622000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6634000 b6637000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6647000 b6652000 r-xp /usr/lib/libvconf.so.0.2.45
b6662000 b6664000 r-xp /usr/lib/libvasum.so.0.3.1
b6674000 b6676000 r-xp /usr/lib/libttrace.so.1.1
b6686000 b6689000 r-xp /usr/lib/libiniparser.so.0
b6699000 b66bc000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66cc000 b66d1000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66e2000 b66f9000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b670a000 b6717000 r-xp /usr/lib/libunwind.so.8.0.1
b674d000 b6871000 r-xp /lib/libc-2.20-2014.11.so
b6886000 b689f000 r-xp /lib/libgcc_s-4.9.so.1
b68af000 b6991000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b69a2000 b69d6000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69e6000 b6a20000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a22000 b6aa2000 r-xp /usr/lib/libedje.so.1.13.0
b6aa5000 b6ac3000 r-xp /usr/lib/libecore.so.1.13.0
b6ae3000 b6c45000 r-xp /usr/lib/libevas.so.1.13.0
b6c7c000 b6c90000 r-xp /lib/libpthread-2.20-2014.11.so
b6ca4000 b6ec8000 r-xp /usr/lib/libelementary.so.1.13.0
b6ef6000 b6efa000 r-xp /usr/lib/libsmack.so.1.0.0
b6f0a000 b6f10000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6f21000 b6f23000 r-xp /usr/lib/libdlog.so.0.0.0
b6f33000 b6f36000 r-xp /usr/lib/libbundle.so.0.1.22
b6f46000 b6f48000 r-xp /lib/libdl-2.20-2014.11.so
b6f59000 b6f72000 r-xp /usr/lib/libaul.so.0.1.0
b6f84000 b6f86000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f97000 b6f9b000 r-xp /usr/lib/libsys-assert.so
b6fac000 b6fcc000 r-xp /lib/ld-2.20-2014.11.so
b6fdd000 b6fe3000 r-xp /usr/bin/launchpad-loader
b78e6000 b7eac000 rw-p [heap]
be8a3000 be8c4000 rwxp [stack]
be8a3000 be8c4000 rwxp [stack]
End of Maps Information

Callstack Information (PID:3670)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb67ab128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb33d0d5f) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d5f
 2: (0xb318eabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3111865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb64755bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6481f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb6487a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb6487c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf99dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf99e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6900157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c81cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.181+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.181+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:4973.7
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [HSC]Mix=0000b850,Csd=0001855a ,(BV=-2.756,x=0.351,y=0.377)
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:4, 0x0000b850,0x0000b850
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.125531 ,Awb Bv=-2.755524 in/out_0
01-22 21:42:48.181+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.255920,GGain=1.000000,BGain=1.614304,Dtct=0.351440,0.376831 ,Curr=0.356827,0.384888 ,CTmep: QC=4986, AL= 4755
01-22 21:42:48.191+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.231+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 3 -> 1
01-22 21:42:48.231+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 3 -> 1
01-22 21:42:48.231+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:42:48.271+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e276c0), gem(44), surface(0xb7cb8bd0)
01-22 21:42:48.302+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:380, cur_lum:65, next_index:380, target_lum:62
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.302+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.302+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.92, detect:   0.34,   0.37 CTemp:5107.6
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [HSC]Mix=0000d708,Csd=0001027e ,(BV=-2.502,x=0.348,y=0.373)
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:3, 0x0000d708,0x0000d708
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.125531 ,Awb Bv=-2.502182 in/out_0
01-22 21:42:48.302+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.248871,GGain=1.000000,BGain=1.600357,Dtct=0.347733,0.372650 ,Curr=0.356369,0.383453 ,CTmep: QC=4983, AL= 4753
01-22 21:42:48.322+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.362+0900 I/ISP_AE  ( 3670): AE_TEST ----------------------change to smooth
01-22 21:42:48.362+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:380, cur_lum:60, next_index:380, target_lum:62
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.362+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.362+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.91, detect:   0.34,   0.36 CTemp:5229.2
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [HSC]Mix=0000f5c0,Csd=00025cb3 ,(BV=-2.229,x=0.346,y=0.371)
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:4, 0x0000f5c0,0x0000f5c0
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.125531 ,Awb Bv=-2.229095 in/out_0
01-22 21:42:48.362+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.245407,GGain=1.000000,BGain=1.583298,Dtct=0.345825,0.371109 ,Curr=0.355392,0.381699 ,CTmep: QC=4983, AL= 4753
01-22 21:42:48.372+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e276c0), gem(44), surface(0xb7cb8bd0)
01-22 21:42:48.422+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:380, cur_lum:56, next_index:381, target_lum:62
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.422+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.422+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.89, detect:   0.34,   0.36 CTemp:5322.8
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [HSC]Mix=00011478,Csd=0001f9d5 ,(BV=-1.966,x=0.345,y=0.370)
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:3, 0x00011478,0x00011478
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.157953 ,Awb Bv=-1.965912 in/out_0
01-22 21:42:48.422+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.243561,GGain=1.000000,BGain=1.564407,Dtct=0.345352,0.370041 ,Curr=0.354050,0.379730 ,CTmep: QC=4988, AL= 4757
01-22 21:42:48.452+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.502+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e276c0), gem(44), surface(0xb7cb8bd0)
01-22 21:42:48.542+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:381, cur_lum:54, next_index:382, target_lum:62
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.542+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.542+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.88, detect:   0.33,   0.36 CTemp:5521.6
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [HSC]Mix=00013330,Csd=fffe27fb ,(BV=-1.732,x=0.343,y=0.367)
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:4, 0x00013330,0x00013330
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.189662 ,Awb Bv=-1.732178 in/out_0
01-22 21:42:48.542+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.243240,GGain=1.000000,BGain=1.544800,Dtct=0.343170,0.366760 ,Curr=0.352432,0.377655 ,CTmep: QC=4995, AL= 4762
01-22 21:42:48.552+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.632+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e276c0), gem(44), surface(0xb7cb8bd0)
01-22 21:42:48.662+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:382, cur_lum:55, next_index:383, target_lum:62
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.662+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.662+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.85, detect:   0.33,   0.35 CTemp:5619.0
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [HSC]Mix=00011478,Csd=fffd6143 ,(BV=-1.539,x=0.341,y=0.366)
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:3, 0x00011478,0x00011478
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.220688 ,Awb Bv=-1.538635 in/out_0
01-22 21:42:48.662+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.243286,GGain=1.000000,BGain=1.524521,Dtct=0.341217,0.365585 ,Curr=0.350647,0.375458 ,CTmep: QC=5005, AL= 4770
01-22 21:42:48.682+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.682+0900 I/ISP_AE  ( 3670): FDAE: ->disable, frame_idx=30
01-22 21:42:48.732+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e276c0), gem(44), surface(0xb7cb8bd0)
01-22 21:42:48.782+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:383, cur_lum:60, next_index:383, target_lum:62
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.782+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.782+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.83, detect:   0.33,   0.35 CTemp:5698.2
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [HSC]Mix=0000f5c0,Csd=fffe8edd ,(BV=-1.388,x=0.340,y=0.365)
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:4, 0x0000f5c0,0x0000f5c0
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.220688 ,Awb Bv=-1.388336 in/out_0
01-22 21:42:48.782+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.242691,GGain=1.000000,BGain=1.512756,Dtct=0.340103,0.365494 ,Curr=0.348785,0.373306 ,CTmep: QC=5018, AL= 4780
01-22 21:42:48.802+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.842+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:383, cur_lum:60, next_index:383, target_lum:62
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.842+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.842+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.83, detect:   0.33,   0.35 CTemp:5703.4
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [HSC]Mix=0000d708,Csd=fffdf436 ,(BV=-1.278,x=0.340,y=0.365)
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:3, 0x0000d708,0x0000d708
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.220688 ,Awb Bv=-1.278442 in/out_0
01-22 21:42:48.842+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.245346,GGain=1.000000,BGain=1.490891,Dtct=0.339859,0.365295 ,Curr=0.346863,0.371246 ,CTmep: QC=5034, AL= 4793
01-22 21:42:48.852+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e276c0), gem(44), surface(0xb7cb8bd0)
01-22 21:42:48.902+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:383, cur_lum:59, next_index:383, target_lum:62
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.902+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.902+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.82, detect:   0.33,   0.35 CTemp:5739.6
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [HSC]Mix=0000b850,Csd=ffff2a4f ,(BV=-1.203,x=0.339,y=0.366)
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:4, 0x0000b850,0x0000b850
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.220688 ,Awb Bv=-1.203308 in/out_0
01-22 21:42:48.902+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.248734,GGain=1.000000,BGain=1.472534,Dtct=0.339386,0.365784 ,Curr=0.345093,0.369507 ,CTmep: QC=5052, AL= 4807
01-22 21:42:48.932+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d808b0)
01-22 21:42:48.962+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:383, cur_lum:58, next_index:384, target_lum:62
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:48.962+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:48.962+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:48.962+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.82, detect:   0.33,   0.35 CTemp:5776.2
01-22 21:42:48.972+0900 D/alPrinter0( 3670): [HSC]Mix=0000a51d,Csd=ffffe0cd ,(BV=-1.157,x=0.339,y=0.366)
01-22 21:42:48.972+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:3, 0x0000a51d,0x0000a51d
01-22 21:42:48.972+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.251062 ,Awb Bv=-1.157089 in/out_0
01-22 21:42:48.972+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.252594,GGain=1.000000,BGain=1.457001,Dtct=0.338821,0.366257 ,Curr=0.343475,0.368042 ,CTmep: QC=5073, AL= 4824
01-22 21:42:48.982+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7df1b20), gem(44), surface(0xb7e65430)
01-22 21:42:49.032+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b54480), gem(47), surface(0xb7d77428)
01-22 21:42:49.052+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20165f 
01-22 21:42:49.082+0900 I/ISP_AE  ( 3670): AE_TEST:----cur_index:384, cur_lum:61, next_index:384, target_lum:62
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:42:49.082+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [CMD0][if=b7ca0740,Wrap=b7ca5c70]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:42:49.082+0900 D/awb_al_cmd0( 3670): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [CALL][0xb7ca0740][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [AIS_WRAP]msiFlash_state=0
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [LOCK]0
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [SuperHighCTemp] Mapin:  0.83, detect:   0.32,   0.35 CTemp:5812.7
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [HSC]Mix=0000a51d,Csd=000064c7 ,(BV=-1.134,x=0.338,y=0.366)
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [AlHscWrap_Main]:4, 0x0000a51d,0x0000a51d
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [AIS_WRAP]In BV=-1.251062 ,Awb Bv=-1.134384 in/out_0
01-22 21:42:49.082+0900 D/alPrinter0( 3670): [AIS_WRAP]RGain=1.257385,GGain=1.000000,BGain=1.445496,Dtct=0.338135,0.366211 ,Curr=0.342072,0.366974 ,CTmep: QC=5098, AL= 4843
01-22 21:42:49.122+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.132+0900 I/ISP_AE  ( 3670): ae_state=3
01-22 21:42:49.162+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d7d670), gem(47), surface(0xb7d7d590)
01-22 21:42:49.212+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.282+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d7d670), gem(47), surface(0xb7d7d590)
01-22 21:42:49.333+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.393+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d7d670), gem(47), surface(0xb7e27650)
01-22 21:42:49.453+0900 D/RESOURCED(  870): logging.c: logging_send_signal_to_data(1097) > logging timer callback function start
01-22 21:42:49.453+0900 I/RESOURCED(  870): logging.c: logging_send_signal_to_data(1106) > send signal to logging data thread
01-22 21:42:49.453+0900 D/RESOURCED(  870): logging.c: logging_send_signal_to_update(1177) > logging timer callback function start
01-22 21:42:49.453+0900 I/RESOURCED(  870): logging.c: logging_send_signal_to_update(1186) > send signal to logging update thread
01-22 21:42:49.463+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b8bd88), gem(44), surface(0xb7e27170)
01-22 21:42:49.523+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d7d670), gem(47), surface(0xb7d77200)
01-22 21:42:49.593+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.643+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d7d590)
01-22 21:42:49.693+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.763+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d7d590)
01-22 21:42:49.803+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.863+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d7d590)
01-22 21:42:49.933+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:49.983+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d7d590)
01-22 21:42:50.053+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:50.113+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d7d590)
01-22 21:42:50.163+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(44), surface(0xb7d7d590)
01-22 21:42:50.233+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e26ab8), gem(47), surface(0xb7d7d590)
01-22 21:42:50.283+0900 I/ISP_AE  ( 3670): calc_iso=300,real_gain=96,iso=0
01-22 21:42:50.293+0900 I/ISP_AE  ( 3670): calc_iso=300,real_gain=96,iso=0
01-22 21:42:50.293+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e65368), gem(44), surface(0xb7df1b20)
01-22 21:42:50.544+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d77f20), gem(47), surface(0xb7df1b20)
01-22 21:42:50.544+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d781c0), gem(54), surface(0xb7df1b20)
01-22 21:42:50.574+0900 D/AUL_AMD (  819): amd_status.c: __app_terminate_timer_cb(442) > pid(3568)
01-22 21:42:50.574+0900 W/AUL_AMD (  819): amd_status.c: __app_terminate_timer_cb(446) > send SIGKILL: No such process
01-22 21:42:50.594+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e12b80), gem(44), surface(0xb7df1b20)
01-22 21:42:50.624+0900 D/camera  ( 3670): Writing image to file.
01-22 21:42:50.644+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e12c88), gem(47), surface(0xb7df1b20)
01-22 21:42:50.694+0900 I/ISP_AE  ( 3670): ANTI_FLAG: =600000, 4477, 134, 1
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v_s :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v_s :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :1
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :2
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 -10
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :3
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 -10
01-22 21:42:50.694+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :4
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 -10
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :5
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 -10
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :6
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 -10
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :7
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 -10
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 430
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :8
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :430
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 0
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 3
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :3
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 460
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :9
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :460
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 3
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 6
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :6
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 790
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :10
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :790
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 6
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 12
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :12
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 970
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :11
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :970
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 12
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 22
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :22
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 150
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :12
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :150
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 22
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 18
01-22 21:42:50.704+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :18
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 230
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :13
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :230
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 18
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 19
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :19
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 210
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :14
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :210
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 19
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 20
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :20
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 360
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :15
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :360
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 20
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 22
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :22
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 70
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :16
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :70
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 22
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 15
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :15
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 140
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :17
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :140
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 15
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 70
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :18
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :70
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 3
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :3
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 310
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :19
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :310
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 3
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 5
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :5
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 180
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :20
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :180
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 5
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 4
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :4
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 720
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :21
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :720
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 4
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 310
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :22
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :310
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 12
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :12
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 140
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :23
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :140
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 12
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 7
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :7
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 490
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :24
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :490
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 7
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 550
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :25
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :550
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 10
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 14
01-22 21:42:50.714+0900 I/MALI    ( 3670): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ded930), gem(44), surface(0xb7df1b20)
01-22 21:42:50.714+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :14
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 380
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :26
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :380
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 14
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 16
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :16
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 260
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :27
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :260
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 16
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 17
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :17
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 360
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :28
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :360
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 17
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 19
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :19
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 240
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :29
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :240
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 19
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 20
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :20
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 420
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :30
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :420
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 20
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 23
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :23
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v_s :0
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v_s :0
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 550
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :31
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :550
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 23
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 27
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :27
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 300
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :300
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 27
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 29
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :29
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 280
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :33
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :280
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 29
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 30
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :30
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 320
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :34
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :320
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 30
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 190
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :35
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :190
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 300
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :36
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :300
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 32
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 34
01-22 21:42:50.724+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :34
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 610
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :37
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :610
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 34
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 39
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :39
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 410
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :38
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :410
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 39
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 42
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :42
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 350
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :39
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :350
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 42
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 44
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :44
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman frame_flicker_value = 410
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman still_f :40
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_f_v :410
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b0 44
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b1 200
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman b2 47
01-22 21:42:50.734+0900 I/ISP_DEFLICKER V3( 3670): hyman afl_v_v :47
01-22 21:42:50.764+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:42:50.784+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:42:50.794+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:42:50.794+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:42:50.794+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:42:50.794+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:42:50.794+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:42:50.794+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:42:50.794+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:42:50.804+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:42:50.804+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:42:50.804+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x10229a0), gem(11), surface(0x104c3b8)
01-22 21:42:50.804+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:42:50.804+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:42:50.804+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(3)
01-22 21:42:50.804+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-22 21:42:50.804+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-22 21:42:50.804+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: fg
01-22 21:42:50.804+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 913
01-22 21:42:50.804+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 913, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
01-22 21:42:50.804+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 913, appname = org.tizen.homescreen
01-22 21:42:50.804+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 913
01-22 21:42:50.804+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 913 foreground
01-22 21:42:50.824+0900 W/CRASH_MANAGER( 3914): worker.c: worker_job(1204) > 110367063616d142193057
