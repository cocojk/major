S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 4943
Date: 2015-01-22 21:50:46+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 4943, uid 5000)

Register Information
r0   = 0x935c7008, r1   = 0x00000001
r2   = 0x001dfc37, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x001dfc37
r6   = 0x001dfc37, r7   = 0xadfe9588
r8   = 0xb75d7378, r9   = 0xadfe9734
r10  = 0xb75dc8d0, fp   = 0x0000000d
ip   = 0xb6743110, sp   = 0xadfe94e8
lr   = 0xb3368c2f, pc   = 0xb6743128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    400612 KB
Buffers:     22052 KB
Cached:     145352 KB
VmPeak:     590676 KB
VmSize:     590672 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       45544 KB
VmRSS:       45544 KB
VmData:     412956 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         286 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 4943 TID = 5143
4943 4945 5129 5130 5131 5132 5141 5142 5143 5144 5145 5146 5147 5148 5149 5150 5152 5153 5154 5156 5157 5158 5159 5160 5161 5162 5163 5164 5165 5166 5167 5168 5169 5170 5171 5172 5173 5174 5175 5176 5177 5179 5180 5181 5183 5184 5187 

Maps Information
93ab1000 942b0000 rwxp [stack:5184]
942b1000 94ab0000 rwxp [stack:5183]
94ab1000 952b0000 rwxp [stack:5187]
99101000 99900000 rwxp [stack:5181]
99901000 9a100000 rwxp [stack:5180]
9c1b7000 9c9b6000 rwxp [stack:5179]
9ca4e000 9d24d000 rwxp [stack:5177]
9d24e000 9da4d000 rwxp [stack:5176]
9da4e000 9e24d000 rwxp [stack:5175]
9e75f000 9ef5e000 rwxp [stack:5174]
9ef5f000 9f75e000 rwxp [stack:5173]
9f75f000 9ff5e000 rwxp [stack:5172]
9ff5f000 a075e000 rwxp [stack:5171]
a075f000 a0f5e000 rwxp [stack:5170]
a0f5f000 a175e000 rwxp [stack:5169]
a175f000 a1f5e000 rwxp [stack:5168]
a1f5f000 a275e000 rwxp [stack:5167]
a275f000 a2f5e000 rwxp [stack:5166]
a2f5f000 a375e000 rwxp [stack:5165]
a375f000 a3f5e000 rwxp [stack:5164]
a3f5f000 a475e000 rwxp [stack:5163]
a475f000 a4f5e000 rwxp [stack:5162]
a4f5f000 a575e000 rwxp [stack:5161]
a575f000 a5f5e000 rwxp [stack:5160]
a5f5f000 a675e000 rwxp [stack:5159]
a6c01000 a7400000 rwxp [stack:5158]
a7401000 a7c00000 rwxp [stack:5157]
a7c01000 a8400000 rwxp [stack:5156]
a8401000 a8c00000 rwxp [stack:5154]
a8c01000 a9400000 rwxp [stack:5153]
a9401000 a9c00000 rwxp [stack:5152]
a9c01000 aa400000 rwxp [stack:5150]
aa401000 aac00000 rwxp [stack:5149]
aac01000 ab400000 rwxp [stack:5148]
ab401000 abc00000 rwxp [stack:5147]
abc01000 ac400000 rwxp [stack:5146]
ac401000 acc00000 rwxp [stack:5145]
ace01000 ad600000 rwxp [stack:5144]
ad7ec000 adfeb000 rwxp [stack:5143]
adfeb000 adfee000 r-xp /usr/lib/libXv.so.1.0.0
adffe000 ae010000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae021000 ae058000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae06a000 ae869000 rwxp [stack:5142]
ae869000 ae886000 r-xp /usr/lib/libAl_Awb_Sp.so
ae88f000 ae892000 r-xp /usr/lib/libdeflicker.so
ae8aa000 ae8c0000 r-xp /usr/lib/libAl_Awb.so
ae8c8000 ae8d2000 r-xp /usr/lib/libcalibration.so
ae8db000 ae8ed000 r-xp /usr/lib/libaf_lib.so
ae8f5000 ae8fb000 r-xp /usr/lib/libspaf.so
ae903000 ae909000 r-xp /usr/lib/liblsc.so
ae912000 ae91e000 r-xp /usr/lib/libae.so
ae926000 ae967000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae9ae000 aea8d000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aeeea000 aeeeb000 r-xp /usr/lib/libcamerahdr.so.0.0.0
aeefb000 aef37000 r-xp /usr/lib/libcamerahal.so.0.0.0
af11d000 af91c000 rwxp [stack:5141]
af925000 af93d000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0501000 b0d00000 rwxp [stack:5132]
b0e92000 b1691000 rwxp [stack:5131]
b1692000 b1e91000 rwxp [stack:5130]
b1e91000 b1e96000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f22000 b1f2a000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f3b000 b1f3c000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f4c000 b1f53000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f77000 b1f78000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f88000 b1f9b000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fef000 b1ff4000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2005000 b2804000 rwxp [stack:5129]
b2804000 b295f000 r-xp /usr/lib/egl/libMali.so
b2974000 b29fd000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a16000 b2ae4000 r-xp /usr/lib/libCOREGL.so.4.0
b2aff000 b2b02000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b12000 b2b1f000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b30000 b2b3a000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b4a000 b2b56000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b67000 b2b6b000 r-xp /usr/lib/libogg.so.0.7.1
b2b7b000 b2b9d000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bad000 b2c91000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2cad000 b2cf0000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d05000 b2d4c000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d5d000 b2d64000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d74000 b2da9000 r-xp /usr/lib/libpulse.so.0.16.2
b2dba000 b2dbd000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2dce000 b2dd1000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2de2000 b2e25000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e36000 b2e3e000 r-xp /usr/lib/libdrm.so.2.4.0
b2e4e000 b2e50000 r-xp /usr/lib/libdri2.so.0.0.0
b2e60000 b2e67000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e77000 b2e82000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e96000 b2e9c000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2ead000 b2eb5000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ec6000 b2ecb000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2edb000 b2ef2000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f02000 b2f22000 r-xp /usr/lib/libexif.so.12.3.3
b2f2e000 b2f36000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f46000 b2f75000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f88000 b2f90000 r-xp /usr/lib/libtbm.so.1.0.0
b2fa0000 b3059000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b306d000 b3074000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b3084000 b30e2000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30f7000 b30fb000 r-xp /usr/lib/libstorage.so.0.1
b310b000 b3112000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3122000 b3131000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b325b000 b325f000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3270000 b3350000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3365000 b336a000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3372000 b3399000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33ac000 b3bab000 rwxp [stack:4945]
b3bab000 b3bad000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dbd000 b3dc6000 r-xp /lib/libnss_files-2.20-2014.11.so
b3dd7000 b3de0000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3df1000 b3e02000 r-xp /lib/libnsl-2.20-2014.11.so
b3e15000 b3e1b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e2c000 b3e46000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e57000 b3e58000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e68000 b3e6a000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e7b000 b3e80000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e90000 b3e93000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ea4000 b3eab000 r-xp /usr/lib/libsensord-share.so
b3ebb000 b3ecc000 r-xp /usr/lib/libsensor.so.1.2.0
b3edd000 b3ee3000 r-xp /usr/lib/libappcore-common.so.1.1
b3f06000 b3f0b000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f21000 b3f23000 r-xp /usr/lib/libXau.so.6.0.0
b3f33000 b3f47000 r-xp /usr/lib/libxcb.so.1.1.0
b3f57000 b3f5e000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f96000 b3f98000 r-xp /usr/lib/libiri.so
b3fa9000 b3fbe000 r-xp /lib/libexpat.so.1.5.2
b3fd0000 b401e000 r-xp /usr/lib/libssl.so.1.0.0
b4033000 b403c000 r-xp /usr/lib/libethumb.so.1.13.0
b404d000 b4050000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4060000 b4217000 r-xp /usr/lib/libcrypto.so.1.0.0
b57ae000 b57b7000 r-xp /usr/lib/libXi.so.6.1.0
b57c8000 b57ca000 r-xp /usr/lib/libXgesture.so.7.0.0
b57da000 b57de000 r-xp /usr/lib/libXtst.so.6.1.0
b57ee000 b57f4000 r-xp /usr/lib/libXrender.so.1.3.0
b5804000 b580a000 r-xp /usr/lib/libXrandr.so.2.2.0
b581a000 b581c000 r-xp /usr/lib/libXinerama.so.1.0.0
b582c000 b582f000 r-xp /usr/lib/libXfixes.so.3.1.0
b5840000 b584b000 r-xp /usr/lib/libXext.so.6.4.0
b585b000 b585d000 r-xp /usr/lib/libXdamage.so.1.1.0
b586d000 b586f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b587f000 b5962000 r-xp /usr/lib/libX11.so.6.3.0
b5975000 b597c000 r-xp /usr/lib/libXcursor.so.1.0.2
b598d000 b59a5000 r-xp /usr/lib/libudev.so.1.6.0
b59a7000 b59aa000 r-xp /lib/libattr.so.1.1.0
b59ba000 b59da000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59db000 b59e0000 r-xp /usr/lib/libffi.so.6.0.2
b59f0000 b5a08000 r-xp /lib/libz.so.1.2.8
b5a18000 b5a1a000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a2a000 b5aff000 r-xp /usr/lib/libxml2.so.2.9.2
b5b14000 b5baf000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bcb000 b5bce000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bde000 b5bf8000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c08000 b5c19000 r-xp /lib/libresolv-2.20-2014.11.so
b5c2d000 b5c44000 r-xp /usr/lib/liblzma.so.5.0.3
b5c54000 b5c56000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c66000 b5c6d000 r-xp /usr/lib/libembryo.so.1.13.0
b5c7d000 b5c95000 r-xp /usr/lib/libpng12.so.0.50.0
b5ca6000 b5cc9000 r-xp /usr/lib/libjpeg.so.8.0.2
b5ce9000 b5cef000 r-xp /lib/librt-2.20-2014.11.so
b5d00000 b5d14000 r-xp /usr/lib/libector.so.1.13.0
b5d25000 b5d3d000 r-xp /usr/lib/liblua-5.1.so
b5d4e000 b5da5000 r-xp /usr/lib/libfreetype.so.6.11.3
b5db9000 b5de1000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5df2000 b5e05000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e16000 b5e50000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e61000 b5ecc000 r-xp /lib/libm-2.20-2014.11.so
b5edd000 b5eea000 r-xp /usr/lib/libeio.so.1.13.0
b5efa000 b5efc000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f0c000 b5f11000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f21000 b5f38000 r-xp /usr/lib/libefreet.so.1.13.0
b5f4a000 b5f6a000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f7a000 b5f9a000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f9c000 b5fa2000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fb2000 b5fb9000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fc9000 b5fd7000 r-xp /usr/lib/libeo.so.1.13.0
b5fe7000 b5ff9000 r-xp /usr/lib/libecore_input.so.1.13.0
b600a000 b600f000 r-xp /usr/lib/libecore_file.so.1.13.0
b601f000 b6037000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6048000 b6065000 r-xp /usr/lib/libeet.so.1.13.0
b607e000 b60c6000 r-xp /usr/lib/libeina.so.1.13.0
b60d7000 b60e7000 r-xp /usr/lib/libefl.so.1.13.0
b60f8000 b61dd000 r-xp /usr/lib/libicuuc.so.51.1
b61fa000 b633a000 r-xp /usr/lib/libicui18n.so.51.1
b6351000 b6389000 r-xp /usr/lib/libecore_x.so.1.13.0
b639b000 b639e000 r-xp /lib/libcap.so.2.21
b63ae000 b63d7000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63e8000 b63ef000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6401000 b6437000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6448000 b6530000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6544000 b65ba000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65cc000 b65cf000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65df000 b65ea000 r-xp /usr/lib/libvconf.so.0.2.45
b65fa000 b65fc000 r-xp /usr/lib/libvasum.so.0.3.1
b660c000 b660e000 r-xp /usr/lib/libttrace.so.1.1
b661e000 b6621000 r-xp /usr/lib/libiniparser.so.0
b6631000 b6654000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6664000 b6669000 r-xp /usr/lib/libxdgmime.so.1.1.0
b667a000 b6691000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66a2000 b66af000 r-xp /usr/lib/libunwind.so.8.0.1
b66e5000 b6809000 r-xp /lib/libc-2.20-2014.11.so
b681e000 b6837000 r-xp /lib/libgcc_s-4.9.so.1
b6847000 b6929000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b693a000 b696e000 r-xp /usr/lib/libdbus-1.so.3.8.11
b697e000 b69b8000 r-xp /usr/lib/libsystemd.so.0.4.0
b69ba000 b6a3a000 r-xp /usr/lib/libedje.so.1.13.0
b6a3d000 b6a5b000 r-xp /usr/lib/libecore.so.1.13.0
b6a7b000 b6bdd000 r-xp /usr/lib/libevas.so.1.13.0
b6c14000 b6c28000 r-xp /lib/libpthread-2.20-2014.11.so
b6c3c000 b6e60000 r-xp /usr/lib/libelementary.so.1.13.0
b6e8e000 b6e92000 r-xp /usr/lib/libsmack.so.1.0.0
b6ea2000 b6ea8000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6eb9000 b6ebb000 r-xp /usr/lib/libdlog.so.0.0.0
b6ecb000 b6ece000 r-xp /usr/lib/libbundle.so.0.1.22
b6ede000 b6ee0000 r-xp /lib/libdl-2.20-2014.11.so
b6ef1000 b6f0a000 r-xp /usr/lib/libaul.so.0.1.0
b6f1c000 b6f1e000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f2f000 b6f33000 r-xp /usr/lib/libsys-assert.so
b6f44000 b6f64000 r-xp /lib/ld-2.20-2014.11.so
b6f75000 b6f7b000 r-xp /usr/bin/launchpad-loader
b7323000 b78c4000 rw-p [heap]
becec000 bed0d000 rwxp [stack]
becec000 bed0d000 rwxp [stack]
End of Maps Information

Callstack Information (PID:4943)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6743128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb3368c2f) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3c2f
 2: (0xb3126abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb30a9865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb640d5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6419f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb641fa8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb641fc81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf92fcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf930459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6898157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c19cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
 [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [LED]LPF Disable
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [CHROMA]START BV=0.137497 Ratio=0.250000
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV= 0.137,x=0.355,y=0.385)
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=0.137504 ,Awb Bv=0.137497 in/out_0
01-22 21:50:43.976+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.286407,GGain=1.000000,BGain=1.292862,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.086+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:340, cur_lum:0, next_index:398, target_lum:62
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.086+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.086+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [LED]LPF Disable
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-1.620,x=0.355,y=0.385)
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-1.620296 ,Awb Bv=-1.620285 in/out_0
01-22 21:50:44.086+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.278168,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.146+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb782f188), gem(56), surface(0xb782f548)
01-22 21:50:44.156+0900 E/EFL     ( 4943): evas_main<4943> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:50:44.196+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:398, cur_lum:0, next_index:456, target_lum:62
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.196+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.196+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [LED]LPF Disable
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.130,x=0.355,y=0.385)
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.129624 ,Awb Bv=-3.129623 in/out_0
01-22 21:50:44.196+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.216+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb789a9c0)
01-22 21:50:44.276+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(56), surface(0xb789a9c0)
01-22 21:50:44.316+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:456, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.316+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.316+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [LED]LPF Enable
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.316+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.326+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.133,x=0.355,y=0.385)
01-22 21:50:44.326+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.326+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.133194 in/out_0
01-22 21:50:44.326+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.336+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x1600003
01-22 21:50:44.356+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb76c4748)
01-22 21:50:44.406+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb7344508)
01-22 21:50:44.436+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.436+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.436+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.146,x=0.355,y=0.385)
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.146042 in/out_0
01-22 21:50:44.436+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.466+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb7344508)
01-22 21:50:44.496+0900 I/ISP_AE  ( 4943): AE_TEST ----------------------change to smooth
01-22 21:50:44.496+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.496+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.496+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.167,x=0.355,y=0.385)
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.167419 in/out_0
01-22 21:50:44.496+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.516+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7816400), gem(56), surface(0xb7344508)
01-22 21:50:44.556+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.556+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.556+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.193,x=0.355,y=0.385)
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.192505 in/out_0
01-22 21:50:44.556+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.566+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb76c4748)
01-22 21:50:44.616+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.616+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.616+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.218,x=0.355,y=0.385)
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.218002 in/out_0
01-22 21:50:44.616+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.646+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb7344508)
01-22 21:50:44.676+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.676+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.676+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.242,x=0.355,y=0.385)
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.241684 in/out_0
01-22 21:50:44.676+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.696+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb76c4748)
01-22 21:50:44.736+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.736+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.736+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.262,x=0.355,y=0.385)
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.262314 in/out_0
01-22 21:50:44.736+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.746+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb7344508)
01-22 21:50:44.796+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.796+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.796+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.279,x=0.355,y=0.385)
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.279312 in/out_0
01-22 21:50:44.796+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.826+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb76c4748)
01-22 21:50:44.856+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.856+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.856+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.293,x=0.355,y=0.385)
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.292633 in/out_0
01-22 21:50:44.856+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.876+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb7344508)
01-22 21:50:44.916+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.916+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.916+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.303,x=0.355,y=0.385)
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.302505 in/out_0
01-22 21:50:44.916+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:44.927+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb76c4748)
01-22 21:50:44.977+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:44.977+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:44.977+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.309,x=0.355,y=0.385)
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.309387 in/out_0
01-22 21:50:44.977+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:45.007+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb7344508)
01-22 21:50:45.037+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.037+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.037+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.314,x=0.355,y=0.385)
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.313812 in/out_0
01-22 21:50:45.037+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:45.057+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb78234f8)
01-22 21:50:45.057+0900 I/MALI    ( 4943): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:50:45.107+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:0, next_index:468, target_lum:62
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.107+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.107+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=00000000 ,(BV=-3.316,x=0.355,y=0.385)
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.316269 in/out_0
01-22 21:50:45.107+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.274048,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:50:45.127+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb78234f8)
01-22 21:50:45.127+0900 I/MALI    ( 4943): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:50:45.157+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:7, next_index:468, target_lum:62
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.157+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.157+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.157+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.80, detect:   0.35,   0.40 CTemp:4808.0
01-22 21:50:45.167+0900 D/alPrinter0( 4943): [HSC]Mix=00000000,Csd=0004667c ,(BV=-3.317,x=0.357,y=0.395)
01-22 21:50:45.167+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:50:45.167+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.317291 in/out_0
01-22 21:50:45.167+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.275513,GGain=1.000000,BGain=1.615707,Dtct=0.356750,0.394958 ,Curr=0.355011,0.385193 ,CTmep: QC=5004, AL= 4769
01-22 21:50:45.177+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb78234f8)
01-22 21:50:45.187+0900 I/MALI    ( 4943): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:50:45.217+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:50, next_index:468, target_lum:62
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.217+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.217+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.217+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.227+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.99, detect:   0.35,   0.39 CTemp:4904.8
01-22 21:50:45.227+0900 D/alPrinter0( 4943): [HSC]Mix=00001eb8,Csd=000b8f3f ,(BV=-3.317,x=0.353,y=0.390)
01-22 21:50:45.227+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:50:45.227+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.317322 in/out_0
01-22 21:50:45.227+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.279953,GGain=1.000000,BGain=1.621460,Dtct=0.352524,0.389999 ,Curr=0.355057,0.385788 ,CTmep: QC=5004, AL= 4769
01-22 21:50:45.257+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb78234f8)
01-22 21:50:45.277+0900 I/ISP_AE  ( 4943): AE_TEST:--------------high----------------T_lum:62, be_lum:50, cur_lum:109
01-22 21:50:45.277+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:109, next_index:468, target_lum:62
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.277+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.277+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.277+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.287+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  1.00, detect:   0.35,   0.39 CTemp:4856.5
01-22 21:50:45.287+0900 D/alPrinter0( 4943): [HSC]Mix=00003d70,Csd=000a357f ,(BV=-3.317,x=0.353,y=0.388)
01-22 21:50:45.287+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:50:45.287+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-3.309956 ,Awb Bv=-3.316681 in/out_0
01-22 21:50:45.287+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.287552,GGain=1.000000,BGain=1.629181,Dtct=0.353058,0.388367 ,Curr=0.354965,0.386597 ,CTmep: QC=5004, AL= 4769
01-22 21:50:45.307+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb78234f8)
01-22 21:50:45.347+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:468, cur_lum:151, next_index:426, target_lum:62
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.347+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.347+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4643.3
01-22 21:50:45.347+0900 D/alPrinter0( 4943): [HSC]Mix=00005c28,Csd=000a8b0a ,(BV=-3.300,x=0.360,y=0.391)
01-22 21:50:45.357+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:50:45.357+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-2.524080 ,Awb Bv=-3.299911 in/out_0
01-22 21:50:45.357+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.294449,GGain=1.000000,BGain=1.636093,Dtct=0.359924,0.391327 ,Curr=0.354874,0.387314 ,CTmep: QC=5006, AL= 4771
01-22 21:50:45.357+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(56), surface(0xb78234f8)
01-22 21:50:45.407+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(57), surface(0xb78234f8)
01-22 21:50:45.427+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x202d98 
01-22 21:50:45.487+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(56), surface(0xb78234f8)
01-22 21:50:45.537+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb78234f8)
01-22 21:50:45.547+0900 I/ISP_AE  ( 4943): FDAE: ->disable, frame_idx=30
01-22 21:50:45.587+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb78234f8)
01-22 21:50:45.617+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 1 -> 4
01-22 21:50:45.617+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 1 -> 4
01-22 21:50:45.617+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:50:45.667+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb78234f8)
01-22 21:50:45.697+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:426, cur_lum:119, next_index:396, target_lum:62
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:45.707+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:45.707+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  1.00, detect:   0.37,   0.39 CTemp:4429.0
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [HSC]Mix=00007ae0,Csd=0003cae8 ,(BV=-3.223,x=0.365,y=0.391)
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-1.572990 ,Awb Bv=-3.223465 in/out_0
01-22 21:50:45.707+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.297623,GGain=1.000000,BGain=1.643585,Dtct=0.365097,0.390869 ,Curr=0.355179,0.388046 ,CTmep: QC=5005, AL= 4770
01-22 21:50:45.717+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(56), surface(0xb78234f8)
01-22 21:50:45.787+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(57), surface(0xb78234f8)
01-22 21:50:45.837+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(56), surface(0xb78234f8)
01-22 21:50:45.887+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(57), surface(0xb78234f8)
01-22 21:50:45.968+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(56), surface(0xb78234f8)
01-22 21:50:45.998+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:396, cur_lum:94, next_index:378, target_lum:62
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:46.008+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:46.008+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.94, detect:   0.35,   0.37 CTemp:4949.6
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [HSC]Mix=00009998,Csd=0002e532 ,(BV=-3.051,x=0.357,y=0.383)
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-1.058417 ,Awb Bv=-3.050583 in/out_0
01-22 21:50:46.008+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.294998,GGain=1.000000,BGain=1.649490,Dtct=0.356689,0.382645 ,Curr=0.355896,0.388580 ,CTmep: QC=5002, AL= 4768
01-22 21:50:46.018+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 4 -> 1
01-22 21:50:46.018+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 4 -> 1
01-22 21:50:46.018+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:50:46.018+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb78234f8)
01-22 21:50:46.068+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(56), surface(0xb78234f8)
01-22 21:50:46.148+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb77bd1c0), gem(57), surface(0xb78234f8)
01-22 21:50:46.198+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(56), surface(0xb78234f8)
01-22 21:50:46.248+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:378, cur_lum:75, next_index:374, target_lum:62
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:46.248+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:46.248+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:46.248+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:46.258+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.92, detect:   0.34,   0.37 CTemp:5217.5
01-22 21:50:46.258+0900 D/alPrinter0( 4943): [HSC]Mix=0000b850,Csd=000309a3 ,(BV=-2.787,x=0.346,y=0.373)
01-22 21:50:46.258+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:3, 0x0000b850,0x0000b850
01-22 21:50:46.258+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-0.914027 ,Awb Bv=-2.787064 in/out_0
01-22 21:50:46.258+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.288666,GGain=1.000000,BGain=1.648102,Dtct=0.346420,0.373230 ,Curr=0.356384,0.388397 ,CTmep: QC=4999, AL= 4765
01-22 21:50:46.278+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7344590), gem(57), surface(0xb74cdd48)
01-22 21:50:46.298+0900 I/ISP_AE  ( 4943): warning call at out of rule!
01-22 21:50:46.328+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb74edc78), gem(56), surface(0xb76f9900)
01-22 21:50:46.338+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x202d98 
01-22 21:50:46.368+0900 I/ISP_AE  ( 4943): AE_TEST:----cur_index:374, cur_lum:65, next_index:374, target_lum:62
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:50:46.368+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [CMD0][if=a6a202a8,Wrap=a6a257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:50:46.368+0900 D/awb_al_cmd0( 4943): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [CALL][0xa6a202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [AIS_WRAP]msiFlash_state=0
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [LOCK]0
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [SuperHighCTemp] Mapin:  0.88, detect:   0.34,   0.36 CTemp:5270.2
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [HSC]Mix=0000d708,Csd=000102c1 ,(BV=-2.470,x=0.347,y=0.372)
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [AlHscWrap_Main]:4, 0x0000d708,0x0000d708
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [AIS_WRAP]In BV=-0.914027 ,Awb Bv=-2.470474 in/out_0
01-22 21:50:46.368+0900 D/alPrinter0( 4943): [AIS_WRAP]RGain=1.282013,GGain=1.000000,BGain=1.636414,Dtct=0.346512,0.372070 ,Curr=0.356094,0.387238 ,CTmep: QC=4999, AL= 4765
01-22 21:50:46.378+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb75811d8), gem(57), surface(0xb7816d48)
01-22 21:50:46.418+0900 I/ISP_AE  ( 4943): ae_state=3
01-22 21:50:46.428+0900 I/ISP_AE  ( 4943): calc_iso=230,real_gain=76,iso=0
01-22 21:50:46.428+0900 I/ISP_AE  ( 4943): calc_iso=230,real_gain=76,iso=0
01-22 21:50:46.458+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7828918), gem(56), surface(0xb781cdd8)
01-22 21:50:46.678+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76cd7b8), gem(57), surface(0xb781cdd8)
01-22 21:50:46.678+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76cdb78), gem(59), surface(0xb781cdd8)
01-22 21:50:46.738+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7828cb8), gem(56), surface(0xb781cdd8)
01-22 21:50:46.798+0900 D/camera  ( 4943): Writing image to file.
01-22 21:50:46.808+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7828478), gem(57), surface(0xb781cdd8)
01-22 21:50:46.858+0900 I/MALI    ( 4943): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb76cc6e0), gem(56), surface(0xb781cdd8)
01-22 21:50:46.918+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:50:46.948+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:50:46.948+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:50:46.958+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:50:46.958+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:50:46.958+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:50:46.958+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:50:46.958+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:50:46.958+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:50:46.958+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1019c38), gem(13), surface(0x10a0168)
01-22 21:50:46.968+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:50:46.968+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:50:46.999+0900 W/CRASH_MANAGER( 5191): worker.c: worker_job(1204) > 110494363616d142193104
