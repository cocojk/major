S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 3953
Date: 2015-01-22 21:43:08+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = (nil)

Register Information
r0   = 0x93250008, r1   = 0x00000001
r2   = 0x0025615b, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0025615b
r6   = 0x0025615b, r7   = 0xad84a578
r8   = 0xb7ff5030, r9   = 0xad84a724
r10  = 0xb7ffad90, fp   = 0x0000000d
ip   = 0xb69f9110, sp   = 0xad84a4d8
lr   = 0xb6fe2d5f, pc   = 0xb69f9128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    419104 KB
Buffers:     20188 KB
Cached:     131744 KB
VmPeak:     595380 KB
VmSize:     594652 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       46032 KB
VmRSS:       46032 KB
VmData:     417768 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       30868 KB
VmPTE:         282 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 3953 TID = 3965
3953 3955 3956 3957 3958 3960 3961 3963 3964 3965 3966 3967 3968 3969 3970 3971 3972 3975 3976 3977 3978 3979 3980 3981 3982 3983 3984 3985 3986 3987 3988 3989 3990 3991 3992 3993 3994 3995 3996 3997 3998 3999 4001 4002 4003 4005 4006 4009 

Maps Information
93827000 94026000 rwxp [stack:4006]
94027000 94826000 rwxp [stack:4005]
94868000 95067000 rwxp [stack:4009]
98f29000 99728000 rwxp [stack:4003]
99729000 99f28000 rwxp [stack:4002]
9be29000 9c628000 rwxp [stack:4001]
9c6c0000 9cebf000 rwxp [stack:3999]
9cec0000 9d6bf000 rwxp [stack:3998]
9d6c0000 9debf000 rwxp [stack:3997]
9e5ab000 9edaa000 rwxp [stack:3996]
9edab000 9f5aa000 rwxp [stack:3995]
9f5ab000 9fdaa000 rwxp [stack:3994]
9fdab000 a05aa000 rwxp [stack:3993]
a05ab000 a0daa000 rwxp [stack:3992]
a0dab000 a15aa000 rwxp [stack:3991]
a15ab000 a1daa000 rwxp [stack:3990]
a1dab000 a25aa000 rwxp [stack:3989]
a25ab000 a2daa000 rwxp [stack:3988]
a2dab000 a35aa000 rwxp [stack:3987]
a35ab000 a3daa000 rwxp [stack:3986]
a3dab000 a45aa000 rwxp [stack:3985]
a484d000 a504c000 rwxp [stack:3984]
a504d000 a584c000 rwxp [stack:3983]
a584d000 a604c000 rwxp [stack:3982]
a604d000 a684c000 rwxp [stack:3980]
a684d000 a704c000 rwxp [stack:3981]
a704d000 a784c000 rwxp [stack:3978]
a784d000 a804c000 rwxp [stack:3979]
a804d000 a884c000 rwxp [stack:3977]
a884d000 a904c000 rwxp [stack:3976]
a904d000 a984c000 rwxp [stack:3975]
a984d000 aa04c000 rwxp [stack:3972]
aa04d000 aa84c000 rwxp [stack:3971]
aa84d000 ab04c000 rwxp [stack:3970]
ab04d000 ab84c000 rwxp [stack:3969]
ab84d000 ac04c000 rwxp [stack:3968]
ac04d000 ac84c000 rwxp [stack:3967]
ac84d000 ad04c000 rwxp [stack:3966]
ad04d000 ad84c000 rwxp [stack:3965]
ad84c000 ad84f000 r-xp /usr/lib/libXv.so.1.0.0
ad85f000 ad871000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad882000 ad8b9000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad8cb000 ae0ca000 rwxp [stack:3964]
ae0ca000 ae0e7000 r-xp /usr/lib/libAl_Awb_Sp.so
ae0f0000 ae0f3000 r-xp /usr/lib/libdeflicker.so
ae10b000 ae121000 r-xp /usr/lib/libAl_Awb.so
ae129000 ae133000 r-xp /usr/lib/libcalibration.so
ae13c000 ae17d000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae1c4000 ae2a3000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae807000 ae819000 r-xp /usr/lib/libaf_lib.so
ae821000 ae827000 r-xp /usr/lib/libspaf.so
ae82f000 ae86b000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae8fe000 af0fd000 rwxp [stack:3963]
af106000 af10c000 r-xp /usr/lib/liblsc.so
af115000 af121000 r-xp /usr/lib/libae.so
afd01000 afd02000 r-xp /usr/lib/libcamerahdr.so.0.0.0
afe01000 b0600000 rwxp [stack:3961]
b0601000 b0e00000 rwxp [stack:3960]
b0f06000 b0f1e000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0ff1000 b17f0000 rwxp [stack:3958]
b17f1000 b1ff0000 rwxp [stack:3957]
b1ff0000 b1ff5000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b2081000 b2089000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b209a000 b209b000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b20ab000 b20b2000 r-xp /usr/lib/libfeedback.so.0.1.4
b20d6000 b20d7000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b20e7000 b20fa000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2255000 b225a000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b226b000 b2a6a000 rwxp [stack:3956]
b2a6a000 b2bc5000 r-xp /usr/lib/egl/libMali.so
b2bda000 b2c63000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2c7c000 b2d4a000 r-xp /usr/lib/libCOREGL.so.4.0
b2d65000 b2d68000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2d78000 b2d85000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2d96000 b2da0000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2db0000 b2dbc000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2dcd000 b2dd6000 r-xp /lib/libnss_files-2.20-2014.11.so
b2de7000 b2df0000 r-xp /lib/libnss_nis-2.20-2014.11.so
b2e01000 b2e12000 r-xp /lib/libnsl-2.20-2014.11.so
b2e25000 b2e2b000 r-xp /lib/libnss_compat-2.20-2014.11.so
b2e3c000 b2e40000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b2e51000 b2f31000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b2f53000 b2f7a000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b2f8d000 b378c000 rwxp [stack:3955]
b378c000 b378e000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b39a5000 b39a9000 r-xp /usr/lib/libogg.so.0.7.1
b39b9000 b39db000 r-xp /usr/lib/libvorbis.so.0.4.3
b39eb000 b3acf000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b3aeb000 b3b2e000 r-xp /usr/lib/libsndfile.so.1.0.25
b3b44000 b3b8b000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b3b9c000 b3ba3000 r-xp /usr/lib/libjson-c.so.2.0.1
b3bb3000 b3bb5000 r-xp /usr/lib/libXau.so.6.0.0
b3bc6000 b3bfb000 r-xp /usr/lib/libpulse.so.0.16.2
b3c0c000 b3c0f000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b3c20000 b3c23000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b3c34000 b3c77000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b3c89000 b3c8e000 r-xp /usr/lib/libffi.so.6.0.2
b3c9e000 b3d73000 r-xp /usr/lib/libxml2.so.2.9.2
b3d88000 b3d8f000 r-xp /usr/lib/libsensord-share.so
b3d9f000 b3da2000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b3db3000 b3dcd000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b3ddd000 b3df7000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e08000 b3e1d000 r-xp /lib/libexpat.so.1.5.2
b3e2f000 b3e7d000 r-xp /usr/lib/libssl.so.1.0.0
b3e93000 b3e9c000 r-xp /usr/lib/libethumb.so.1.13.0
b3eac000 b3eaf000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b3ebf000 b3ed7000 r-xp /lib/libz.so.1.2.8
b3ee7000 b409e000 r-xp /usr/lib/libcrypto.so.1.0.0
b5636000 b56d1000 r-xp /usr/lib/libstdc++.so.6.0.20
b56ed000 b56f6000 r-xp /usr/lib/libXi.so.6.1.0
b5706000 b5708000 r-xp /usr/lib/libXgesture.so.7.0.0
b5718000 b571c000 r-xp /usr/lib/libXtst.so.6.1.0
b572c000 b5732000 r-xp /usr/lib/libXrender.so.1.3.0
b5742000 b5748000 r-xp /usr/lib/libXrandr.so.2.2.0
b5759000 b575b000 r-xp /usr/lib/libXinerama.so.1.0.0
b576b000 b576e000 r-xp /usr/lib/libXfixes.so.3.1.0
b577e000 b5789000 r-xp /usr/lib/libXext.so.6.4.0
b5799000 b579b000 r-xp /usr/lib/libXdamage.so.1.1.0
b57ab000 b57ad000 r-xp /usr/lib/libXcomposite.so.1.0.0
b57be000 b57c5000 r-xp /usr/lib/libXcursor.so.1.0.2
b57d5000 b57ed000 r-xp /usr/lib/libudev.so.1.6.0
b57ef000 b5803000 r-xp /usr/lib/libxcb.so.1.1.0
b5813000 b5815000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5825000 b582c000 r-xp /usr/lib/libembryo.so.1.13.0
b583d000 b584e000 r-xp /lib/libresolv-2.20-2014.11.so
b5862000 b5879000 r-xp /usr/lib/liblzma.so.5.0.3
b5889000 b5891000 r-xp /usr/lib/libdrm.so.2.4.0
b58a1000 b58a3000 r-xp /usr/lib/libdri2.so.0.0.0
b58b3000 b58b5000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b58c6000 b58cd000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b58dd000 b58e8000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b58fc000 b5902000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5913000 b591b000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b592c000 b5931000 r-xp /usr/lib/libmmfsession.so.0.0.0
b5942000 b5959000 r-xp /usr/lib/libmmfsound.so.0.1.0
b5969000 b5989000 r-xp /usr/lib/libexif.so.12.3.3
b5995000 b599d000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b59ad000 b59dc000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b59ef000 b5a25000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b5a37000 b5b1f000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b5b33000 b5ba9000 r-xp /usr/lib/libsqlite3.so.0.8.6
b5bbb000 b5bbe000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5bce000 b5bd0000 r-xp /usr/lib/libvasum.so.0.3.1
b5be0000 b5be3000 r-xp /usr/lib/libiniparser.so.0
b5bf3000 b5bf7000 r-xp /usr/lib/libsmack.so.1.0.0
b5c07000 b5c0c000 r-xp /usr/lib/libxdgmime.so.1.1.0
b5c1d000 b5c34000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5c45000 b5c56000 r-xp /usr/lib/libsensor.so.1.2.0
b5c67000 b5c9b000 r-xp /usr/lib/libdbus-1.so.3.8.11
b5cab000 b5cad000 r-xp /usr/lib/libttrace.so.1.1
b5cbd000 b5ce0000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b5cf0000 b5cf3000 r-xp /usr/lib/libbundle.so.0.1.22
b5d03000 b5d04000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b5d14000 b5d16000 r-xp /usr/lib/libappsvc.so.0.1.0
b5d26000 b5d3e000 r-xp /usr/lib/libpng12.so.0.50.0
b5d4f000 b5d72000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d92000 b5da6000 r-xp /usr/lib/libector.so.1.13.0
b5db7000 b5dcf000 r-xp /usr/lib/liblua-5.1.so
b5de0000 b5e37000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e4b000 b5e73000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e84000 b5e97000 r-xp /usr/lib/libfribidi.so.0.3.1
b5ea8000 b5ee2000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ef3000 b5f00000 r-xp /usr/lib/libeio.so.1.13.0
b5f10000 b5f12000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f22000 b5f27000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f37000 b5f4e000 r-xp /usr/lib/libefreet.so.1.13.0
b5f60000 b5f80000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f90000 b5fb0000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fb2000 b5fb8000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fc8000 b5fcf000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fdf000 b5ff1000 r-xp /usr/lib/libecore_input.so.1.13.0
b6002000 b6007000 r-xp /usr/lib/libecore_file.so.1.13.0
b6017000 b602f000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6040000 b605d000 r-xp /usr/lib/libeet.so.1.13.0
b6076000 b615b000 r-xp /usr/lib/libicuuc.so.51.1
b6178000 b62b8000 r-xp /usr/lib/libicui18n.so.51.1
b62cf000 b6307000 r-xp /usr/lib/libecore_x.so.1.13.0
b6319000 b63fc000 r-xp /usr/lib/libX11.so.6.3.0
b640f000 b648f000 r-xp /usr/lib/libedje.so.1.13.0
b6492000 b64fd000 r-xp /lib/libm-2.20-2014.11.so
b650e000 b6514000 r-xp /lib/librt-2.20-2014.11.so
b6525000 b655f000 r-xp /usr/lib/libsystemd.so.0.4.0
b6561000 b656f000 r-xp /usr/lib/libeo.so.1.13.0
b657f000 b658f000 r-xp /usr/lib/libefl.so.1.13.0
b65a0000 b6682000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6693000 b669e000 r-xp /usr/lib/libvconf.so.0.2.45
b66ae000 b66b6000 r-xp /usr/lib/libtbm.so.1.0.0
b66c6000 b677f000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b6793000 b679a000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b67aa000 b6808000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b681d000 b6865000 r-xp /usr/lib/libeina.so.1.13.0
b6876000 b688f000 r-xp /usr/lib/libaul.so.0.1.0
b68a1000 b68a7000 r-xp /usr/lib/libappcore-common.so.1.1
b68b7000 b68bc000 r-xp /usr/lib/libappcore-efl.so.1.1
b68cc000 b68ce000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b68df000 b68e4000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b68f4000 b68f6000 r-xp /lib/libdl-2.20-2014.11.so
b6907000 b6914000 r-xp /usr/lib/libunwind.so.8.0.1
b694a000 b695e000 r-xp /lib/libpthread-2.20-2014.11.so
b6972000 b698b000 r-xp /lib/libgcc_s-4.9.so.1
b699b000 b6abf000 r-xp /lib/libc-2.20-2014.11.so
b6ad4000 b6ad8000 r-xp /usr/lib/libstorage.so.0.1
b6ae8000 b6c4a000 r-xp /usr/lib/libevas.so.1.13.0
b6c81000 b6ea5000 r-xp /usr/lib/libelementary.so.1.13.0
b6ed3000 b6eda000 r-xp /usr/lib/libefl-extension.so.0.1.0
b6eea000 b6f08000 r-xp /usr/lib/libecore.so.1.13.0
b6f28000 b6f2a000 r-xp /usr/lib/libdlog.so.0.0.0
b6f3a000 b6f49000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b6f59000 b6f60000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6f72000 b6f75000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b6f99000 b6f9d000 r-xp /usr/lib/libsys-assert.so
b6fae000 b6fce000 r-xp /lib/ld-2.20-2014.11.so
b6fdf000 b6fe4000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b7d4a000 b82e4000 rw-p [heap]
beab1000 bead2000 rwxp [stack]
beab1000 bead2000 rwxp [stack]
End of Maps Information

Callstack Information (PID:3953)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb69f9128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb6 (0xb6fe2d5f) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d5f
 2: (0xb6f3eabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb67cf865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb59fb5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb5a07f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb5a0da8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb5a0dc81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xb0f10cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xb0f11459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb65f1157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb694fcf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
/CAPI_APPFW_APPLICATION( 3859): app_main.c: _ui_app_appcore_terminate(662) > app_appcore_terminate
01-22 21:43:04.127+0900 D/TASK_MGR( 3859): main.c: _terminate_cb(234) > 
01-22 21:43:04.127+0900 D/TASK_MGR( 3859): list.c: list_destroy(356) > 
01-22 21:43:04.127+0900 D/TASK_MGR( 3859): list.c: _destroy_pkginfo_table(270) > 
01-22 21:43:04.127+0900 E/APP_CORE( 3859): appcore.c: appcore_flush_memory(798) > Appcore not initialized
01-22 21:43:04.127+0900 E/TASK_MGR( 3859): item.c: item_destroy(652) > cannot get the object
01-22 21:43:04.137+0900 I/APP_CORE( 3953): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
01-22 21:43:04.137+0900 I/APP_CORE( 3953): appcore-efl.c: __do_app(614) > [APP 3953] Initial Launching, call the resume_cb
01-22 21:43:04.137+0900 I/CAPI_APPFW_APPLICATION( 3953): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-22 21:43:04.137+0900 D/LAUNCH  ( 3953): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-22 21:43:04.137+0900 D/LAUNCH  ( 3953): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-22 21:43:04.137+0900 D/APP_CORE( 3953): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-22 21:43:04.137+0900 E/APP_CORE( 3953): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-22 21:43:04.147+0900 E/EFL     ( 3859): eo<3859> lib/eo/eo_ptr_indirection.x:294 _eo_obj_pointer_get() obj_id 0x8001188d is not pointing to a valid object. Maybe it has already been freed.
01-22 21:43:04.147+0900 E/EFL     ( 3859): eo<3859> lib/eo/eo.c:485 _eo_do_internal() Obj (0x8001188d) is an invalid ref.
01-22 21:43:04.147+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x04200007), visible:1
01-22 21:43:04.147+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_wininfo_del(169) > [PROCESSMGR] delete anr_confirm_timer!
01-22 21:43:04.177+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
01-22 21:43:04.177+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
01-22 21:43:04.217+0900 I/MALI    ( 3859): egl_platform_x11.c: __egl_platform_terminate(333) > [EGL-X11] ################################################
01-22 21:43:04.217+0900 I/MALI    ( 3859): egl_platform_x11.c: __egl_platform_terminate(334) > [EGL-X11] PID=3859   close drm_fd=31 
01-22 21:43:04.217+0900 I/MALI    ( 3859): egl_platform_x11.c: __egl_platform_terminate(335) > [EGL-X11] ################################################
01-22 21:43:04.227+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xf9c4c8), gem(22), surface(0x104c300)
01-22 21:43:04.257+0900 D/RESOURCED(  870): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
01-22 21:43:04.257+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
01-22 21:43:04.257+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 3953
01-22 21:43:04.257+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 3953, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-22 21:43:04.257+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 3953
01-22 21:43:04.277+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2906) > pid(3953) status(0)
01-22 21:43:04.297+0900 D/AUL_AMD (  819): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.camera /opt/usr/apps/org.example.camera/bin/camera
01-22 21:43:04.297+0900 D/RUA     (  819): rua.c: rua_add_history(179) > rua_add_history start
01-22 21:43:04.307+0900 D/RUA     (  819): rua.c: rua_add_history(247) > rua_add_history ok
01-22 21:43:04.357+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 3953, appname = org.example.camera, pkgname = org.example.camera
01-22 21:43:04.357+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 3953, appname = org.example.camera
01-22 21:43:04.357+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 3953
01-22 21:43:04.357+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 3953 foreground
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-22 21:43:04.457+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-22 21:43:04.457+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 3859 pgid = 3859
01-22 21:43:04.457+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(141) > dead_pid(3859)
01-22 21:43:04.487+0900 D/AUL_PAD (  958): sigchild.h: __send_app_dead_signal(90) > send dead signal done
01-22 21:43:04.487+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
01-22 21:43:04.487+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
01-22 21:43:04.487+0900 E/AUL_PAD (  958): launchpad.c: main(688) > error reading sigchld info
01-22 21:43:04.487+0900 I/ESD     (  993): esd_main.c: __esd_app_dead_handler(1771) > pid: 3859
01-22 21:43:04.487+0900 D/STARTER (  872): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 3859 is termianted
01-22 21:43:04.487+0900 D/STARTER (  872): starter.c: _check_dead_signal(202) > [_check_dead_signal:202] Unknown process, ignore it
01-22 21:43:04.487+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 3859
01-22 21:43:04.487+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 3859
01-22 21:43:04.487+0900 D/AUL_AMD (  819): amd_key.c: _unregister_key_event(179) > ===key stack===
01-22 21:43:04.487+0900 E/AUL_AMD (  819): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
01-22 21:43:04.487+0900 D/AUL_AMD (  819): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.tizen.task-mgr)
01-22 21:43:04.487+0900 D/AUL     (  819): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
01-22 21:43:04.487+0900 E/AUL     (  819): simple_util.c: __trm_app_info_send_socket(330) > access
01-22 21:43:04.497+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 3859
01-22 21:43:04.497+0900 D/RESOURCED(  870): appinfo-list.c: resourced_appinfo_put(132) > appid org.tizen.task-mgr, pkgname = org.tizen.task-mgr, ref = 0
01-22 21:43:05.678+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xfc6680), gem(21), surface(0x104c300)
01-22 21:43:05.759+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x2017d7 
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): tunnig_param=263480
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): param_num=3
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): cur target lum=62, ev diff=0, level=4
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): AE VERSION : 0x20150828-00
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): cvg speed=0
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): target lum=62, target lum zone=8
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): lime time=134, min line=1
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): target_lum_ev0=62
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): highcount=19,lowcount=15
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): FDAE: failed open fdae_param.txt
01-22 21:43:06.019+0900 I/ISP_AE  ( 3953): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:43:06.019+0900 D/alPrinter0( 3953): LSC Size:20 16
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [LSC]TableSize=   320
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [LSC]TableSize=   320
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [LSC]TableSize=   320
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [OTP]module has otp data 0xb0e17054 (nil) 20 16
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [LSC]TableSize=   320
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [LSC]TableSize=   320
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:43:06.019+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): work_mode=0 last mode=0
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): cvg speed=0
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): target lum=62, target lum zone=8
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): lime time=134, min line=1
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): target_lum_ev0=62
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): highcount=19,lowcount=15
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): is_quick=0
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): AE_TEST:-----------SET index:282
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:43:06.139+0900 I/ISP_AE  ( 3953): AE_TEST:-----------SET index:282
01-22 21:43:06.149+0900 I/ISP_AE  ( 3953): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:43:06.159+0900 I/ISP_AE  ( 3953): calc_iso=50,real_gain=19,iso=0
01-22 21:43:06.429+0900 I/ISP_AE  ( 3953): set_weight, table[0] = 1
01-22 21:43:06.429+0900 I/ISP_AE  ( 3953): set weight from 1 to 0, rtn=0
01-22 21:43:06.429+0900 I/ISP_AE  ( 3953): AE_TEST ----------------------change to fast
01-22 21:43:06.429+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:282, cur_lum:12, next_index:318, target_lum:62
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,84,a8,00,00,00,00
01-22 21:43:06.429+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,84,a8,00,00,00,00
01-22 21:43:06.429+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LineAdj] Mode -2147483647
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LineAdj]Tar RGB 557,733,473
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LineAdj]Ref RGB 557,750,487
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LED]LPF Disable
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.57, detect:   0.33,   0.37 CTemp:5458.0
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [CHROMA]START BV=0.810333 Ratio=1.000000
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [HSC]Mix=00000000,Csd=0001460e ,(BV= 0.810,x=0.337,y=0.370)
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=0.810338 ,Awb Bv=0.810333 in/out_0
01-22 21:43:06.429+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.325882,GGain=1.000000,BGain=1.457306,Dtct=0.337006,0.370026 ,Curr=0.337006,0.370026 ,CTmep: QC=5696, AL= 5330
01-22 21:43:06.529+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:318, cur_lum:32, next_index:332, target_lum:62
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:06.529+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:06.529+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [LED]LPF Disable
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.76, detect:   0.33,   0.36 CTemp:5647.4
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [HSC]Mix=00001eb8,Csd=000265ea ,(BV= 0.427,x=0.332,y=0.364)
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=0.427010 ,Awb Bv=0.427002 in/out_0
01-22 21:43:06.529+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.328827,GGain=1.000000,BGain=1.402664,Dtct=0.332123,0.364380 ,Curr=0.332123,0.364380 ,CTmep: QC=5904, AL= 5509
01-22 21:43:06.599+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(44), surface(0xb821a748)
01-22 21:43:06.609+0900 E/EFL     ( 3953): evas_main<3953> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:43:06.609+0900 I/MALI    ( 3953): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:43:06.619+0900 I/MALI    ( 3953): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:43:06.629+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:332, cur_lum:40, next_index:340, target_lum:62
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:06.639+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:06.639+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [LED]LPF Disable
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.84, detect:   0.33,   0.36 CTemp:5627.0
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [HSC]Mix=00003d70,Csd=0002996c ,(BV= 0.137,x=0.331,y=0.361)
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=0.137504 ,Awb Bv=0.137497 in/out_0
01-22 21:43:06.639+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.317322,GGain=1.000000,BGain=1.372681,Dtct=0.330521,0.360992 ,Curr=0.330521,0.360992 ,CTmep: QC=5974, AL= 5571
01-22 21:43:06.649+0900 I/MALI    ( 3953): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:43:06.669+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8219088), gem(47), surface(0xb81ef2d0)
01-22 21:43:06.689+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb821a5f0), gem(44), surface(0xb81f1a70)
01-22 21:43:06.709+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:340, cur_lum:39, next_index:348, target_lum:62
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:06.719+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:06.719+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [LED]LPF Enable
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.83, detect:   0.33,   0.36 CTemp:5612.5
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [HSC]Mix=00005c28,Csd=0002d4ca ,(BV= 0.133,x=0.331,y=0.362)
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.103505 ,Awb Bv=0.132660 in/out_0
01-22 21:43:06.719+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.317429,GGain=1.000000,BGain=1.372803,Dtct=0.331299,0.362030 ,Curr=0.330521,0.361008 ,CTmep: QC=5975, AL= 5572
01-22 21:43:06.750+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8219088), gem(47), surface(0xb821a728)
01-22 21:43:06.760+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x1600003
01-22 21:43:06.800+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb821a5f0), gem(44), surface(0xb81ef6d0)
01-22 21:43:06.810+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:348, cur_lum:53, next_index:349, target_lum:62
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:06.820+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:06.820+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.36 CTemp:5593.5
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [HSC]Mix=00007ae0,Csd=00025510 ,(BV= 0.115,x=0.331,y=0.358)
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.130985 ,Awb Bv=0.114868 in/out_0
01-22 21:43:06.820+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.316879,GGain=1.000000,BGain=1.372696,Dtct=0.330582,0.358231 ,Curr=0.330566,0.360992 ,CTmep: QC=5974, AL= 5571
01-22 21:43:06.850+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(47), surface(0xb821a728)
01-22 21:43:06.900+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb821a5f0), gem(44), surface(0xb81dc600)
01-22 21:43:06.910+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:349, cur_lum:54, next_index:350, target_lum:62
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:06.920+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:06.920+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5562.9
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [HSC]Mix=00009998,Csd=0000d186 ,(BV= 0.083,x=0.331,y=0.357)
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.184424 ,Awb Bv=0.083191 in/out_0
01-22 21:43:06.920+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.315231,GGain=1.000000,BGain=1.371323,Dtct=0.330856,0.357483 ,Curr=0.330597,0.360825 ,CTmep: QC=5974, AL= 5571
01-22 21:43:06.950+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8222b38), gem(47), surface(0xb8221690)
01-22 21:43:06.980+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb821a5f0), gem(44), surface(0xb821a728)
01-22 21:43:07.010+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:350, cur_lum:57, next_index:351, target_lum:62
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.020+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.020+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5544.4
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [HSC]Mix=0000accb,Csd=000099e7 ,(BV= 0.042,x=0.331,y=0.357)
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x0000accb,0x0000accb
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=0.041931 in/out_0
01-22 21:43:07.020+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.311432,GGain=1.000000,BGain=1.368210,Dtct=0.331467,0.356979 ,Curr=0.330673,0.360443 ,CTmep: QC=5973, AL= 5570
01-22 21:43:07.040+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(47), surface(0xb821a728)
01-22 21:43:07.070+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef7a0), gem(44), surface(0xb821a728)
01-22 21:43:07.110+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:351, cur_lum:60, next_index:351, target_lum:62
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.110+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.110+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.110+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.120+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.35 CTemp:5546.5
01-22 21:43:07.120+0900 D/alPrinter0( 3953): [HSC]Mix=0000bffe,Csd=ffffd237 ,(BV=-0.004,x=0.331,y=0.355)
01-22 21:43:07.120+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x0000bffe,0x0000bffe
01-22 21:43:07.120+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=-0.004288 in/out_0
01-22 21:43:07.120+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.306686,GGain=1.000000,BGain=1.363663,Dtct=0.330658,0.355057 ,Curr=0.330704,0.359894 ,CTmep: QC=5973, AL= 5570
01-22 21:43:07.120+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb81ef6d0)
01-22 21:43:07.160+0900 I/ISP_AE  ( 3953): AE_TEST ----------------------change to smooth
01-22 21:43:07.160+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:351, cur_lum:60, next_index:351, target_lum:62
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.160+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.160+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.160+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.170+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.35 CTemp:5555.9
01-22 21:43:07.170+0900 D/alPrinter0( 3953): [HSC]Mix=0000bffe,Csd=ffff8f75 ,(BV=-0.050,x=0.331,y=0.356)
01-22 21:43:07.170+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x0000bffe,0x0000bffe
01-22 21:43:07.170+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=-0.050476 in/out_0
01-22 21:43:07.170+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.300201,GGain=1.000000,BGain=1.357819,Dtct=0.331039,0.355560 ,Curr=0.330780,0.359177 ,CTmep: QC=5972, AL= 5569
01-22 21:43:07.200+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef7a0), gem(44), surface(0xb81ef6d0)
01-22 21:43:07.210+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:351, cur_lum:60, next_index:351, target_lum:62
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.210+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.210+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.210+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.220+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.90, detect:   0.33,   0.36 CTemp:5549.6
01-22 21:43:07.220+0900 D/alPrinter0( 3953): [HSC]Mix=0000b5c1,Csd=ffffdd26 ,(BV=-0.093,x=0.330,y=0.355)
01-22 21:43:07.220+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x0000b5c1,0x0000b5c1
01-22 21:43:07.220+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=-0.092957 in/out_0
01-22 21:43:07.220+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.294098,GGain=1.000000,BGain=1.351746,Dtct=0.330414,0.354980 ,Curr=0.330795,0.358429 ,CTmep: QC=5971, AL= 5568
01-22 21:43:07.220+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb81ef6d0)
01-22 21:43:07.260+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:351, cur_lum:59, next_index:351, target_lum:62
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.260+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.260+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.260+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.270+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.92, detect:   0.33,   0.36 CTemp:5554.5
01-22 21:43:07.270+0900 D/alPrinter0( 3953): [HSC]Mix=0000b5c1,Csd=ffff4fea ,(BV=-0.130,x=0.330,y=0.355)
01-22 21:43:07.270+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x0000b5c1,0x0000b5c1
01-22 21:43:07.270+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=-0.129639 in/out_0
01-22 21:43:07.270+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.287964,GGain=1.000000,BGain=1.345322,Dtct=0.329788,0.354599 ,Curr=0.330780,0.357635 ,CTmep: QC=5970, AL= 5567
01-22 21:43:07.300+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef7a0), gem(44), surface(0xb81ef6d0)
01-22 21:43:07.310+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:351, cur_lum:59, next_index:351, target_lum:62
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.310+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.310+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.310+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.320+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5554.5
01-22 21:43:07.320+0900 D/alPrinter0( 3953): [HSC]Mix=0000a28e,Csd=ffff964a ,(BV=-0.160,x=0.330,y=0.355)
01-22 21:43:07.320+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x0000a28e,0x0000a28e
01-22 21:43:07.320+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=-0.159637 in/out_0
01-22 21:43:07.320+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.283066,GGain=1.000000,BGain=1.339676,Dtct=0.330185,0.355225 ,Curr=0.330719,0.356934 ,CTmep: QC=5970, AL= 5567
01-22 21:43:07.320+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb81ef6d0)
01-22 21:43:07.360+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:351, cur_lum:58, next_index:352, target_lum:62
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.370+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.370+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5568.1
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [HSC]Mix=00009851,Csd=ffffbda8 ,(BV=-0.183,x=0.330,y=0.356)
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x00009851,0x00009851
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.235955 ,Awb Bv=-0.183487 in/out_0
01-22 21:43:07.370+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.279480,GGain=1.000000,BGain=1.330566,Dtct=0.330231,0.355637 ,Curr=0.330597,0.356308 ,CTmep: QC=5971, AL= 5568
01-22 21:43:07.400+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(44), surface(0xb821a728)
01-22 21:43:07.430+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb821a728)
01-22 21:43:07.470+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:352, cur_lum:59, next_index:352, target_lum:62
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.470+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.470+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5587.4
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [HSC]Mix=00009851,Csd=ffffe9a6 ,(BV=-0.202,x=0.330,y=0.356)
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x00009851,0x00009851
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.235955 ,Awb Bv=-0.202469 in/out_0
01-22 21:43:07.470+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.279510,GGain=1.000000,BGain=1.330566,Dtct=0.329971,0.355972 ,Curr=0.330597,0.356308 ,CTmep: QC=5971, AL= 5568
01-22 21:43:07.510+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82190a0), gem(44), surface(0xb81f1a70)
01-22 21:43:07.510+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:352, cur_lum:59, next_index:352, target_lum:62
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.510+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.510+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.510+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.520+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.92, detect:   0.33,   0.36 CTemp:5582.9
01-22 21:43:07.520+0900 D/alPrinter0( 3953): [HSC]Mix=00009851,Csd=0000b9a6 ,(BV=-0.217,x=0.330,y=0.356)
01-22 21:43:07.520+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x00009851,0x00009851
01-22 21:43:07.520+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.235955 ,Awb Bv=-0.217316 in/out_0
01-22 21:43:07.520+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.279556,GGain=1.000000,BGain=1.330566,Dtct=0.329987,0.356186 ,Curr=0.330597,0.356308 ,CTmep: QC=5972, AL= 5569
01-22 21:43:07.540+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef330), gem(47), surface(0xb821ac28)
01-22 21:43:07.560+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:352, cur_lum:57, next_index:353, target_lum:62
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.570+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.570+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.91, detect:   0.33,   0.36 CTemp:5550.4
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [HSC]Mix=0000ab84,Csd=0000bff5 ,(BV=-0.229,x=0.331,y=0.358)
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:4, 0x0000ab84,0x0000ab84
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.261046 ,Awb Bv=-0.228851 in/out_0
01-22 21:43:07.570+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.276962,GGain=1.000000,BGain=1.327438,Dtct=0.331421,0.357880 ,Curr=0.330536,0.355896 ,CTmep: QC=5972, AL= 5569
01-22 21:43:07.590+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x2017d7 
01-22 21:43:07.620+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8222758), gem(44), surface(0xb7e72170)
01-22 21:43:07.630+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(55), surface(0xb8221160)
01-22 21:43:07.660+0900 I/ISP_AE  ( 3953): AE_TEST:----cur_index:353, cur_lum:56, next_index:354, target_lum:62
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:43:07.670+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [CMD0][if=b0e20d00,Wrap=b0e26230]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:43:07.670+0900 D/awb_al_cmd0( 3953): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [CALL][0xb0e20d00][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [AIS_WRAP]msiFlash_state=0
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [LOCK]0
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [SuperHighCTemp] Mapin:  0.92, detect:   0.33,   0.36 CTemp:5508.2
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [HSC]Mix=0000beb7,Csd=ffffe560 ,(BV=-0.239,x=0.332,y=0.357)
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [AlHscWrap_Main]:3, 0x0000beb7,0x0000beb7
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [AIS_WRAP]In BV=-0.309955 ,Awb Bv=-0.239304 in/out_0
01-22 21:43:07.670+0900 D/alPrinter0( 3953): [AIS_WRAP]RGain=1.275848,GGain=1.000000,BGain=1.326172,Dtct=0.331665,0.356949 ,Curr=0.330521,0.355728 ,CTmep: QC=5973, AL= 5570
01-22 21:43:07.680+0900 I/ISP_AE  ( 3953): FDAE: ->disable, frame_idx=30
01-22 21:43:07.680+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef330), gem(44), surface(0xb7e72170)
01-22 21:43:07.700+0900 I/ISP_AE  ( 3953): ae_state=3
01-22 21:43:07.730+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(47), surface(0xb821ac10)
01-22 21:43:07.781+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(44), surface(0xb821ac10)
01-22 21:43:07.841+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8222758), gem(47), surface(0xb7ff26b0)
01-22 21:43:07.901+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef330), gem(44), surface(0xb7e72170)
01-22 21:43:07.941+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8222758), gem(47), surface(0xb8222ff8)
01-22 21:43:07.991+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(44), surface(0xb7e72170)
01-22 21:43:08.041+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e72d18), gem(47), surface(0xb8222c40)
01-22 21:43:08.091+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ef330), gem(44), surface(0xb7e72170)
01-22 21:43:08.141+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb8222ff8)
01-22 21:43:08.191+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(44), surface(0xb7e72170)
01-22 21:43:08.241+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb7ff26b0)
01-22 21:43:08.291+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(44), surface(0xb7e72170)
01-22 21:43:08.341+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb7ff26b0)
01-22 21:43:08.391+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(44), surface(0xb7e72170)
01-22 21:43:08.441+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(47), surface(0xb7ff26b0)
01-22 21:43:08.491+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb82464a8), gem(44), surface(0xb7e72170)
01-22 21:43:08.531+0900 I/ISP_AE  ( 3953): calc_iso=180,real_gain=60,iso=0
01-22 21:43:08.531+0900 I/ISP_AE  ( 3953): calc_iso=180,real_gain=60,iso=0
01-22 21:43:08.541+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822bc08), gem(47), surface(0xb7e72170)
01-22 21:43:08.741+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8228fa8), gem(44), surface(0xb7e72170)
01-22 21:43:08.751+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8229368), gem(55), surface(0xb7ff26b0)
01-22 21:43:08.802+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8229270), gem(44), surface(0xb7e72170)
01-22 21:43:08.852+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8228fa8), gem(47), surface(0xb8247638)
01-22 21:43:08.852+0900 D/camera  ( 3953): Writing image to file.
01-22 21:43:08.902+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81edf98), gem(44), surface(0xb7e72170)
01-22 21:43:08.922+0900 I/MALI    ( 3953): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822b968), gem(47), surface(0xb8247638)
01-22 21:43:08.962+0900 W/CRASH_MANAGER( 3914): worker.c: worker_job(1204) > 110395363616d142193058
