S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2918
Date: 2015-01-22 21:37:49+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2918, uid 5000)

Register Information
r0   = 0x9391b008, r1   = 0x00000001
r2   = 0x002398e7, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x002398e7
r6   = 0x002398e7, r7   = 0xadffa588
r8   = 0xb7af7350, r9   = 0xadffa734
r10  = 0xb7afc8a8, fp   = 0x0000000d
ip   = 0xb6755110, sp   = 0xadffa4f0
lr   = 0xb337ad37, pc   = 0xb6755128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    426560 KB
Buffers:     18740 KB
Cached:     129532 KB
VmPeak:     587384 KB
VmSize:     587380 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       46116 KB
VmRSS:       46116 KB
VmData:     409664 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         284 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 2918 TID = 3117
2918 2920 3106 3107 3108 3109 3115 3116 3117 3118 3119 3120 3121 3122 3123 3124 3125 3126 3127 3130 3131 3132 3133 3134 3135 3136 3137 3138 3139 3140 3141 3142 3143 3144 3145 3146 3147 3148 3149 3150 3151 3153 3154 3155 3157 3158 3161 

Maps Information
93eb8000 946b7000 rwxp [stack:3158]
946b8000 94eb7000 rwxp [stack:3157]
98dba000 995b9000 rwxp [stack:3155]
995ba000 99db9000 rwxp [stack:3154]
99dba000 9a5b9000 rwxp [stack:3153]
9c4ba000 9ccb9000 rwxp [stack:3161]
9cd51000 9d550000 rwxp [stack:3151]
9d551000 9dd50000 rwxp [stack:3150]
9dd51000 9e550000 rwxp [stack:3149]
9eb5f000 9f35e000 rwxp [stack:3148]
9f35f000 9fb5e000 rwxp [stack:3147]
9fb5f000 a035e000 rwxp [stack:3146]
a035f000 a0b5e000 rwxp [stack:3145]
a0b5f000 a135e000 rwxp [stack:3144]
a135f000 a1b5e000 rwxp [stack:3143]
a1b5f000 a235e000 rwxp [stack:3142]
a235f000 a2b5e000 rwxp [stack:3141]
a2b5f000 a335e000 rwxp [stack:3140]
a335f000 a3b5e000 rwxp [stack:3139]
a3b5f000 a435e000 rwxp [stack:3138]
a435f000 a4b5e000 rwxp [stack:3137]
a4b5f000 a535e000 rwxp [stack:3136]
a535f000 a5b5e000 rwxp [stack:3135]
a5b5f000 a635e000 rwxp [stack:3134]
a635f000 a6b5e000 rwxp [stack:3133]
a6e01000 a7600000 rwxp [stack:3132]
a7601000 a7e00000 rwxp [stack:3131]
a7e01000 a8600000 rwxp [stack:3130]
a8601000 a8e00000 rwxp [stack:3127]
a8e01000 a9600000 rwxp [stack:3126]
a9601000 a9e00000 rwxp [stack:3125]
a9e01000 aa600000 rwxp [stack:3124]
aa601000 aae00000 rwxp [stack:3123]
aae01000 ab600000 rwxp [stack:3122]
ab601000 abe00000 rwxp [stack:3121]
abe01000 ac600000 rwxp [stack:3120]
ac601000 ace00000 rwxp [stack:3119]
ace01000 ad600000 rwxp [stack:3118]
ad7fd000 adffc000 rwxp [stack:3117]
adffc000 adfff000 r-xp /usr/lib/libXv.so.1.0.0
ae00f000 ae021000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae032000 ae069000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae07b000 ae87a000 rwxp [stack:3116]
ae87a000 ae897000 r-xp /usr/lib/libAl_Awb_Sp.so
ae8a0000 ae8a3000 r-xp /usr/lib/libdeflicker.so
ae8bb000 ae8d1000 r-xp /usr/lib/libAl_Awb.so
ae8d9000 ae8e3000 r-xp /usr/lib/libcalibration.so
ae8ec000 ae8fe000 r-xp /usr/lib/libaf_lib.so
ae906000 ae90c000 r-xp /usr/lib/libspaf.so
ae914000 ae91a000 r-xp /usr/lib/liblsc.so
ae923000 ae92f000 r-xp /usr/lib/libae.so
ae937000 ae978000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae9bf000 aea9e000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aeefb000 aef37000 r-xp /usr/lib/libcamerahal.so.0.0.0
af10a000 af10b000 r-xp /usr/lib/libcamerahdr.so.0.0.0
af11c000 af91b000 rwxp [stack:3115]
af925000 af93d000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0501000 b0d00000 rwxp [stack:3109]
b0ea4000 b16a3000 rwxp [stack:3108]
b16a4000 b1ea3000 rwxp [stack:3107]
b1ea3000 b1ea8000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f34000 b1f3c000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f4d000 b1f4e000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f5e000 b1f65000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f89000 b1f8a000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f9a000 b1fad000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2001000 b2006000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2017000 b2816000 rwxp [stack:3106]
b2816000 b2971000 r-xp /usr/lib/egl/libMali.so
b2986000 b2a0f000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a28000 b2af6000 r-xp /usr/lib/libCOREGL.so.4.0
b2b11000 b2b14000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b24000 b2b31000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b42000 b2b4c000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b5c000 b2b68000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b79000 b2b7d000 r-xp /usr/lib/libogg.so.0.7.1
b2b8d000 b2baf000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bbf000 b2ca3000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2cbf000 b2d02000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d17000 b2d5e000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d6f000 b2d76000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d86000 b2dbb000 r-xp /usr/lib/libpulse.so.0.16.2
b2dcc000 b2dcf000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2de0000 b2de3000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2df4000 b2e37000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e48000 b2e50000 r-xp /usr/lib/libdrm.so.2.4.0
b2e60000 b2e62000 r-xp /usr/lib/libdri2.so.0.0.0
b2e72000 b2e79000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e89000 b2e94000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2ea8000 b2eae000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2ebf000 b2ec7000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ed8000 b2edd000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2eed000 b2f04000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f14000 b2f34000 r-xp /usr/lib/libexif.so.12.3.3
b2f40000 b2f48000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f58000 b2f87000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f9a000 b2fa2000 r-xp /usr/lib/libtbm.so.1.0.0
b2fb2000 b306b000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b307f000 b3086000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b3096000 b30f4000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3109000 b310d000 r-xp /usr/lib/libstorage.so.0.1
b311d000 b3124000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3134000 b3143000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b326d000 b3271000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3282000 b3362000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3377000 b337c000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3384000 b33ab000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33be000 b3bbd000 rwxp [stack:2920]
b3bbd000 b3bbf000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dcf000 b3dd8000 r-xp /lib/libnss_files-2.20-2014.11.so
b3de9000 b3df2000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e03000 b3e14000 r-xp /lib/libnsl-2.20-2014.11.so
b3e27000 b3e2d000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e3e000 b3e58000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e69000 b3e6a000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e7a000 b3e7c000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e8d000 b3e92000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ea2000 b3ea5000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3eb6000 b3ebd000 r-xp /usr/lib/libsensord-share.so
b3ecd000 b3ede000 r-xp /usr/lib/libsensor.so.1.2.0
b3eef000 b3ef5000 r-xp /usr/lib/libappcore-common.so.1.1
b3f18000 b3f1d000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f33000 b3f35000 r-xp /usr/lib/libXau.so.6.0.0
b3f45000 b3f59000 r-xp /usr/lib/libxcb.so.1.1.0
b3f69000 b3f70000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fa8000 b3faa000 r-xp /usr/lib/libiri.so
b3fbb000 b3fd0000 r-xp /lib/libexpat.so.1.5.2
b3fe2000 b4030000 r-xp /usr/lib/libssl.so.1.0.0
b4045000 b404e000 r-xp /usr/lib/libethumb.so.1.13.0
b405f000 b4062000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4072000 b4229000 r-xp /usr/lib/libcrypto.so.1.0.0
b57c0000 b57c9000 r-xp /usr/lib/libXi.so.6.1.0
b57da000 b57dc000 r-xp /usr/lib/libXgesture.so.7.0.0
b57ec000 b57f0000 r-xp /usr/lib/libXtst.so.6.1.0
b5800000 b5806000 r-xp /usr/lib/libXrender.so.1.3.0
b5816000 b581c000 r-xp /usr/lib/libXrandr.so.2.2.0
b582c000 b582e000 r-xp /usr/lib/libXinerama.so.1.0.0
b583e000 b5841000 r-xp /usr/lib/libXfixes.so.3.1.0
b5852000 b585d000 r-xp /usr/lib/libXext.so.6.4.0
b586d000 b586f000 r-xp /usr/lib/libXdamage.so.1.1.0
b587f000 b5881000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5891000 b5974000 r-xp /usr/lib/libX11.so.6.3.0
b5987000 b598e000 r-xp /usr/lib/libXcursor.so.1.0.2
b599f000 b59b7000 r-xp /usr/lib/libudev.so.1.6.0
b59b9000 b59bc000 r-xp /lib/libattr.so.1.1.0
b59cc000 b59ec000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59ed000 b59f2000 r-xp /usr/lib/libffi.so.6.0.2
b5a02000 b5a1a000 r-xp /lib/libz.so.1.2.8
b5a2a000 b5a2c000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a3c000 b5b11000 r-xp /usr/lib/libxml2.so.2.9.2
b5b26000 b5bc1000 r-xp /usr/lib/libstdc++.so.6.0.20
b5bdd000 b5be0000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bf0000 b5c0a000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c1a000 b5c2b000 r-xp /lib/libresolv-2.20-2014.11.so
b5c3f000 b5c56000 r-xp /usr/lib/liblzma.so.5.0.3
b5c66000 b5c68000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c78000 b5c7f000 r-xp /usr/lib/libembryo.so.1.13.0
b5c8f000 b5ca7000 r-xp /usr/lib/libpng12.so.0.50.0
b5cb8000 b5cdb000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cfb000 b5d01000 r-xp /lib/librt-2.20-2014.11.so
b5d12000 b5d26000 r-xp /usr/lib/libector.so.1.13.0
b5d37000 b5d4f000 r-xp /usr/lib/liblua-5.1.so
b5d60000 b5db7000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dcb000 b5df3000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e04000 b5e17000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e28000 b5e62000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e73000 b5ede000 r-xp /lib/libm-2.20-2014.11.so
b5eef000 b5efc000 r-xp /usr/lib/libeio.so.1.13.0
b5f0c000 b5f0e000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f1e000 b5f23000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f33000 b5f4a000 r-xp /usr/lib/libefreet.so.1.13.0
b5f5c000 b5f7c000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f8c000 b5fac000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fae000 b5fb4000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fc4000 b5fcb000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fdb000 b5fe9000 r-xp /usr/lib/libeo.so.1.13.0
b5ff9000 b600b000 r-xp /usr/lib/libecore_input.so.1.13.0
b601c000 b6021000 r-xp /usr/lib/libecore_file.so.1.13.0
b6031000 b6049000 r-xp /usr/lib/libecore_evas.so.1.13.0
b605a000 b6077000 r-xp /usr/lib/libeet.so.1.13.0
b6090000 b60d8000 r-xp /usr/lib/libeina.so.1.13.0
b60e9000 b60f9000 r-xp /usr/lib/libefl.so.1.13.0
b610a000 b61ef000 r-xp /usr/lib/libicuuc.so.51.1
b620c000 b634c000 r-xp /usr/lib/libicui18n.so.51.1
b6363000 b639b000 r-xp /usr/lib/libecore_x.so.1.13.0
b63ad000 b63b0000 r-xp /lib/libcap.so.2.21
b63c0000 b63e9000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63fa000 b6401000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6413000 b6449000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b645a000 b6542000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6556000 b65cc000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65de000 b65e1000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65f1000 b65fc000 r-xp /usr/lib/libvconf.so.0.2.45
b660c000 b660e000 r-xp /usr/lib/libvasum.so.0.3.1
b661e000 b6620000 r-xp /usr/lib/libttrace.so.1.1
b6630000 b6633000 r-xp /usr/lib/libiniparser.so.0
b6643000 b6666000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6676000 b667b000 r-xp /usr/lib/libxdgmime.so.1.1.0
b668c000 b66a3000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66b4000 b66c1000 r-xp /usr/lib/libunwind.so.8.0.1
b66f7000 b681b000 r-xp /lib/libc-2.20-2014.11.so
b6830000 b6849000 r-xp /lib/libgcc_s-4.9.so.1
b6859000 b693b000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b694c000 b6980000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6990000 b69ca000 r-xp /usr/lib/libsystemd.so.0.4.0
b69cc000 b6a4c000 r-xp /usr/lib/libedje.so.1.13.0
b6a4f000 b6a6d000 r-xp /usr/lib/libecore.so.1.13.0
b6a8d000 b6bef000 r-xp /usr/lib/libevas.so.1.13.0
b6c26000 b6c3a000 r-xp /lib/libpthread-2.20-2014.11.so
b6c4e000 b6e72000 r-xp /usr/lib/libelementary.so.1.13.0
b6ea0000 b6ea4000 r-xp /usr/lib/libsmack.so.1.0.0
b6eb4000 b6eba000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ecb000 b6ecd000 r-xp /usr/lib/libdlog.so.0.0.0
b6edd000 b6ee0000 r-xp /usr/lib/libbundle.so.0.1.22
b6ef0000 b6ef2000 r-xp /lib/libdl-2.20-2014.11.so
b6f03000 b6f1c000 r-xp /usr/lib/libaul.so.0.1.0
b6f2e000 b6f30000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f41000 b6f45000 r-xp /usr/lib/libsys-assert.so
b6f56000 b6f76000 r-xp /lib/ld-2.20-2014.11.so
b6f87000 b6f8d000 r-xp /usr/bin/launchpad-loader
b7843000 b7e06000 rw-p [heap]
be84d000 be86e000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2918)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6755128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb337ad37) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d37
 2: (0xb3138abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb30bb865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb641f5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb642bf67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb6431a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb6431c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf92fcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf930459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb68aa157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c2bcf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
back_locale_country. [0m
01-22 21:37:44.755+0900 D/LOCKSCREEN( 2819): property.c: lock_property_unregister(254) > [lock_property_unregister:254:D] unregister property cb
01-22 21:37:44.755+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2819): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:37:44.755+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2819): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=17
01-22 21:37:44.755+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2819): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 16, key = 17, type = 2
01-22 21:37:44.755+0900 D/SYSTEM-SETTINGS( 2819): system_setting_platform.c: system_setting_unset_changed_callback_sound_lock(1697) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_sound_lock. [0m
01-22 21:37:44.755+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2819): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:37:44.755+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2819): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=19
01-22 21:37:44.755+0900 E/TIZEN_N_SYSTEM_SETTINGS( 2819): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 18, key = 19, type = 2
01-22 21:37:44.755+0900 D/SYSTEM-SETTINGS( 2819): system_setting_platform.c: system_setting_unset_changed_callback_sound_touch(1810) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_sound_touch. [0m
01-22 21:37:44.775+0900 D/LOCKSCREEN( 2819): dbus.c: lock_dbus_fini(328) > [lock_dbus_fini:328:D] DBUS connection is closed
01-22 21:37:44.775+0900 E/E17_TZSH(  535): policy_tzsh.c: _policy_tzsh_service_destroy(118) > TZSH SERVICE DESTROY.. WIN:b34d37b8, role:118
01-22 21:37:44.775+0900 I/TZSH    (  986): tzsh.c: _tizen_ws_shell_cb_service_remove(56) > INF: Removed service: 'lockscreen'
01-22 21:37:44.775+0900 E/EFL     ( 2819): eo<2819> lib/eo/eo_ptr_indirection.x:294 _eo_obj_pointer_get() obj_id 0x80006433 is not pointing to a valid object. Maybe it has already been freed.
01-22 21:37:44.775+0900 E/EFL     ( 2819): eo<2819> lib/eo/eo.c:485 _eo_do_internal() Obj (0x80006433) is an invalid ref.
01-22 21:37:44.785+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x04c00007), visible:1
01-22 21:37:44.785+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:37:44.785+0900 W/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=2918
01-22 21:37:44.785+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_wininfo_del(160) > [PROCESSMGR] delete anr_trigger_timer!
01-22 21:37:44.785+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 4c00007
01-22 21:37:44.785+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.opaque
01-22 21:37:44.785+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:37:44.785+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:37:44.785+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:37:44.785+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:37:44.795+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:37:44.805+0900 D/APP_CORE( 2918): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:1600003 fully_obscured 0
01-22 21:37:44.805+0900 D/APP_CORE( 2918): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
01-22 21:37:44.805+0900 D/APP_CORE( 2918): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
01-22 21:37:44.805+0900 I/APP_CORE( 2918): appcore-efl.c: __do_app(496) > [APP 2918] Event: RESUME State: CREATED
01-22 21:37:44.805+0900 D/LAUNCH  ( 2918): appcore-efl.c: __do_app(597) > [camera:Application:resume:start]
01-22 21:37:44.805+0900 D/APP_CORE( 2918): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
01-22 21:37:44.805+0900 D/APP_CORE( 2918): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-22 21:37:44.805+0900 D/APP_CORE( 2918): appcore-efl.c: __do_app(607) > [APP 2918] RESUME
01-22 21:37:44.815+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(2918) status(3)
01-22 21:37:44.815+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:37:44.815+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:37:44.815+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:37:44.815+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(2918) status(3)
01-22 21:37:44.815+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(2918) appid(org.example.camera) pkgid(org.example.camera) status(3)
01-22 21:37:44.815+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.camera
01-22 21:37:44.815+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 2918, appid: org.example.camera, status: fg
01-22 21:37:44.815+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 2918
01-22 21:37:44.815+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 2918, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-22 21:37:44.815+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 2918
01-22 21:37:44.825+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(838) > __request_handler: 15
01-22 21:37:44.825+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:37:44.825+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:37:44.835+0900 D/AUL_AMD (  819): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 2918 is org.example.camera
01-22 21:37:44.835+0900 D/AUL     ( 1005): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
01-22 21:37:44.835+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 2918 : 0
01-22 21:37:44.835+0900 I/APP_CORE( 2918): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
01-22 21:37:44.835+0900 I/APP_CORE( 2918): appcore-efl.c: __do_app(614) > [APP 2918] Initial Launching, call the resume_cb
01-22 21:37:44.835+0900 I/CAPI_APPFW_APPLICATION( 2918): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-22 21:37:44.835+0900 D/LAUNCH  ( 2918): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-22 21:37:44.835+0900 D/LAUNCH  ( 2918): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-22 21:37:44.835+0900 D/APP_CORE( 2918): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-22 21:37:44.835+0900 E/APP_CORE( 2918): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-22 21:37:44.845+0900 I/MALI    ( 2819): egl_platform_x11.c: __egl_platform_terminate(333) > [EGL-X11] ################################################
01-22 21:37:44.845+0900 I/MALI    ( 2819): egl_platform_x11.c: __egl_platform_terminate(334) > [EGL-X11] PID=2819   close drm_fd=31 
01-22 21:37:44.845+0900 I/MALI    ( 2819): egl_platform_x11.c: __egl_platform_terminate(335) > [EGL-X11] ################################################
01-22 21:37:44.875+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 2918, appname = org.example.camera, pkgname = org.example.camera
01-22 21:37:44.875+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 2918, appname = org.example.camera
01-22 21:37:44.875+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 2918
01-22 21:37:44.875+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 2918 foreground
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-22 21:37:45.016+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-22 21:37:45.016+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 2819 pgid = 2819
01-22 21:37:45.016+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(141) > dead_pid(2819)
01-22 21:37:45.046+0900 D/AUL_PAD (  958): sigchild.h: __send_app_dead_signal(90) > send dead signal done
01-22 21:37:45.046+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
01-22 21:37:45.046+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
01-22 21:37:45.046+0900 E/AUL_PAD (  958): launchpad.c: main(688) > error reading sigchld info
01-22 21:37:45.046+0900 I/ESD     (  993): esd_main.c: __esd_app_dead_handler(1771) > pid: 2819
01-22 21:37:45.046+0900 D/STARTER (  872): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 2819 is termianted
01-22 21:37:45.046+0900 D/STARTER (  872): starter.c: _check_dead_signal(199) > [_check_dead_signal:199] lockscreen is dead
01-22 21:37:45.046+0900 E/STARTER (  872): lock_pwd_util.c: lock_pwd_util_win_visible_get(71) > [lock_pwd_util_win_visible_get:71] (!s_lock_pwd_util.lock_pwd_win) -> lock_pwd_util_win_visible_get() return
01-22 21:37:45.046+0900 D/STARTER (  872): lock_mgr.c: lock_mgr_unlock(339) > [lock_mgr_unlock:339] pwd win visible(0), lock type(1)
01-22 21:37:45.046+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 2819
01-22 21:37:45.046+0900 D/STARTER (  872): lock_mgr.c: lock_mgr_idle_lock_state_set(253) > [lock_mgr_idle_lock_state_set:253] lock state : 0
01-22 21:37:45.046+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 2819
01-22 21:37:45.046+0900 D/AUL_AMD (  819): amd_key.c: _unregister_key_event(179) > ===key stack===
01-22 21:37:45.046+0900 E/AUL_AMD (  819): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
01-22 21:37:45.046+0900 D/AUL_AMD (  819): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.tizen.lockscreen)
01-22 21:37:45.046+0900 D/AUL     (  819): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
01-22 21:37:45.046+0900 E/AUL     (  819): simple_util.c: __trm_app_info_send_socket(330) > access
01-22 21:37:45.046+0900 D/INDICATOR(  893): util.c: util_signal_emit(84) > [SECURE_LOG] util_signal_emit[84]	 "emission clock.font.12"
01-22 21:37:45.056+0900 W/STARTER (  872): window_mgr.c: _pwd_transient_unset(159) > [_pwd_transient_unset:159] 0x4c00007 is not transient
01-22 21:37:45.056+0900 E/RESOURCED(  870): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.313
01-22 21:37:45.066+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 2819
01-22 21:37:45.066+0900 D/RESOURCED(  870): appinfo-list.c: resourced_appinfo_put(132) > appid org.tizen.lockscreen, pkgname = org.tizen.lockscreen, ref = 0
01-22 21:37:45.086+0900 D/VOLUME  (  912): control.c: _idle_lock_state_vconf_changed_cb(810) > [_idle_lock_state_vconf_changed_cb:810] idle lock state : 0
01-22 21:37:45.916+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20110e 
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): tunnig_param=263480
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): param_num=3
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): cur target lum=62, ev diff=0, level=4
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): AE VERSION : 0x20150828-00
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): cvg speed=0
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): target lum=62, target lum zone=8
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): lime time=134, min line=1
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): target_lum_ev0=62
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): highcount=19,lowcount=15
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): FDAE: failed open fdae_param.txt
01-22 21:37:46.187+0900 I/ISP_AE  ( 2918): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:37:46.187+0900 D/alPrinter0( 2918): LSC Size:20 16
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [LSC]TableSize=   320
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [LSC]TableSize=   320
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [LSC]TableSize=   320
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [OTP]module has otp data 0xaf01a14c (nil) 20 16
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [LSC]TableSize=   320
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [LSC]TableSize=   320
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:37:46.187+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): work_mode=0 last mode=0
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): cvg speed=0
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): target lum=62, target lum zone=8
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): lime time=134, min line=1
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): target_lum_ev0=62
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): highcount=19,lowcount=15
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): is_quick=0
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): AE_TEST:-----------SET index:282
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): AE_TEST:-----------SET index:282
01-22 21:37:46.317+0900 I/ISP_AE  ( 2918): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:37:46.337+0900 I/ISP_AE  ( 2918): calc_iso=50,real_gain=19,iso=0
01-22 21:37:46.597+0900 I/ISP_AE  ( 2918): set_weight, table[0] = 1
01-22 21:37:46.597+0900 I/ISP_AE  ( 2918): set weight from 1 to 0, rtn=0
01-22 21:37:46.597+0900 I/ISP_AE  ( 2918): AE_TEST ----------------------change to fast
01-22 21:37:46.597+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:282, cur_lum:2, next_index:332, target_lum:62
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,df,a9,00,00,00,00
01-22 21:37:46.607+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,df,a9,00,00,00,00
01-22 21:37:46.607+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LineAdj] Mode -2147483647
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LineAdj]Tar RGB 557,733,473
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LineAdj]Ref RGB 557,750,487
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LED]LPF Disable
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  0.00, detect:   0.34,   0.39 CTemp:5134.5
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [CHROMA]START BV=0.427002 Ratio=1.000000
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [HSC]Mix=00000000,Csd=00000000 ,(BV= 0.427,x=0.355,y=0.385)
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=0.427010 ,Awb Bv=0.427002 in/out_0
01-22 21:37:46.607+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.304474,GGain=1.000000,BGain=1.613815,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:37:46.707+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:332, cur_lum:9, next_index:376, target_lum:62
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:46.707+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:46.707+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [LED]LPF Disable
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:46.707+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.38 CTemp:4616.8
01-22 21:37:46.717+0900 D/alPrinter0( 2918): [HSC]Mix=00000000,Csd=00097cf2 ,(BV=-0.988,x=0.360,y=0.384)
01-22 21:37:46.717+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:37:46.717+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-0.988028 ,Awb Bv=-0.988022 in/out_0
01-22 21:37:46.717+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.230057,GGain=1.000000,BGain=1.605759,Dtct=0.359604,0.383743 ,Curr=0.359604,0.383743 ,CTmep: QC=4821, AL= 4626
01-22 21:37:46.777+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7dc2928), gem(44), surface(0xb7d4f600)
01-22 21:37:46.777+0900 E/EFL     ( 2918): evas_main<2918> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:37:46.807+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:376, cur_lum:29, next_index:390, target_lum:62
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:46.807+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:46.807+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [LED]LPF Disable
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:46.807+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.38 CTemp:4702.6
01-22 21:37:46.817+0900 D/alPrinter0( 2918): [HSC]Mix=00001eb8,Csd=000b0791 ,(BV=-1.421,x=0.357,y=0.385)
01-22 21:37:46.817+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:3, 0x00001eb8,0x00001eb8
01-22 21:37:46.817+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-1.420987 ,Awb Bv=-1.420975 in/out_0
01-22 21:37:46.817+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.258545,GGain=1.000000,BGain=1.613007,Dtct=0.356995,0.384735 ,Curr=0.356995,0.384735 ,CTmep: QC=4925, AL= 4707
01-22 21:37:46.827+0900 I/MALI    ( 2918): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:37:46.837+0900 I/MALI    ( 2918): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:37:46.847+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(47), surface(0xb7aa9da0)
01-22 21:37:46.847+0900 I/MALI    ( 2918): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:37:46.897+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7cf04b0), gem(44), surface(0xb7aa9da0)
01-22 21:37:46.917+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x1600003
01-22 21:37:46.927+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:390, cur_lum:49, next_index:393, target_lum:62
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:46.927+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:46.927+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [LED]LPF Enable
01-22 21:37:46.927+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:46.937+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4647.2
01-22 21:37:46.937+0900 D/alPrinter0( 2918): [HSC]Mix=00003d70,Csd=0009251f ,(BV=-1.423,x=0.359,y=0.385)
01-22 21:37:46.937+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:4, 0x00003d70,0x00003d70
01-22 21:37:46.937+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-1.498990 ,Awb Bv=-1.422516 in/out_0
01-22 21:37:46.937+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.258255,GGain=1.000000,BGain=1.613037,Dtct=0.358719,0.385284 ,Curr=0.357025,0.384735 ,CTmep: QC=4925, AL= 4707
01-22 21:37:46.947+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7cf04b0), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.008+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2b9a0), gem(44), surface(0xb7d4f600)
01-22 21:37:47.048+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:393, cur_lum:61, next_index:393, target_lum:62
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.048+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.048+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4615.5
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [HSC]Mix=00005c28,Csd=00077e93 ,(BV=-1.428,x=0.360,y=0.386)
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:3, 0x00005c28,0x00005c28
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-1.498990 ,Awb Bv=-1.428070 in/out_0
01-22 21:37:47.048+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.257309,GGain=1.000000,BGain=1.613571,Dtct=0.359772,0.385712 ,Curr=0.357162,0.384781 ,CTmep: QC=4923, AL= 4706
01-22 21:37:47.088+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.108+0900 I/ISP_AE  ( 2918): AE_TEST ----------------------change to smooth
01-22 21:37:47.108+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:393, cur_lum:66, next_index:392, target_lum:62
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.108+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.108+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.108+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.118+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4623.1
01-22 21:37:47.118+0900 D/alPrinter0( 2918): [HSC]Mix=00007ae0,Csd=0006bbf9 ,(BV=-1.437,x=0.359,y=0.386)
01-22 21:37:47.118+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:4, 0x00007ae0,0x00007ae0
01-22 21:37:47.118+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-1.473454 ,Awb Bv=-1.436798 in/out_0
01-22 21:37:47.118+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.255447,GGain=1.000000,BGain=1.614670,Dtct=0.359467,0.385864 ,Curr=0.357437,0.384872 ,CTmep: QC=4923, AL= 4706
01-22 21:37:47.138+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b03cf8), gem(44), surface(0xb7d4f600)
01-22 21:37:47.178+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.228+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:392, cur_lum:95, next_index:374, target_lum:62
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.228+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.228+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.228+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.238+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.38 CTemp:4653.5
01-22 21:37:47.238+0900 D/alPrinter0( 2918): [HSC]Mix=00009998,Csd=0003bdc4 ,(BV=-1.435,x=0.358,y=0.384)
01-22 21:37:47.238+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:3, 0x00009998,0x00009998
01-22 21:37:47.238+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-0.914027 ,Awb Bv=-1.434601 in/out_0
01-22 21:37:47.238+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.255493,GGain=1.000000,BGain=1.614670,Dtct=0.358185,0.383942 ,Curr=0.357437,0.384872 ,CTmep: QC=4921, AL= 4704
01-22 21:37:47.248+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(44), surface(0xb7aa9da0)
01-22 21:37:47.258+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 1 -> 3
01-22 21:37:47.258+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 1 -> 3
01-22 21:37:47.258+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:37:47.308+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.378+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(44), surface(0xb7aa9da0)
01-22 21:37:47.428+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.458+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 3 -> 1
01-22 21:37:47.458+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 3 -> 1
01-22 21:37:47.458+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:37:47.468+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:374, cur_lum:68, next_index:373, target_lum:62
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.478+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.478+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.478+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:4938.9
01-22 21:37:47.478+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b03cf8), gem(44), surface(0xb7aa9da0)
01-22 21:37:47.488+0900 D/alPrinter0( 2918): [HSC]Mix=0000b850,Csd=00018ca9 ,(BV=-1.402,x=0.354,y=0.379)
01-22 21:37:47.488+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:4, 0x0000b850,0x0000b850
01-22 21:37:47.488+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-0.875553 ,Awb Bv=-1.401794 in/out_0
01-22 21:37:47.488+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.253677,GGain=1.000000,BGain=1.614868,Dtct=0.353699,0.378540 ,Curr=0.357651,0.384872 ,CTmep: QC=4920, AL= 4703
01-22 21:37:47.558+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.588+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:373, cur_lum:66, next_index:372, target_lum:62
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.588+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.588+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.588+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.598+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:5008.5
01-22 21:37:47.598+0900 D/alPrinter0( 2918): [HSC]Mix=0000d708,Csd=0000a15c ,(BV=-1.338,x=0.351,y=0.376)
01-22 21:37:47.598+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:3, 0x0000d708,0x0000d708
01-22 21:37:47.598+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-0.836025 ,Awb Bv=-1.338470 in/out_0
01-22 21:37:47.598+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.251373,GGain=1.000000,BGain=1.610413,Dtct=0.351425,0.375778 ,Curr=0.357544,0.384415 ,CTmep: QC=4917, AL= 4701
01-22 21:37:47.608+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(44), surface(0xb7aa9da0)
01-22 21:37:47.688+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.708+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:372, cur_lum:65, next_index:372, target_lum:62
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.708+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.708+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.708+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:4939.1
01-22 21:37:47.718+0900 D/alPrinter0( 2918): [HSC]Mix=0000ea3b,Csd=00002bf4 ,(BV=-1.258,x=0.352,y=0.376)
01-22 21:37:47.718+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:4, 0x0000ea3b,0x0000ea3b
01-22 21:37:47.718+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-0.836025 ,Awb Bv=-1.258240 in/out_0
01-22 21:37:47.718+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.249252,GGain=1.000000,BGain=1.601364,Dtct=0.352219,0.375702 ,Curr=0.357040,0.383499 ,CTmep: QC=4920, AL= 4703
01-22 21:37:47.738+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x20110e 
01-22 21:37:47.738+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(44), surface(0xb7aa9da0)
01-22 21:37:47.768+0900 I/ISP_AE  ( 2918): AE_TEST:----cur_index:372, cur_lum:65, next_index:372, target_lum:62
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:37:47.768+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [CMD0][if=af023db0,Wrap=af0292e0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:37:47.768+0900 D/awb_al_cmd0( 2918): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [CALL][0xaf023db0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [AIS_WRAP]msiFlash_state=0
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [LOCK]0
01-22 21:37:47.768+0900 D/alPrinter0( 2918): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:4945.9
01-22 21:37:47.778+0900 D/alPrinter0( 2918): [HSC]Mix=0000ea3b,Csd=00004178 ,(BV=-1.173,x=0.352,y=0.375)
01-22 21:37:47.778+0900 D/alPrinter0( 2918): [AlHscWrap_Main]:3, 0x0000ea3b,0x0000ea3b
01-22 21:37:47.778+0900 D/alPrinter0( 2918): [AIS_WRAP]In BV=-0.836025 ,Awb Bv=-1.172882 in/out_0
01-22 21:37:47.778+0900 D/alPrinter0( 2918): [AIS_WRAP]RGain=1.246887,GGain=1.000000,BGain=1.589233,Dtct=0.352097,0.375488 ,Curr=0.356293,0.382263 ,CTmep: QC=4921, AL= 4704
01-22 21:37:47.808+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d4efc0), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.818+0900 I/ISP_AE  ( 2918): ae_state=3
01-22 21:37:47.838+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(44), surface(0xb7aa9da0)
01-22 21:37:47.908+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(47), surface(0xb7aa9da0)
01-22 21:37:47.968+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.039+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.089+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d03158), gem(44), surface(0xb7c16bb8)
01-22 21:37:48.139+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ceeee8), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.159+0900 I/ISP_AE  ( 2918): FDAE: ->disable, frame_idx=30
01-22 21:37:48.219+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.269+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.339+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ceeee8), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.389+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.439+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.519+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ceeee8), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.569+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.619+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.699+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ceeee8), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.749+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.819+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d2bb20), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.869+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ceeee8), gem(47), surface(0xb7aa9da0)
01-22 21:37:48.919+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d23088), gem(44), surface(0xb7aa9da0)
01-22 21:37:48.989+0900 I/ISP_AE  ( 2918): calc_iso=220,real_gain=72,iso=0
01-22 21:37:48.989+0900 I/ISP_AE  ( 2918): calc_iso=220,real_gain=72,iso=0
01-22 21:37:49.000+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d09d90), gem(47), surface(0xb7aa9da0)
01-22 21:37:49.230+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d098f0), gem(44), surface(0xb7aa9da0)
01-22 21:37:49.230+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d37d10), gem(52), surface(0xb7aa9da0)
01-22 21:37:49.300+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d37e18), gem(44), surface(0xb7aa9da0)
01-22 21:37:49.340+0900 D/camera  ( 2918): Writing image to file.
01-22 21:37:49.350+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7d37aa8), gem(47), surface(0xb7aa9da0)
01-22 21:37:49.400+0900 I/MALI    ( 2918): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ceeee8), gem(44), surface(0xb7aa9da0)
01-22 21:37:49.450+0900 D/RESOURCED(  870): logging.c: logging_send_signal_to_data(1097) > logging timer callback function start
01-22 21:37:49.450+0900 I/RESOURCED(  870): logging.c: logging_send_signal_to_data(1106) > send signal to logging data thread
01-22 21:37:49.450+0900 D/RESOURCED(  870): logging.c: logging_send_signal_to_update(1177) > logging timer callback function start
01-22 21:37:49.450+0900 I/RESOURCED(  870): logging.c: logging_send_signal_to_update(1186) > send signal to logging update thread
01-22 21:37:49.460+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:37:49.490+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:37:49.490+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:37:49.500+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:37:49.500+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:37:49.500+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:37:49.500+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:37:49.500+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(3)
01-22 21:37:49.500+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-22 21:37:49.500+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-22 21:37:49.500+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: fg
01-22 21:37:49.500+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:37:49.500+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:37:49.500+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:37:49.500+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:37:49.500+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:37:49.500+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:37:49.510+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xef6f20), gem(11), surface(0x1019b68)
01-22 21:37:49.520+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.lockscreen org.tizen.lockscreen 1421929654 158 43 910 2
01-22 21:37:49.520+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421929654 101 18 1161 1
01-22 21:37:49.520+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.homescreen org.tizen.homescreen 1421929656 1071 376 913 1
01-22 21:37:49.520+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.example.camera org.example.camera 1421929657 103 18 1161 2
01-22 21:37:49.520+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_update(576) > org.tizen.task-mgr org.tizen.task-mgr 1421929660 51 15 1401 1
01-22 21:37:49.520+0900 W/CRASH_MANAGER( 3166): worker.c: worker_job(1204) > 110291863616d142193026
