S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2711
Date: 2015-01-22 21:35:45+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2711, uid 5000)

Register Information
r0   = 0x9323e008, r1   = 0x00000001
r2   = 0x0020d44f, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0020d44f
r6   = 0x0020d44f, r7   = 0xad85d588
r8   = 0xb7f446e8, r9   = 0xad85d734
r10  = 0xb7f49c38, fp   = 0x0000000d
ip   = 0xb67b9110, sp   = 0xad85d4f0
lr   = 0xb33ded13, pc   = 0xb67b9128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    430144 KB
Buffers:     18328 KB
Cached:     128416 KB
VmPeak:     595564 KB
VmSize:     594812 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       45924 KB
VmRSS:       45924 KB
VmData:     416584 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         284 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 2711 TID = 2734
2711 2713 2724 2725 2726 2727 2728 2732 2733 2734 2735 2736 2737 2738 2739 2740 2741 2744 2745 2746 2747 2748 2749 2750 2751 2752 2753 2754 2755 2756 2757 2758 2759 2760 2761 2762 2763 2764 2765 2766 2767 2768 2770 2771 2772 2775 2776 2779 

Maps Information
9383a000 94039000 rwxp [stack:2776]
9403a000 94839000 rwxp [stack:2775]
9487b000 9507a000 rwxp [stack:2779]
98f3c000 9973b000 rwxp [stack:2772]
9973c000 99f3b000 rwxp [stack:2771]
9be3c000 9c63b000 rwxp [stack:2770]
9c6d3000 9ced2000 rwxp [stack:2768]
9ced3000 9d6d2000 rwxp [stack:2767]
9d6d3000 9ded2000 rwxp [stack:2766]
9e5be000 9edbd000 rwxp [stack:2765]
9edbe000 9f5bd000 rwxp [stack:2764]
9f5be000 9fdbd000 rwxp [stack:2763]
9fdbe000 a05bd000 rwxp [stack:2762]
a05be000 a0dbd000 rwxp [stack:2761]
a0dbe000 a15bd000 rwxp [stack:2760]
a15be000 a1dbd000 rwxp [stack:2759]
a1dbe000 a25bd000 rwxp [stack:2758]
a25be000 a2dbd000 rwxp [stack:2757]
a2dbe000 a35bd000 rwxp [stack:2756]
a35be000 a3dbd000 rwxp [stack:2755]
a3dbe000 a45bd000 rwxp [stack:2754]
a4860000 a505f000 rwxp [stack:2753]
a5060000 a585f000 rwxp [stack:2752]
a5860000 a605f000 rwxp [stack:2751]
a6060000 a685f000 rwxp [stack:2750]
a6860000 a705f000 rwxp [stack:2749]
a7060000 a785f000 rwxp [stack:2748]
a7860000 a805f000 rwxp [stack:2747]
a8060000 a885f000 rwxp [stack:2746]
a8860000 a905f000 rwxp [stack:2745]
a9060000 a985f000 rwxp [stack:2744]
a9860000 aa05f000 rwxp [stack:2741]
aa060000 aa85f000 rwxp [stack:2740]
aa860000 ab05f000 rwxp [stack:2739]
ab060000 ab85f000 rwxp [stack:2738]
ab860000 ac05f000 rwxp [stack:2737]
ac060000 ac85f000 rwxp [stack:2736]
ac860000 ad05f000 rwxp [stack:2735]
ad060000 ad85f000 rwxp [stack:2734]
ad85f000 ad862000 r-xp /usr/lib/libXv.so.1.0.0
ad872000 ad884000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad895000 ad8cc000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad8de000 ae0dd000 rwxp [stack:2733]
ae0dd000 ae0fa000 r-xp /usr/lib/libAl_Awb_Sp.so
ae103000 ae106000 r-xp /usr/lib/libdeflicker.so
ae11e000 ae134000 r-xp /usr/lib/libAl_Awb.so
ae13c000 ae146000 r-xp /usr/lib/libcalibration.so
ae14f000 ae161000 r-xp /usr/lib/libaf_lib.so
ae169000 ae16f000 r-xp /usr/lib/libspaf.so
ae177000 ae17d000 r-xp /usr/lib/liblsc.so
ae186000 ae192000 r-xp /usr/lib/libae.so
ae19a000 ae1db000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae222000 ae301000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae75e000 ae75f000 r-xp /usr/lib/libcamerahdr.so.0.0.0
ae76f000 ae7ab000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae888000 af087000 rwxp [stack:2732]
af093000 af0ab000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afe01000 b0600000 rwxp [stack:2728]
b0601000 b0e00000 rwxp [stack:2727]
b0f08000 b1707000 rwxp [stack:2726]
b1708000 b1f07000 rwxp [stack:2725]
b1f07000 b1f0c000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f98000 b1fa0000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1fb1000 b1fb2000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1fc2000 b1fc9000 r-xp /usr/lib/libfeedback.so.0.1.4
b1fed000 b1fee000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1ffe000 b2011000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2065000 b206a000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b207b000 b287a000 rwxp [stack:2724]
b287a000 b29d5000 r-xp /usr/lib/egl/libMali.so
b29ea000 b2a73000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a8c000 b2b5a000 r-xp /usr/lib/libCOREGL.so.4.0
b2b75000 b2b78000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b88000 b2b95000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2ba6000 b2bb0000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2bc0000 b2bcc000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2bdd000 b2be1000 r-xp /usr/lib/libogg.so.0.7.1
b2bf1000 b2c13000 r-xp /usr/lib/libvorbis.so.0.4.3
b2c23000 b2d07000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2d23000 b2d66000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d7b000 b2dc2000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2dd3000 b2dda000 r-xp /usr/lib/libjson-c.so.2.0.1
b2dea000 b2e1f000 r-xp /usr/lib/libpulse.so.0.16.2
b2e30000 b2e33000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2e44000 b2e47000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2e58000 b2e9b000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2eac000 b2eb4000 r-xp /usr/lib/libdrm.so.2.4.0
b2ec4000 b2ec6000 r-xp /usr/lib/libdri2.so.0.0.0
b2ed6000 b2edd000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2eed000 b2ef8000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2f0c000 b2f12000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2f23000 b2f2b000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2f3c000 b2f41000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2f51000 b2f68000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f78000 b2f98000 r-xp /usr/lib/libexif.so.12.3.3
b2fa4000 b2fac000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2fbc000 b2feb000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2ffe000 b3006000 r-xp /usr/lib/libtbm.so.1.0.0
b3016000 b30cf000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b30e3000 b30ea000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b30fa000 b3158000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b316d000 b3171000 r-xp /usr/lib/libstorage.so.0.1
b3181000 b3188000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3198000 b31a7000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b32d1000 b32d5000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32e6000 b33c6000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33db000 b33e0000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b33e8000 b340f000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3422000 b3c21000 rwxp [stack:2713]
b3c21000 b3c23000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3e33000 b3e3c000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e4d000 b3e56000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e67000 b3e78000 r-xp /lib/libnsl-2.20-2014.11.so
b3e8b000 b3e91000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3ea2000 b3ebc000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3ecd000 b3ece000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ede000 b3ee0000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ef1000 b3ef6000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3f06000 b3f09000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3f1a000 b3f21000 r-xp /usr/lib/libsensord-share.so
b3f31000 b3f42000 r-xp /usr/lib/libsensor.so.1.2.0
b3f53000 b3f59000 r-xp /usr/lib/libappcore-common.so.1.1
b3f7c000 b3f81000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f97000 b3f99000 r-xp /usr/lib/libXau.so.6.0.0
b3fa9000 b3fbd000 r-xp /usr/lib/libxcb.so.1.1.0
b3fcd000 b3fd4000 r-xp /lib/libcrypt-2.20-2014.11.so
b400c000 b400e000 r-xp /usr/lib/libiri.so
b401f000 b4034000 r-xp /lib/libexpat.so.1.5.2
b4046000 b4094000 r-xp /usr/lib/libssl.so.1.0.0
b40a9000 b40b2000 r-xp /usr/lib/libethumb.so.1.13.0
b40c3000 b40c6000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40d6000 b428d000 r-xp /usr/lib/libcrypto.so.1.0.0
b5824000 b582d000 r-xp /usr/lib/libXi.so.6.1.0
b583e000 b5840000 r-xp /usr/lib/libXgesture.so.7.0.0
b5850000 b5854000 r-xp /usr/lib/libXtst.so.6.1.0
b5864000 b586a000 r-xp /usr/lib/libXrender.so.1.3.0
b587a000 b5880000 r-xp /usr/lib/libXrandr.so.2.2.0
b5890000 b5892000 r-xp /usr/lib/libXinerama.so.1.0.0
b58a2000 b58a5000 r-xp /usr/lib/libXfixes.so.3.1.0
b58b6000 b58c1000 r-xp /usr/lib/libXext.so.6.4.0
b58d1000 b58d3000 r-xp /usr/lib/libXdamage.so.1.1.0
b58e3000 b58e5000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58f5000 b59d8000 r-xp /usr/lib/libX11.so.6.3.0
b59eb000 b59f2000 r-xp /usr/lib/libXcursor.so.1.0.2
b5a03000 b5a1b000 r-xp /usr/lib/libudev.so.1.6.0
b5a1d000 b5a20000 r-xp /lib/libattr.so.1.1.0
b5a30000 b5a50000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a51000 b5a56000 r-xp /usr/lib/libffi.so.6.0.2
b5a66000 b5a7e000 r-xp /lib/libz.so.1.2.8
b5a8e000 b5a90000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5aa0000 b5b75000 r-xp /usr/lib/libxml2.so.2.9.2
b5b8a000 b5c25000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c41000 b5c44000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c54000 b5c6e000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c7e000 b5c8f000 r-xp /lib/libresolv-2.20-2014.11.so
b5ca3000 b5cba000 r-xp /usr/lib/liblzma.so.5.0.3
b5cca000 b5ccc000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5cdc000 b5ce3000 r-xp /usr/lib/libembryo.so.1.13.0
b5cf3000 b5d0b000 r-xp /usr/lib/libpng12.so.0.50.0
b5d1c000 b5d3f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d5f000 b5d65000 r-xp /lib/librt-2.20-2014.11.so
b5d76000 b5d8a000 r-xp /usr/lib/libector.so.1.13.0
b5d9b000 b5db3000 r-xp /usr/lib/liblua-5.1.so
b5dc4000 b5e1b000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e2f000 b5e57000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e68000 b5e7b000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e8c000 b5ec6000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ed7000 b5f42000 r-xp /lib/libm-2.20-2014.11.so
b5f53000 b5f60000 r-xp /usr/lib/libeio.so.1.13.0
b5f70000 b5f72000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f82000 b5f87000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f97000 b5fae000 r-xp /usr/lib/libefreet.so.1.13.0
b5fc0000 b5fe0000 r-xp /usr/lib/libeldbus.so.1.13.0
b5ff0000 b6010000 r-xp /usr/lib/libecore_con.so.1.13.0
b6012000 b6018000 r-xp /usr/lib/libecore_imf.so.1.13.0
b6028000 b602f000 r-xp /usr/lib/libethumb_client.so.1.13.0
b603f000 b604d000 r-xp /usr/lib/libeo.so.1.13.0
b605d000 b606f000 r-xp /usr/lib/libecore_input.so.1.13.0
b6080000 b6085000 r-xp /usr/lib/libecore_file.so.1.13.0
b6095000 b60ad000 r-xp /usr/lib/libecore_evas.so.1.13.0
b60be000 b60db000 r-xp /usr/lib/libeet.so.1.13.0
b60f4000 b613c000 r-xp /usr/lib/libeina.so.1.13.0
b614d000 b615d000 r-xp /usr/lib/libefl.so.1.13.0
b616e000 b6253000 r-xp /usr/lib/libicuuc.so.51.1
b6270000 b63b0000 r-xp /usr/lib/libicui18n.so.51.1
b63c7000 b63ff000 r-xp /usr/lib/libecore_x.so.1.13.0
b6411000 b6414000 r-xp /lib/libcap.so.2.21
b6424000 b644d000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b645e000 b6465000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6477000 b64ad000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b64be000 b65a6000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b65ba000 b6630000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6642000 b6645000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6655000 b6660000 r-xp /usr/lib/libvconf.so.0.2.45
b6670000 b6672000 r-xp /usr/lib/libvasum.so.0.3.1
b6682000 b6684000 r-xp /usr/lib/libttrace.so.1.1
b6694000 b6697000 r-xp /usr/lib/libiniparser.so.0
b66a7000 b66ca000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66da000 b66df000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66f0000 b6707000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6718000 b6725000 r-xp /usr/lib/libunwind.so.8.0.1
b675b000 b687f000 r-xp /lib/libc-2.20-2014.11.so
b6894000 b68ad000 r-xp /lib/libgcc_s-4.9.so.1
b68bd000 b699f000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b69b0000 b69e4000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69f4000 b6a2e000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a30000 b6ab0000 r-xp /usr/lib/libedje.so.1.13.0
b6ab3000 b6ad1000 r-xp /usr/lib/libecore.so.1.13.0
b6af1000 b6c53000 r-xp /usr/lib/libevas.so.1.13.0
b6c8a000 b6c9e000 r-xp /lib/libpthread-2.20-2014.11.so
b6cb2000 b6ed6000 r-xp /usr/lib/libelementary.so.1.13.0
b6f04000 b6f08000 r-xp /usr/lib/libsmack.so.1.0.0
b6f18000 b6f1e000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6f2f000 b6f31000 r-xp /usr/lib/libdlog.so.0.0.0
b6f41000 b6f44000 r-xp /usr/lib/libbundle.so.0.1.22
b6f54000 b6f56000 r-xp /lib/libdl-2.20-2014.11.so
b6f67000 b6f80000 r-xp /usr/lib/libaul.so.0.1.0
b6f92000 b6f94000 r-xp /usr/lib/libappsvc.so.0.1.0
b6fa5000 b6fa9000 r-xp /usr/lib/libsys-assert.so
b6fba000 b6fda000 r-xp /lib/ld-2.20-2014.11.so
b6feb000 b6ff1000 r-xp /usr/bin/launchpad-loader
b7c90000 b8236000 rw-p [heap]
be85c000 be87d000 rwxp [stack]
be85c000 be87d000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2711)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb67b9128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb33ded13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb319cabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb311f865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb64835bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb648ff67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb6495a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb6495c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf09dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf09e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb690e157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c8fcf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
,00,00,00,00,00,00,00
01-22 21:35:43.587+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:43.587+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:43.587+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:43.587+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:43.597+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5414.0
01-22 21:35:43.597+0900 D/alPrinter0( 2711): [HSC]Mix=00008f5a,Csd=0000625c ,(BV= 0.062,x=0.332,y=0.358)
01-22 21:35:43.597+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00008f5a,0x00008f5a
01-22 21:35:43.597+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.184424 ,Awb Bv=0.061523 in/out_0
01-22 21:35:43.597+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.297577,GGain=1.000000,BGain=1.362228,Dtct=0.331955,0.357773 ,Curr=0.331406,0.359665 ,CTmep: QC=5937, AL= 5538
01-22 21:35:43.607+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7efd2f8), gem(44), surface(0xb804fce0)
01-22 21:35:43.647+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f36010), gem(47), surface(0xb804fce0)
01-22 21:35:43.687+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:350, cur_lum:54, next_index:351, target_lum:62
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:43.687+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:43.687+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:43.687+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:43.697+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5397.5
01-22 21:35:43.697+0900 D/alPrinter0( 2711): [HSC]Mix=00008f5a,Csd=00005404 ,(BV= 0.020,x=0.332,y=0.358)
01-22 21:35:43.697+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00008f5a,0x00008f5a
01-22 21:35:43.697+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.210420 ,Awb Bv=0.019913 in/out_0
01-22 21:35:43.697+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.294174,GGain=1.000000,BGain=1.359634,Dtct=0.332382,0.358185 ,Curr=0.331497,0.359344 ,CTmep: QC=5937, AL= 5538
01-22 21:35:43.707+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb804ff80), gem(44), surface(0xb804fce0)
01-22 21:35:43.757+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb804fdb0), gem(47), surface(0xb804fce0)
01-22 21:35:43.787+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:351, cur_lum:55, next_index:352, target_lum:62
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:43.787+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:43.787+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:43.787+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5401.0
01-22 21:35:43.797+0900 D/alPrinter0( 2711): [HSC]Mix=00008f5a,Csd=000095fe ,(BV=-0.025,x=0.332,y=0.358)
01-22 21:35:43.797+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00008f5a,0x00008f5a
01-22 21:35:43.797+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.235955 ,Awb Bv=-0.025253 in/out_0
01-22 21:35:43.797+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.290802,GGain=1.000000,BGain=1.356949,Dtct=0.332184,0.357971 ,Curr=0.331573,0.359009 ,CTmep: QC=5936, AL= 5537
01-22 21:35:43.807+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb804daf0), gem(44), surface(0xb804fce0)
01-22 21:35:43.867+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb804fdb0), gem(47), surface(0xb804fce0)
01-22 21:35:43.887+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:352, cur_lum:56, next_index:353, target_lum:62
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:43.897+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:43.897+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.34,   0.36 CTemp:5382.6
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=00005e12 ,(BV=-0.071,x=0.333,y=0.358)
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.261046 ,Awb Bv=-0.071152 in/out_0
01-22 21:35:43.897+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.287491,GGain=1.000000,BGain=1.354935,Dtct=0.332977,0.358475 ,Curr=0.331711,0.358749 ,CTmep: QC=5936, AL= 5537
01-22 21:35:43.907+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7efd2f8), gem(44), surface(0xb804fce0)
01-22 21:35:43.937+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200f99 
01-22 21:35:43.968+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7efd2f8), gem(47), surface(0xb804fce0)
01-22 21:35:43.988+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:353, cur_lum:57, next_index:354, target_lum:62
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:43.988+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:43.988+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:43.988+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:43.998+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.88, detect:   0.33,   0.36 CTemp:5405.9
01-22 21:35:43.998+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffd16e ,(BV=-0.116,x=0.331,y=0.357)
01-22 21:35:43.998+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:43.998+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.309955 ,Awb Bv=-0.116302 in/out_0
01-22 21:35:43.998+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.284363,GGain=1.000000,BGain=1.352875,Dtct=0.331436,0.356644 ,Curr=0.331833,0.358490 ,CTmep: QC=5934, AL= 5535
01-22 21:35:44.018+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f36010), gem(44), surface(0xb805cbf8)
01-22 21:35:44.058+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb816afe8), gem(47), surface(0xb804fce0)
01-22 21:35:44.088+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:354, cur_lum:58, next_index:355, target_lum:62
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.088+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.088+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.088+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.098+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5406.5
01-22 21:35:44.098+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=00001067 ,(BV=-0.160,x=0.332,y=0.357)
01-22 21:35:44.098+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:44.098+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.160324 in/out_0
01-22 21:35:44.098+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.281387,GGain=1.000000,BGain=1.350723,Dtct=0.331589,0.357071 ,Curr=0.331924,0.358215 ,CTmep: QC=5932, AL= 5534
01-22 21:35:44.108+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f36010), gem(44), surface(0xb804fce0)
01-22 21:35:44.168+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb816afe8), gem(47), surface(0xb804fce0)
01-22 21:35:44.188+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.188+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.188+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.188+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.198+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5418.8
01-22 21:35:44.198+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffe9b5 ,(BV=-0.202,x=0.332,y=0.357)
01-22 21:35:44.198+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:44.198+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.201996 in/out_0
01-22 21:35:44.198+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.279297,GGain=1.000000,BGain=1.348511,Dtct=0.331604,0.356979 ,Curr=0.331924,0.357941 ,CTmep: QC=5930, AL= 5532
01-22 21:35:44.208+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f36010), gem(44), surface(0xb804fce0)
01-22 21:35:44.238+0900 I/ISP_AE  ( 2711): AE_TEST ----------------------change to smooth
01-22 21:35:44.238+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.238+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.238+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.238+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.88, detect:   0.33,   0.36 CTemp:5427.6
01-22 21:35:44.248+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffc82f ,(BV=-0.239,x=0.332,y=0.357)
01-22 21:35:44.248+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:44.248+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.239319 in/out_0
01-22 21:35:44.248+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277405,GGain=1.000000,BGain=1.346283,Dtct=0.331512,0.356720 ,Curr=0.331909,0.357666 ,CTmep: QC=5930, AL= 5532
01-22 21:35:44.258+0900 I/ISP_AE  ( 2711): FDAE: ->disable, frame_idx=30
01-22 21:35:44.278+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb816afe8), gem(47), surface(0xb804fce0)
01-22 21:35:44.288+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.288+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.288+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.288+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5423.6
01-22 21:35:44.298+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffc882 ,(BV=-0.271,x=0.331,y=0.357)
01-22 21:35:44.298+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:44.298+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.270844 in/out_0
01-22 21:35:44.298+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277451,GGain=1.000000,BGain=1.346283,Dtct=0.331436,0.356873 ,Curr=0.331909,0.357666 ,CTmep: QC=5929, AL= 5531
01-22 21:35:44.308+0900 I/MALI    ( 2711): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:35:44.318+0900 I/MALI    ( 2711): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:35:44.318+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8087100), gem(44), surface(0xb7f032d8)
01-22 21:35:44.328+0900 I/MALI    ( 2711): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:35:44.338+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.338+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.338+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.338+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5425.3
01-22 21:35:44.348+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=0000186c ,(BV=-0.296,x=0.332,y=0.357)
01-22 21:35:44.348+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:44.348+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.296112 in/out_0
01-22 21:35:44.348+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277496,GGain=1.000000,BGain=1.346283,Dtct=0.331665,0.357193 ,Curr=0.331909,0.357666 ,CTmep: QC=5928, AL= 5530
01-22 21:35:44.368+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb804c460), gem(47), surface(0xb7ef86e8)
01-22 21:35:44.388+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.388+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.388+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.388+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5427.1
01-22 21:35:44.398+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffa712 ,(BV=-0.315,x=0.331,y=0.357)
01-22 21:35:44.398+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:44.398+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.315353 in/out_0
01-22 21:35:44.398+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277542,GGain=1.000000,BGain=1.346283,Dtct=0.331451,0.357269 ,Curr=0.331909,0.357666 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.408+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200f99 
01-22 21:35:44.418+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f36010), gem(44), surface(0xb7e3a6e0)
01-22 21:35:44.438+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.438+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.438+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.438+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.448+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5427.2
01-22 21:35:44.448+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffafb5 ,(BV=-0.329,x=0.331,y=0.357)
01-22 21:35:44.448+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:44.448+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.329147 in/out_0
01-22 21:35:44.448+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277557,GGain=1.000000,BGain=1.346283,Dtct=0.331284,0.356964 ,Curr=0.331909,0.357666 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.468+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80876c8), gem(47), surface(0xb8080968)
01-22 21:35:44.488+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:59, next_index:355, target_lum:62
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.488+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.488+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.488+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.498+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5424.2
01-22 21:35:44.498+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffc30f ,(BV=-0.338,x=0.331,y=0.357)
01-22 21:35:44.498+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:44.498+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.333802 ,Awb Bv=-0.338379 in/out_0
01-22 21:35:44.498+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277573,GGain=1.000000,BGain=1.346283,Dtct=0.331177,0.356857 ,Curr=0.331909,0.357666 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.518+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb808e610), gem(44), surface(0xb816ae20)
01-22 21:35:44.538+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:355, cur_lum:58, next_index:356, target_lum:62
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.538+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.538+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.538+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.548+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5408.3
01-22 21:35:44.548+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffffe0ef ,(BV=-0.344,x=0.331,y=0.357)
01-22 21:35:44.548+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:44.548+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.357261 ,Awb Bv=-0.344391 in/out_0
01-22 21:35:44.548+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277573,GGain=1.000000,BGain=1.346283,Dtct=0.331360,0.357025 ,Curr=0.331909,0.357666 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.568+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200f99 
01-22 21:35:44.578+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80886f8), gem(47), surface(0xb8052cc8)
01-22 21:35:44.628+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80875a8), gem(44), surface(0xb808e1b0)
01-22 21:35:44.638+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:356, cur_lum:59, next_index:356, target_lum:62
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.638+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.638+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.638+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.648+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5443.8
01-22 21:35:44.648+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=00008cc4 ,(BV=-0.349,x=0.331,y=0.357)
01-22 21:35:44.648+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:44.648+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.357261 ,Awb Bv=-0.348801 in/out_0
01-22 21:35:44.648+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277603,GGain=1.000000,BGain=1.346283,Dtct=0.330994,0.357071 ,Curr=0.331909,0.357666 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.668+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8087488), gem(47), surface(0xb7f032d8)
01-22 21:35:44.688+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:356, cur_lum:58, next_index:357, target_lum:62
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.698+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.698+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5439.7
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=000040f3 ,(BV=-0.353,x=0.331,y=0.357)
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x0000a3d4,0x0000a3d4
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.352783 in/out_0
01-22 21:35:44.698+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.277603,GGain=1.000000,BGain=1.346283,Dtct=0.330994,0.357071 ,Curr=0.331909,0.357666 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.708+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200f99 
01-22 21:35:44.738+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb808b4e8), gem(44), surface(0xb808e1b0)
01-22 21:35:44.778+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb816afe8), gem(47), surface(0xb808e470)
01-22 21:35:44.788+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.788+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.788+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.788+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.798+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5437.9
01-22 21:35:44.798+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=ffffe151 ,(BV=-0.357,x=0.331,y=0.357)
01-22 21:35:44.798+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x0000a3d4,0x0000a3d4
01-22 21:35:44.798+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.357071 in/out_0
01-22 21:35:44.798+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.276260,GGain=1.000000,BGain=1.344284,Dtct=0.330765,0.356720 ,Curr=0.331848,0.357422 ,CTmep: QC=5927, AL= 5529
01-22 21:35:44.798+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8061dc8), gem(44), surface(0xb8066aa8)
01-22 21:35:44.838+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.838+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.838+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.838+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5445.1
01-22 21:35:44.848+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=ffffd0ab ,(BV=-0.362,x=0.331,y=0.356)
01-22 21:35:44.848+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x0000a3d4,0x0000a3d4
01-22 21:35:44.848+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.361679 in/out_0
01-22 21:35:44.848+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.275833,GGain=1.000000,BGain=1.342377,Dtct=0.330521,0.356430 ,Curr=0.331711,0.357193 ,CTmep: QC=5928, AL= 5530
01-22 21:35:44.878+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80886f8), gem(47), surface(0xb8061bc8)
01-22 21:35:44.888+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.888+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.888+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.888+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.898+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5444.4
01-22 21:35:44.898+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=ffffc617 ,(BV=-0.366,x=0.330,y=0.356)
01-22 21:35:44.898+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x0000a3d4,0x0000a3d4
01-22 21:35:44.898+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.366150 in/out_0
01-22 21:35:44.898+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.275635,GGain=1.000000,BGain=1.340424,Dtct=0.330338,0.356232 ,Curr=0.331543,0.356964 ,CTmep: QC=5929, AL= 5531
01-22 21:35:44.898+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8087488), gem(44), surface(0xb8066aa8)
01-22 21:35:44.938+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.938+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.938+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.938+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.948+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5443.9
01-22 21:35:44.948+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=ffffd77a ,(BV=-0.370,x=0.331,y=0.357)
01-22 21:35:44.948+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x0000a3d4,0x0000a3d4
01-22 21:35:44.948+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.370132 in/out_0
01-22 21:35:44.948+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.275650,GGain=1.000000,BGain=1.340424,Dtct=0.330734,0.356659 ,Curr=0.331543,0.356964 ,CTmep: QC=5931, AL= 5533
01-22 21:35:44.948+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8088908), gem(47), surface(0xb8061bc8)
01-22 21:35:44.989+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:44.989+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:44.989+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:44.989+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:44.999+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5440.9
01-22 21:35:44.999+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=ffffa508 ,(BV=-0.374,x=0.331,y=0.357)
01-22 21:35:44.999+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x0000a3d4,0x0000a3d4
01-22 21:35:44.999+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.373520 in/out_0
01-22 21:35:44.999+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.275665,GGain=1.000000,BGain=1.340424,Dtct=0.330734,0.356598 ,Curr=0.331543,0.356964 ,CTmep: QC=5932, AL= 5534
01-22 21:35:44.999+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8065fe8), gem(44), surface(0xb808ad70)
01-22 21:35:45.039+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:61, next_index:357, target_lum:62
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:45.039+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:45.039+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:45.039+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:45.049+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.36 CTemp:5447.3
01-22 21:35:45.049+0900 D/alPrinter0( 2711): [HSC]Mix=0000a3d4,Csd=ffff7d74 ,(BV=-0.376,x=0.331,y=0.357)
01-22 21:35:45.049+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x0000a3d4,0x0000a3d4
01-22 21:35:45.049+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.376205 in/out_0
01-22 21:35:45.049+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.275681,GGain=1.000000,BGain=1.340424,Dtct=0.330765,0.356552 ,Curr=0.331543,0.356964 ,CTmep: QC=5935, AL= 5536
01-22 21:35:45.069+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8088ab8), gem(47), surface(0xb808e468)
01-22 21:35:45.089+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:45.089+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:45.089+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:45.089+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:45.099+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.88, detect:   0.33,   0.36 CTemp:5429.4
01-22 21:35:45.099+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=00001170 ,(BV=-0.378,x=0.330,y=0.356)
01-22 21:35:45.099+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:3, 0x00009997,0x00009997
01-22 21:35:45.099+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.378281 in/out_0
01-22 21:35:45.099+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.276337,GGain=1.000000,BGain=1.338821,Dtct=0.330490,0.355957 ,Curr=0.331329,0.356781 ,CTmep: QC=5937, AL= 5538
01-22 21:35:45.119+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200f99 
01-22 21:35:45.119+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb808afc8), gem(44), surface(0xb808ad70)
01-22 21:35:45.129+0900 I/ISP_AE  ( 2711): warning call at out of rule!
01-22 21:35:45.139+0900 I/ISP_AE  ( 2711): AE_TEST:----cur_index:357, cur_lum:60, next_index:357, target_lum:62
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:35:45.139+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [CMD0][if=afc20dc0,Wrap=afc262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:35:45.139+0900 D/awb_al_cmd0( 2711): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [CALL][0xafc20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [AIS_WRAP]msiFlash_state=0
01-22 21:35:45.139+0900 D/alPrinter0( 2711): [LOCK]0
01-22 21:35:45.149+0900 D/alPrinter0( 2711): [SuperHighCTemp] Mapin:  0.86, detect:   0.33,   0.36 CTemp:5462.9
01-22 21:35:45.149+0900 D/alPrinter0( 2711): [HSC]Mix=00009997,Csd=ffff0e56 ,(BV=-0.380,x=0.331,y=0.357)
01-22 21:35:45.149+0900 D/alPrinter0( 2711): [AlHscWrap_Main]:4, 0x00009997,0x00009997
01-22 21:35:45.149+0900 D/alPrinter0( 2711): [AIS_WRAP]In BV=-0.380345 ,Awb Bv=-0.379761 in/out_0
01-22 21:35:45.149+0900 D/alPrinter0( 2711): [AIS_WRAP]RGain=1.276367,GGain=1.000000,BGain=1.338821,Dtct=0.330795,0.356857 ,Curr=0.331329,0.356781 ,CTmep: QC=5939, AL= 5540
01-22 21:35:45.179+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb816afe8), gem(47), surface(0xb8061c98)
01-22 21:35:45.179+0900 I/ISP_AE  ( 2711): ae_state=3
01-22 21:35:45.199+0900 D/AUL_AMD (  819): amd_status.c: __app_terminate_timer_cb(442) > pid(2617)
01-22 21:35:45.199+0900 W/AUL_AMD (  819): amd_status.c: __app_terminate_timer_cb(446) > send SIGKILL: No such process
01-22 21:35:45.209+0900 I/ISP_AE  ( 2711): calc_iso=190,real_gain=63,iso=0
01-22 21:35:45.209+0900 I/ISP_AE  ( 2711): calc_iso=190,real_gain=63,iso=0
01-22 21:35:45.219+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb808eca0), gem(44), surface(0xb7e3af78)
01-22 21:35:45.489+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8087a68), gem(47), surface(0xb7e3af78)
01-22 21:35:45.499+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8087488), gem(50), surface(0xb7e3af78)
01-22 21:35:45.519+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8088908), gem(44), surface(0xb808b128)
01-22 21:35:45.569+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80889c0), gem(47), surface(0xb7e3af78)
01-22 21:35:45.619+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80875a8), gem(44), surface(0xb808b128)
01-22 21:35:45.639+0900 D/camera  ( 2711): Writing image to file.
01-22 21:35:45.669+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7e3aeb8), gem(47), surface(0xb7e3af78)
01-22 21:35:45.719+0900 I/MALI    ( 2711): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8087a68), gem(44), surface(0xb7e3af78)
01-22 21:35:45.779+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:35:45.799+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:35:45.809+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:35:45.809+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:35:45.809+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:35:45.809+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:35:45.809+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:35:45.809+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:35:45.809+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:35:45.819+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:35:45.819+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:35:45.819+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:35:45.819+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:35:45.819+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(3)
01-22 21:35:45.819+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-22 21:35:45.819+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-22 21:35:45.819+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: fg
01-22 21:35:45.819+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xf67d08), gem(13), surface(0x1001678)
01-22 21:35:45.819+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 913
01-22 21:35:45.819+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 913, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
01-22 21:35:45.819+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 913, appname = org.tizen.homescreen
01-22 21:35:45.819+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 913
01-22 21:35:45.819+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 913 foreground
01-22 21:35:45.839+0900 W/CRASH_MANAGER( 2783): worker.c: worker_job(1204) > 110271163616d142193014
