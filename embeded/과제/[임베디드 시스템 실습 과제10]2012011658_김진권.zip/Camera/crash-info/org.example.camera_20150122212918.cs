S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 1735
Date: 2015-01-22 21:29:18+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 1735, uid 5000)

Register Information
r0   = 0x93444008, r1   = 0x00000001
r2   = 0x0015c0c0, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0015c0c0
r6   = 0x0015c0c0, r7   = 0xad813588
r8   = 0xb8e08840, r9   = 0xad813734
r10  = 0xb8e0f5d8, fp   = 0x0000000d
ip   = 0xb679d110, sp   = 0xad8134f0
lr   = 0xb33c2d13, pc   = 0xb679d128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    419536 KB
Buffers:     17688 KB
Cached:     126356 KB
VmPeak:     592660 KB
VmSize:     592656 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       44972 KB
VmRSS:       44972 KB
VmData:     414940 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         280 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 1735 TID = 1827
1735 1778 1818 1819 1820 1821 1822 1825 1826 1827 1828 1829 1830 1831 1832 1833 1834 1837 1838 1839 1840 1841 1842 1843 1844 1845 1846 1847 1848 1849 1850 1851 1852 1853 1854 1855 1856 1857 1858 1859 1860 1861 1863 1864 1865 1868 1869 1873 

Maps Information
937f0000 93fef000 rwxp [stack:1869]
93ff0000 947ef000 rwxp [stack:1868]
94831000 95030000 rwxp [stack:1873]
98ef2000 996f1000 rwxp [stack:1865]
996f2000 99ef1000 rwxp [stack:1864]
9bdf2000 9c5f1000 rwxp [stack:1863]
9c689000 9ce88000 rwxp [stack:1861]
9ce89000 9d688000 rwxp [stack:1860]
9d689000 9de88000 rwxp [stack:1859]
9e574000 9ed73000 rwxp [stack:1858]
9ed74000 9f573000 rwxp [stack:1857]
9f574000 9fd73000 rwxp [stack:1856]
9fd74000 a0573000 rwxp [stack:1855]
a0574000 a0d73000 rwxp [stack:1854]
a0d74000 a1573000 rwxp [stack:1853]
a1574000 a1d73000 rwxp [stack:1852]
a1d74000 a2573000 rwxp [stack:1851]
a2574000 a2d73000 rwxp [stack:1850]
a2d74000 a3573000 rwxp [stack:1849]
a3574000 a3d73000 rwxp [stack:1848]
a3d74000 a4573000 rwxp [stack:1847]
a4574000 a4d73000 rwxp [stack:1846]
a5016000 a5815000 rwxp [stack:1845]
a5816000 a6015000 rwxp [stack:1844]
a6016000 a6815000 rwxp [stack:1843]
a6816000 a7015000 rwxp [stack:1842]
a7016000 a7815000 rwxp [stack:1841]
a7816000 a8015000 rwxp [stack:1840]
a8016000 a8815000 rwxp [stack:1839]
a8816000 a9015000 rwxp [stack:1838]
a9016000 a9815000 rwxp [stack:1837]
a9816000 aa015000 rwxp [stack:1834]
aa016000 aa815000 rwxp [stack:1833]
aa816000 ab015000 rwxp [stack:1832]
ab016000 ab815000 rwxp [stack:1831]
ab816000 ac015000 rwxp [stack:1830]
ac016000 ac815000 rwxp [stack:1829]
ac816000 ad015000 rwxp [stack:1828]
ad016000 ad815000 rwxp [stack:1827]
ad815000 ad818000 r-xp /usr/lib/libXv.so.1.0.0
ad828000 ad83a000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad84b000 ad882000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad894000 ae093000 rwxp [stack:1826]
ae093000 ae0b0000 r-xp /usr/lib/libAl_Awb_Sp.so
ae0b9000 ae0bc000 r-xp /usr/lib/libdeflicker.so
ae0d4000 ae0ea000 r-xp /usr/lib/libAl_Awb.so
ae0f2000 ae104000 r-xp /usr/lib/libaf_lib.so
ae10c000 ae14d000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae194000 ae273000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae6d0000 ae70c000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae7d6000 aefd5000 rwxp [stack:1825]
aefd5000 aefdf000 r-xp /usr/lib/libcalibration.so
aefe8000 aefee000 r-xp /usr/lib/libspaf.so
aeff6000 aeffc000 r-xp /usr/lib/liblsc.so
af04c000 af058000 r-xp /usr/lib/libae.so
afc01000 afc02000 r-xp /usr/lib/libcamerahdr.so.0.0.0
afd01000 b0500000 rwxp [stack:1822]
b0501000 b0d00000 rwxp [stack:1821]
b0e01000 b0e19000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0eec000 b16eb000 rwxp [stack:1820]
b16ec000 b1eeb000 rwxp [stack:1819]
b1eeb000 b1ef0000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f7c000 b1f84000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f95000 b1f96000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1fa6000 b1fad000 r-xp /usr/lib/libfeedback.so.0.1.4
b1fd1000 b1fd2000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1fe2000 b1ff5000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2049000 b204e000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b205f000 b285e000 rwxp [stack:1818]
b285e000 b29b9000 r-xp /usr/lib/egl/libMali.so
b29ce000 b2a57000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a70000 b2b3e000 r-xp /usr/lib/libCOREGL.so.4.0
b2b59000 b2b5c000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b6c000 b2b79000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b8a000 b2b94000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2ba4000 b2bb0000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2bc1000 b2bc5000 r-xp /usr/lib/libogg.so.0.7.1
b2bd5000 b2bf7000 r-xp /usr/lib/libvorbis.so.0.4.3
b2c07000 b2ceb000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2d07000 b2d4a000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d5f000 b2da6000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2db7000 b2dbe000 r-xp /usr/lib/libjson-c.so.2.0.1
b2dce000 b2e03000 r-xp /usr/lib/libpulse.so.0.16.2
b2e14000 b2e17000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2e28000 b2e2b000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2e3c000 b2e7f000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e90000 b2e98000 r-xp /usr/lib/libdrm.so.2.4.0
b2ea8000 b2eaa000 r-xp /usr/lib/libdri2.so.0.0.0
b2eba000 b2ec1000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2ed1000 b2edc000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2ef0000 b2ef6000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2f07000 b2f0f000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2f20000 b2f25000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2f35000 b2f4c000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f5c000 b2f7c000 r-xp /usr/lib/libexif.so.12.3.3
b2f88000 b2f90000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2fa0000 b2fcf000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2fe2000 b2fea000 r-xp /usr/lib/libtbm.so.1.0.0
b2ffa000 b30b3000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b30c7000 b30ce000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b30de000 b313c000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3151000 b3155000 r-xp /usr/lib/libstorage.so.0.1
b3165000 b316c000 r-xp /usr/lib/libefl-extension.so.0.1.0
b317c000 b318b000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b32b5000 b32b9000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32ca000 b33aa000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33bf000 b33c4000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b33cc000 b33f3000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3406000 b3c05000 rwxp [stack:1778]
b3c05000 b3c07000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3e17000 b3e20000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e31000 b3e3a000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e4b000 b3e5c000 r-xp /lib/libnsl-2.20-2014.11.so
b3e6f000 b3e75000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e86000 b3ea0000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3eb1000 b3eb2000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ec2000 b3ec4000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ed5000 b3eda000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3eea000 b3eed000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3efe000 b3f05000 r-xp /usr/lib/libsensord-share.so
b3f15000 b3f26000 r-xp /usr/lib/libsensor.so.1.2.0
b3f37000 b3f3d000 r-xp /usr/lib/libappcore-common.so.1.1
b3f60000 b3f65000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f7b000 b3f7d000 r-xp /usr/lib/libXau.so.6.0.0
b3f8d000 b3fa1000 r-xp /usr/lib/libxcb.so.1.1.0
b3fb1000 b3fb8000 r-xp /lib/libcrypt-2.20-2014.11.so
b3ff0000 b3ff2000 r-xp /usr/lib/libiri.so
b4003000 b4018000 r-xp /lib/libexpat.so.1.5.2
b402a000 b4078000 r-xp /usr/lib/libssl.so.1.0.0
b408d000 b4096000 r-xp /usr/lib/libethumb.so.1.13.0
b40a7000 b40aa000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40ba000 b4271000 r-xp /usr/lib/libcrypto.so.1.0.0
b5808000 b5811000 r-xp /usr/lib/libXi.so.6.1.0
b5822000 b5824000 r-xp /usr/lib/libXgesture.so.7.0.0
b5834000 b5838000 r-xp /usr/lib/libXtst.so.6.1.0
b5848000 b584e000 r-xp /usr/lib/libXrender.so.1.3.0
b585e000 b5864000 r-xp /usr/lib/libXrandr.so.2.2.0
b5874000 b5876000 r-xp /usr/lib/libXinerama.so.1.0.0
b5886000 b5889000 r-xp /usr/lib/libXfixes.so.3.1.0
b589a000 b58a5000 r-xp /usr/lib/libXext.so.6.4.0
b58b5000 b58b7000 r-xp /usr/lib/libXdamage.so.1.1.0
b58c7000 b58c9000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58d9000 b59bc000 r-xp /usr/lib/libX11.so.6.3.0
b59cf000 b59d6000 r-xp /usr/lib/libXcursor.so.1.0.2
b59e7000 b59ff000 r-xp /usr/lib/libudev.so.1.6.0
b5a01000 b5a04000 r-xp /lib/libattr.so.1.1.0
b5a14000 b5a34000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a35000 b5a3a000 r-xp /usr/lib/libffi.so.6.0.2
b5a4a000 b5a62000 r-xp /lib/libz.so.1.2.8
b5a72000 b5a74000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a84000 b5b59000 r-xp /usr/lib/libxml2.so.2.9.2
b5b6e000 b5c09000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c25000 b5c28000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c38000 b5c52000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c62000 b5c73000 r-xp /lib/libresolv-2.20-2014.11.so
b5c87000 b5c9e000 r-xp /usr/lib/liblzma.so.5.0.3
b5cae000 b5cb0000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5cc0000 b5cc7000 r-xp /usr/lib/libembryo.so.1.13.0
b5cd7000 b5cef000 r-xp /usr/lib/libpng12.so.0.50.0
b5d00000 b5d23000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d43000 b5d49000 r-xp /lib/librt-2.20-2014.11.so
b5d5a000 b5d6e000 r-xp /usr/lib/libector.so.1.13.0
b5d7f000 b5d97000 r-xp /usr/lib/liblua-5.1.so
b5da8000 b5dff000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e13000 b5e3b000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e4c000 b5e5f000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e70000 b5eaa000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ebb000 b5f26000 r-xp /lib/libm-2.20-2014.11.so
b5f37000 b5f44000 r-xp /usr/lib/libeio.so.1.13.0
b5f54000 b5f56000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f66000 b5f6b000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f7b000 b5f92000 r-xp /usr/lib/libefreet.so.1.13.0
b5fa4000 b5fc4000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fd4000 b5ff4000 r-xp /usr/lib/libecore_con.so.1.13.0
b5ff6000 b5ffc000 r-xp /usr/lib/libecore_imf.so.1.13.0
b600c000 b6013000 r-xp /usr/lib/libethumb_client.so.1.13.0
b6023000 b6031000 r-xp /usr/lib/libeo.so.1.13.0
b6041000 b6053000 r-xp /usr/lib/libecore_input.so.1.13.0
b6064000 b6069000 r-xp /usr/lib/libecore_file.so.1.13.0
b6079000 b6091000 r-xp /usr/lib/libecore_evas.so.1.13.0
b60a2000 b60bf000 r-xp /usr/lib/libeet.so.1.13.0
b60d8000 b6120000 r-xp /usr/lib/libeina.so.1.13.0
b6131000 b6141000 r-xp /usr/lib/libefl.so.1.13.0
b6152000 b6237000 r-xp /usr/lib/libicuuc.so.51.1
b6254000 b6394000 r-xp /usr/lib/libicui18n.so.51.1
b63ab000 b63e3000 r-xp /usr/lib/libecore_x.so.1.13.0
b63f5000 b63f8000 r-xp /lib/libcap.so.2.21
b6408000 b6431000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6442000 b6449000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b645b000 b6491000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b64a2000 b658a000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b659e000 b6614000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6626000 b6629000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b6639000 b6644000 r-xp /usr/lib/libvconf.so.0.2.45
b6654000 b6656000 r-xp /usr/lib/libvasum.so.0.3.1
b6666000 b6668000 r-xp /usr/lib/libttrace.so.1.1
b6678000 b667b000 r-xp /usr/lib/libiniparser.so.0
b668b000 b66ae000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66be000 b66c3000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66d4000 b66eb000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66fc000 b6709000 r-xp /usr/lib/libunwind.so.8.0.1
b673f000 b6863000 r-xp /lib/libc-2.20-2014.11.so
b6878000 b6891000 r-xp /lib/libgcc_s-4.9.so.1
b68a1000 b6983000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6994000 b69c8000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69d8000 b6a12000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a14000 b6a94000 r-xp /usr/lib/libedje.so.1.13.0
b6a97000 b6ab5000 r-xp /usr/lib/libecore.so.1.13.0
b6ad5000 b6c37000 r-xp /usr/lib/libevas.so.1.13.0
b6c6e000 b6c82000 r-xp /lib/libpthread-2.20-2014.11.so
b6c96000 b6eba000 r-xp /usr/lib/libelementary.so.1.13.0
b6ee8000 b6eec000 r-xp /usr/lib/libsmack.so.1.0.0
b6efc000 b6f02000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6f13000 b6f15000 r-xp /usr/lib/libdlog.so.0.0.0
b6f25000 b6f28000 r-xp /usr/lib/libbundle.so.0.1.22
b6f38000 b6f3a000 r-xp /lib/libdl-2.20-2014.11.so
b6f4b000 b6f64000 r-xp /usr/lib/libaul.so.0.1.0
b6f76000 b6f78000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f89000 b6f8d000 r-xp /usr/lib/libsys-assert.so
b6f9e000 b6fbe000 r-xp /lib/ld-2.20-2014.11.so
b6fcf000 b6fd5000 r-xp /usr/bin/launchpad-loader
b8b54000 b90fa000 rw-p [heap]
bef41000 bef62000 rwxp [stack]
bef41000 bef62000 rwxp [stack]
End of Maps Information

Callstack Information (PID:1735)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb679d128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb33c2d13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb3180abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3103865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb64675bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6473f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb6479a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb6479c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xb0e0bcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xb0e0c459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb68f2157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c73cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:15.569+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.74, detect:   0.32,   0.34 CTemp:5827.3
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [HSC]Mix=00009998,Csd=fffe0026 ,(BV=-2.753,x=0.324,y=0.354)
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-2.023651 ,Awb Bv=-2.752762 in/out_0
01-22 21:29:15.569+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.294739,GGain=1.000000,BGain=1.567627,Dtct=0.323776,0.353531 ,Curr=0.349060,0.380524 ,CTmep: QC=5023, AL= 4784
01-22 21:29:15.599+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:15.649+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:15.689+0900 I/ISP_AE  ( 1735): AE_TEST:--------------low----------------T_lum:62, be_lum:82, cur_lum:39
01-22 21:29:15.689+0900 I/ISP_AE  ( 1735): AE_TEST:----cur_index:409, cur_lum:39, next_index:409, target_lum:62
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:15.689+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:15.689+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.84, detect:   0.34,   0.36 CTemp:5311.0
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [HSC]Mix=00007ae0,Csd=0004bde5 ,(BV=-2.592,x=0.327,y=0.356)
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-2.023651 ,Awb Bv=-2.591812 in/out_0
01-22 21:29:15.689+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.296967,GGain=1.000000,BGain=1.536118,Dtct=0.327499,0.356262 ,Curr=0.344666,0.375931 ,CTmep: QC=5049, AL= 4805
01-22 21:29:15.699+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:15.749+0900 I/ISP_AE  ( 1735): AE_TEST:----cur_index:409, cur_lum:43, next_index:421, target_lum:62
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:15.749+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:15.749+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.80, detect:   0.34,   0.36 CTemp:5328.2
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [HSC]Mix=00009998,Csd=0004fe61 ,(BV=-2.450,x=0.329,y=0.357)
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-2.394020 ,Awb Bv=-2.450348 in/out_0
01-22 21:29:15.749+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.301895,GGain=1.000000,BGain=1.485565,Dtct=0.328552,0.356812 ,Curr=0.340424,0.371307 ,CTmep: QC=5084, AL= 4832
01-22 21:29:15.769+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:15.819+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:15.869+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:15.949+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb8d2e748)
01-22 21:29:15.989+0900 I/ISP_AE  ( 1735): AE_TEST:----cur_index:421, cur_lum:49, next_index:425, target_lum:62
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:15.989+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:15.989+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.89, detect:   0.34,   0.36 CTemp:5296.7
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [HSC]Mix=0000b850,Csd=0002f398 ,(BV=-2.350,x=0.328,y=0.356)
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:3, 0x0000b850,0x0000b850
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-2.498989 ,Awb Bv=-2.349716 in/out_0
01-22 21:29:15.989+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.305862,GGain=1.000000,BGain=1.443100,Dtct=0.328262,0.356308 ,Curr=0.336716,0.367188 ,CTmep: QC=5120, AL= 4861
01-22 21:29:15.999+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb8d2e748)
01-22 21:29:16.079+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:16.109+0900 I/ISP_AE  ( 1735): AE_TEST:----cur_index:425, cur_lum:62, next_index:425, target_lum:62
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:16.109+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:16.109+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.83, detect:   0.34,   0.36 CTemp:5085.1
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [HSC]Mix=0000d708,Csd=0003f35f ,(BV=-2.295,x=0.334,y=0.358)
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:4, 0x0000d708,0x0000d708
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-2.498989 ,Awb Bv=-2.295029 in/out_0
01-22 21:29:16.109+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.306976,GGain=1.000000,BGain=1.408829,Dtct=0.333527,0.358429 ,Curr=0.333771,0.363693 ,CTmep: QC=5162, AL= 4894
01-22 21:29:16.129+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:16.169+0900 I/ISP_AE  ( 1735): AE_TEST:----cur_index:425, cur_lum:83, next_index:421, target_lum:62
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:16.169+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:16.169+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.78, detect:   0.34,   0.36 CTemp:5234.4
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [HSC]Mix=0000f5c0,Csd=0002ef35 ,(BV=-2.274,x=0.330,y=0.356)
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:3, 0x0000f5c0,0x0000f5c0
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-2.394020 ,Awb Bv=-2.274185 in/out_0
01-22 21:29:16.169+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.305527,GGain=1.000000,BGain=1.382889,Dtct=0.329941,0.355789 ,Curr=0.331680,0.360947 ,CTmep: QC=5203, AL= 4927
01-22 21:29:16.199+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:16.249+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:16.289+0900 I/ISP_AE  ( 1735): AE_TEST:----cur_index:421, cur_lum:132, next_index:387, target_lum:62
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:29:16.289+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:29:16.289+0900 D/awb_al_cmd0( 1735): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [AIS_WRAP]msiFlash_state=0
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [LOCK]0
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [SuperHighCTemp] Mapin:  0.61, detect:   0.33,   0.34 CTemp:5431.9
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [HSC]Mix=00011478,Csd=00000557 ,(BV=-2.251,x=0.325,y=0.349)
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [AlHscWrap_Main]:4, 0x00011478,0x00011478
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [AIS_WRAP]In BV=-1.338525 ,Awb Bv=-2.251328 in/out_0
01-22 21:29:16.289+0900 D/alPrinter0( 1735): [AIS_WRAP]RGain=1.301971,GGain=1.000000,BGain=1.361938,Dtct=0.325256,0.348648 ,Curr=0.330170,0.358658 ,CTmep: QC=5248, AL= 4963
01-22 21:29:16.299+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:16.349+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:16.429+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:16.479+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:16.560+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(49), surface(0xb902faf8)
01-22 21:29:16.590+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200a27 
01-22 21:29:16.630+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b7aa48), gem(47), surface(0xb9029930)
01-22 21:29:16.640+0900 I/ISP_AE  ( 1735): ae_state=3
01-22 21:29:16.660+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb8fb5148)
01-22 21:29:16.730+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:16.780+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(49), surface(0xb8fb5148)
01-22 21:29:16.830+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:16.910+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(49), surface(0xb9029be0)
01-22 21:29:16.960+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff5b08), gem(47), surface(0xb902faf8)
01-22 21:29:17.040+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8d2e6e8), gem(49), surface(0xb9029be0)
01-22 21:29:17.090+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(47), surface(0xb902faf8)
01-22 21:29:17.130+0900 I/ISP_AE  ( 1735): ANTI_FLAG: =600000, 4477, 134, 1
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :61
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :62
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.130+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.140+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b7aa48), gem(49), surface(0xb902faf8)
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :63
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :64
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :65
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :66
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.140+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :67
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :68
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :69
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :70
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.150+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :71
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :72
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :73
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :74
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.160+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :75
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :76
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :77
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :78
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :79
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.170+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :80
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :81
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 60
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :82
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :60
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 580
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :83
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :580
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 4
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :4
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :84
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 4
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -3
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 640
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :85
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :640
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 5
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :5
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 570
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :86
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :570
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 5
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 9
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :9
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 380
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :87
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :380
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 9
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 11
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :11
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 210
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :88
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :210
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 11
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 12
01-22 21:29:17.180+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 210
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :89
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :210
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 140
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :90
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :140
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 8
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :8
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v_s :0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v_s :0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 580
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :91
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :580
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 8
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 280
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :92
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :280
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 240
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :93
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :240
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 14
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :14
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 150
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :94
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :150
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 14
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 10
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :10
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 490
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :95
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :490
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 10
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 180
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :96
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :180
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 13
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 140
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :97
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :140
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 12
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 7
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :7
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :98
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 7
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 150
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :99
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :150
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -4
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 140
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :100
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :140
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -5
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :101
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 250
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :102
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :250
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 1
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :1
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 350
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :103
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :350
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 1
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 3
01-22 21:29:17.190+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :3
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 470
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :104
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :470
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 3
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 6
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :6
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 50
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :105
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :50
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 6
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -1
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 80
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :106
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :80
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :107
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 60
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :108
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :60
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 30
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :109
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :30
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 140
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :110
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :140
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -5
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 160
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :111
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :160
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -3
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :112
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 70
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :113
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :70
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 40
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :114
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :40
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 220
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :115
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :220
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 1
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :1
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 30
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :116
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :30
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 1
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -6
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 170
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :117
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :170
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -2
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 140
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :118
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :140
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -5
01-22 21:29:17.200+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :119
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -10
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 20
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :120
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :20
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v_s :0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v_s :0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman frame_flicker_value = 60
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman still_f :121
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_f_v :60
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b0 0
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b1 200
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman b2 -7
01-22 21:29:17.210+0900 I/ISP_DEFLICKER V3( 1735): hyman afl_v_v :0
01-22 21:29:17.210+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(47), surface(0xb902faf8)
01-22 21:29:17.260+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(49), surface(0xb902faf8)
01-22 21:29:17.340+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:17.390+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:17.440+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(47), surface(0xb902faf8)
01-22 21:29:17.510+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(49), surface(0xb902faf8)
01-22 21:29:17.561+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(47), surface(0xb902faf8)
01-22 21:29:17.611+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(49), surface(0xb902faf8)
01-22 21:29:17.691+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:17.741+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dfa188), gem(49), surface(0xb902faf8)
01-22 21:29:17.821+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff58c0), gem(47), surface(0xb902faf8)
01-22 21:29:17.861+0900 I/ISP_AE  ( 1735): calc_iso=310,real_gain=102,iso=0
01-22 21:29:17.871+0900 I/ISP_AE  ( 1735): calc_iso=310,real_gain=102,iso=0
01-22 21:29:17.881+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ffc308), gem(49), surface(0xb902faf8)
01-22 21:29:18.101+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ffbe68), gem(47), surface(0xb902faf8)
01-22 21:29:18.121+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff7358), gem(50), surface(0xb902faf8)
01-22 21:29:18.131+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff7460), gem(49), surface(0xb902faf8)
01-22 21:29:18.181+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff70f0), gem(47), surface(0xb902faf8)
01-22 21:29:18.201+0900 D/camera  ( 1735): Writing image to file.
01-22 21:29:18.231+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ff5e08), gem(49), surface(0xb902faf8)
01-22 21:29:18.281+0900 I/MALI    ( 1735): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb902fbf0), gem(47), surface(0xb902faf8)
01-22 21:29:18.301+0900 W/CRASH_MANAGER( 1695): worker.c: worker_job(1204) > 110173563616d142192975
