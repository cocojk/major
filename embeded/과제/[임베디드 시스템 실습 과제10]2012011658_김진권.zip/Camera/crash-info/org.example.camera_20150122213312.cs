S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2435
Date: 2015-01-22 21:33:12+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2435, uid 5000)

Register Information
r0   = 0x931ad008, r1   = 0x00000001
r2   = 0x0025905a, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0025905a
r6   = 0x0025905a, r7   = 0xad7ad588
r8   = 0xb8c99790, r9   = 0xad7ad734
r10  = 0xb8ca0538, fp   = 0x0000000d
ip   = 0xb6709110, sp   = 0xad7ad4f0
lr   = 0xb332ed13, pc   = 0xb6709128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    430028 KB
Buffers:     18112 KB
Cached:     129228 KB
VmPeak:     594700 KB
VmSize:     594696 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       46500 KB
VmRSS:       46500 KB
VmData:     416980 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         284 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 2435 TID = 2533
2435 2478 2523 2524 2525 2526 2527 2531 2532 2533 2534 2535 2536 2537 2538 2539 2540 2543 2544 2545 2546 2547 2548 2549 2550 2551 2552 2553 2554 2555 2556 2557 2558 2559 2560 2561 2562 2563 2564 2565 2566 2567 2569 2570 2571 2573 2574 2578 

Maps Information
9378a000 93f89000 rwxp [stack:2574]
93f8a000 94789000 rwxp [stack:2573]
947cb000 94fca000 rwxp [stack:2578]
98e8c000 9968b000 rwxp [stack:2571]
9968c000 99e8b000 rwxp [stack:2570]
9bd8c000 9c58b000 rwxp [stack:2569]
9c623000 9ce22000 rwxp [stack:2567]
9ce23000 9d622000 rwxp [stack:2566]
9d623000 9de22000 rwxp [stack:2565]
9e50e000 9ed0d000 rwxp [stack:2564]
9ed0e000 9f50d000 rwxp [stack:2563]
9f50e000 9fd0d000 rwxp [stack:2562]
9fd0e000 a050d000 rwxp [stack:2561]
a050e000 a0d0d000 rwxp [stack:2560]
a0d0e000 a150d000 rwxp [stack:2559]
a150e000 a1d0d000 rwxp [stack:2558]
a1d0e000 a250d000 rwxp [stack:2557]
a250e000 a2d0d000 rwxp [stack:2556]
a2d0e000 a350d000 rwxp [stack:2555]
a350e000 a3d0d000 rwxp [stack:2554]
a3d0e000 a450d000 rwxp [stack:2553]
a450e000 a4d0d000 rwxp [stack:2552]
a4fb0000 a57af000 rwxp [stack:2551]
a57b0000 a5faf000 rwxp [stack:2550]
a5fb0000 a67af000 rwxp [stack:2549]
a67b0000 a6faf000 rwxp [stack:2547]
a6fb0000 a77af000 rwxp [stack:2548]
a77b0000 a7faf000 rwxp [stack:2546]
a7fb0000 a87af000 rwxp [stack:2544]
a87b0000 a8faf000 rwxp [stack:2545]
a8fb0000 a97af000 rwxp [stack:2543]
a97b0000 a9faf000 rwxp [stack:2540]
a9fb0000 aa7af000 rwxp [stack:2539]
aa7b0000 aafaf000 rwxp [stack:2538]
aafb0000 ab7af000 rwxp [stack:2537]
ab7b0000 abfaf000 rwxp [stack:2536]
abfb0000 ac7af000 rwxp [stack:2535]
ac7b0000 acfaf000 rwxp [stack:2534]
acfb0000 ad7af000 rwxp [stack:2533]
ad7af000 ad7b2000 r-xp /usr/lib/libXv.so.1.0.0
ad7c2000 ad7d4000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad7e5000 ad81c000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad82e000 ae02d000 rwxp [stack:2532]
ae02d000 ae04a000 r-xp /usr/lib/libAl_Awb_Sp.so
ae053000 ae056000 r-xp /usr/lib/libdeflicker.so
ae06e000 ae084000 r-xp /usr/lib/libAl_Awb.so
ae08c000 ae096000 r-xp /usr/lib/libcalibration.so
ae09f000 ae0b1000 r-xp /usr/lib/libaf_lib.so
ae0b9000 ae0bf000 r-xp /usr/lib/libspaf.so
ae0c7000 ae0cd000 r-xp /usr/lib/liblsc.so
ae0d6000 ae0e2000 r-xp /usr/lib/libae.so
ae0ea000 ae12b000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae172000 ae251000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae766000 aef65000 rwxp [stack:2531]
aef6a000 aef6b000 r-xp /usr/lib/libcamerahdr.so.0.0.0
aef7b000 aefb7000 r-xp /usr/lib/libcamerahal.so.0.0.0
aefdc000 aeff4000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afd01000 b0500000 rwxp [stack:2527]
b0501000 b0d00000 rwxp [stack:2526]
b0e58000 b1657000 rwxp [stack:2525]
b1658000 b1e57000 rwxp [stack:2524]
b1e57000 b1e5c000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1ee8000 b1ef0000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f01000 b1f02000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f12000 b1f19000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f3d000 b1f3e000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f4e000 b1f61000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fb5000 b1fba000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1fcb000 b27ca000 rwxp [stack:2523]
b27ca000 b2925000 r-xp /usr/lib/egl/libMali.so
b293a000 b29c3000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b29dc000 b2aaa000 r-xp /usr/lib/libCOREGL.so.4.0
b2ac5000 b2ac8000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2ad8000 b2ae5000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2af6000 b2b00000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b10000 b2b1c000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b2d000 b2b31000 r-xp /usr/lib/libogg.so.0.7.1
b2b41000 b2b63000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b73000 b2c57000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c73000 b2cb6000 r-xp /usr/lib/libsndfile.so.1.0.25
b2ccb000 b2d12000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d23000 b2d2a000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d3a000 b2d6f000 r-xp /usr/lib/libpulse.so.0.16.2
b2d80000 b2d83000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2d94000 b2d97000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2da8000 b2deb000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2dfc000 b2e04000 r-xp /usr/lib/libdrm.so.2.4.0
b2e14000 b2e16000 r-xp /usr/lib/libdri2.so.0.0.0
b2e26000 b2e2d000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e3d000 b2e48000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e5c000 b2e62000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e73000 b2e7b000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2e8c000 b2e91000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2ea1000 b2eb8000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2ec8000 b2ee8000 r-xp /usr/lib/libexif.so.12.3.3
b2ef4000 b2efc000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f0c000 b2f3b000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f4e000 b2f56000 r-xp /usr/lib/libtbm.so.1.0.0
b2f66000 b301f000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3033000 b303a000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b304a000 b30a8000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30bd000 b30c1000 r-xp /usr/lib/libstorage.so.0.1
b30d1000 b30d8000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30e8000 b30f7000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3221000 b3225000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3236000 b3316000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b332b000 b3330000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3338000 b335f000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3372000 b3b71000 rwxp [stack:2478]
b3b71000 b3b73000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d83000 b3d8c000 r-xp /lib/libnss_files-2.20-2014.11.so
b3d9d000 b3da6000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3db7000 b3dc8000 r-xp /lib/libnsl-2.20-2014.11.so
b3ddb000 b3de1000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3df2000 b3e0c000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e1d000 b3e1e000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e2e000 b3e30000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e41000 b3e46000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e56000 b3e59000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e6a000 b3e71000 r-xp /usr/lib/libsensord-share.so
b3e81000 b3e92000 r-xp /usr/lib/libsensor.so.1.2.0
b3ea3000 b3ea9000 r-xp /usr/lib/libappcore-common.so.1.1
b3ecc000 b3ed1000 r-xp /usr/lib/libappcore-efl.so.1.1
b3ee7000 b3ee9000 r-xp /usr/lib/libXau.so.6.0.0
b3ef9000 b3f0d000 r-xp /usr/lib/libxcb.so.1.1.0
b3f1d000 b3f24000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f5c000 b3f5e000 r-xp /usr/lib/libiri.so
b3f6f000 b3f84000 r-xp /lib/libexpat.so.1.5.2
b3f96000 b3fe4000 r-xp /usr/lib/libssl.so.1.0.0
b3ff9000 b4002000 r-xp /usr/lib/libethumb.so.1.13.0
b4013000 b4016000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4026000 b41dd000 r-xp /usr/lib/libcrypto.so.1.0.0
b5774000 b577d000 r-xp /usr/lib/libXi.so.6.1.0
b578e000 b5790000 r-xp /usr/lib/libXgesture.so.7.0.0
b57a0000 b57a4000 r-xp /usr/lib/libXtst.so.6.1.0
b57b4000 b57ba000 r-xp /usr/lib/libXrender.so.1.3.0
b57ca000 b57d0000 r-xp /usr/lib/libXrandr.so.2.2.0
b57e0000 b57e2000 r-xp /usr/lib/libXinerama.so.1.0.0
b57f2000 b57f5000 r-xp /usr/lib/libXfixes.so.3.1.0
b5806000 b5811000 r-xp /usr/lib/libXext.so.6.4.0
b5821000 b5823000 r-xp /usr/lib/libXdamage.so.1.1.0
b5833000 b5835000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5845000 b5928000 r-xp /usr/lib/libX11.so.6.3.0
b593b000 b5942000 r-xp /usr/lib/libXcursor.so.1.0.2
b5953000 b596b000 r-xp /usr/lib/libudev.so.1.6.0
b596d000 b5970000 r-xp /lib/libattr.so.1.1.0
b5980000 b59a0000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59a1000 b59a6000 r-xp /usr/lib/libffi.so.6.0.2
b59b6000 b59ce000 r-xp /lib/libz.so.1.2.8
b59de000 b59e0000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59f0000 b5ac5000 r-xp /usr/lib/libxml2.so.2.9.2
b5ada000 b5b75000 r-xp /usr/lib/libstdc++.so.6.0.20
b5b91000 b5b94000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5ba4000 b5bbe000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bce000 b5bdf000 r-xp /lib/libresolv-2.20-2014.11.so
b5bf3000 b5c0a000 r-xp /usr/lib/liblzma.so.5.0.3
b5c1a000 b5c1c000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c2c000 b5c33000 r-xp /usr/lib/libembryo.so.1.13.0
b5c43000 b5c5b000 r-xp /usr/lib/libpng12.so.0.50.0
b5c6c000 b5c8f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5caf000 b5cb5000 r-xp /lib/librt-2.20-2014.11.so
b5cc6000 b5cda000 r-xp /usr/lib/libector.so.1.13.0
b5ceb000 b5d03000 r-xp /usr/lib/liblua-5.1.so
b5d14000 b5d6b000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d7f000 b5da7000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5db8000 b5dcb000 r-xp /usr/lib/libfribidi.so.0.3.1
b5ddc000 b5e16000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e27000 b5e92000 r-xp /lib/libm-2.20-2014.11.so
b5ea3000 b5eb0000 r-xp /usr/lib/libeio.so.1.13.0
b5ec0000 b5ec2000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5ed2000 b5ed7000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5ee7000 b5efe000 r-xp /usr/lib/libefreet.so.1.13.0
b5f10000 b5f30000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f40000 b5f60000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f62000 b5f68000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f78000 b5f7f000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f8f000 b5f9d000 r-xp /usr/lib/libeo.so.1.13.0
b5fad000 b5fbf000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fd0000 b5fd5000 r-xp /usr/lib/libecore_file.so.1.13.0
b5fe5000 b5ffd000 r-xp /usr/lib/libecore_evas.so.1.13.0
b600e000 b602b000 r-xp /usr/lib/libeet.so.1.13.0
b6044000 b608c000 r-xp /usr/lib/libeina.so.1.13.0
b609d000 b60ad000 r-xp /usr/lib/libefl.so.1.13.0
b60be000 b61a3000 r-xp /usr/lib/libicuuc.so.51.1
b61c0000 b6300000 r-xp /usr/lib/libicui18n.so.51.1
b6317000 b634f000 r-xp /usr/lib/libecore_x.so.1.13.0
b6361000 b6364000 r-xp /lib/libcap.so.2.21
b6374000 b639d000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63ae000 b63b5000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63c7000 b63fd000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b640e000 b64f6000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b650a000 b6580000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6592000 b6595000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65a5000 b65b0000 r-xp /usr/lib/libvconf.so.0.2.45
b65c0000 b65c2000 r-xp /usr/lib/libvasum.so.0.3.1
b65d2000 b65d4000 r-xp /usr/lib/libttrace.so.1.1
b65e4000 b65e7000 r-xp /usr/lib/libiniparser.so.0
b65f7000 b661a000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b662a000 b662f000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6640000 b6657000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6668000 b6675000 r-xp /usr/lib/libunwind.so.8.0.1
b66ab000 b67cf000 r-xp /lib/libc-2.20-2014.11.so
b67e4000 b67fd000 r-xp /lib/libgcc_s-4.9.so.1
b680d000 b68ef000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6900000 b6934000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6944000 b697e000 r-xp /usr/lib/libsystemd.so.0.4.0
b6980000 b6a00000 r-xp /usr/lib/libedje.so.1.13.0
b6a03000 b6a21000 r-xp /usr/lib/libecore.so.1.13.0
b6a41000 b6ba3000 r-xp /usr/lib/libevas.so.1.13.0
b6bda000 b6bee000 r-xp /lib/libpthread-2.20-2014.11.so
b6c02000 b6e26000 r-xp /usr/lib/libelementary.so.1.13.0
b6e54000 b6e58000 r-xp /usr/lib/libsmack.so.1.0.0
b6e68000 b6e6e000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e7f000 b6e81000 r-xp /usr/lib/libdlog.so.0.0.0
b6e91000 b6e94000 r-xp /usr/lib/libbundle.so.0.1.22
b6ea4000 b6ea6000 r-xp /lib/libdl-2.20-2014.11.so
b6eb7000 b6ed0000 r-xp /usr/lib/libaul.so.0.1.0
b6ee2000 b6ee4000 r-xp /usr/lib/libappsvc.so.0.1.0
b6ef5000 b6ef9000 r-xp /usr/lib/libsys-assert.so
b6f0a000 b6f2a000 r-xp /lib/ld-2.20-2014.11.so
b6f3b000 b6f41000 r-xp /usr/bin/launchpad-loader
b89e5000 b8f8b000 rw-p [heap]
be99e000 be9bf000 rwxp [stack]
be99e000 be9bf000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2435)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6709128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb332ed13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb30ecabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb306f865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63d35bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb63dff67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb63e5a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb63e5c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaefe6cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaefe7459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb685e157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6bdfcf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
: appcore-efl.c: __do_app(496) > [APP 2435] Event: RESET State: CREATED
01-22 21:33:07.104+0900 D/APP_CORE( 2435): appcore-efl.c: __do_app(527) > [APP 2435] RESET
01-22 21:33:07.104+0900 D/LAUNCH  ( 2435): appcore-efl.c: __do_app(529) > [camera:Application:reset:start]
01-22 21:33:07.104+0900 D/APP_CORE( 2435): appcore-efl.c: __do_app(533) > [__SUSPEND__] reset case
01-22 21:33:07.104+0900 D/APP_CORE( 2435): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-22 21:33:07.104+0900 I/CAPI_APPFW_APPLICATION( 2435): app_main.c: _ui_app_appcore_reset(722) > app_appcore_reset
01-22 21:33:07.104+0900 D/LAUNCH  ( 2435): appcore-efl.c: __do_app(544) > [camera:Application:reset:done]
01-22 21:33:07.104+0900 D/APP_CORE( 2435): appcore.c: __aul_handler(608) > [SECURE_LOG] caller_appid : org.tizen.homescreen
01-22 21:33:07.104+0900 E/EFL     ( 2435): edje<2435> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
01-22 21:33:07.104+0900 E/EFL     ( 2435): By the power of Grayskull, your previous Embryo stack is now broken!
01-22 21:33:07.114+0900 E/EFL     ( 2435): edje<2435> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
01-22 21:33:07.114+0900 E/EFL     ( 2435): By the power of Grayskull, your previous Embryo stack is now broken!
01-22 21:33:07.114+0900 E/EFL     ( 2435): edje<2435> lib/edje/edje_embryo.c:4134 _edje_embryo_test_run() You are running Embryo->EDC->Embryo with script program '_p24';
01-22 21:33:07.114+0900 E/EFL     ( 2435): By the power of Grayskull, your previous Embryo stack is now broken!
01-22 21:33:07.175+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 2200002
01-22 21:33:07.175+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.opaque
01-22 21:33:07.175+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xf4e490), gem(11), surface(0xf6cf80)
01-22 21:33:07.175+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:33:07.175+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:33:07.175+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:33:07.175+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:33:07.185+0900 W/APP_CORE( 2435): appcore-efl.c: __show_cb(914) > [EVENT_TEST][EVENT] GET SHOW EVENT!!!. WIN:4200003
01-22 21:33:07.185+0900 D/APP_CORE( 2435): appcore-efl.c: __add_win(753) > [EVENT_TEST][EVENT] __add_win WIN:4200003
01-22 21:33:07.185+0900 D/APP_CORE( 2435): appcore-group.c: appcore_group_attach(13) > appcore_group_attach
01-22 21:33:07.185+0900 D/AUL     ( 2435): app_sock.c: __app_send_raw(285) > pid(-2) : cmd(34)
01-22 21:33:07.185+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(838) > __request_handler: 34
01-22 21:33:07.195+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(838) > __request_handler: 15
01-22 21:33:07.195+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:33:07.205+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:33:07.205+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xf16628), gem(13), surface(0xfe8330)
01-22 21:33:07.205+0900 D/AUL_AMD (  819): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 2435 is org.example.camera
01-22 21:33:07.205+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 2435 : 0
01-22 21:33:07.205+0900 D/AUL     ( 1005): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
01-22 21:33:07.205+0900 I/MALI    (  913): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:33:07.225+0900 I/MALI    ( 2435): tizen_buffer.c: tizen_dri2_get_buffers(624) > Allocated private data for surface(0xb8b03ce8)
01-22 21:33:07.295+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xed8ba0), gem(20), surface(0xfb9a60)
01-22 21:33:07.295+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xf16628), gem(13), surface(0xfeb250)
01-22 21:33:07.305+0900 I/MALI    ( 2435): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:33:07.305+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xed8ba0), gem(20), surface(0xf78d20)
01-22 21:33:07.305+0900 D/APP_CORE( 2435): appcore.c: __prt_ltime(236) > [APP 2435] first idle after reset: 720 msec
01-22 21:33:07.305+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xf8dcb0), gem(10), surface(0xfc3cd0)
01-22 21:33:07.315+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x02200002), visible:1
01-22 21:33:07.315+0900 D/APP_CORE( 2435): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:4200003 fully_obscured 0
01-22 21:33:07.315+0900 D/APP_CORE( 2435): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active -1
01-22 21:33:07.315+0900 D/APP_CORE(  913): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2200002 fully_obscured 1
01-22 21:33:07.315+0900 D/APP_CORE( 2435): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
01-22 21:33:07.315+0900 D/APP_CORE(  913): appcore-efl.c: __visibility_cb(974) > bvisibility 0, b_active 1
01-22 21:33:07.315+0900 D/APP_CORE(  913): appcore-efl.c: __visibility_cb(989) >  Go to Pasue state 
01-22 21:33:07.315+0900 I/APP_CORE(  913): appcore-efl.c: __do_app(496) > [APP 913] Event: PAUSE State: RUNNING
01-22 21:33:07.315+0900 D/APP_CORE(  913): appcore-efl.c: __do_app(565) > [APP 913] PAUSE
01-22 21:33:07.315+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_pause(688) > app_appcore_pause
01-22 21:33:07.315+0900 E/cluster-home(  913): homescreen.cpp: OnPause(84) >  app pause
01-22 21:33:07.315+0900 I/APP_CORE( 2435): appcore-efl.c: __do_app(496) > [APP 2435] Event: RESUME State: CREATED
01-22 21:33:07.315+0900 D/LAUNCH  ( 2435): appcore-efl.c: __do_app(597) > [camera:Application:resume:start]
01-22 21:33:07.315+0900 D/cluster-view(  913): homescreen-view-manager.cpp: AppPause(915) >  BEGIN
01-22 21:33:07.315+0900 D/APP_CORE( 2435): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
01-22 21:33:07.315+0900 D/cluster-view(  913): homescreen-view-manager.cpp: AppPause(923) >  END
01-22 21:33:07.315+0900 D/APP_CORE( 2435): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-22 21:33:07.315+0900 D/APP_CORE( 2435): appcore-efl.c: __do_app(607) > [APP 2435] RESUME
01-22 21:33:07.315+0900 D/APP_CORE(  913): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-22 21:33:07.315+0900 E/APP_CORE(  913): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(4)
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(4)
01-22 21:33:07.315+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(180) > send_signal BG org.tizen.homescreen
01-22 21:33:07.315+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: bg
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(2435) status(3)
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2893) > back key ungrab
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(2435) status(3)
01-22 21:33:07.315+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(2435) appid(org.example.camera) pkgid(org.example.camera) status(3)
01-22 21:33:07.315+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.camera
01-22 21:33:07.315+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 2435, appid: org.example.camera, status: fg
01-22 21:33:07.325+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 2435
01-22 21:33:07.325+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 2435, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-22 21:33:07.325+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 2435
01-22 21:33:07.325+0900 D/DATA_PROVIDER_MASTER(  979): xmonitor.c: xmonitor_pause(331) > [SECURE_LOG] 913 is paused
01-22 21:33:07.325+0900 D/DATA_PROVIDER_MASTER(  979): client_life.c: client_is_all_paused(479) > [SECURE_LOG] 1, 1
01-22 21:33:07.325+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __provider_pause_cb(292) > widget obj was paused
01-22 21:33:07.325+0900 I/CAPI_WIDGET_APPLICATION(  966): widget_app.c: __check_status_for_cgroup(142) > enter background group
01-22 21:33:07.325+0900 W/AUL     (  966): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 966, appid: org.tizen.calendar.widget, status: bg
01-22 21:33:07.325+0900 I/APP_CORE( 2435): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
01-22 21:33:07.325+0900 I/APP_CORE( 2435): appcore-efl.c: __do_app(614) > [APP 2435] Initial Launching, call the resume_cb
01-22 21:33:07.325+0900 I/CAPI_APPFW_APPLICATION( 2435): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-22 21:33:07.325+0900 D/LAUNCH  ( 2435): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-22 21:33:07.325+0900 D/LAUNCH  ( 2435): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-22 21:33:07.325+0900 D/APP_CORE( 2435): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-22 21:33:07.325+0900 E/APP_CORE( 2435): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-22 21:33:07.405+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 2435, appname = org.example.camera, pkgname = org.example.camera
01-22 21:33:07.405+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 2435, appname = org.example.camera
01-22 21:33:07.405+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 2435
01-22 21:33:07.405+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 2435 foreground
01-22 21:33:07.405+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 966, proc_name: org.tizen.calendar.widget, cg_name: previous, oom_score_adj: 230
01-22 21:33:07.405+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/previous//cgroup.procs, value 966
01-22 21:33:07.515+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2906) > pid(2435) status(0)
01-22 21:33:07.565+0900 D/RESOURCED(  870): cpu.c: cpu_control_state(212) > cpu_service_launch : pid = 966, appname = org.tizen.calendar.widget
01-22 21:33:07.565+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/background/cgroup.procs, value 966
01-22 21:33:07.715+0900 D/AUL_PAD (  958): launchpad.c: __send_launchpad_loader(429) > Prepare another candidate process
01-22 21:33:07.725+0900 D/AUL_PAD ( 2529): sigchild.h: __signal_unblock_sigchld(223) > SIGCHLD unblocked
01-22 21:33:07.735+0900 D/AUL_PAD (  958): sigchild.h: __send_app_launch_signal(130) > send launch signal done
01-22 21:33:07.755+0900 E/RESOURCED(  870): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.253
01-22 21:33:08.206+0900 D/AUL_AMD (  819): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.camera /opt/usr/apps/org.example.camera/bin/camera
01-22 21:33:08.206+0900 D/RUA     (  819): rua.c: rua_add_history(179) > rua_add_history start
01-22 21:33:08.216+0900 D/RUA     (  819): rua.c: rua_add_history(247) > rua_add_history ok
01-22 21:33:08.826+0900 D/AUL_PAD ( 2529): launchpad_loader.c: main(588) > sleeping 1 sec...
01-22 21:33:08.826+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(52) > max_cmdline_size = 1053
01-22 21:33:08.836+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(65) > preload /usr/lib/libappcore-efl.so.1# - handle : b854b768
01-22 21:33:08.836+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(69) > get pre-initialization function
01-22 21:33:08.836+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(73) > get shutdown function
01-22 21:33:08.846+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(65) > preload /usr/lib/libappcore-common.so.1# - handle : b854ba48
01-22 21:33:08.856+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(65) > preload /usr/lib/libcapi-appfw-application.so.0# - handle : b854d5b0
01-22 21:33:08.856+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(69) > get pre-initialization function
01-22 21:33:08.856+0900 D/AUL_PAD ( 2529): preload.h: __preload_init(73) > get shutdown function
01-22 21:33:08.856+0900 D/AUL_PAD ( 2529): preexec.h: __preexec_init(76) > preexec start
01-22 21:33:08.856+0900 D/AUL_PAD ( 2529): launchpad_loader.c: main(599) > [candidate] Another candidate process was forked.
01-22 21:33:08.856+0900 D/AUL     ( 2529): process_pool.c: __connect_to_launchpad(107) > [launchpad] enter, type: 0
01-22 21:33:08.856+0900 D/AUL     ( 2529): process_pool.c: __connect_to_launchpad(119) > connect to /tmp/.launchpad-type0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x1
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(707) > pfds[POOL_TYPE + 0].revents & POLLIN
01-22 21:33:08.856+0900 D/AUL_PAD (  958): launchpad.c: main(719) > [SECURE_LOG] Type 0 candidate process was connected, pid: 2529
01-22 21:33:08.856+0900 D/AUL     ( 2529): process_pool.c: __connect_to_launchpad(132) > send(2529) : 4
01-22 21:33:08.856+0900 D/AUL     ( 2529): process_pool.c: __connect_to_launchpad(139) > [SECURE_LOG] [launchpad] done, connect fd: 9
01-22 21:33:09.096+0900 D/AUL_PAD ( 2529): launchpad_loader.c: main(631) > [candidate] elm init, returned: 1
01-22 21:33:09.136+0900 D/AUL_PAD ( 2529): launchpad_loader.c: main(678) > theme path: /usr/share/elementary/themes/tizen-2.4-mobile-HD.edj
01-22 21:33:09.136+0900 D/AUL_PAD ( 2529): launchpad_loader.c: main(693) > [candidate] ecore handler add
01-22 21:33:09.136+0900 D/AUL_PAD ( 2529): launchpad_loader.c: main(707) > [candidate] ecore main loop begin
01-22 21:33:09.497+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_update_image_change_buffer(646) > [EGL-X11] eglimage target 30b0 imported bo(0xf94aa0), gem(10), surface(0xf78c10)
01-22 21:33:09.557+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200df1 
01-22 21:33:09.557+0900 I/MALI    ( 2435): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:33:09.637+0900 I/MALI    ( 2435): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): tunnig_param=263480
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): param_num=3
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): cur target lum=62, ev diff=0, level=4
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): AE VERSION : 0x20150828-00
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): cvg speed=0
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): target lum=62, target lum zone=8
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): lime time=134, min line=1
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): target_lum_ev0=62
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): highcount=19,lowcount=15
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): FDAE: failed open fdae_param.txt
01-22 21:33:09.827+0900 I/ISP_AE  ( 2435): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:33:09.827+0900 D/alPrinter0( 2435): LSC Size:20 16
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [LSC]TableSize=   320
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [LSC]TableSize=   320
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [LSC]TableSize=   320
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [OTP]module has otp data 0xb0d17b5c (nil) 20 16
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [LSC]TableSize=   320
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [LSC]TableSize=   320
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:33:09.827+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): work_mode=0 last mode=0
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): cvg speed=0
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): target lum=62, target lum zone=8
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): lime time=134, min line=1
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): target_lum_ev0=62
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): highcount=19,lowcount=15
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): is_quick=0
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): AE_TEST:-----------SET index:282
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:33:09.957+0900 I/ISP_AE  ( 2435): AE_TEST:-----------SET index:282
01-22 21:33:09.967+0900 I/ISP_AE  ( 2435): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:33:09.977+0900 I/ISP_AE  ( 2435): calc_iso=50,real_gain=19,iso=0
01-22 21:33:10.238+0900 I/ISP_AE  ( 2435): set_weight, table[0] = 1
01-22 21:33:10.238+0900 I/ISP_AE  ( 2435): set weight from 1 to 0, rtn=0
01-22 21:33:10.238+0900 I/ISP_AE  ( 2435): AE_TEST ----------------------change to fast
01-22 21:33:10.238+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:282, cur_lum:14, next_index:318, target_lum:62
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,7a,a8,00,00,00,00
01-22 21:33:10.248+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,7a,a8,00,00,00,00
01-22 21:33:10.248+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LineAdj] Mode -2147483647
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LineAdj]Tar RGB 557,733,473
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LineAdj]Ref RGB 557,750,487
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LED]LPF Disable
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.20, detect:   0.30,   0.33 CTemp:7463.5
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [CHROMA]START BV=0.810333 Ratio=1.000000
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [HSC]Mix=00000000,Csd=fffffd10 ,(BV= 0.810,x=0.306,y=0.341)
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.810338 ,Awb Bv=0.810333 in/out_0
01-22 21:33:10.248+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.424988,GGain=1.000000,BGain=1.228897,Dtct=0.306259,0.340576 ,Curr=0.306259,0.340576 ,CTmep: QC=7048, AL= 6756
01-22 21:33:10.348+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:318, cur_lum:34, next_index:328, target_lum:62
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.348+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.348+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [LED]LPF Disable
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.30, detect:   0.30,   0.34 CTemp:6979.6
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [HSC]Mix=00000000,Csd=00008406 ,(BV= 0.561,x=0.307,y=0.339)
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.561311 ,Awb Bv=0.561310 in/out_0
01-22 21:33:10.348+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.402267,GGain=1.000000,BGain=1.215347,Dtct=0.306717,0.338577 ,Curr=0.306717,0.338577 ,CTmep: QC=7044, AL= 6749
01-22 21:33:10.388+0900 I/MALI    ( 2435): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:33:10.408+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ed9708), gem(42), surface(0xb8ed80d8)
01-22 21:33:10.408+0900 E/EFL     ( 2435): evas_main<2435> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:33:10.428+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8e0eb98), gem(44), surface(0xb8e11330)
01-22 21:33:10.448+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:328, cur_lum:40, next_index:336, target_lum:62
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.448+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.448+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [LED]LPF Disable
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.33, detect:   0.31,   0.34 CTemp:6829.3
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [HSC]Mix=00000a3d,Csd=0000741d ,(BV= 0.275,x=0.308,y=0.338)
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:3, 0x00000a3d,0x00000a3d
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.275007 ,Awb Bv=0.274994 in/out_0
01-22 21:33:10.448+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.388123,GGain=1.000000,BGain=1.213135,Dtct=0.307846,0.337936 ,Curr=0.307846,0.337936 ,CTmep: QC=7009, AL= 6695
01-22 21:33:10.458+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ed0548), gem(42), surface(0xb8ec6130)
01-22 21:33:10.508+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dcf390), gem(44), surface(0xb8ec7940)
01-22 21:33:10.538+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:336, cur_lum:46, next_index:339, target_lum:62
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.538+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.538+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [LED]LPF Enable
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.538+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.38, detect:   0.31,   0.34 CTemp:6690.3
01-22 21:33:10.548+0900 D/alPrinter0( 2435): [HSC]Mix=0000147a,Csd=000083d8 ,(BV= 0.273,x=0.309,y=0.338)
01-22 21:33:10.548+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:4, 0x0000147a,0x0000147a
01-22 21:33:10.548+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.170671 ,Awb Bv=0.272888 in/out_0
01-22 21:33:10.548+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.387833,GGain=1.000000,BGain=1.213028,Dtct=0.308990,0.337555 ,Curr=0.307861,0.337921 ,CTmep: QC=7009, AL= 6695
01-22 21:33:10.558+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x4200003
01-22 21:33:10.558+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da6118), gem(42), surface(0xb8ed7e80)
01-22 21:33:10.618+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bbf710), gem(44), surface(0xb8bbfa88)
01-22 21:33:10.638+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:339, cur_lum:49, next_index:342, target_lum:62
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.648+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.648+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.40, detect:   0.31,   0.34 CTemp:6540.2
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [HSC]Mix=00001eb7,Csd=00004808 ,(BV= 0.263,x=0.310,y=0.338)
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:3, 0x00001eb7,0x00001eb7
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.073373 ,Awb Bv=0.263474 in/out_0
01-22 21:33:10.648+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.386658,GGain=1.000000,BGain=1.212982,Dtct=0.309860,0.337875 ,Curr=0.307953,0.337906 ,CTmep: QC=7008, AL= 6694
01-22 21:33:10.668+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da6118), gem(42), surface(0xb8bbf9b8)
01-22 21:33:10.718+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8f60e90), gem(44), surface(0xb8bbfa88)
01-22 21:33:10.738+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:342, cur_lum:51, next_index:343, target_lum:62
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.738+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.738+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.738+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.44, detect:   0.31,   0.34 CTemp:6474.2
01-22 21:33:10.748+0900 D/alPrinter0( 2435): [HSC]Mix=00001eb7,Csd=0000cc0b ,(BV= 0.243,x=0.309,y=0.335)
01-22 21:33:10.748+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:4, 0x00001eb7,0x00001eb7
01-22 21:33:10.748+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.042346 ,Awb Bv=0.243484 in/out_0
01-22 21:33:10.748+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.383926,GGain=1.000000,BGain=1.212357,Dtct=0.308716,0.335190 ,Curr=0.308121,0.337814 ,CTmep: QC=7007, AL= 6692
01-22 21:33:10.768+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(42), surface(0xb8ed7e80)
01-22 21:33:10.808+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da6118), gem(44), surface(0xb8ed7e80)
01-22 21:33:10.838+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:343, cur_lum:52, next_index:344, target_lum:62
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.838+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.838+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.838+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.46, detect:   0.31,   0.34 CTemp:6421.1
01-22 21:33:10.848+0900 D/alPrinter0( 2435): [HSC]Mix=000031ea,Csd=00008c04 ,(BV= 0.215,x=0.309,y=0.334)
01-22 21:33:10.848+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:3, 0x000031ea,0x000031ea
01-22 21:33:10.848+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=0.011973 ,Awb Bv=0.214523 in/out_0
01-22 21:33:10.848+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.379852,GGain=1.000000,BGain=1.210815,Dtct=0.308807,0.334305 ,Curr=0.308304,0.337585 ,CTmep: QC=7006, AL= 6691
01-22 21:33:10.868+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dcf390), gem(42), surface(0xb8bbeb48)
01-22 21:33:10.908+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(44), surface(0xb8ed0500)
01-22 21:33:10.938+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:344, cur_lum:51, next_index:345, target_lum:62
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:10.938+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:10.938+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:10.938+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:10.948+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.46, detect:   0.31,   0.34 CTemp:6367.5
01-22 21:33:10.948+0900 D/alPrinter0( 2435): [HSC]Mix=00003c27,Csd=00007ab6 ,(BV= 0.180,x=0.310,y=0.334)
01-22 21:33:10.948+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:4, 0x00003c27,0x00003c27
01-22 21:33:10.948+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=-0.017775 ,Awb Bv=0.179672 in/out_0
01-22 21:33:10.948+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.374588,GGain=1.000000,BGain=1.208023,Dtct=0.309921,0.334274 ,Curr=0.308456,0.337173 ,CTmep: QC=7005, AL= 6689
01-22 21:33:10.958+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da6118), gem(42), surface(0xb8bbeb48)
01-22 21:33:11.008+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dcf390), gem(44), surface(0xb8bbeb48)
01-22 21:33:11.038+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:345, cur_lum:51, next_index:346, target_lum:62
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:11.038+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:11.038+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:11.038+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.46, detect:   0.32,   0.34 CTemp:6313.6
01-22 21:33:11.048+0900 D/alPrinter0( 2435): [HSC]Mix=00004664,Csd=000025f7 ,(BV= 0.141,x=0.311,y=0.334)
01-22 21:33:11.048+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:3, 0x00004664,0x00004664
01-22 21:33:11.048+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=-0.046921 ,Awb Bv=0.141495 in/out_0
01-22 21:33:11.048+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.367889,GGain=1.000000,BGain=1.204742,Dtct=0.310791,0.334351 ,Curr=0.308685,0.336685 ,CTmep: QC=7003, AL= 6687
01-22 21:33:11.058+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(42), surface(0xb8bbeb48)
01-22 21:33:11.118+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ed9420), gem(44), surface(0xb8ed7e80)
01-22 21:33:11.138+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:346, cur_lum:50, next_index:349, target_lum:62
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:11.148+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:11.148+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.48, detect:   0.32,   0.34 CTemp:6241.7
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [HSC]Mix=00004664,Csd=ffffc155 ,(BV= 0.101,x=0.311,y=0.333)
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:4, 0x00004664,0x00004664
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=-0.130985 ,Awb Bv=0.100739 in/out_0
01-22 21:33:11.148+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.360352,GGain=1.000000,BGain=1.201157,Dtct=0.310745,0.333466 ,Curr=0.308960,0.336151 ,CTmep: QC=7001, AL= 6684
01-22 21:33:11.168+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ed00d0), gem(42), surface(0xb8ed8d40)
01-22 21:33:11.188+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200df1 
01-22 21:33:11.229+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ed9420), gem(44), surface(0xb8ed5a60)
01-22 21:33:11.239+0900 I/ISP_AE  ( 2435): AE_TEST:----cur_index:349, cur_lum:52, next_index:350, target_lum:62
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:11.249+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [CMD0][if=b0d21808,Wrap=b0d26d38]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:11.249+0900 D/awb_al_cmd0( 2435): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [CALL][0xb0d21808][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [AIS_WRAP]msiFlash_state=0
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [LOCK]0
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [SuperHighCTemp] Mapin:  0.47, detect:   0.32,   0.34 CTemp:6184.1
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [HSC]Mix=00004664,Csd=000038c0 ,(BV= 0.057,x=0.312,y=0.335)
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [AlHscWrap_Main]:3, 0x00004664,0x00004664
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [AIS_WRAP]In BV=-0.184424 ,Awb Bv=0.056641 in/out_0
01-22 21:33:11.249+0900 D/alPrinter0( 2435): [AIS_WRAP]RGain=1.352295,GGain=1.000000,BGain=1.197830,Dtct=0.311523,0.335281 ,Curr=0.309311,0.335648 ,CTmep: QC=6999, AL= 6681
01-22 21:33:11.269+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(42), surface(0xb8f61148)
01-22 21:33:11.279+0900 I/ISP_AE  ( 2435): ae_state=3
01-22 21:33:11.319+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da6118), gem(44), surface(0xb8f61148)
01-22 21:33:11.369+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dcf390), gem(42), surface(0xb8ed0248)
01-22 21:33:11.419+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ed8de0), gem(44), surface(0xb8f61148)
01-22 21:33:11.479+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dcf390), gem(42), surface(0xb8daff18)
01-22 21:33:11.509+0900 I/ISP_AE  ( 2435): FDAE: ->disable, frame_idx=30
01-22 21:33:11.529+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ec6e88), gem(44), surface(0xb8ed93b0)
01-22 21:33:11.569+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da6118), gem(42), surface(0xb8f61148)
01-22 21:33:11.639+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8dcf390), gem(44), surface(0xb8ee5e60)
01-22 21:33:11.649+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ec6e88), gem(42), surface(0xb8ed0260)
01-22 21:33:11.699+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(44), surface(0xb8f61148)
01-22 21:33:11.749+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ec6e88), gem(42), surface(0xb8f61148)
01-22 21:33:11.799+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(44), surface(0xb8f61148)
01-22 21:33:11.849+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ec6e88), gem(42), surface(0xb8f61148)
01-22 21:33:11.899+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(44), surface(0xb8f61148)
01-22 21:33:11.949+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ec6e88), gem(42), surface(0xb8f61148)
01-22 21:33:11.999+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(44), surface(0xb8f61148)
01-22 21:33:12.049+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ec6e88), gem(42), surface(0xb8f61148)
01-22 21:33:12.099+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8ef4778), gem(44), surface(0xb8f61148)
01-22 21:33:12.159+0900 I/ISP_AE  ( 2435): calc_iso=170,real_gain=55,iso=0
01-22 21:33:12.159+0900 I/ISP_AE  ( 2435): calc_iso=170,real_gain=55,iso=0
01-22 21:33:12.169+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da4ec0), gem(42), surface(0xb8f2d860)
01-22 21:33:12.320+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
01-22 21:33:12.320+0900 I/APP_CORE(  913): appcore-efl.c: __do_app(496) > [APP 913] Event: MEM_FLUSH State: PAUSED
01-22 21:33:12.320+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
01-22 21:33:12.320+0900 D/APP_CORE(  913): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 913
01-22 21:33:12.320+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
01-22 21:33:12.320+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 913
01-22 21:33:12.400+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da4f60), gem(44), surface(0xb8f61148)
01-22 21:33:12.410+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8db1870), gem(45), surface(0xb8da5db8)
01-22 21:33:12.450+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8db1978), gem(42), surface(0xb8f61148)
01-22 21:33:12.510+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8db1608), gem(44), surface(0xb8f2d860)
01-22 21:33:12.510+0900 D/camera  ( 2435): Writing image to file.
01-22 21:33:12.560+0900 I/MALI    ( 2435): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8da4fc0), gem(42), surface(0xb8f61148)
01-22 21:33:12.610+0900 W/CRASH_MANAGER( 2489): worker.c: worker_job(1204) > 110243563616d142192999
