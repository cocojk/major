S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2529
Date: 2015-01-22 21:33:39+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2529, uid 5000)

Register Information
r0   = 0x93282008, r1   = 0x00000001
r2   = 0x00241cea, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x00241cea
r6   = 0x00241cea, r7   = 0xad81c588
r8   = 0xb87f9718, r9   = 0xad81c734
r10  = 0xb88004c0, fp   = 0x0000000d
ip   = 0xb67af110, sp   = 0xad81c4f0
lr   = 0xb33d4d13, pc   = 0xb67af128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    428424 KB
Buffers:     18160 KB
Cached:     129892 KB
VmPeak:     594480 KB
VmSize:     594476 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       46664 KB
VmRSS:       46664 KB
VmData:     416760 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         282 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 2529 TID = 2620
2529 2530 2611 2612 2613 2614 2615 2618 2619 2620 2621 2622 2623 2624 2625 2626 2627 2628 2629 2630 2631 2634 2635 2636 2637 2638 2639 2640 2641 2642 2643 2644 2645 2646 2647 2648 2649 2650 2651 2652 2653 2654 2656 2657 2658 2661 2662 2665 

Maps Information
937f9000 93ff8000 rwxp [stack:2662]
93ff9000 947f8000 rwxp [stack:2661]
9483a000 95039000 rwxp [stack:2665]
98efb000 996fa000 rwxp [stack:2658]
996fb000 99efa000 rwxp [stack:2657]
9bdfb000 9c5fa000 rwxp [stack:2656]
9c692000 9ce91000 rwxp [stack:2654]
9ce92000 9d691000 rwxp [stack:2653]
9d692000 9de91000 rwxp [stack:2652]
9e57d000 9ed7c000 rwxp [stack:2651]
9ed7d000 9f57c000 rwxp [stack:2650]
9f57d000 9fd7c000 rwxp [stack:2649]
9fd7d000 a057c000 rwxp [stack:2648]
a057d000 a0d7c000 rwxp [stack:2647]
a0d7d000 a157c000 rwxp [stack:2646]
a157d000 a1d7c000 rwxp [stack:2645]
a1d7d000 a257c000 rwxp [stack:2644]
a257d000 a2d7c000 rwxp [stack:2643]
a2d7d000 a357c000 rwxp [stack:2642]
a357d000 a3d7c000 rwxp [stack:2641]
a3d7d000 a457c000 rwxp [stack:2640]
a457d000 a4d7c000 rwxp [stack:2639]
a4d7d000 a557c000 rwxp [stack:2638]
a557d000 a5d7c000 rwxp [stack:2637]
a5d7d000 a657c000 rwxp [stack:2636]
a657d000 a6d7c000 rwxp [stack:2635]
a6d7d000 a757c000 rwxp [stack:2634]
a781f000 a801e000 rwxp [stack:2631]
a801f000 a881e000 rwxp [stack:2630]
a881f000 a901e000 rwxp [stack:2629]
a901f000 a981e000 rwxp [stack:2628]
a981f000 aa01e000 rwxp [stack:2627]
aa01f000 aa81e000 rwxp [stack:2626]
aa81f000 ab01e000 rwxp [stack:2625]
ab01f000 ab81e000 rwxp [stack:2624]
ab81f000 ac01e000 rwxp [stack:2623]
ac01f000 ac81e000 rwxp [stack:2622]
ac81f000 ad01e000 rwxp [stack:2621]
ad01f000 ad81e000 rwxp [stack:2620]
ad81e000 ad821000 r-xp /usr/lib/libXv.so.1.0.0
ad831000 ad843000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad854000 ad88b000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad89d000 ae09c000 rwxp [stack:2619]
ae09c000 ae0b9000 r-xp /usr/lib/libAl_Awb_Sp.so
ae0c2000 ae0c5000 r-xp /usr/lib/libdeflicker.so
ae0dd000 ae0f3000 r-xp /usr/lib/libAl_Awb.so
ae0fb000 ae105000 r-xp /usr/lib/libcalibration.so
ae10e000 ae120000 r-xp /usr/lib/libaf_lib.so
ae128000 ae12e000 r-xp /usr/lib/libspaf.so
ae136000 ae13c000 r-xp /usr/lib/liblsc.so
ae145000 ae151000 r-xp /usr/lib/libae.so
ae159000 ae19a000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae1e1000 ae2c0000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae71d000 ae71e000 r-xp /usr/lib/libcamerahdr.so.0.0.0
ae72e000 ae76a000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae847000 af046000 rwxp [stack:2618]
af093000 af0ab000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afd01000 b0500000 rwxp [stack:2615]
b0501000 b0d00000 rwxp [stack:2614]
b0efe000 b16fd000 rwxp [stack:2613]
b16fe000 b1efd000 rwxp [stack:2612]
b1efd000 b1f02000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f8e000 b1f96000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1fa7000 b1fa8000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1fb8000 b1fbf000 r-xp /usr/lib/libfeedback.so.0.1.4
b1fe3000 b1fe4000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1ff4000 b2007000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b205b000 b2060000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2071000 b2870000 rwxp [stack:2611]
b2870000 b29cb000 r-xp /usr/lib/egl/libMali.so
b29e0000 b2a69000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a82000 b2b50000 r-xp /usr/lib/libCOREGL.so.4.0
b2b6b000 b2b6e000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b7e000 b2b8b000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b9c000 b2ba6000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2bb6000 b2bc2000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2bd3000 b2bd7000 r-xp /usr/lib/libogg.so.0.7.1
b2be7000 b2c09000 r-xp /usr/lib/libvorbis.so.0.4.3
b2c19000 b2cfd000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2d19000 b2d5c000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d71000 b2db8000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2dc9000 b2dd0000 r-xp /usr/lib/libjson-c.so.2.0.1
b2de0000 b2e15000 r-xp /usr/lib/libpulse.so.0.16.2
b2e26000 b2e29000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2e3a000 b2e3d000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2e4e000 b2e91000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2ea2000 b2eaa000 r-xp /usr/lib/libdrm.so.2.4.0
b2eba000 b2ebc000 r-xp /usr/lib/libdri2.so.0.0.0
b2ecc000 b2ed3000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2ee3000 b2eee000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2f02000 b2f08000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2f19000 b2f21000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2f32000 b2f37000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2f47000 b2f5e000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f6e000 b2f8e000 r-xp /usr/lib/libexif.so.12.3.3
b2f9a000 b2fa2000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2fb2000 b2fe1000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2ff4000 b2ffc000 r-xp /usr/lib/libtbm.so.1.0.0
b300c000 b30c5000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b30d9000 b30e0000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b30f0000 b314e000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3163000 b3167000 r-xp /usr/lib/libstorage.so.0.1
b3177000 b317e000 r-xp /usr/lib/libefl-extension.so.0.1.0
b318e000 b319d000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b32c7000 b32cb000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32dc000 b33bc000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33d1000 b33d6000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b33de000 b3405000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3418000 b3c17000 rwxp [stack:2530]
b3c17000 b3c19000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3e29000 b3e32000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e43000 b3e4c000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e5d000 b3e6e000 r-xp /lib/libnsl-2.20-2014.11.so
b3e81000 b3e87000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e98000 b3eb2000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3ec3000 b3ec4000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ed4000 b3ed6000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3ee7000 b3eec000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3efc000 b3eff000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3f10000 b3f17000 r-xp /usr/lib/libsensord-share.so
b3f27000 b3f38000 r-xp /usr/lib/libsensor.so.1.2.0
b3f49000 b3f4f000 r-xp /usr/lib/libappcore-common.so.1.1
b3f72000 b3f77000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f8d000 b3f8f000 r-xp /usr/lib/libXau.so.6.0.0
b3f9f000 b3fb3000 r-xp /usr/lib/libxcb.so.1.1.0
b3fc3000 b3fca000 r-xp /lib/libcrypt-2.20-2014.11.so
b4002000 b4004000 r-xp /usr/lib/libiri.so
b4015000 b402a000 r-xp /lib/libexpat.so.1.5.2
b403c000 b408a000 r-xp /usr/lib/libssl.so.1.0.0
b409f000 b40a8000 r-xp /usr/lib/libethumb.so.1.13.0
b40b9000 b40bc000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b40cc000 b4283000 r-xp /usr/lib/libcrypto.so.1.0.0
b581a000 b5823000 r-xp /usr/lib/libXi.so.6.1.0
b5834000 b5836000 r-xp /usr/lib/libXgesture.so.7.0.0
b5846000 b584a000 r-xp /usr/lib/libXtst.so.6.1.0
b585a000 b5860000 r-xp /usr/lib/libXrender.so.1.3.0
b5870000 b5876000 r-xp /usr/lib/libXrandr.so.2.2.0
b5886000 b5888000 r-xp /usr/lib/libXinerama.so.1.0.0
b5898000 b589b000 r-xp /usr/lib/libXfixes.so.3.1.0
b58ac000 b58b7000 r-xp /usr/lib/libXext.so.6.4.0
b58c7000 b58c9000 r-xp /usr/lib/libXdamage.so.1.1.0
b58d9000 b58db000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58eb000 b59ce000 r-xp /usr/lib/libX11.so.6.3.0
b59e1000 b59e8000 r-xp /usr/lib/libXcursor.so.1.0.2
b59f9000 b5a11000 r-xp /usr/lib/libudev.so.1.6.0
b5a13000 b5a16000 r-xp /lib/libattr.so.1.1.0
b5a26000 b5a46000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a47000 b5a4c000 r-xp /usr/lib/libffi.so.6.0.2
b5a5c000 b5a74000 r-xp /lib/libz.so.1.2.8
b5a84000 b5a86000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a96000 b5b6b000 r-xp /usr/lib/libxml2.so.2.9.2
b5b80000 b5c1b000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c37000 b5c3a000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c4a000 b5c64000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c74000 b5c85000 r-xp /lib/libresolv-2.20-2014.11.so
b5c99000 b5cb0000 r-xp /usr/lib/liblzma.so.5.0.3
b5cc0000 b5cc2000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5cd2000 b5cd9000 r-xp /usr/lib/libembryo.so.1.13.0
b5ce9000 b5d01000 r-xp /usr/lib/libpng12.so.0.50.0
b5d12000 b5d35000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d55000 b5d5b000 r-xp /lib/librt-2.20-2014.11.so
b5d6c000 b5d80000 r-xp /usr/lib/libector.so.1.13.0
b5d91000 b5da9000 r-xp /usr/lib/liblua-5.1.so
b5dba000 b5e11000 r-xp /usr/lib/libfreetype.so.6.11.3
b5e25000 b5e4d000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e5e000 b5e71000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e82000 b5ebc000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ecd000 b5f38000 r-xp /lib/libm-2.20-2014.11.so
b5f49000 b5f56000 r-xp /usr/lib/libeio.so.1.13.0
b5f66000 b5f68000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f78000 b5f7d000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f8d000 b5fa4000 r-xp /usr/lib/libefreet.so.1.13.0
b5fb6000 b5fd6000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fe6000 b6006000 r-xp /usr/lib/libecore_con.so.1.13.0
b6008000 b600e000 r-xp /usr/lib/libecore_imf.so.1.13.0
b601e000 b6025000 r-xp /usr/lib/libethumb_client.so.1.13.0
b6035000 b6043000 r-xp /usr/lib/libeo.so.1.13.0
b6053000 b6065000 r-xp /usr/lib/libecore_input.so.1.13.0
b6076000 b607b000 r-xp /usr/lib/libecore_file.so.1.13.0
b608b000 b60a3000 r-xp /usr/lib/libecore_evas.so.1.13.0
b60b4000 b60d1000 r-xp /usr/lib/libeet.so.1.13.0
b60ea000 b6132000 r-xp /usr/lib/libeina.so.1.13.0
b6143000 b6153000 r-xp /usr/lib/libefl.so.1.13.0
b6164000 b6249000 r-xp /usr/lib/libicuuc.so.51.1
b6266000 b63a6000 r-xp /usr/lib/libicui18n.so.51.1
b63bd000 b63f5000 r-xp /usr/lib/libecore_x.so.1.13.0
b6407000 b640a000 r-xp /lib/libcap.so.2.21
b641a000 b6443000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6454000 b645b000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b646d000 b64a3000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b64b4000 b659c000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b65b0000 b6626000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6638000 b663b000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b664b000 b6656000 r-xp /usr/lib/libvconf.so.0.2.45
b6666000 b6668000 r-xp /usr/lib/libvasum.so.0.3.1
b6678000 b667a000 r-xp /usr/lib/libttrace.so.1.1
b668a000 b668d000 r-xp /usr/lib/libiniparser.so.0
b669d000 b66c0000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66d0000 b66d5000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66e6000 b66fd000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b670e000 b671b000 r-xp /usr/lib/libunwind.so.8.0.1
b6751000 b6875000 r-xp /lib/libc-2.20-2014.11.so
b688a000 b68a3000 r-xp /lib/libgcc_s-4.9.so.1
b68b3000 b6995000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b69a6000 b69da000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69ea000 b6a24000 r-xp /usr/lib/libsystemd.so.0.4.0
b6a26000 b6aa6000 r-xp /usr/lib/libedje.so.1.13.0
b6aa9000 b6ac7000 r-xp /usr/lib/libecore.so.1.13.0
b6ae7000 b6c49000 r-xp /usr/lib/libevas.so.1.13.0
b6c80000 b6c94000 r-xp /lib/libpthread-2.20-2014.11.so
b6ca8000 b6ecc000 r-xp /usr/lib/libelementary.so.1.13.0
b6efa000 b6efe000 r-xp /usr/lib/libsmack.so.1.0.0
b6f0e000 b6f14000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6f25000 b6f27000 r-xp /usr/lib/libdlog.so.0.0.0
b6f37000 b6f3a000 r-xp /usr/lib/libbundle.so.0.1.22
b6f4a000 b6f4c000 r-xp /lib/libdl-2.20-2014.11.so
b6f5d000 b6f76000 r-xp /usr/lib/libaul.so.0.1.0
b6f88000 b6f8a000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f9b000 b6f9f000 r-xp /usr/lib/libsys-assert.so
b6fb0000 b6fd0000 r-xp /lib/ld-2.20-2014.11.so
b6fe1000 b6fe7000 r-xp /usr/bin/launchpad-loader
b8545000 b8aeb000 rw-p [heap]
bee08000 bee29000 rwxp [stack]
bee08000 bee29000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2529)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb67af128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb33d4d13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb3192abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3115865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb64795bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6485f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb648ba8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb648bc81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf09dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf09e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6904157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c85cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:35.252+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:35.252+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:35.252+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:35.252+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:35.252+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:35.252+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5296.1
01-22 21:33:35.262+0900 D/alPrinter0( 2529): [HSC]Mix=0000f5c0,Csd=0002382e ,(BV=-1.600,x=0.347,y=0.371)
01-22 21:33:35.262+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:4, 0x0000f5c0,0x0000f5c0
01-22 21:33:35.262+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-1.988028 ,Awb Bv=-1.600449 in/out_0
01-22 21:33:35.262+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.255310,GGain=1.000000,BGain=1.540054,Dtct=0.347351,0.371399 ,Curr=0.350861,0.377319 ,CTmep: QC=5066, AL= 4818
01-22 21:33:35.282+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb891ee48), gem(47), surface(0xb871f628)
01-22 21:33:35.332+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(44), surface(0xb8a48c78)
01-22 21:33:35.362+0900 I/ISP_AE  ( 2529): ae_state=3
01-22 21:33:35.382+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb871ec38)
01-22 21:33:35.462+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(44), surface(0xb871f5c0)
01-22 21:33:35.502+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb891ee48), gem(47), surface(0xb890ac28)
01-22 21:33:35.582+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a48000), gem(44), surface(0xb88e9d70)
01-22 21:33:35.632+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb871ec38)
01-22 21:33:35.682+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(44), surface(0xb8a48c78)
01-22 21:33:35.762+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a4b300), gem(47), surface(0xb87adae0)
01-22 21:33:35.762+0900 I/ISP_AE  ( 2529): FDAE: ->disable, frame_idx=30
01-22 21:33:35.812+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a48000), gem(44), surface(0xb8a48c78)
01-22 21:33:35.863+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb87adae0)
01-22 21:33:35.933+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200082 bd->visible=0
01-22 21:33:35.933+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb8a48c78)
01-22 21:33:35.983+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:36.063+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a48000), gem(44), surface(0xb8a48c78)
01-22 21:33:36.113+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb87adae0)
01-22 21:33:36.163+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb8a48c78)
01-22 21:33:36.243+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:36.283+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a48000), gem(44), surface(0xb8a48c78)
01-22 21:33:36.333+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb87adae0)
01-22 21:33:36.403+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb8a48c78)
01-22 21:33:36.453+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:36.533+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a48000), gem(44), surface(0xb8a48c78)
01-22 21:33:36.583+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb87adae0)
01-22 21:33:36.633+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb8a48c78)
01-22 21:33:36.703+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:36.753+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a48000), gem(44), surface(0xb8a48c78)
01-22 21:33:36.833+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb87adae0)
01-22 21:33:36.884+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb8a48c78)
01-22 21:33:36.934+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:36.984+0900 I/ISP_AE  ( 2529): ae_state=1
01-22 21:33:37.014+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(44), surface(0xb89a6300)
01-22 21:33:37.064+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb87adae0)
01-22 21:33:37.114+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:408, cur_lum:57, next_index:409, target_lum:62
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.114+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.114+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5242.7
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [HSC]Mix=00011478,Csd=0000e907 ,(BV=-1.687,x=0.348,y=0.372)
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:3, 0x00011478,0x00011478
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.023651 ,Awb Bv=-1.687393 in/out_0
01-22 21:33:37.114+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.252975,GGain=1.000000,BGain=1.530029,Dtct=0.348495,0.371613 ,Curr=0.350143,0.376236 ,CTmep: QC=5073, AL= 4824
01-22 21:33:37.134+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb89a6300)
01-22 21:33:37.184+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:37.224+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:409, cur_lum:58, next_index:410, target_lum:62
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.234+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.234+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.234+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5207.6
01-22 21:33:37.234+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(44), surface(0xb89a6300)
01-22 21:33:37.244+0900 D/alPrinter0( 2529): [HSC]Mix=00013330,Csd=0000fe9d ,(BV=-1.770,x=0.349,y=0.372)
01-22 21:33:37.244+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:4, 0x00013330,0x00013330
01-22 21:33:37.244+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-1.770157 in/out_0
01-22 21:33:37.244+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.249832,GGain=1.000000,BGain=1.520279,Dtct=0.348862,0.372025 ,Curr=0.349533,0.375168 ,CTmep: QC=5080, AL= 4829
01-22 21:33:37.314+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb87adae0)
01-22 21:33:37.344+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:410, cur_lum:60, next_index:410, target_lum:62
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.344+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.344+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.344+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.354+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5205.6
01-22 21:33:37.354+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=00013b46 ,(BV=-1.846,x=0.349,y=0.372)
01-22 21:33:37.354+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:3, 0x00013333,0x00013333
01-22 21:33:37.354+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-1.845642 in/out_0
01-22 21:33:37.354+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.246323,GGain=1.000000,BGain=1.511642,Dtct=0.348557,0.371826 ,Curr=0.349060,0.374207 ,CTmep: QC=5087, AL= 4835
01-22 21:33:37.364+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb89a6300)
01-22 21:33:37.404+0900 I/ISP_AE  ( 2529): AE_TEST ----------------------change to smooth
01-22 21:33:37.404+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:410, cur_lum:60, next_index:410, target_lum:62
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.404+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.404+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.404+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.414+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5206.3
01-22 21:33:37.414+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=0000bae2 ,(BV=-1.911,x=0.348,y=0.372)
01-22 21:33:37.414+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:4, 0x00013333,0x00013333
01-22 21:33:37.414+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-1.911133 in/out_0
01-22 21:33:37.414+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.241501,GGain=1.000000,BGain=1.512619,Dtct=0.348434,0.371811 ,Curr=0.348724,0.373428 ,CTmep: QC=5095, AL= 4841
01-22 21:33:37.444+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:37.464+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:410, cur_lum:60, next_index:410, target_lum:62
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.464+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.464+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.464+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.474+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5220.3
01-22 21:33:37.474+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=0000c1e1 ,(BV=-1.965,x=0.348,y=0.371)
01-22 21:33:37.474+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:3, 0x00013333,0x00013333
01-22 21:33:37.474+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-1.964935 in/out_0
01-22 21:33:37.474+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.238541,GGain=1.000000,BGain=1.505371,Dtct=0.348038,0.371384 ,Curr=0.348465,0.372742 ,CTmep: QC=5101, AL= 4846
01-22 21:33:37.474+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
01-22 21:33:37.474+0900 I/APP_CORE(  913): appcore-efl.c: __do_app(496) > [APP 913] Event: MEM_FLUSH State: PAUSED
01-22 21:33:37.474+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
01-22 21:33:37.474+0900 D/APP_CORE(  913): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 913
01-22 21:33:37.474+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
01-22 21:33:37.474+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 913
01-22 21:33:37.494+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(44), surface(0xb89a6300)
01-22 21:33:37.524+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:410, cur_lum:59, next_index:410, target_lum:62
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.524+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.524+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.524+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.534+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.93, detect:   0.34,   0.36 CTemp:5271.3
01-22 21:33:37.534+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=000119cb ,(BV=-2.007,x=0.348,y=0.372)
01-22 21:33:37.534+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:4, 0x00013333,0x00013333
01-22 21:33:37.534+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-2.006927 in/out_0
01-22 21:33:37.534+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.238342,GGain=1.000000,BGain=1.505173,Dtct=0.348221,0.371811 ,Curr=0.348465,0.372742 ,CTmep: QC=5110, AL= 4853
01-22 21:33:37.544+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb87adae0)
01-22 21:33:37.594+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:410, cur_lum:59, next_index:410, target_lum:62
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.594+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.594+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5308.6
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=000054d8 ,(BV=-2.038,x=0.346,y=0.370)
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:3, 0x00013333,0x00013333
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-2.037949 in/out_0
01-22 21:33:37.594+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.236343,GGain=1.000000,BGain=1.499451,Dtct=0.346481,0.370453 ,Curr=0.348236,0.372208 ,CTmep: QC=5118, AL= 4859
01-22 21:33:37.614+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb89a6300)
01-22 21:33:37.644+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:410, cur_lum:58, next_index:411, target_lum:62
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.654+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.654+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.94, detect:   0.34,   0.36 CTemp:5359.3
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=0000a1c8 ,(BV=-2.060,x=0.345,y=0.370)
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:4, 0x00013333,0x00013333
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.092364 ,Awb Bv=-2.060150 in/out_0
01-22 21:33:37.654+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.235001,GGain=1.000000,BGain=1.494064,Dtct=0.345413,0.369507 ,Curr=0.347961,0.371704 ,CTmep: QC=5127, AL= 4866
01-22 21:33:37.664+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:37.714+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(44), surface(0xb89a6300)
01-22 21:33:37.764+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:411, cur_lum:57, next_index:412, target_lum:62
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.774+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.774+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.93, detect:   0.34,   0.36 CTemp:5395.2
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=0000bcd1 ,(BV=-2.077,x=0.345,y=0.369)
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:3, 0x00013333,0x00013333
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.125531 ,Awb Bv=-2.076920 in/out_0
01-22 21:33:37.774+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.234802,GGain=1.000000,BGain=1.488602,Dtct=0.344574,0.368713 ,Curr=0.347565,0.371201 ,CTmep: QC=5137, AL= 4874
01-22 21:33:37.774+0900 I/ISP_AE  ( 2529): ANTI_FLAG: =600000, 4477, 134, 1
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v_s :0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v_s :0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :1
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 0
01-22 21:33:37.774+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :0
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 1180
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :2
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :1180
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 0
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 10
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :10
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 70
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :3
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :70
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 10
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 3
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :3
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 640
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :4
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :640
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 3
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 8
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :8
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 420
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :5
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :420
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 8
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 11
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :11
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 280
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :6
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :280
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 11
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 12
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :12
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 70
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :7
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :70
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 12
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 5
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :5
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 580
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :8
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :580
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 5
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 9
01-22 21:33:37.784+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :9
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 600
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :9
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :600
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 9
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 14
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :14
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 210
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :10
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :210
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 14
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 15
01-22 21:33:37.794+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :15
01-22 21:33:37.794+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb87adae0)
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 1240
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :11
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :1240
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 15
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 25
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :25
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 210
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :12
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :210
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 25
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 26
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :26
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 790
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :13
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :790
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 26
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 32
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :32
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 970
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :14
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :970
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 32
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 42
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :42
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 70
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :15
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :70
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 42
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 35
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :35
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 170
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :16
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :170
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 35
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 33
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :33
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 960
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :17
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :960
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 33
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 43
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :43
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 900
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :18
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :900
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 43
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 53
01-22 21:33:37.804+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :53
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 190
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :19
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :190
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 53
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 53
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :53
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 820
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :20
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :820
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 53
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 60
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :60
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 540
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :21
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :540
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 60
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 64
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :64
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 730
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :22
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :730
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 64
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 70
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :70
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 350
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :23
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :350
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 70
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 72
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :72
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 1060
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :24
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :1060
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 72
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 82
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :82
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 990
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :25
01-22 21:33:37.814+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :990
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 82
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 92
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :92
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman frame_flicker_value = 1260
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman still_f :26
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_f_v :1260
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman b0 92
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman b1 200
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman b2 102
01-22 21:33:37.824+0900 I/ISP_DEFLICKER V3( 2529): hyman afl_v_v :102
01-22 21:33:37.844+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ad560), gem(44), surface(0xb89a6300)
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): rtn=0,scene_index=0, flicker_index=1, iso_index=0
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:413, cur_ev:0x328866c0, next_ev:0x1d34cc96, 666666, 735
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:414, cur_ev:0x328866c0, next_ev:0x1e7a51d6, 666666, 767
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:415, cur_ev:0x328866c0, next_ev:0x1f1d1476, 666666, 783
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:416, cur_ev:0x328866c0, next_ev:0x1fbfd716, 666666, 799
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:417, cur_ev:0x328866c0, next_ev:0x21055c56, 666666, 831
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:418, cur_ev:0x328866c0, next_ev:0x224ae196, 666666, 863
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:419, cur_ev:0x328866c0, next_ev:0x22eda436, 666666, 879
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:420, cur_ev:0x328866c0, next_ev:0x239066d6, 666666, 895
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:421, cur_ev:0x328866c0, next_ev:0x24d5ec16, 666666, 927
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:422, cur_ev:0x328866c0, next_ev:0x261b7156, 666666, 959
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:423, cur_ev:0x328866c0, next_ev:0x2760f696, 666666, 991
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:424, cur_ev:0x328866c0, next_ev:0x28a67bd6, 666666, 1023
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:425, cur_ev:0x328866c0, next_ev:0x29ec0116, 666666, 1055
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:426, cur_ev:0x328866c0, next_ev:0x2b318656, 666666, 1087
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:427, cur_ev:0x328866c0, next_ev:0x2c770b96, 666666, 1119
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:428, cur_ev:0x328866c0, next_ev:0x2dbc90d6, 666666, 1151
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:429, cur_ev:0x328866c0, next_ev:0x2f021616, 666666, 1183
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:430, cur_ev:0x328866c0, next_ev:0x30479b56, 666666, 1215
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:431, cur_ev:0x328866c0, next_ev:0x318d2096, 666666, 1247
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: index:432, cur_ev:0x328866c0, next_ev:0x32d2a5d6, 666666, 1279
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST: cur_index:412, next_index:432
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): set flicker from 0 to 1, rtn=0
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): min_index=0, max_index=490, new_index=432
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST:-----------SET index:432
01-22 21:33:37.885+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:432, cur_lum:58, next_index:433, target_lum:62
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:37.895+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:37.895+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.92, detect:   0.33,   0.36 CTemp:5396.9
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=00012818 ,(BV=-2.092,x=0.345,y=0.369)
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:4, 0x00013333,0x00013333
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.201805 ,Awb Bv=-2.092422 in/out_0
01-22 21:33:37.895+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.235153,GGain=1.000000,BGain=1.483139,Dtct=0.344879,0.368881 ,Curr=0.347107,0.370697 ,CTmep: QC=5145, AL= 4881
01-22 21:33:37.915+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb87adae0)
01-22 21:33:37.975+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb870fff0), gem(44), surface(0xb89a6300)
01-22 21:33:38.025+0900 I/ISP_AE  ( 2529): AE_TEST:----cur_index:433, cur_lum:58, next_index:434, target_lum:62
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:33:38.025+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [CMD0][if=afb20dc0,Wrap=afb262f0]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:33:38.025+0900 D/awb_al_cmd0( 2529): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [CALL][0xafb20dc0][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [AIS_WRAP]msiFlash_state=0
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [LOCK]0
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [SuperHighCTemp] Mapin:  0.92, detect:   0.33,   0.36 CTemp:5416.6
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [HSC]Mix=00013333,Csd=00009899 ,(BV=-2.111,x=0.345,y=0.368)
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [AlHscWrap_Main]:3, 0x00013333,0x00013333
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [AIS_WRAP]In BV=-2.269312 ,Awb Bv=-2.110947 in/out_0
01-22 21:33:38.025+0900 D/alPrinter0( 2529): [AIS_WRAP]RGain=1.235977,GGain=1.000000,BGain=1.477753,Dtct=0.344757,0.368408 ,Curr=0.346603,0.370209 ,CTmep: QC=5157, AL= 4890
01-22 21:33:38.045+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(47), surface(0xb87adae0)
01-22 21:33:38.065+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200e5a 
01-22 21:33:38.095+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(44), surface(0xb8909ef8)
01-22 21:33:38.145+0900 I/ISP_AE  ( 2529): ae_state=3
01-22 21:33:38.175+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a4b300), gem(47), surface(0xb87ad4b0)
01-22 21:33:38.225+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87eb078), gem(44), surface(0xb89a6b90)
01-22 21:33:38.305+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(47), surface(0xb87ad4b0)
01-22 21:33:38.385+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(44), surface(0xb871f628)
01-22 21:33:38.435+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb870fff0), gem(47), surface(0xb8a48c78)
01-22 21:33:38.515+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a3c148), gem(44), surface(0xb8909f50)
01-22 21:33:38.585+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(47), surface(0xb871f628)
01-22 21:33:38.625+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb891ee48), gem(44), surface(0xb8a48ab8)
01-22 21:33:38.705+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a4b300), gem(47), surface(0xb87ad4b0)
01-22 21:33:38.755+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(44), surface(0xb8a48ab8)
01-22 21:33:38.835+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb87ad4b0)
01-22 21:33:38.906+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb891ee48), gem(44), surface(0xb8a48ab8)
01-22 21:33:38.956+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a4b300), gem(47), surface(0xb87ad4b0)
01-22 21:33:39.036+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(44), surface(0xb8a48ab8)
01-22 21:33:39.106+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a50f08), gem(47), surface(0xb87ad4b0)
01-22 21:33:39.166+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb891ee48), gem(44), surface(0xb8a48ab8)
01-22 21:33:39.236+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8a4b300), gem(47), surface(0xb87ad4b0)
01-22 21:33:39.316+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb87ebb58), gem(44), surface(0xb8a48ab8)
01-22 21:33:39.366+0900 I/ISP_AE  ( 2529): calc_iso=540,real_gain=175,iso=0
01-22 21:33:39.376+0900 I/ISP_AE  ( 2529): calc_iso=540,real_gain=175,iso=0
01-22 21:33:39.376+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb890a390), gem(47), surface(0xb87ad4b0)
01-22 21:33:39.526+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200e5a bd->visible=1
01-22 21:33:39.636+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb890a270), gem(44), surface(0xb8a3b8e0)
01-22 21:33:39.646+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb89005b8), gem(49), surface(0xb8a3b8e0)
01-22 21:33:39.696+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb88f7d20), gem(44), surface(0xb87ad4b0)
01-22 21:33:39.736+0900 D/camera  ( 2529): Writing image to file.
01-22 21:33:39.766+0900 I/MALI    ( 2529): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb88f80e0), gem(47), surface(0xb8a3b8e0)
01-22 21:33:39.826+0900 W/CRASH_MANAGER( 2489): worker.c: worker_job(1204) > 110252963616d142193001
