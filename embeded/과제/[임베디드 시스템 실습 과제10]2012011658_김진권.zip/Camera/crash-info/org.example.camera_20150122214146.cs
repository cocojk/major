S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 3368
Date: 2015-01-22 21:41:46+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3368, uid 5000)

Register Information
r0   = 0x9383c008, r1   = 0x00000001
r2   = 0x001ba123, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x001ba123
r6   = 0x001ba123, r7   = 0xae02f588
r8   = 0xb7fd43a8, r9   = 0xae02f734
r10  = 0xb7fd98f8, fp   = 0x0000000d
ip   = 0xb6782110, sp   = 0xae02f4f0
lr   = 0xb33a7d5b, pc   = 0xb6782128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    424348 KB
Buffers:     19608 KB
Cached:     130836 KB
VmPeak:     588284 KB
VmSize:     588280 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       44784 KB
VmRSS:       44784 KB
VmData:     410564 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         286 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 3368 TID = 3575
3368 3369 3563 3564 3565 3566 3573 3574 3575 3576 3577 3578 3579 3580 3581 3582 3584 3585 3587 3588 3589 3590 3591 3592 3593 3594 3595 3596 3597 3598 3599 3600 3601 3602 3603 3604 3605 3606 3607 3608 3609 3611 3612 3613 3615 3616 3619 

Maps Information
93cdb000 944da000 rwxp [stack:3616]
944db000 94cda000 rwxp [stack:3615]
94d1c000 9551b000 rwxp [stack:3619]
993dd000 99bdc000 rwxp [stack:3613]
99bdd000 9a3dc000 rwxp [stack:3612]
9c2dd000 9cadc000 rwxp [stack:3611]
9cb74000 9d373000 rwxp [stack:3609]
9d374000 9db73000 rwxp [stack:3608]
9db74000 9e373000 rwxp [stack:3607]
9ea5f000 9f25e000 rwxp [stack:3606]
9f25f000 9fa5e000 rwxp [stack:3605]
9fa5f000 a025e000 rwxp [stack:3604]
a025f000 a0a5e000 rwxp [stack:3603]
a0a5f000 a125e000 rwxp [stack:3602]
a125f000 a1a5e000 rwxp [stack:3601]
a1a5f000 a225e000 rwxp [stack:3600]
a225f000 a2a5e000 rwxp [stack:3599]
a2a5f000 a325e000 rwxp [stack:3598]
a325f000 a3a5e000 rwxp [stack:3597]
a3a5f000 a425e000 rwxp [stack:3596]
a425f000 a4a5e000 rwxp [stack:3595]
a4a5f000 a525e000 rwxp [stack:3594]
a525f000 a5a5e000 rwxp [stack:3593]
a5a5f000 a625e000 rwxp [stack:3592]
a625f000 a6a5e000 rwxp [stack:3591]
a6d01000 a7500000 rwxp [stack:3590]
a7501000 a7d00000 rwxp [stack:3589]
a7d01000 a8500000 rwxp [stack:3588]
a8501000 a8d00000 rwxp [stack:3587]
a8d01000 a9500000 rwxp [stack:3585]
a9501000 a9d00000 rwxp [stack:3584]
a9d01000 aa500000 rwxp [stack:3582]
aa501000 aad00000 rwxp [stack:3581]
aad01000 ab500000 rwxp [stack:3580]
ab501000 abd00000 rwxp [stack:3579]
abd01000 ac500000 rwxp [stack:3578]
ac501000 acd00000 rwxp [stack:3577]
acf01000 ad700000 rwxp [stack:3576]
ad832000 ae031000 rwxp [stack:3575]
ae031000 ae034000 r-xp /usr/lib/libXv.so.1.0.0
ae044000 ae056000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae067000 ae09e000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae0b0000 ae8af000 rwxp [stack:3574]
ae8af000 ae8cc000 r-xp /usr/lib/libAl_Awb_Sp.so
ae8d5000 ae8d8000 r-xp /usr/lib/libdeflicker.so
ae8f0000 ae906000 r-xp /usr/lib/libAl_Awb.so
ae90e000 ae918000 r-xp /usr/lib/libcalibration.so
ae921000 ae933000 r-xp /usr/lib/libaf_lib.so
ae93b000 ae941000 r-xp /usr/lib/libspaf.so
ae949000 ae955000 r-xp /usr/lib/libae.so
ae95d000 ae99e000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae9e5000 aeac4000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aef21000 aef22000 r-xp /usr/lib/libcamerahdr.so.0.0.0
aef32000 aef6e000 r-xp /usr/lib/libcamerahal.so.0.0.0
af155000 af954000 rwxp [stack:3573]
af95c000 af974000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
b0501000 b0d00000 rwxp [stack:3566]
b0e00000 b0e06000 r-xp /usr/lib/liblsc.so
b0ed1000 b16d0000 rwxp [stack:3565]
b16d1000 b1ed0000 rwxp [stack:3564]
b1ed0000 b1ed5000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f61000 b1f69000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f7a000 b1f7b000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f8b000 b1f92000 r-xp /usr/lib/libfeedback.so.0.1.4
b1fb6000 b1fb7000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1fc7000 b1fda000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b202e000 b2033000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b2044000 b2843000 rwxp [stack:3563]
b2843000 b299e000 r-xp /usr/lib/egl/libMali.so
b29b3000 b2a3c000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a55000 b2b23000 r-xp /usr/lib/libCOREGL.so.4.0
b2b3e000 b2b41000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b51000 b2b5e000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b6f000 b2b79000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b89000 b2b95000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2ba6000 b2baa000 r-xp /usr/lib/libogg.so.0.7.1
b2bba000 b2bdc000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bec000 b2cd0000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2cec000 b2d2f000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d44000 b2d8b000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d9c000 b2da3000 r-xp /usr/lib/libjson-c.so.2.0.1
b2db3000 b2de8000 r-xp /usr/lib/libpulse.so.0.16.2
b2df9000 b2dfc000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2e0d000 b2e10000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2e21000 b2e64000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e75000 b2e7d000 r-xp /usr/lib/libdrm.so.2.4.0
b2e8d000 b2e8f000 r-xp /usr/lib/libdri2.so.0.0.0
b2e9f000 b2ea6000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2eb6000 b2ec1000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2ed5000 b2edb000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2eec000 b2ef4000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2f05000 b2f0a000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2f1a000 b2f31000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f41000 b2f61000 r-xp /usr/lib/libexif.so.12.3.3
b2f6d000 b2f75000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f85000 b2fb4000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2fc7000 b2fcf000 r-xp /usr/lib/libtbm.so.1.0.0
b2fdf000 b3098000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b30ac000 b30b3000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b30c3000 b3121000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b3136000 b313a000 r-xp /usr/lib/libstorage.so.0.1
b314a000 b3151000 r-xp /usr/lib/libefl-extension.so.0.1.0
b3161000 b3170000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b329a000 b329e000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b32af000 b338f000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b33a4000 b33a9000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b33b1000 b33d8000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33eb000 b3bea000 rwxp [stack:3369]
b3bea000 b3bec000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dfc000 b3e05000 r-xp /lib/libnss_files-2.20-2014.11.so
b3e16000 b3e1f000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e30000 b3e41000 r-xp /lib/libnsl-2.20-2014.11.so
b3e54000 b3e5a000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e6b000 b3e85000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e96000 b3e97000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3ea7000 b3ea9000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3eba000 b3ebf000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ecf000 b3ed2000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ee3000 b3eea000 r-xp /usr/lib/libsensord-share.so
b3efa000 b3f0b000 r-xp /usr/lib/libsensor.so.1.2.0
b3f1c000 b3f22000 r-xp /usr/lib/libappcore-common.so.1.1
b3f45000 b3f4a000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f60000 b3f62000 r-xp /usr/lib/libXau.so.6.0.0
b3f72000 b3f86000 r-xp /usr/lib/libxcb.so.1.1.0
b3f96000 b3f9d000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fd5000 b3fd7000 r-xp /usr/lib/libiri.so
b3fe8000 b3ffd000 r-xp /lib/libexpat.so.1.5.2
b400f000 b405d000 r-xp /usr/lib/libssl.so.1.0.0
b4072000 b407b000 r-xp /usr/lib/libethumb.so.1.13.0
b408c000 b408f000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b409f000 b4256000 r-xp /usr/lib/libcrypto.so.1.0.0
b57ed000 b57f6000 r-xp /usr/lib/libXi.so.6.1.0
b5807000 b5809000 r-xp /usr/lib/libXgesture.so.7.0.0
b5819000 b581d000 r-xp /usr/lib/libXtst.so.6.1.0
b582d000 b5833000 r-xp /usr/lib/libXrender.so.1.3.0
b5843000 b5849000 r-xp /usr/lib/libXrandr.so.2.2.0
b5859000 b585b000 r-xp /usr/lib/libXinerama.so.1.0.0
b586b000 b586e000 r-xp /usr/lib/libXfixes.so.3.1.0
b587f000 b588a000 r-xp /usr/lib/libXext.so.6.4.0
b589a000 b589c000 r-xp /usr/lib/libXdamage.so.1.1.0
b58ac000 b58ae000 r-xp /usr/lib/libXcomposite.so.1.0.0
b58be000 b59a1000 r-xp /usr/lib/libX11.so.6.3.0
b59b4000 b59bb000 r-xp /usr/lib/libXcursor.so.1.0.2
b59cc000 b59e4000 r-xp /usr/lib/libudev.so.1.6.0
b59e6000 b59e9000 r-xp /lib/libattr.so.1.1.0
b59f9000 b5a19000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5a1a000 b5a1f000 r-xp /usr/lib/libffi.so.6.0.2
b5a2f000 b5a47000 r-xp /lib/libz.so.1.2.8
b5a57000 b5a59000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a69000 b5b3e000 r-xp /usr/lib/libxml2.so.2.9.2
b5b53000 b5bee000 r-xp /usr/lib/libstdc++.so.6.0.20
b5c0a000 b5c0d000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5c1d000 b5c37000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c47000 b5c58000 r-xp /lib/libresolv-2.20-2014.11.so
b5c6c000 b5c83000 r-xp /usr/lib/liblzma.so.5.0.3
b5c93000 b5c95000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5ca5000 b5cac000 r-xp /usr/lib/libembryo.so.1.13.0
b5cbc000 b5cd4000 r-xp /usr/lib/libpng12.so.0.50.0
b5ce5000 b5d08000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d28000 b5d2e000 r-xp /lib/librt-2.20-2014.11.so
b5d3f000 b5d53000 r-xp /usr/lib/libector.so.1.13.0
b5d64000 b5d7c000 r-xp /usr/lib/liblua-5.1.so
b5d8d000 b5de4000 r-xp /usr/lib/libfreetype.so.6.11.3
b5df8000 b5e20000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e31000 b5e44000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e55000 b5e8f000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5ea0000 b5f0b000 r-xp /lib/libm-2.20-2014.11.so
b5f1c000 b5f29000 r-xp /usr/lib/libeio.so.1.13.0
b5f39000 b5f3b000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f4b000 b5f50000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f60000 b5f77000 r-xp /usr/lib/libefreet.so.1.13.0
b5f89000 b5fa9000 r-xp /usr/lib/libeldbus.so.1.13.0
b5fb9000 b5fd9000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fdb000 b5fe1000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5ff1000 b5ff8000 r-xp /usr/lib/libethumb_client.so.1.13.0
b6008000 b6016000 r-xp /usr/lib/libeo.so.1.13.0
b6026000 b6038000 r-xp /usr/lib/libecore_input.so.1.13.0
b6049000 b604e000 r-xp /usr/lib/libecore_file.so.1.13.0
b605e000 b6076000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6087000 b60a4000 r-xp /usr/lib/libeet.so.1.13.0
b60bd000 b6105000 r-xp /usr/lib/libeina.so.1.13.0
b6116000 b6126000 r-xp /usr/lib/libefl.so.1.13.0
b6137000 b621c000 r-xp /usr/lib/libicuuc.so.51.1
b6239000 b6379000 r-xp /usr/lib/libicui18n.so.51.1
b6390000 b63c8000 r-xp /usr/lib/libecore_x.so.1.13.0
b63da000 b63dd000 r-xp /lib/libcap.so.2.21
b63ed000 b6416000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6427000 b642e000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6440000 b6476000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6487000 b656f000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6583000 b65f9000 r-xp /usr/lib/libsqlite3.so.0.8.6
b660b000 b660e000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b661e000 b6629000 r-xp /usr/lib/libvconf.so.0.2.45
b6639000 b663b000 r-xp /usr/lib/libvasum.so.0.3.1
b664b000 b664d000 r-xp /usr/lib/libttrace.so.1.1
b665d000 b6660000 r-xp /usr/lib/libiniparser.so.0
b6670000 b6693000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b66a3000 b66a8000 r-xp /usr/lib/libxdgmime.so.1.1.0
b66b9000 b66d0000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66e1000 b66ee000 r-xp /usr/lib/libunwind.so.8.0.1
b6724000 b6848000 r-xp /lib/libc-2.20-2014.11.so
b685d000 b6876000 r-xp /lib/libgcc_s-4.9.so.1
b6886000 b6968000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6979000 b69ad000 r-xp /usr/lib/libdbus-1.so.3.8.11
b69bd000 b69f7000 r-xp /usr/lib/libsystemd.so.0.4.0
b69f9000 b6a79000 r-xp /usr/lib/libedje.so.1.13.0
b6a7c000 b6a9a000 r-xp /usr/lib/libecore.so.1.13.0
b6aba000 b6c1c000 r-xp /usr/lib/libevas.so.1.13.0
b6c53000 b6c67000 r-xp /lib/libpthread-2.20-2014.11.so
b6c7b000 b6e9f000 r-xp /usr/lib/libelementary.so.1.13.0
b6ecd000 b6ed1000 r-xp /usr/lib/libsmack.so.1.0.0
b6ee1000 b6ee7000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ef8000 b6efa000 r-xp /usr/lib/libdlog.so.0.0.0
b6f0a000 b6f0d000 r-xp /usr/lib/libbundle.so.0.1.22
b6f1d000 b6f1f000 r-xp /lib/libdl-2.20-2014.11.so
b6f30000 b6f49000 r-xp /usr/lib/libaul.so.0.1.0
b6f5b000 b6f5d000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f6e000 b6f72000 r-xp /usr/lib/libsys-assert.so
b6f83000 b6fa3000 r-xp /lib/ld-2.20-2014.11.so
b6fb4000 b6fba000 r-xp /usr/bin/launchpad-loader
b7d20000 b82c2000 rw-p [heap]
be833000 be854000 rwxp [stack]
be833000 be854000 rwxp [stack]
End of Maps Information

Callstack Information (PID:3368)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6782128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb33a7d5b) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d5b
 2: (0xb3165abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb30e8865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb644c5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb6458f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb645ea8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb645ec81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf966cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf967459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb68d7157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6c58cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
p:243:D] _terminate_app
01-22 21:41:41.586+0900 D/COM_CORE( 3227): com-core_packet.c: client_disconnected_cb(361) > [SECURE_LOG] Clean up all requests and a receive context for handle(49) for pid(-1)
01-22 21:41:41.586+0900 D/COM_CORE( 3227): com-core_thread.c: client_cb(378) > [SECURE_LOG] Thread is canceled
01-22 21:41:41.586+0900 D/COM_CORE( 3227): com-core_thread.c: client_cb(433) > [SECURE_LOG] Client CB is terminated (49)
01-22 21:41:41.586+0900 D/COM_CORE(  979): secure_socket.c: secure_socket_recv_with_fd(610) > [SECURE_LOG] Disconnected
01-22 21:41:41.596+0900 D/DATA_PROVIDER_MASTER(  979): notification_service.c: service_thread_main(851) > [SECURE_LOG] TCB: 0xb2300468 is terminated
01-22 21:41:41.596+0900 D/DATA_PROVIDER_MASTER(  979): service_common.c: tcb_destroy(613) > [SECURE_LOG] Thread returns: 0xffffff83
01-22 21:41:41.596+0900 E/COM_CORE( 3227): com-core_thread.c: terminate_thread(192) > [SECURE_LOG] Thread returns: -125
01-22 21:41:41.596+0900 E/LOCKSCREEN( 3227): contextual_event.c: lock_contextual_event_page_get(388) > [lock_contextual_event_page_get:388:E] (!s_info.box) -> lock_contextual_event_page_get() return
01-22 21:41:41.596+0900 E/LOCKSCREEN( 3227): contextual_event.c: lock_contextual_event_missed_event_del(643) > [lock_contextual_event_missed_event_del:643:E] (!page) -> lock_contextual_event_missed_event_del() return
01-22 21:41:41.606+0900 D/LOCKSCREEN( 3227): sim_state.c: lock_sim_state_deinit(640) > [lock_sim_state_deinit:640:D] De-initialization
01-22 21:41:41.606+0900 E/CALL_MGR_CLIENT( 3227): <LIB:cm_unset_call_status_cb:1538> CM_RETURN_VAL_IF_FAIL: Failed: Returning [-22]
01-22 21:41:41.606+0900 E/CALL_MGR_CLIENT( 3227): <LIB:cm_deinit:442> CM_RETURN_VAL_IF_FAIL: Failed: Returning [-22]
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=16
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 15, key = 16, type = 1
01-22 21:41:41.606+0900 D/SYSTEM-SETTINGS( 3227): system_setting_platform.c: system_setting_unset_changed_callback_time_changed(1669) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_time_changed. [0m
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=14
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 13, key = 14, type = 2
01-22 21:41:41.606+0900 D/SYSTEM-SETTINGS( 3227): system_setting_platform.c: system_setting_unset_changed_callback_locale_timeformat_24hour(1614) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_locale_timeformat_24hour. [0m
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=12
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 11, key = 12, type = 0
01-22 21:41:41.606+0900 D/SYSTEM-SETTINGS( 3227): system_setting_platform.c: system_setting_unset_changed_callback_locale_country(1504) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_locale_country. [0m
01-22 21:41:41.606+0900 D/LOCKSCREEN( 3227): property.c: lock_property_unregister(254) > [lock_property_unregister:254:D] unregister property cb
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=17
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 16, key = 17, type = 2
01-22 21:41:41.606+0900 D/SYSTEM-SETTINGS( 3227): system_setting_platform.c: system_setting_unset_changed_callback_sound_lock(1697) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_sound_lock. [0m
01-22 21:41:41.606+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_unset_changed_cb(589) > Enter [system_settings_unset_changed_cb]
01-22 21:41:41.616+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(379) > Enter [system_settings_get_item], key=19
01-22 21:41:41.616+0900 E/TIZEN_N_SYSTEM_SETTINGS( 3227): system_settings.c: system_settings_get_item(392) > Enter [system_settings_get_item], index = 18, key = 19, type = 2
01-22 21:41:41.616+0900 D/SYSTEM-SETTINGS( 3227): system_setting_platform.c: system_setting_unset_changed_callback_sound_touch(1810) > [SECURE_LOG] [0;35mENTER FUNCTION: system_setting_unset_changed_callback_sound_touch. [0m
01-22 21:41:41.636+0900 D/LOCKSCREEN( 3227): dbus.c: lock_dbus_fini(328) > [lock_dbus_fini:328:D] DBUS connection is closed
01-22 21:41:41.636+0900 E/E17_TZSH(  535): policy_tzsh.c: _policy_tzsh_service_destroy(118) > TZSH SERVICE DESTROY.. WIN:b34d37b8, role:118
01-22 21:41:41.636+0900 E/EFL     ( 3227): eo<3227> lib/eo/eo_ptr_indirection.x:294 _eo_obj_pointer_get() obj_id 0x80006433 is not pointing to a valid object. Maybe it has already been freed.
01-22 21:41:41.636+0900 E/EFL     ( 3227): eo<3227> lib/eo/eo.c:485 _eo_do_internal() Obj (0x80006433) is an invalid ref.
01-22 21:41:41.636+0900 I/TZSH    (  986): tzsh.c: _tizen_ws_shell_cb_service_remove(56) > INF: Removed service: 'lockscreen'
01-22 21:41:41.636+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01200007), visible:1
01-22 21:41:41.636+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:41:41.636+0900 W/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_send_mDNIe_action(612) > [PROCESSMGR] =====================> Broadcast mDNIeStatus : PID=3368
01-22 21:41:41.636+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_wininfo_del(160) > [PROCESSMGR] delete anr_trigger_timer!
01-22 21:41:41.636+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1200007
01-22 21:41:41.646+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.opaque
01-22 21:41:41.646+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:41:41.646+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:41:41.646+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:41:41.646+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:41:41.646+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:41:41.656+0900 D/APP_CORE( 3368): appcore-efl.c: __update_win(799) > [EVENT_TEST][EVENT] __update_win WIN:2e00003 fully_obscured 0
01-22 21:41:41.656+0900 D/APP_CORE( 3368): appcore-efl.c: __visibility_cb(974) > bvisibility 1, b_active 0
01-22 21:41:41.656+0900 D/APP_CORE( 3368): appcore-efl.c: __visibility_cb(977) >  Go to Resume state
01-22 21:41:41.656+0900 I/APP_CORE( 3368): appcore-efl.c: __do_app(496) > [APP 3368] Event: RESUME State: CREATED
01-22 21:41:41.656+0900 D/LAUNCH  ( 3368): appcore-efl.c: __do_app(597) > [camera:Application:resume:start]
01-22 21:41:41.656+0900 D/APP_CORE( 3368): appcore-efl.c: __do_app(601) > [__SUSPEND__] resume case
01-22 21:41:41.656+0900 D/APP_CORE( 3368): appcore-efl.c: __appcore_efl_exit_from_suspend(380) > [__SUSPEND__]
01-22 21:41:41.656+0900 D/APP_CORE( 3368): appcore-efl.c: __do_app(607) > [APP 3368] RESUME
01-22 21:41:41.666+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(3368) status(3)
01-22 21:41:41.666+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:41:41.677+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:41:41.677+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:41:41.677+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(3368) status(3)
01-22 21:41:41.677+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(3368) appid(org.example.camera) pkgid(org.example.camera) status(3)
01-22 21:41:41.677+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.example.camera
01-22 21:41:41.677+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 3368, appid: org.example.camera, status: fg
01-22 21:41:41.677+0900 I/APP_CORE( 3368): appcore-efl.c: __do_app(612) > Legacy lifecycle: 0
01-22 21:41:41.677+0900 I/APP_CORE( 3368): appcore-efl.c: __do_app(614) > [APP 3368] Initial Launching, call the resume_cb
01-22 21:41:41.677+0900 I/CAPI_APPFW_APPLICATION( 3368): app_main.c: _ui_app_appcore_resume(705) > app_appcore_resume
01-22 21:41:41.677+0900 D/LAUNCH  ( 3368): appcore-efl.c: __do_app(636) > [camera:Application:resume:done]
01-22 21:41:41.677+0900 D/LAUNCH  ( 3368): appcore-efl.c: __do_app(638) > [camera:Application:Launching:done]
01-22 21:41:41.677+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 3368
01-22 21:41:41.677+0900 D/APP_CORE( 3368): appcore-efl.c: __trm_app_info_send_socket(239) > __trm_app_info_send_socket
01-22 21:41:41.677+0900 E/APP_CORE( 3368): appcore-efl.c: __trm_app_info_send_socket(242) > access
01-22 21:41:41.677+0900 D/RESOURCED(  870): vmpressure-lowmem-handler.c: lowmem_move_memcgroup(1670) > pid: 3368, proc_name: org.example.camera, cg_name: foreground, oom_score_adj: 200
01-22 21:41:41.677+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/memory/foreground//cgroup.procs, value 3368
01-22 21:41:41.687+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(838) > __request_handler: 15
01-22 21:41:41.687+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3617) > [SECURE_LOG] where = package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:41:41.687+0900 D/PKGMGR_INFO(  819): pkgmgrinfo_appinfo.c: pkgmgrinfo_appinfo_filter_foreach_appinfo(3623) > [SECURE_LOG] query = select DISTINCT package_app_info.*, package_app_localized_info.app_locale, package_app_localized_info.app_label, package_app_localized_info.app_icon from package_app_info LEFT OUTER JOIN package_app_localized_info ON package_app_info.app_id=package_app_localized_info.app_id and package_app_localized_info.app_locale IN ('No Locale', 'en-us') LEFT OUTER JOIN package_app_app_svc ON package_app_info.app_id=package_app_app_svc.app_id LEFT OUTER JOIN package_app_app_category ON package_app_info.app_id=package_app_app_category.app_id where package_app_info.app_exec='/opt/usr/apps/org.example.camera/bin/camera' and package_app_info.app_disable IN ('false','False')
01-22 21:41:41.697+0900 I/MALI    ( 3227): egl_platform_x11.c: __egl_platform_terminate(333) > [EGL-X11] ################################################
01-22 21:41:41.697+0900 I/MALI    ( 3227): egl_platform_x11.c: __egl_platform_terminate(334) > [EGL-X11] PID=3227   close drm_fd=31 
01-22 21:41:41.697+0900 I/MALI    ( 3227): egl_platform_x11.c: __egl_platform_terminate(335) > [EGL-X11] ################################################
01-22 21:41:41.697+0900 D/AUL_AMD (  819): amd_status.c: _status_get_appid_bypid(971) > [SECURE_LOG] appid for 3368 is org.example.camera
01-22 21:41:41.697+0900 D/AUL_AMD (  819): amd_request.c: __request_handler(1039) > APP_GET_APPID_BYPID : 3368 : 0
01-22 21:41:41.697+0900 D/AUL     ( 1005): app_sock.c: __app_send_cmd_with_result(643) > recv result  = 27
01-22 21:41:41.747+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 3368, appname = org.example.camera, pkgname = org.example.camera
01-22 21:41:41.747+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 3368, appname = org.example.camera
01-22 21:41:41.747+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 3368
01-22 21:41:41.747+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 3368 foreground
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(665) > pfds[LAUNCH_PAD].revent  : 0x0
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 0].revents : 0x0
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 0].revents : 0x0
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 1].revents : 0x0
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 1].revents : 0x0
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(667) > pfds[POOL_TYPE + 2].revents : 0x0
01-22 21:41:42.027+0900 D/AUL_PAD (  958): launchpad.c: main(668) > pfds[CANDIDATE_TYPE + 2].revents : 0x0
01-22 21:41:42.027+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(160) > dead_pid = 3227 pgid = 3227
01-22 21:41:42.027+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(141) > dead_pid(3227)
01-22 21:41:42.057+0900 D/AUL_PAD (  958): sigchild.h: __send_app_dead_signal(90) > send dead signal done
01-22 21:41:42.057+0900 I/AUL_PAD (  958): sigchild.h: __sigchild_action(147) > __send_app_dead_signal(0)
01-22 21:41:42.057+0900 I/AUL_PAD (  958): sigchild.h: __launchpad_process_sigchld(168) > after __sigchild_action
01-22 21:41:42.057+0900 E/AUL_PAD (  958): launchpad.c: main(688) > error reading sigchld info
01-22 21:41:42.057+0900 I/ESD     (  993): esd_main.c: __esd_app_dead_handler(1771) > pid: 3227
01-22 21:41:42.057+0900 D/STARTER (  872): starter.c: _check_dead_signal(181) > [_check_dead_signal:181] Process 3227 is termianted
01-22 21:41:42.057+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(324) > __app_dead_handler, pid: 3227
01-22 21:41:42.057+0900 D/STARTER (  872): starter.c: _check_dead_signal(199) > [_check_dead_signal:199] lockscreen is dead
01-22 21:41:42.057+0900 E/STARTER (  872): lock_pwd_util.c: lock_pwd_util_win_visible_get(71) > [lock_pwd_util_win_visible_get:71] (!s_lock_pwd_util.lock_pwd_win) -> lock_pwd_util_win_visible_get() return
01-22 21:41:42.057+0900 D/STARTER (  872): lock_mgr.c: lock_mgr_unlock(339) > [lock_mgr_unlock:339] pwd win visible(0), lock type(1)
01-22 21:41:42.057+0900 W/AUL_AMD (  819): amd_main.c: __app_dead_handler(334) > app_group_leader_app, pid: 3227
01-22 21:41:42.057+0900 D/STARTER (  872): lock_mgr.c: lock_mgr_idle_lock_state_set(253) > [lock_mgr_idle_lock_state_set:253] lock state : 0
01-22 21:41:42.057+0900 D/AUL_AMD (  819): amd_key.c: _unregister_key_event(179) > ===key stack===
01-22 21:41:42.057+0900 E/AUL_AMD (  819): amd_launch.c: _revoke_temporary_permission(2128) > list or callee_label was null
01-22 21:41:42.057+0900 D/AUL_AMD (  819): amd_status.c: __remove_pkg_info(266) > ~STATUS_SERVICE : appid(org.tizen.lockscreen)
01-22 21:41:42.057+0900 D/AUL     (  819): simple_util.c: __trm_app_info_send_socket(325) > __trm_app_info_send_socket
01-22 21:41:42.057+0900 E/AUL     (  819): simple_util.c: __trm_app_info_send_socket(330) > access
01-22 21:41:42.067+0900 W/STARTER (  872): window_mgr.c: _pwd_transient_unset(159) > [_pwd_transient_unset:159] 0x1200007 is not transient
01-22 21:41:42.067+0900 D/INDICATOR(  893): util.c: util_signal_emit(84) > [SECURE_LOG] util_signal_emit[84]	 "emission clock.font.12"
01-22 21:41:42.077+0900 E/RESOURCED(  870): resourced-dbus.c: resourced_dbus_system_hash_drop_busname(324) > Does not exist in busname hash: :1.363
01-22 21:41:42.077+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_aul_terminated(1080) > received terminated process : pid 3227
01-22 21:41:42.077+0900 D/RESOURCED(  870): appinfo-list.c: resourced_appinfo_put(132) > appid org.tizen.lockscreen, pkgname = org.tizen.lockscreen, ref = 0
01-22 21:41:42.117+0900 D/VOLUME  (  912): control.c: _idle_lock_state_vconf_changed_cb(810) > [_idle_lock_state_vconf_changed_cb:810] idle lock state : 0
01-22 21:41:42.637+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x201560 
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): tunnig_param=263480
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): param_num=3
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): cur target lum=62, ev diff=0, level=4
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): AE VERSION : 0x20150828-00
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): cvg speed=0
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): target lum=62, target lum zone=8
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): lime time=134, min line=1
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): target_lum_ev0=62
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): highcount=19,lowcount=15
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): FDAE: failed open fdae_param.txt
01-22 21:41:42.908+0900 I/ISP_AE  ( 3368): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:41:42.908+0900 D/alPrinter0( 3368): LSC Size:20 16
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [LSC]TableSize=   320
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [LSC]TableSize=   320
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [LSC]TableSize=   320
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [OTP]module has otp data 0xb80d04cc (nil) 20 16
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [LSC]TableSize=   320
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [LSC]TableSize=   320
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:41:42.908+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): work_mode=0 last mode=0
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): cvg speed=0
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): target lum=62, target lum zone=8
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): lime time=134, min line=1
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): target_lum_ev0=62
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): highcount=19,lowcount=15
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): is_quick=0
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): AE_TEST:-----------SET index:282
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): AE_TEST:-----------SET index:282
01-22 21:41:43.038+0900 I/ISP_AE  ( 3368): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:41:43.048+0900 I/ISP_AE  ( 3368): calc_iso=50,real_gain=19,iso=0
01-22 21:41:43.318+0900 I/ISP_AE  ( 3368): set_weight, table[0] = 1
01-22 21:41:43.318+0900 I/ISP_AE  ( 3368): set weight from 1 to 0, rtn=0
01-22 21:41:43.318+0900 I/ISP_AE  ( 3368): AE_TEST ----------------------change to fast
01-22 21:41:43.318+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:282, cur_lum:0, next_index:340, target_lum:62
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,cf,a9,00,00,00,00
01-22 21:41:43.318+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,cf,a9,00,00,00,00
01-22 21:41:43.318+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LineAdj] Mode -2147483647
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LineAdj]Tar RGB 557,733,473
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LineAdj]Ref RGB 557,750,487
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LED]LPF Disable
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:41:43.318+0900 D/alPrinter0( 3368): [CHROMA]START BV=0.137497 Ratio=0.250000
01-22 21:41:43.328+0900 D/alPrinter0( 3368): [HSC]Mix=00000000,Csd=00000000 ,(BV= 0.137,x=0.355,y=0.385)
01-22 21:41:43.328+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:41:43.328+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=0.137504 ,Awb Bv=0.137497 in/out_0
01-22 21:41:43.328+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.286407,GGain=1.000000,BGain=1.292862,Dtct=0.354996,0.384995 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:41:43.438+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:340, cur_lum:0, next_index:398, target_lum:62
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:43.438+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:43.438+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [LED]LPF Disable
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.00, detect:32768.00,32768.00 CTemp:1817.3
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [HSC]Mix=00000000,Csd=00000000 ,(BV=-1.620,x=0.355,y=0.385)
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:4, 0x00000000,0x00000000
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-1.620296 ,Awb Bv=-1.620285 in/out_0
01-22 21:41:43.438+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.278168,GGain=1.000000,BGain=1.613815,Dtct=0.000000,0.000000 ,Curr=0.354996,0.384995 ,CTmep: QC=5004, AL= 4769
01-22 21:41:43.508+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c790), gem(44), surface(0xb7eca1d0)
01-22 21:41:43.508+0900 E/EFL     ( 3368): evas_main<3368> lib/evas/canvas/evas_object_image.c:3504 evas_object_image_render_pre() 0x8002a151 has invalid fill size: 0x0. Ignored
01-22 21:41:43.548+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:398, cur_lum:22, next_index:430, target_lum:62
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:43.548+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:43.548+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [LED]LPF Disable
01-22 21:41:43.548+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.558+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  1.00, detect:   0.35,   0.39 CTemp:4835.8
01-22 21:41:43.558+0900 D/alPrinter0( 3368): [HSC]Mix=00000000,Csd=0008b813 ,(BV=-2.620,x=0.353,y=0.387)
01-22 21:41:43.558+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:41:43.558+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-2.620296 ,Awb Bv=-2.620285 in/out_0
01-22 21:41:43.558+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.306732,GGain=1.000000,BGain=1.628723,Dtct=0.353210,0.386810 ,Curr=0.353210,0.386810 ,CTmep: QC=5080, AL= 4829
01-22 21:41:43.568+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(47), surface(0xb7eca1d0)
01-22 21:41:43.618+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(44), surface(0xb7eca1d0)
01-22 21:41:43.638+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_begin_handler(439) > [PROCESSMGR] ecore_x_netwm_ping_send to the client_win=0x2e00003
01-22 21:41:43.668+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:430, cur_lum:118, next_index:418, target_lum:62
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:43.668+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:43.668+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [LED]LPF Enable
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.668+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4634.9
01-22 21:41:43.678+0900 D/alPrinter0( 3368): [HSC]Mix=00001eb8,Csd=000b8cfe ,(BV=-2.614,x=0.360,y=0.391)
01-22 21:41:43.678+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:41:43.678+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-2.309956 ,Awb Bv=-2.613998 in/out_0
01-22 21:41:43.678+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.305893,GGain=1.000000,BGain=1.629486,Dtct=0.359940,0.390671 ,Curr=0.353348,0.386871 ,CTmep: QC=5080, AL= 4829
01-22 21:41:43.678+0900 I/MALI    ( 3368): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:41:43.688+0900 I/MALI    ( 3368): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:41:43.698+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80f12b8), gem(47), surface(0xb7eca2a0)
01-22 21:41:43.698+0900 I/MALI    ( 3368): tizen_buffer.c: tizen_dri2_get_buffers(734) > Re-used flag set for un-cached buffer.
01-22 21:41:43.749+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(44), surface(0xb7eca1d0)
01-22 21:41:43.789+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:418, cur_lum:102, next_index:410, target_lum:62
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:43.789+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:43.789+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.789+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.799+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.96, detect:   0.35,   0.37 CTemp:4962.5
01-22 21:41:43.799+0900 D/alPrinter0( 3368): [HSC]Mix=00003d70,Csd=000a5c9d ,(BV=-2.587,x=0.353,y=0.378)
01-22 21:41:43.799+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:41:43.799+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-2.586731 in/out_0
01-22 21:41:43.799+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.302795,GGain=1.000000,BGain=1.629929,Dtct=0.352524,0.377731 ,Curr=0.353668,0.386887 ,CTmep: QC=5077, AL= 4827
01-22 21:41:43.829+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(47), surface(0xb80f62b8)
01-22 21:41:43.879+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb825fb08), gem(44), surface(0xb7eca1d0)
01-22 21:41:43.909+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:410, cur_lum:62, next_index:410, target_lum:62
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:43.909+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:43.909+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.909+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 1 -> 1
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.94, detect:   0.33,   0.36 CTemp:5523.8
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [HSC]Mix=00005c28,Csd=00066b3a ,(BV=-2.532,x=0.341,y=0.370)
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-2.058417 ,Awb Bv=-2.531799 in/out_0
01-22 21:41:43.909+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.297058,GGain=1.000000,BGain=1.623779,Dtct=0.341110,0.369965 ,Curr=0.353699,0.386246 ,CTmep: QC=5076, AL= 4826
01-22 21:41:43.919+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(47), surface(0xb80f62b8)
01-22 21:41:43.969+0900 I/ISP_AE  ( 3368): AE_TEST ----------------------change to smooth
01-22 21:41:43.969+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:410, cur_lum:80, next_index:406, target_lum:62
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:43.969+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:43.969+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:43.969+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.87, detect:   0.33,   0.35 CTemp:5768.5
01-22 21:41:43.979+0900 D/alPrinter0( 3368): [HSC]Mix=00007ae0,Csd=0002dd64 ,(BV=-2.456,x=0.338,y=0.367)
01-22 21:41:43.979+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:41:43.979+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-1.914027 ,Awb Bv=-2.455627 in/out_0
01-22 21:41:43.979+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.291962,GGain=1.000000,BGain=1.607559,Dtct=0.337708,0.366516 ,Curr=0.352859,0.384628 ,CTmep: QC=5079, AL= 4828
01-22 21:41:43.999+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ba478), gem(44), surface(0xb80f62b8)
01-22 21:41:44.049+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(47), surface(0xb80f62b8)
01-22 21:41:44.089+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:406, cur_lum:87, next_index:394, target_lum:62
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:44.089+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:44.089+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:44.089+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:44.099+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.85, detect:   0.33,   0.35 CTemp:5750.2
01-22 21:41:44.099+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ba478), gem(44), surface(0xb80f62b8)
01-22 21:41:44.099+0900 D/alPrinter0( 3368): [HSC]Mix=00009998,Csd=0000e59f ,(BV=-2.358,x=0.323,y=0.353)
01-22 21:41:44.099+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:41:44.099+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-1.524081 ,Awb Bv=-2.358292 in/out_0
01-22 21:41:44.099+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.288986,GGain=1.000000,BGain=1.580505,Dtct=0.323471,0.353485 ,Curr=0.350891,0.381912 ,CTmep: QC=5086, AL= 4834
01-22 21:41:44.179+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(47), surface(0xb80f62b8)
01-22 21:41:44.229+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ba478), gem(44), surface(0xb80f62b8)
01-22 21:41:44.279+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(47), surface(0xb80f62b8)
01-22 21:41:44.329+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:394, cur_lum:94, next_index:376, target_lum:62
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:44.329+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:44.329+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:44.329+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.68, detect:   0.32,   0.34 CTemp:5950.6
01-22 21:41:44.339+0900 D/alPrinter0( 3368): [HSC]Mix=0000accb,Csd=fffdbe6f ,(BV=-2.226,x=0.324,y=0.352)
01-22 21:41:44.339+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:3, 0x0000accb,0x0000accb
01-22 21:41:44.339+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-0.988028 ,Awb Bv=-2.225891 in/out_0
01-22 21:41:44.339+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.289032,GGain=1.000000,BGain=1.543625,Dtct=0.323730,0.351578 ,Curr=0.347702,0.378113 ,CTmep: QC=5103, AL= 4847
01-22 21:41:44.349+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ba478), gem(44), surface(0xb80f62b8)
01-22 21:41:44.399+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(47), surface(0xb80f62b8)
01-22 21:41:44.479+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(44), surface(0xb80f62b8)
01-22 21:41:44.529+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(47), surface(0xb80f62b8)
01-22 21:41:44.559+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x201560 
01-22 21:41:44.569+0900 I/ISP_AE  ( 3368): AE_TEST:----cur_index:376, cur_lum:89, next_index:364, target_lum:62
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:41:44.569+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [CMD0][if=b80da130,Wrap=b80df660]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:41:44.569+0900 D/awb_al_cmd0( 3368): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [CALL][0xb80da130][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [AIS_WRAP]msiFlash_state=0
01-22 21:41:44.569+0900 D/alPrinter0( 3368): [LOCK]0
01-22 21:41:44.579+0900 D/alPrinter0( 3368): [SuperHighCTemp] Mapin:  0.60, detect:   0.32,   0.33 CTemp:6218.2
01-22 21:41:44.579+0900 D/alPrinter0( 3368): [HSC]Mix=00008e13,Csd=ffffad34 ,(BV=-2.044,x=0.319,y=0.346)
01-22 21:41:44.579+0900 D/alPrinter0( 3368): [AlHscWrap_Main]:4, 0x00008e13,0x00008e13
01-22 21:41:44.579+0900 D/alPrinter0( 3368): [AIS_WRAP]In BV=-0.572990 ,Awb Bv=-2.043930 in/out_0
01-22 21:41:44.579+0900 D/alPrinter0( 3368): [AIS_WRAP]RGain=1.289352,GGain=1.000000,BGain=1.508423,Dtct=0.318939,0.346436 ,Curr=0.343628,0.373489 ,CTmep: QC=5128, AL= 4867
01-22 21:41:44.609+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(44), surface(0xb80f62b8)
01-22 21:41:44.659+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(47), surface(0xb80f62b8)
01-22 21:41:44.679+0900 I/ISP_AE  ( 3368): ae_state=3
01-22 21:41:44.709+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7f4a288), gem(44), surface(0xb8227748)
01-22 21:41:44.760+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(47), surface(0xb80f62b8)
01-22 21:41:44.830+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(44), surface(0xb80f62b8)
01-22 21:41:44.890+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81ba478), gem(47), surface(0xb80f97a8)
01-22 21:41:44.900+0900 I/ISP_AE  ( 3368): FDAE: ->disable, frame_idx=30
01-22 21:41:44.960+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(44), surface(0xb80f62b8)
01-22 21:41:45.020+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb80c29e8), gem(47), surface(0xb8227748)
01-22 21:41:45.070+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(44), surface(0xb80f62b8)
01-22 21:41:45.140+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(47), surface(0xb80f62b8)
01-22 21:41:45.190+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(44), surface(0xb80f62b8)
01-22 21:41:45.240+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b0f38), gem(47), surface(0xb80f62b8)
01-22 21:41:45.310+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(44), surface(0xb80f62b8)
01-22 21:41:45.360+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(47), surface(0xb80f62b8)
01-22 21:41:45.440+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b0f38), gem(44), surface(0xb80f62b8)
01-22 21:41:45.490+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(47), surface(0xb80f62b8)
01-22 21:41:45.540+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(44), surface(0xb80f62b8)
01-22 21:41:45.620+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b0f38), gem(47), surface(0xb80f62b8)
01-22 21:41:45.670+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(44), surface(0xb80f62b8)
01-22 21:41:45.720+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(47), surface(0xb80f62b8)
01-22 21:41:45.791+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b0f38), gem(44), surface(0xb80f62b8)
01-22 21:41:45.841+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7fc5cd0), gem(47), surface(0xb80f62b8)
01-22 21:41:45.921+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb822c238), gem(44), surface(0xb80f62b8)
01-22 21:41:45.971+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b0f38), gem(47), surface(0xb80f62b8)
01-22 21:41:46.031+0900 I/ISP_AE  ( 3368): calc_iso=180,real_gain=60,iso=0
01-22 21:41:46.031+0900 I/ISP_AE  ( 3368): calc_iso=180,real_gain=60,iso=0
01-22 21:41:46.051+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b9a28), gem(44), surface(0xb80f62b8)
01-22 21:41:46.271+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b9de8), gem(47), surface(0xb80f62b8)
01-22 21:41:46.281+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b8bd0), gem(53), surface(0xb80f62b8)
01-22 21:41:46.331+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb81b8e70), gem(44), surface(0xb80f62b8)
01-22 21:41:46.371+0900 D/camera  ( 3368): Writing image to file.
01-22 21:41:46.401+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8230450), gem(47), surface(0xb80f62b8)
01-22 21:41:46.451+0900 I/MALI    ( 3368): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8230810), gem(44), surface(0xb80f62b8)
01-22 21:41:46.511+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:41:46.531+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:41:46.541+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x02e00003), visible:1
01-22 21:41:46.551+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x1037790), gem(13), surface(0x10023c8)
01-22 21:41:46.551+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:41:46.551+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:41:46.591+0900 W/CRASH_MANAGER( 3624): worker.c: worker_job(1204) > 110336863616d142193050
