S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2406
Date: 2015-01-22 21:33:01+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2406, uid 5000)

Register Information
r0   = 0x931d4008, r1   = 0x00000001
r2   = 0x0024b6a6, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0024b6a6
r6   = 0x0024b6a6, r7   = 0xad781588
r8   = 0xb863e8b8, r9   = 0xad781734
r10  = 0xb8645660, fp   = 0x0000000d
ip   = 0xb6718110, sp   = 0xad7814f0
lr   = 0xb333dd13, pc   = 0xb6718128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    431280 KB
Buffers:     18096 KB
Cached:     128760 KB
VmPeak:     594560 KB
VmSize:     594556 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       46716 KB
VmRSS:       46716 KB
VmData:     416840 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         288 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 2406 TID = 2438
2406 2407 2429 2430 2431 2432 2433 2436 2437 2438 2439 2440 2441 2442 2443 2444 2445 2448 2449 2450 2451 2452 2453 2454 2455 2456 2457 2458 2459 2460 2461 2462 2463 2464 2465 2466 2467 2468 2469 2470 2471 2472 2474 2475 2476 2479 2480 2484 

Maps Information
9375e000 93f5d000 rwxp [stack:2480]
93f5e000 9475d000 rwxp [stack:2479]
9479f000 94f9e000 rwxp [stack:2484]
98e60000 9965f000 rwxp [stack:2476]
99660000 99e5f000 rwxp [stack:2475]
9bd60000 9c55f000 rwxp [stack:2474]
9c5f7000 9cdf6000 rwxp [stack:2472]
9cdf7000 9d5f6000 rwxp [stack:2471]
9d5f7000 9ddf6000 rwxp [stack:2470]
9e4e2000 9ece1000 rwxp [stack:2469]
9ece2000 9f4e1000 rwxp [stack:2468]
9f4e2000 9fce1000 rwxp [stack:2467]
9fce2000 a04e1000 rwxp [stack:2466]
a04e2000 a0ce1000 rwxp [stack:2465]
a0ce2000 a14e1000 rwxp [stack:2464]
a14e2000 a1ce1000 rwxp [stack:2463]
a1ce2000 a24e1000 rwxp [stack:2462]
a24e2000 a2ce1000 rwxp [stack:2461]
a2ce2000 a34e1000 rwxp [stack:2460]
a34e2000 a3ce1000 rwxp [stack:2459]
a3ce2000 a44e1000 rwxp [stack:2458]
a44e2000 a4ce1000 rwxp [stack:2457]
a4f84000 a5783000 rwxp [stack:2456]
a5784000 a5f83000 rwxp [stack:2455]
a5f84000 a6783000 rwxp [stack:2454]
a6784000 a6f83000 rwxp [stack:2453]
a6f84000 a7783000 rwxp [stack:2452]
a7784000 a7f83000 rwxp [stack:2451]
a7f84000 a8783000 rwxp [stack:2450]
a8784000 a8f83000 rwxp [stack:2449]
a8f84000 a9783000 rwxp [stack:2448]
a9784000 a9f83000 rwxp [stack:2445]
a9f84000 aa783000 rwxp [stack:2444]
aa784000 aaf83000 rwxp [stack:2443]
aaf84000 ab783000 rwxp [stack:2442]
ab784000 abf83000 rwxp [stack:2441]
abf84000 ac783000 rwxp [stack:2440]
ac784000 acf83000 rwxp [stack:2439]
acf84000 ad783000 rwxp [stack:2438]
ad783000 ad786000 r-xp /usr/lib/libXv.so.1.0.0
ad796000 ad7a8000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad7b9000 ad7f0000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad802000 ae001000 rwxp [stack:2437]
ae001000 ae01e000 r-xp /usr/lib/libAl_Awb_Sp.so
ae027000 ae02a000 r-xp /usr/lib/libdeflicker.so
ae042000 ae058000 r-xp /usr/lib/libAl_Awb.so
ae060000 ae06a000 r-xp /usr/lib/libcalibration.so
ae073000 ae085000 r-xp /usr/lib/libaf_lib.so
ae08d000 ae093000 r-xp /usr/lib/liblsc.so
ae09c000 ae0dd000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae124000 ae203000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae660000 ae69c000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae766000 aef65000 rwxp [stack:2436]
aef65000 aef6b000 r-xp /usr/lib/libspaf.so
aef73000 aef7f000 r-xp /usr/lib/libae.so
aef87000 aef88000 r-xp /usr/lib/libcamerahdr.so.0.0.0
aefdc000 aeff4000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afd01000 b0500000 rwxp [stack:2433]
b0501000 b0d00000 rwxp [stack:2432]
b0e67000 b1666000 rwxp [stack:2431]
b1667000 b1e66000 rwxp [stack:2430]
b1e66000 b1e6b000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1ef7000 b1eff000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f10000 b1f11000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f21000 b1f28000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f4c000 b1f4d000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f5d000 b1f70000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1fc4000 b1fc9000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1fda000 b27d9000 rwxp [stack:2429]
b27d9000 b2934000 r-xp /usr/lib/egl/libMali.so
b2949000 b29d2000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b29eb000 b2ab9000 r-xp /usr/lib/libCOREGL.so.4.0
b2ad4000 b2ad7000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2ae7000 b2af4000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b05000 b2b0f000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b1f000 b2b2b000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b3c000 b2b40000 r-xp /usr/lib/libogg.so.0.7.1
b2b50000 b2b72000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b82000 b2c66000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c82000 b2cc5000 r-xp /usr/lib/libsndfile.so.1.0.25
b2cda000 b2d21000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d32000 b2d39000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d49000 b2d7e000 r-xp /usr/lib/libpulse.so.0.16.2
b2d8f000 b2d92000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2da3000 b2da6000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2db7000 b2dfa000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e0b000 b2e13000 r-xp /usr/lib/libdrm.so.2.4.0
b2e23000 b2e25000 r-xp /usr/lib/libdri2.so.0.0.0
b2e35000 b2e3c000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e4c000 b2e57000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e6b000 b2e71000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e82000 b2e8a000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2e9b000 b2ea0000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2eb0000 b2ec7000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2ed7000 b2ef7000 r-xp /usr/lib/libexif.so.12.3.3
b2f03000 b2f0b000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f1b000 b2f4a000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f5d000 b2f65000 r-xp /usr/lib/libtbm.so.1.0.0
b2f75000 b302e000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3042000 b3049000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b3059000 b30b7000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30cc000 b30d0000 r-xp /usr/lib/libstorage.so.0.1
b30e0000 b30e7000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30f7000 b3106000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3230000 b3234000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3245000 b3325000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b333a000 b333f000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b3347000 b336e000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3381000 b3b80000 rwxp [stack:2407]
b3b80000 b3b82000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d92000 b3d9b000 r-xp /lib/libnss_files-2.20-2014.11.so
b3dac000 b3db5000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3dc6000 b3dd7000 r-xp /lib/libnsl-2.20-2014.11.so
b3dea000 b3df0000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e01000 b3e1b000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e2c000 b3e2d000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e3d000 b3e3f000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e50000 b3e55000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e65000 b3e68000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e79000 b3e80000 r-xp /usr/lib/libsensord-share.so
b3e90000 b3ea1000 r-xp /usr/lib/libsensor.so.1.2.0
b3eb2000 b3eb8000 r-xp /usr/lib/libappcore-common.so.1.1
b3edb000 b3ee0000 r-xp /usr/lib/libappcore-efl.so.1.1
b3ef6000 b3ef8000 r-xp /usr/lib/libXau.so.6.0.0
b3f08000 b3f1c000 r-xp /usr/lib/libxcb.so.1.1.0
b3f2c000 b3f33000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f6b000 b3f6d000 r-xp /usr/lib/libiri.so
b3f7e000 b3f93000 r-xp /lib/libexpat.so.1.5.2
b3fa5000 b3ff3000 r-xp /usr/lib/libssl.so.1.0.0
b4008000 b4011000 r-xp /usr/lib/libethumb.so.1.13.0
b4022000 b4025000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4035000 b41ec000 r-xp /usr/lib/libcrypto.so.1.0.0
b5783000 b578c000 r-xp /usr/lib/libXi.so.6.1.0
b579d000 b579f000 r-xp /usr/lib/libXgesture.so.7.0.0
b57af000 b57b3000 r-xp /usr/lib/libXtst.so.6.1.0
b57c3000 b57c9000 r-xp /usr/lib/libXrender.so.1.3.0
b57d9000 b57df000 r-xp /usr/lib/libXrandr.so.2.2.0
b57ef000 b57f1000 r-xp /usr/lib/libXinerama.so.1.0.0
b5801000 b5804000 r-xp /usr/lib/libXfixes.so.3.1.0
b5815000 b5820000 r-xp /usr/lib/libXext.so.6.4.0
b5830000 b5832000 r-xp /usr/lib/libXdamage.so.1.1.0
b5842000 b5844000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5854000 b5937000 r-xp /usr/lib/libX11.so.6.3.0
b594a000 b5951000 r-xp /usr/lib/libXcursor.so.1.0.2
b5962000 b597a000 r-xp /usr/lib/libudev.so.1.6.0
b597c000 b597f000 r-xp /lib/libattr.so.1.1.0
b598f000 b59af000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59b0000 b59b5000 r-xp /usr/lib/libffi.so.6.0.2
b59c5000 b59dd000 r-xp /lib/libz.so.1.2.8
b59ed000 b59ef000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59ff000 b5ad4000 r-xp /usr/lib/libxml2.so.2.9.2
b5ae9000 b5b84000 r-xp /usr/lib/libstdc++.so.6.0.20
b5ba0000 b5ba3000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bb3000 b5bcd000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bdd000 b5bee000 r-xp /lib/libresolv-2.20-2014.11.so
b5c02000 b5c19000 r-xp /usr/lib/liblzma.so.5.0.3
b5c29000 b5c2b000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c3b000 b5c42000 r-xp /usr/lib/libembryo.so.1.13.0
b5c52000 b5c6a000 r-xp /usr/lib/libpng12.so.0.50.0
b5c7b000 b5c9e000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cbe000 b5cc4000 r-xp /lib/librt-2.20-2014.11.so
b5cd5000 b5ce9000 r-xp /usr/lib/libector.so.1.13.0
b5cfa000 b5d12000 r-xp /usr/lib/liblua-5.1.so
b5d23000 b5d7a000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d8e000 b5db6000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5dc7000 b5dda000 r-xp /usr/lib/libfribidi.so.0.3.1
b5deb000 b5e25000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e36000 b5ea1000 r-xp /lib/libm-2.20-2014.11.so
b5eb2000 b5ebf000 r-xp /usr/lib/libeio.so.1.13.0
b5ecf000 b5ed1000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5ee1000 b5ee6000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5ef6000 b5f0d000 r-xp /usr/lib/libefreet.so.1.13.0
b5f1f000 b5f3f000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f4f000 b5f6f000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f71000 b5f77000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f87000 b5f8e000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f9e000 b5fac000 r-xp /usr/lib/libeo.so.1.13.0
b5fbc000 b5fce000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fdf000 b5fe4000 r-xp /usr/lib/libecore_file.so.1.13.0
b5ff4000 b600c000 r-xp /usr/lib/libecore_evas.so.1.13.0
b601d000 b603a000 r-xp /usr/lib/libeet.so.1.13.0
b6053000 b609b000 r-xp /usr/lib/libeina.so.1.13.0
b60ac000 b60bc000 r-xp /usr/lib/libefl.so.1.13.0
b60cd000 b61b2000 r-xp /usr/lib/libicuuc.so.51.1
b61cf000 b630f000 r-xp /usr/lib/libicui18n.so.51.1
b6326000 b635e000 r-xp /usr/lib/libecore_x.so.1.13.0
b6370000 b6373000 r-xp /lib/libcap.so.2.21
b6383000 b63ac000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63bd000 b63c4000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63d6000 b640c000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b641d000 b6505000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b6519000 b658f000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65a1000 b65a4000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65b4000 b65bf000 r-xp /usr/lib/libvconf.so.0.2.45
b65cf000 b65d1000 r-xp /usr/lib/libvasum.so.0.3.1
b65e1000 b65e3000 r-xp /usr/lib/libttrace.so.1.1
b65f3000 b65f6000 r-xp /usr/lib/libiniparser.so.0
b6606000 b6629000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b6639000 b663e000 r-xp /usr/lib/libxdgmime.so.1.1.0
b664f000 b6666000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6677000 b6684000 r-xp /usr/lib/libunwind.so.8.0.1
b66ba000 b67de000 r-xp /lib/libc-2.20-2014.11.so
b67f3000 b680c000 r-xp /lib/libgcc_s-4.9.so.1
b681c000 b68fe000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b690f000 b6943000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6953000 b698d000 r-xp /usr/lib/libsystemd.so.0.4.0
b698f000 b6a0f000 r-xp /usr/lib/libedje.so.1.13.0
b6a12000 b6a30000 r-xp /usr/lib/libecore.so.1.13.0
b6a50000 b6bb2000 r-xp /usr/lib/libevas.so.1.13.0
b6be9000 b6bfd000 r-xp /lib/libpthread-2.20-2014.11.so
b6c11000 b6e35000 r-xp /usr/lib/libelementary.so.1.13.0
b6e63000 b6e67000 r-xp /usr/lib/libsmack.so.1.0.0
b6e77000 b6e7d000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e8e000 b6e90000 r-xp /usr/lib/libdlog.so.0.0.0
b6ea0000 b6ea3000 r-xp /usr/lib/libbundle.so.0.1.22
b6eb3000 b6eb5000 r-xp /lib/libdl-2.20-2014.11.so
b6ec6000 b6edf000 r-xp /usr/lib/libaul.so.0.1.0
b6ef1000 b6ef3000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f04000 b6f08000 r-xp /usr/lib/libsys-assert.so
b6f19000 b6f39000 r-xp /lib/ld-2.20-2014.11.so
b6f4a000 b6f50000 r-xp /usr/bin/launchpad-loader
b838a000 b892d000 rw-p [heap]
befd7000 beff8000 rwxp [stack]
befd7000 beff8000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2406)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb6718128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb333dd13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb30fbabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb307e865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63e25bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb63eef67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb63f4a8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb63f4c81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaefe6cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaefe7459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb686d157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6beecf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
 > [PROCESSMGR] last_pointed_win=0x200082 bd->visible=0
01-22 21:32:56.975+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.025+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.105+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.155+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.205+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.275+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.325+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.405+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.455+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.505+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.575+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.625+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.675+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.755+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.755+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
01-22 21:32:57.755+0900 I/APP_CORE(  913): appcore-efl.c: __do_app(496) > [APP 913] Event: MEM_FLUSH State: PAUSED
01-22 21:32:57.755+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
01-22 21:32:57.755+0900 D/APP_CORE(  913): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 913
01-22 21:32:57.755+0900 D/APP_CORE(  913): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
01-22 21:32:57.765+0900 D/RESOURCED(  870): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 913
01-22 21:32:57.805+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.885+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:57.936+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:57.986+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.056+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.106+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.156+0900 I/ISP_AE  ( 2406): ANTI_FLAG: =600000, 4477, 134, 1
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v_s :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v_s :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :1
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :2
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 70
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :3
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :70
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -7
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 100
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :4
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :100
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -7
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :5
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.166+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :6
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :7
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :8
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.176+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.186+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :9
01-22 21:32:58.186+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.186+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.186+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.186+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.186+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.186+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :10
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :11
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :12
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.196+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :13
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :14
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :15
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :16
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.206+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :17
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :18
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :19
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.216+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :20
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :21
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :22
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :23
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :24
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.226+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :25
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.236+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.236+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :26
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :27
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :28
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :29
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.246+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :30
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v_s :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v_s :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :31
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :32
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :33
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.256+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :34
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :35
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :36
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :37
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :38
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.266+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :39
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 30
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :40
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :30
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -7
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :41
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :42
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :43
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.276+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :44
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :45
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :46
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.286+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :47
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :48
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.286+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :49
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :50
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :51
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :52
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.296+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :53
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :54
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :55
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :56
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :57
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :58
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.306+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :59
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman frame_flicker_value = 0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman still_f :60
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v :0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman b0 0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman b1 200
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman b2 -10
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v :0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_f_v_s :0
01-22 21:32:58.316+0900 I/ISP_DEFLICKER V3( 2406): hyman afl_v_v_s :0
01-22 21:32:58.366+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.416+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.466+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.536+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.586+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.666+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.716+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.766+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.846+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:58.896+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:58.947+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.017+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.067+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.147+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.157+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 1 -> 3
01-22 21:32:59.157+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 1 -> 3
01-22 21:32:59.157+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:32:59.197+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.247+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.317+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.357+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 3 -> 1
01-22 21:32:59.357+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 3 -> 1
01-22 21:32:59.357+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:32:59.377+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.447+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.497+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.547+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.627+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.677+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.727+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.797+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.847+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:32:59.877+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200d7b bd->visible=1
01-22 21:32:59.927+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8841750)
01-22 21:32:59.978+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841750)
01-22 21:33:00.038+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8630218), gem(45), surface(0xb8906af0)
01-22 21:33:00.108+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200d7b 
01-22 21:33:00.108+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb88538b8), gem(44), surface(0xb8841750)
01-22 21:33:00.138+0900 I/ISP_AE  ( 2406): ae_state=3
01-22 21:33:00.158+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8630218), gem(45), surface(0xb88408b0)
01-22 21:33:00.228+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb88538b8), gem(44), surface(0xb8906af0)
01-22 21:33:00.288+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8906ba0), gem(45), surface(0xb88408b0)
01-22 21:33:00.338+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb88538b8), gem(44), surface(0xb8906af0)
01-22 21:33:00.428+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8906ba0), gem(45), surface(0xb8908288)
01-22 21:33:00.468+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb88538b8), gem(44), surface(0xb87e8108)
01-22 21:33:00.518+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(45), surface(0xb887c928)
01-22 21:33:00.598+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(44), surface(0xb88408b0)
01-22 21:33:00.638+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8630218), gem(45), surface(0xb8906af0)
01-22 21:33:00.718+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841740)
01-22 21:33:00.768+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb87e8108)
01-22 21:33:00.818+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8630218), gem(44), surface(0xb8841740)
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_get_apm_by_region(666) > indicator_get_apm_by_region[666]	 "TimeZone is Asia/Seoul"
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(780) > indicator_get_time_by_region[780]	 "BestPattern is h"
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(781) > indicator_get_time_by_region[781]	 "TimeZone is Asia/Seoul"
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(801) > indicator_get_time_by_region[801]	 "DATE & TIME is en_US 9:33 4 h"
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(803) > indicator_get_time_by_region[803]	 "24H :: Before change 9:33"
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_get_time_by_region(810) > indicator_get_time_by_region[810]	 "24H :: After change 9&#x2236;33"
01-22 21:33:00.838+0900 D/INDICATOR(  893): clock.c: indicator_clock_changed_cb(295) > [CLOCK MODULE] Timer Status : -2146982957 Time: <font_size=33>9&#x2236;33</font_size> <font_size=32>PM</font_size></font>
01-22 21:33:00.888+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(45), surface(0xb87e8108)
01-22 21:33:00.938+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(44), surface(0xb8841740)
01-22 21:33:00.989+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8630218), gem(45), surface(0xb87e8108)
01-22 21:33:01.069+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(44), surface(0xb8841740)
01-22 21:33:01.119+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(45), surface(0xb8728658)
01-22 21:33:01.169+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8630218), gem(44), surface(0xb8841740)
01-22 21:33:01.249+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb85fc800), gem(45), surface(0xb8728658)
01-22 21:33:01.299+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8832a20), gem(44), surface(0xb8841740)
01-22 21:33:01.359+0900 I/ISP_AE  ( 2406): calc_iso=1250,real_gain=400,iso=0
01-22 21:33:01.369+0900 I/ISP_AE  ( 2406): calc_iso=1250,real_gain=400,iso=0
01-22 21:33:01.379+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8867068), gem(45), surface(0xb8841740)
01-22 21:33:01.609+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8866bc8), gem(44), surface(0xb8841740)
01-22 21:33:01.609+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb886aca8), gem(46), surface(0xb8841740)
01-22 21:33:01.659+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb886adb0), gem(44), surface(0xb8841740)
01-22 21:33:01.719+0900 D/camera  ( 2406): Writing image to file.
01-22 21:33:01.729+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb886aa40), gem(45), surface(0xb8841740)
01-22 21:33:01.779+0900 I/MALI    ( 2406): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8867408), gem(44), surface(0xb8841740)
01-22 21:33:01.849+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:33:01.869+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:33:01.879+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:33:01.879+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1600003
01-22 21:33:01.879+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:33:01.879+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:33:01.879+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:33:01.879+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:33:01.879+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:33:01.889+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xed7b90), gem(13), surface(0xfcd958)
01-22 21:33:01.899+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:33:01.899+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:33:01.919+0900 W/CRASH_MANAGER( 2489): worker.c: worker_job(1204) > 110240663616d142192998
