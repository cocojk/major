S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2833
Date: 2015-01-22 21:19:36+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 2833, uid 5000)

Register Information
r0   = 0xfffffffc, r1   = 0x00000080
r2   = 0x00000002, r3   = 0x00000000
r4   = 0xb6ac67b3, r5   = 0xb85a6e50
r6   = 0xb85a6e50, r7   = 0x000000f0
r8   = 0x8002a151, r9   = 0xb5ffef74
r10  = 0xb82d5810, fp   = 0xb82d5844
ip   = 0xbeaa1cf8, sp   = 0xbeaa1ce8
lr   = 0xb68c44fb, pc   = 0xb67c5ee0
cpsr = 0x200f0010

Memory Information
MemTotal:   987196 KB
MemFree:    389980 KB
Buffers:     21160 KB
Cached:     147172 KB
VmPeak:     607508 KB
VmSize:     607504 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       49264 KB
VmRSS:       46952 KB
VmData:     423220 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         304 KB
VmSwap:          0 KB

Threads Information
Threads: 46
PID = 2833 TID = 2833
2833 2834 3032 3033 3034 3035 3043 3351 3483 3489 3490 3491 3492 3493 3494 3495 3496 3497 3498 3499 3500 3501 3504 3505 3506 3507 3508 3509 3510 3511 3512 3513 3514 3515 3516 3517 3518 3519 3520 3521 3522 3523 3524 3526 3527 3529 

Maps Information
90d27000 91526000 rwxp [stack:3483]
92096000 92895000 rwxp [stack:3529]
964e7000 96ce6000 rwxp [stack:3495]
986e7000 98ee6000 rwxp [stack:3494]
996e7000 99ee6000 rwxp [stack:3489]
9b6df000 9bede000 rwxp [stack:3527]
9bedf000 9c6de000 rwxp [stack:3492]
9c6df000 9cede000 rwxp [stack:3493]
9cedf000 9d6de000 rwxp [stack:3490]
9d71d000 9df1c000 rwxp [stack:3526]
9e77a000 9ef79000 rwxp [stack:3491]
9f67f000 9fe7e000 rwxp [stack:3524]
9fe7f000 a067e000 rwxp [stack:3351]
a0831000 a1030000 rwxp [stack:3523]
a1715000 a1f14000 rwxp [stack:3522]
a1f15000 a2714000 rwxp [stack:3521]
a2715000 a2f14000 rwxp [stack:3520]
a2f15000 a3714000 rwxp [stack:3519]
a3800000 a3fff000 rwxp [stack:3518]
a4000000 a47ff000 rwxp [stack:3517]
a4800000 a4fff000 rwxp [stack:3516]
a5000000 a57ff000 rwxp [stack:3515]
a5800000 a5fff000 rwxp [stack:3514]
a6000000 a67ff000 rwxp [stack:3513]
a6800000 a6fff000 rwxp [stack:3512]
a7000000 a77ff000 rwxp [stack:3511]
a7800000 a7fff000 rwxp [stack:3510]
a8221000 a8a20000 rwxp [stack:3509]
a8a21000 a9220000 rwxp [stack:3508]
a9221000 a9a20000 rwxp [stack:3507]
a9ce0000 aa4df000 rwxp [stack:3506]
aa80b000 ab00a000 rwxp [stack:3505]
ab00b000 ab80a000 rwxp [stack:3504]
ab80b000 ac00a000 rwxp [stack:3501]
ac00b000 ac80a000 rwxp [stack:3500]
ac80b000 ad00a000 rwxp [stack:3499]
ad00b000 ad80a000 rwxp [stack:3498]
ad80b000 ae00a000 rwxp [stack:3496]
ae00a000 ae00d000 r-xp /usr/lib/libXv.so.1.0.0
ae01d000 ae02f000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ae040000 ae077000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae089000 ae888000 rwxp [stack:3497]
ae888000 ae8a5000 r-xp /usr/lib/libAl_Awb_Sp.so
ae8ae000 ae8b1000 r-xp /usr/lib/libdeflicker.so
ae8c9000 ae8df000 r-xp /usr/lib/libAl_Awb.so
ae8e7000 ae8f1000 r-xp /usr/lib/libcalibration.so
ae8fa000 ae90c000 r-xp /usr/lib/libaf_lib.so
ae914000 ae91a000 r-xp /usr/lib/libspaf.so
ae922000 ae928000 r-xp /usr/lib/liblsc.so
ae931000 ae93d000 r-xp /usr/lib/libae.so
ae945000 ae986000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae9cd000 aeaac000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aef09000 aef45000 r-xp /usr/lib/libcamerahal.so.0.0.0
aef57000 aef6f000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
af001000 af800000 rwxp [stack:3043]
af906000 af907000 r-xp /usr/lib/libcamerahdr.so.0.0.0
b0501000 b0d00000 rwxp [stack:3035]
b0eaa000 b16a9000 rwxp [stack:3034]
b16aa000 b1ea9000 rwxp [stack:3033]
b1ea9000 b1eae000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1f3a000 b1f42000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1f53000 b1f54000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f64000 b1f6b000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f8f000 b1f90000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1fa0000 b1fb3000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2007000 b200c000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b201d000 b281c000 rwxp [stack:3032]
b281c000 b2977000 r-xp /usr/lib/egl/libMali.so
b298c000 b2a15000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2a2e000 b2afc000 r-xp /usr/lib/libCOREGL.so.4.0
b2b17000 b2b1a000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2b2a000 b2b37000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2b48000 b2b52000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b62000 b2b6e000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b7f000 b2b83000 r-xp /usr/lib/libogg.so.0.7.1
b2b93000 b2bb5000 r-xp /usr/lib/libvorbis.so.0.4.3
b2bc5000 b2ca9000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2cc5000 b2d08000 r-xp /usr/lib/libsndfile.so.1.0.25
b2d1d000 b2d64000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d75000 b2d7c000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d8c000 b2dc1000 r-xp /usr/lib/libpulse.so.0.16.2
b2dd2000 b2dd5000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2de6000 b2de9000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2dfa000 b2e3d000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2e4e000 b2e56000 r-xp /usr/lib/libdrm.so.2.4.0
b2e66000 b2e68000 r-xp /usr/lib/libdri2.so.0.0.0
b2e78000 b2e7f000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e8f000 b2e9a000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2eae000 b2eb4000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2ec5000 b2ecd000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ede000 b2ee3000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2ef3000 b2f0a000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2f1a000 b2f3a000 r-xp /usr/lib/libexif.so.12.3.3
b2f46000 b2f4e000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f5e000 b2f8d000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2fa0000 b2fa8000 r-xp /usr/lib/libtbm.so.1.0.0
b2fb8000 b3071000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3085000 b308c000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b309c000 b30fa000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b310f000 b3113000 r-xp /usr/lib/libstorage.so.0.1
b3123000 b312a000 r-xp /usr/lib/libefl-extension.so.0.1.0
b313a000 b3149000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3273000 b3277000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b3288000 b3368000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b337d000 b3382000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b338a000 b33b1000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b33c4000 b3bc3000 rwxp [stack:2834]
b3bc3000 b3bc5000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3dd5000 b3dde000 r-xp /lib/libnss_files-2.20-2014.11.so
b3def000 b3df8000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3e09000 b3e1a000 r-xp /lib/libnsl-2.20-2014.11.so
b3e2d000 b3e33000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3e44000 b3e5e000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e6f000 b3e70000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e80000 b3e82000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e93000 b3e98000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3ea8000 b3eab000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3ebc000 b3ec3000 r-xp /usr/lib/libsensord-share.so
b3ed3000 b3ee4000 r-xp /usr/lib/libsensor.so.1.2.0
b3ef5000 b3efb000 r-xp /usr/lib/libappcore-common.so.1.1
b3f1e000 b3f23000 r-xp /usr/lib/libappcore-efl.so.1.1
b3f39000 b3f3b000 r-xp /usr/lib/libXau.so.6.0.0
b3f4b000 b3f5f000 r-xp /usr/lib/libxcb.so.1.1.0
b3f6f000 b3f76000 r-xp /lib/libcrypt-2.20-2014.11.so
b3fae000 b3fb0000 r-xp /usr/lib/libiri.so
b3fc1000 b3fd6000 r-xp /lib/libexpat.so.1.5.2
b3fe8000 b4036000 r-xp /usr/lib/libssl.so.1.0.0
b404b000 b4054000 r-xp /usr/lib/libethumb.so.1.13.0
b4065000 b4068000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b4078000 b422f000 r-xp /usr/lib/libcrypto.so.1.0.0
b57c6000 b57cf000 r-xp /usr/lib/libXi.so.6.1.0
b57e0000 b57e2000 r-xp /usr/lib/libXgesture.so.7.0.0
b57f2000 b57f6000 r-xp /usr/lib/libXtst.so.6.1.0
b5806000 b580c000 r-xp /usr/lib/libXrender.so.1.3.0
b581c000 b5822000 r-xp /usr/lib/libXrandr.so.2.2.0
b5832000 b5834000 r-xp /usr/lib/libXinerama.so.1.0.0
b5844000 b5847000 r-xp /usr/lib/libXfixes.so.3.1.0
b5858000 b5863000 r-xp /usr/lib/libXext.so.6.4.0
b5873000 b5875000 r-xp /usr/lib/libXdamage.so.1.1.0
b5885000 b5887000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5897000 b597a000 r-xp /usr/lib/libX11.so.6.3.0
b598d000 b5994000 r-xp /usr/lib/libXcursor.so.1.0.2
b59a5000 b59bd000 r-xp /usr/lib/libudev.so.1.6.0
b59bf000 b59c2000 r-xp /lib/libattr.so.1.1.0
b59d2000 b59f2000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b59f3000 b59f8000 r-xp /usr/lib/libffi.so.6.0.2
b5a08000 b5a20000 r-xp /lib/libz.so.1.2.8
b5a30000 b5a32000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b5a42000 b5b17000 r-xp /usr/lib/libxml2.so.2.9.2
b5b2c000 b5bc7000 r-xp /usr/lib/libstdc++.so.6.0.20
b5be3000 b5be6000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5bf6000 b5c10000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5c20000 b5c31000 r-xp /lib/libresolv-2.20-2014.11.so
b5c45000 b5c5c000 r-xp /usr/lib/liblzma.so.5.0.3
b5c6c000 b5c6e000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c7e000 b5c85000 r-xp /usr/lib/libembryo.so.1.13.0
b5c95000 b5cad000 r-xp /usr/lib/libpng12.so.0.50.0
b5cbe000 b5ce1000 r-xp /usr/lib/libjpeg.so.8.0.2
b5d01000 b5d07000 r-xp /lib/librt-2.20-2014.11.so
b5d18000 b5d2c000 r-xp /usr/lib/libector.so.1.13.0
b5d3d000 b5d55000 r-xp /usr/lib/liblua-5.1.so
b5d66000 b5dbd000 r-xp /usr/lib/libfreetype.so.6.11.3
b5dd1000 b5df9000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5e0a000 b5e1d000 r-xp /usr/lib/libfribidi.so.0.3.1
b5e2e000 b5e68000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e79000 b5ee4000 r-xp /lib/libm-2.20-2014.11.so
b5ef5000 b5f02000 r-xp /usr/lib/libeio.so.1.13.0
b5f12000 b5f14000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5f24000 b5f29000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5f39000 b5f50000 r-xp /usr/lib/libefreet.so.1.13.0
b5f62000 b5f82000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f92000 b5fb2000 r-xp /usr/lib/libecore_con.so.1.13.0
b5fb4000 b5fba000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5fca000 b5fd1000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5fe1000 b5fef000 r-xp /usr/lib/libeo.so.1.13.0
b5fff000 b6011000 r-xp /usr/lib/libecore_input.so.1.13.0
b6022000 b6027000 r-xp /usr/lib/libecore_file.so.1.13.0
b6037000 b604f000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6060000 b607d000 r-xp /usr/lib/libeet.so.1.13.0
b6096000 b60de000 r-xp /usr/lib/libeina.so.1.13.0
b60ef000 b60ff000 r-xp /usr/lib/libefl.so.1.13.0
b6110000 b61f5000 r-xp /usr/lib/libicuuc.so.51.1
b6212000 b6352000 r-xp /usr/lib/libicui18n.so.51.1
b6369000 b63a1000 r-xp /usr/lib/libecore_x.so.1.13.0
b63b3000 b63b6000 r-xp /lib/libcap.so.2.21
b63c6000 b63ef000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b6400000 b6407000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6419000 b644f000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6460000 b6548000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b655c000 b65d2000 r-xp /usr/lib/libsqlite3.so.0.8.6
b65e4000 b65e7000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b65f7000 b6602000 r-xp /usr/lib/libvconf.so.0.2.45
b6612000 b6614000 r-xp /usr/lib/libvasum.so.0.3.1
b6624000 b6626000 r-xp /usr/lib/libttrace.so.1.1
b6636000 b6639000 r-xp /usr/lib/libiniparser.so.0
b6649000 b666c000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b667c000 b6681000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6692000 b66a9000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b66ba000 b66c7000 r-xp /usr/lib/libunwind.so.8.0.1
b66fd000 b6821000 r-xp /lib/libc-2.20-2014.11.so
b6836000 b684f000 r-xp /lib/libgcc_s-4.9.so.1
b685f000 b6941000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b6952000 b6986000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6996000 b69d0000 r-xp /usr/lib/libsystemd.so.0.4.0
b69d2000 b6a52000 r-xp /usr/lib/libedje.so.1.13.0
b6a55000 b6a73000 r-xp /usr/lib/libecore.so.1.13.0
b6a93000 b6bf5000 r-xp /usr/lib/libevas.so.1.13.0
b6c2c000 b6c40000 r-xp /lib/libpthread-2.20-2014.11.so
b6c54000 b6e78000 r-xp /usr/lib/libelementary.so.1.13.0
b6ea6000 b6eaa000 r-xp /usr/lib/libsmack.so.1.0.0
b6eba000 b6ec0000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ed1000 b6ed3000 r-xp /usr/lib/libdlog.so.0.0.0
b6ee3000 b6ee6000 r-xp /usr/lib/libbundle.so.0.1.22
b6ef6000 b6ef8000 r-xp /lib/libdl-2.20-2014.11.so
b6f09000 b6f22000 r-xp /usr/lib/libaul.so.0.1.0
b6f34000 b6f36000 r-xp /usr/lib/libappsvc.so.0.1.0
b6f47000 b6f4b000 r-xp /usr/lib/libsys-assert.so
b6f5c000 b6f7c000 r-xp /lib/ld-2.20-2014.11.so
b6f8d000 b6f93000 r-xp /usr/bin/launchpad-loader
b8032000 b8753000 rw-p [heap]
bea82000 beaa3000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2833)
Call Stack Count: 2
 0: syscall + 0x20 (0xb67c5ee0) [/lib/libc.so.6] + 0xc8ee0
 1: (0xb68c44fb) [/usr/lib/libglib-2.0.so.0] + 0x654fb
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
xample.camera
01-22 21:19:31.728+0900 D/RESOURCED(  877): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 2833
01-22 21:19:31.728+0900 D/RESOURCED(  877): proc-main.c: resourced_proc_status_change(934) > available memory = 530
01-22 21:19:31.728+0900 E/RESOURCED(  877): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 2833 foreground
01-22 21:19:31.728+0900 W/AUL_AMD (  824): amd_launch.c: __nofork_processing(1251) > __nofork_processing, cmd: 0, pid: 2833
01-22 21:19:31.728+0900 D/AUL_AMD (  824): amd_launch.c: __nofork_processing(1267) > fake launch pid : 2833
01-22 21:19:31.728+0900 D/AUL     (  824): app_sock.c: __app_send_raw_with_delay_reply(455) > pid(2833) : cmd(0)
01-22 21:19:31.738+0900 D/AUL_AMD (  824): amd_launch.c: __set_reply_handler(1014) > listen fd : 30, send fd : 29
01-22 21:19:31.738+0900 D/AUL_AMD (  824): amd_launch.c: __nofork_processing(1270) > fake launch done
01-22 21:19:32.739+0900 D/AUL_AMD (  824): amd_launch.c: __grab_timeout_handler(1444) > pid(2833) ecore_x_pointer_ungrab
01-22 21:19:32.739+0900 D/AUL_AMD (  824): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:19:32.739+0900 D/AUL_AMD (  824): amd_launch.c: __grab_timeout_handler(1448) > back key ungrab
01-22 21:19:33.240+0900 D/AUL_AMD (  824): amd_request.c: __add_history_handler(385) > [SECURE_LOG] add rua history org.example.camera /opt/usr/apps/org.example.camera/bin/camera
01-22 21:19:33.240+0900 D/RUA     (  824): rua.c: rua_add_history(179) > rua_add_history start
01-22 21:19:33.240+0900 D/RUA     (  824): rua.c: rua_add_history(247) > rua_add_history ok
01-22 21:19:33.550+0900 I/ISP_AE  ( 2833): ANTI_FLAG: =500000, 3731, 134, 1
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 330
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :610
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :330
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 2
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :2
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 240
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :611
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :240
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 2
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 3
01-22 21:19:33.550+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :3
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 280
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :612
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :280
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 3
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 4
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :4
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 180
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :613
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :180
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 4
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 3
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :3
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 160
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :614
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :160
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 3
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 0
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :615
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 330
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :616
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :330
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 2
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :2
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 240
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :617
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :240
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 2
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 3
01-22 21:19:33.560+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :3
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 80
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :618
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :80
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 3
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -4
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 350
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :619
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :350
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 2
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :2
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :620
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 2
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 140
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :621
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :140
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 140
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :622
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :140
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :623
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 50
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :624
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :50
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 120
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :625
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :120
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.570+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 40
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :626
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :40
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 190
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :627
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :190
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 440
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :628
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :440
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 3
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :3
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :629
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 3
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 4
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :4
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 150
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :630
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :150
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 4
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v_s :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v_s :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 120
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :631
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :120
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 240
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :632
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :240
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:33.580+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 150
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :633
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :150
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -3
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 20
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :634
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :20
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :635
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 30
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :636
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :30
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 220
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :637
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :220
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 140
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :638
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :140
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -4
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :639
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 70
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :640
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :70
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 610
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :641
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :610
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 5
01-22 21:19:33.590+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :5
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 130
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :642
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :130
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 5
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -1
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 150
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :643
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :150
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -4
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 140
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :644
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :140
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 130
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :645
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :130
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -6
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 210
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :646
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :210
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 130
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :647
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :130
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 240
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :648
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :240
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:33.600+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 180
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :649
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :180
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 300
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :650
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :300
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 2
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :2
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :651
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 2
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :652
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :653
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 190
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :654
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :190
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 230
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :655
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :230
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :656
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -6
01-22 21:19:33.610+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 150
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :657
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :150
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -4
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 70
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :658
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :70
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 10
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :659
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :10
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 70
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :660
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :70
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v_s :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v_s :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 70
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :661
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :70
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :662
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 260
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :663
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :260
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 160
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :664
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :160
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -2
01-22 21:19:33.620+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 70
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :665
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :70
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 140
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :666
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :140
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :667
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 120
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :668
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :120
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :669
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 150
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :670
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :150
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -4
01-22 21:19:33.630+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:34.311+0900 D/APP_CORE( 3037): appcore-efl.c: __appcore_memory_flush_cb(387) > [__SUSPEND__]
01-22 21:19:34.311+0900 I/APP_CORE( 3037): appcore-efl.c: __do_app(496) > [APP 3037] Event: MEM_FLUSH State: PAUSED
01-22 21:19:34.311+0900 D/APP_CORE( 3037): appcore-efl.c: __appcore_memory_flush_cb(396) > [__SUSPEND__] flush case
01-22 21:19:34.311+0900 D/RESOURCED(  877): proc-monitor.c: proc_dbus_suspend_hint(1106) > received susnepd hint : pid 3037
01-22 21:19:34.311+0900 D/APP_CORE( 3037): appcore.c: _appcore_request_to_suspend(532) > [SECURE_LOG] [__SUSPEND__] Send suspend hint, pid: 3037
01-22 21:19:34.311+0900 D/APP_CORE( 3037): appcore-efl.c: __appcore_efl_prepare_to_suspend(362) > [__SUSPEND__]
01-22 21:19:36.093+0900 D/PROCESSMGR(  536): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200086 bd->visible=1
01-22 21:19:36.543+0900 E/EFL     (  536): <536> e_mod_processmgr.c:481 _e_mod_processmgr_anr_ping() safety check failed: bd == NULL
01-22 21:19:36.743+0900 E/AUL_AMD (  824): amd_launch.c: __recv_timeout_handler(931) > application is not responding : pid(2833) cmd(0)
01-22 21:19:36.743+0900 W/AUL_AMD (  824): amd_launch.c: __send_watchdog_signal(399) > send a watchdog signal done: 2833
01-22 21:19:36.743+0900 E/RESOURCED(  877): proc-monitor.c: proc_dbus_watchdog_handler(688) > Receive watchdog signal to pid: 2833(camera)
01-22 21:19:36.743+0900 D/RESOURCED(  877): heart-abnormal.c: heart_abnormal_anr(100) > info : 2833 ANR 1 
01-22 21:19:36.743+0900 E/RESOURCED(  877): proc-monitor.c: proc_dbus_watchdog_handler(698) > just kill watchdog process when debug enabled pid: 2833(camera)
01-22 21:19:36.743+0900 D/RESOURCED(  877): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 2833
01-22 21:19:36.743+0900 E/RESOURCED(  877): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 2833 foreground
01-22 21:19:36.803+0900 I/ISP_AE  ( 2833): ANTI_FLAG: =500000, 3731, 134, 1
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 270
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :671
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :270
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 1
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :1
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 170
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :672
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :170
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 1
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -1
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 30
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :673
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :30
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 50
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :674
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :50
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.803+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 160
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :675
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :160
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -3
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 120
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :676
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :120
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :677
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.813+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 40
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :678
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :40
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 30
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :679
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :30
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :680
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 50
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :681
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :50
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.823+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 80
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :682
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :80
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 80
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :683
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :80
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 30
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :684
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :30
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :685
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.833+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :686
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 140
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :687
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :140
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -5
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :688
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 40
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :689
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :40
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.843+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :690
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v_s :10
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v_s :10
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 30
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :691
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :30
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 160
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :692
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :160
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -3
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 30
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :693
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :30
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.853+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :694
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 10
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :695
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :10
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 100
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :696
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :100
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 110
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :697
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :110
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 130
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :698
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :130
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -6
01-22 21:19:36.863+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 60
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :699
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :60
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 180
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :700
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :180
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -1
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman frame_flicker_value = 90
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman still_f :701
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_f_v :90
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b0 0
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b1 200
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman b2 -7
01-22 21:19:36.873+0900 I/ISP_DEFLICKER V3( 2833): hyman afl_v_v :0
01-22 21:19:36.913+0900 E/E17     (  536): e_border.c: e_border_hide(2248) > BD_HIDE(0x04c00003), visible:1
01-22 21:19:36.933+0900 E/AUL     (  924): app_sock.c: __app_send_raw(356) > recv timeout : cmd(0) Resource temporarily unavailable
01-22 21:19:36.933+0900 D/AUL     (  924): launch.c: app_request_to_launchpad(425) > launch request result : -6
01-22 21:19:36.933+0900 E/CAPI_APPFW_APP_CONTROL(  924): app_control.c: app_control_error(143) > [app_control_send_launch_request] LAUNCH_REJECTED(0xfef00023)
01-22 21:19:36.933+0900 E/cluster-home(  924): mainmenu-custom-box-impl.cpp: OnClicked(198) >  Failed to launch [-17825757][org.example.camera]
01-22 21:19:36.933+0900 D/test-log(  924): mainmenu-apps-view-impl.cpp: _OnScrollViewTouched(1592) >  Stop boost timer of Apps view by [1]
01-22 21:19:36.933+0900 W/CRASH_MANAGER( 3565): worker.c: worker_job(1204) > 060283363616d142192917
