S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 2130
Date: 2015-01-22 21:31:09+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2130, uid 5000)

Register Information
r0   = 0x9b0b1008, r1   = 0x00000001
r2   = 0x0026e1ab, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x0026e1ab
r6   = 0x0026e1ab, r7   = 0xadfb1588
r8   = 0xb89d6420, r9   = 0xadfb1734
r10  = 0xb89db970, fp   = 0x0000000d
ip   = 0xb66fe110, sp   = 0xadfb14f0
lr   = 0xb3323d13, pc   = 0xb66fe128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    431048 KB
Buffers:     17916 KB
Cached:     128192 KB
VmPeak:     588732 KB
VmSize:     588728 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       49196 KB
VmRSS:       49196 KB
VmData:     409596 KB
VmStk:         136 KB
VmExe:          24 KB
VmLib:       31264 KB
VmPTE:         288 KB
VmSwap:          0 KB

Threads Information
Threads: 47
PID = 2130 TID = 2316
2130 2132 2219 2220 2221 2222 2228 2266 2267 2268 2271 2315 2316 2317 2318 2319 2320 2321 2322 2323 2324 2325 2326 2328 2330 2331 2332 2333 2334 2335 2336 2337 2338 2339 2340 2341 2342 2343 2344 2345 2346 2347 2348 2349 2350 2353 2356 

Maps Information
92bae000 933ad000 rwxp [stack:2353]
93f8e000 9478d000 rwxp [stack:2271]
99690000 99e8f000 rwxp [stack:2268]
99e90000 9a68f000 rwxp [stack:2267]
9b590000 9bd8f000 rwxp [stack:2356]
9bd90000 9c58f000 rwxp [stack:2350]
9c590000 9cd8f000 rwxp [stack:2266]
9ce27000 9d626000 rwxp [stack:2318]
9d6bf000 9debe000 rwxp [stack:2317]
9e501000 9ed00000 rwxp [stack:2349]
9ed01000 9f500000 rwxp [stack:2348]
9f7a9000 9ffa8000 rwxp [stack:2347]
9ffa9000 a07a8000 rwxp [stack:2346]
a07a9000 a0fa8000 rwxp [stack:2345]
a0fa9000 a17a8000 rwxp [stack:2344]
a17a9000 a1fa8000 rwxp [stack:2343]
a1fa9000 a27a8000 rwxp [stack:2342]
a27a9000 a2fa8000 rwxp [stack:2341]
a2fa9000 a37a8000 rwxp [stack:2340]
a37a9000 a3fa8000 rwxp [stack:2339]
a3fa9000 a47a8000 rwxp [stack:2338]
a47a9000 a4fa8000 rwxp [stack:2337]
a4fa9000 a57a8000 rwxp [stack:2336]
a57a9000 a5fa8000 rwxp [stack:2335]
a5fa9000 a67a8000 rwxp [stack:2334]
a69ca000 a71c9000 rwxp [stack:2333]
a7489000 a7c88000 rwxp [stack:2332]
a7fb4000 a87b3000 rwxp [stack:2331]
a87b4000 a8fb3000 rwxp [stack:2330]
a8fb4000 a97b3000 rwxp [stack:2328]
a97b4000 a9fb3000 rwxp [stack:2326]
a9fb4000 aa7b3000 rwxp [stack:2325]
aa7b4000 aafb3000 rwxp [stack:2324]
aafb4000 ab7b3000 rwxp [stack:2323]
ab7b4000 abfb3000 rwxp [stack:2322]
abfb4000 ac7b3000 rwxp [stack:2319]
ac7b4000 acfb3000 rwxp [stack:2321]
acfb4000 ad7b3000 rwxp [stack:2320]
ad7b4000 adfb3000 rwxp [stack:2316]
adfb3000 adfb6000 r-xp /usr/lib/libXv.so.1.0.0
adfc6000 adfd8000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
adfe9000 ae020000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ae032000 ae831000 rwxp [stack:2315]
ae831000 ae84e000 r-xp /usr/lib/libAl_Awb_Sp.so
ae857000 ae85a000 r-xp /usr/lib/libdeflicker.so
ae872000 ae888000 r-xp /usr/lib/libAl_Awb.so
ae890000 ae89a000 r-xp /usr/lib/libcalibration.so
ae8a3000 ae8b5000 r-xp /usr/lib/libaf_lib.so
ae8bd000 ae8c3000 r-xp /usr/lib/liblsc.so
ae8cc000 ae8d8000 r-xp /usr/lib/libae.so
ae8e0000 ae921000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae968000 aea47000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
aeea4000 aeea5000 r-xp /usr/lib/libcamerahdr.so.0.0.0
aeeb5000 aeef1000 r-xp /usr/lib/libcamerahal.so.0.0.0
aefce000 af7cd000 rwxp [stack:2228]
af7d7000 af7ef000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
af900000 af906000 r-xp /usr/lib/libspaf.so
b0501000 b0d00000 rwxp [stack:2222]
b0e4d000 b164c000 rwxp [stack:2221]
b164d000 b1e4c000 rwxp [stack:2220]
b1e4c000 b1e51000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1edd000 b1ee5000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1ef6000 b1ef7000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f07000 b1f0e000 r-xp /usr/lib/libfeedback.so.0.1.4
b1f32000 b1f33000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b1f43000 b1f56000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b1faa000 b1faf000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b1fc0000 b27bf000 rwxp [stack:2219]
b27bf000 b291a000 r-xp /usr/lib/egl/libMali.so
b292f000 b29b8000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b29d1000 b2a9f000 r-xp /usr/lib/libCOREGL.so.4.0
b2aba000 b2abd000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2acd000 b2ada000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2aeb000 b2af5000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2b05000 b2b11000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2b22000 b2b26000 r-xp /usr/lib/libogg.so.0.7.1
b2b36000 b2b58000 r-xp /usr/lib/libvorbis.so.0.4.3
b2b68000 b2c4c000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b2c68000 b2cab000 r-xp /usr/lib/libsndfile.so.1.0.25
b2cc0000 b2d07000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b2d18000 b2d1f000 r-xp /usr/lib/libjson-c.so.2.0.1
b2d2f000 b2d64000 r-xp /usr/lib/libpulse.so.0.16.2
b2d75000 b2d78000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b2d89000 b2d8c000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2d9d000 b2de0000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b2df1000 b2df9000 r-xp /usr/lib/libdrm.so.2.4.0
b2e09000 b2e0b000 r-xp /usr/lib/libdri2.so.0.0.0
b2e1b000 b2e22000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2e32000 b2e3d000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2e51000 b2e57000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b2e68000 b2e70000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2e81000 b2e86000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2e96000 b2ead000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2ebd000 b2edd000 r-xp /usr/lib/libexif.so.12.3.3
b2ee9000 b2ef1000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b2f01000 b2f30000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b2f43000 b2f4b000 r-xp /usr/lib/libtbm.so.1.0.0
b2f5b000 b3014000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b3028000 b302f000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b303f000 b309d000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b30b2000 b30b6000 r-xp /usr/lib/libstorage.so.0.1
b30c6000 b30cd000 r-xp /usr/lib/libefl-extension.so.0.1.0
b30dd000 b30ec000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b3216000 b321a000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b322b000 b330b000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b3320000 b3325000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b332d000 b3354000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b3367000 b3b66000 rwxp [stack:2132]
b3b66000 b3b68000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b3d78000 b3d81000 r-xp /lib/libnss_files-2.20-2014.11.so
b3d92000 b3d9b000 r-xp /lib/libnss_nis-2.20-2014.11.so
b3dac000 b3dbd000 r-xp /lib/libnsl-2.20-2014.11.so
b3dd0000 b3dd6000 r-xp /lib/libnss_compat-2.20-2014.11.so
b3de7000 b3e01000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3e12000 b3e13000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b3e23000 b3e25000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b3e36000 b3e3b000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b3e4b000 b3e4e000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b3e5f000 b3e66000 r-xp /usr/lib/libsensord-share.so
b3e76000 b3e87000 r-xp /usr/lib/libsensor.so.1.2.0
b3e98000 b3e9e000 r-xp /usr/lib/libappcore-common.so.1.1
b3ec1000 b3ec6000 r-xp /usr/lib/libappcore-efl.so.1.1
b3edc000 b3ede000 r-xp /usr/lib/libXau.so.6.0.0
b3eee000 b3f02000 r-xp /usr/lib/libxcb.so.1.1.0
b3f12000 b3f19000 r-xp /lib/libcrypt-2.20-2014.11.so
b3f51000 b3f53000 r-xp /usr/lib/libiri.so
b3f64000 b3f79000 r-xp /lib/libexpat.so.1.5.2
b3f8b000 b3fd9000 r-xp /usr/lib/libssl.so.1.0.0
b3fee000 b3ff7000 r-xp /usr/lib/libethumb.so.1.13.0
b4008000 b400b000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b401b000 b41d2000 r-xp /usr/lib/libcrypto.so.1.0.0
b5769000 b5772000 r-xp /usr/lib/libXi.so.6.1.0
b5783000 b5785000 r-xp /usr/lib/libXgesture.so.7.0.0
b5795000 b5799000 r-xp /usr/lib/libXtst.so.6.1.0
b57a9000 b57af000 r-xp /usr/lib/libXrender.so.1.3.0
b57bf000 b57c5000 r-xp /usr/lib/libXrandr.so.2.2.0
b57d5000 b57d7000 r-xp /usr/lib/libXinerama.so.1.0.0
b57e7000 b57ea000 r-xp /usr/lib/libXfixes.so.3.1.0
b57fb000 b5806000 r-xp /usr/lib/libXext.so.6.4.0
b5816000 b5818000 r-xp /usr/lib/libXdamage.so.1.1.0
b5828000 b582a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b583a000 b591d000 r-xp /usr/lib/libX11.so.6.3.0
b5930000 b5937000 r-xp /usr/lib/libXcursor.so.1.0.2
b5948000 b5960000 r-xp /usr/lib/libudev.so.1.6.0
b5962000 b5965000 r-xp /lib/libattr.so.1.1.0
b5975000 b5995000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b5996000 b599b000 r-xp /usr/lib/libffi.so.6.0.2
b59ab000 b59c3000 r-xp /lib/libz.so.1.2.8
b59d3000 b59d5000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b59e5000 b5aba000 r-xp /usr/lib/libxml2.so.2.9.2
b5acf000 b5b6a000 r-xp /usr/lib/libstdc++.so.6.0.20
b5b86000 b5b89000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b5b99000 b5bb3000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b5bc3000 b5bd4000 r-xp /lib/libresolv-2.20-2014.11.so
b5be8000 b5bff000 r-xp /usr/lib/liblzma.so.5.0.3
b5c0f000 b5c11000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5c21000 b5c28000 r-xp /usr/lib/libembryo.so.1.13.0
b5c38000 b5c50000 r-xp /usr/lib/libpng12.so.0.50.0
b5c61000 b5c84000 r-xp /usr/lib/libjpeg.so.8.0.2
b5ca4000 b5caa000 r-xp /lib/librt-2.20-2014.11.so
b5cbb000 b5ccf000 r-xp /usr/lib/libector.so.1.13.0
b5ce0000 b5cf8000 r-xp /usr/lib/liblua-5.1.so
b5d09000 b5d60000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d74000 b5d9c000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5dad000 b5dc0000 r-xp /usr/lib/libfribidi.so.0.3.1
b5dd1000 b5e0b000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e1c000 b5e87000 r-xp /lib/libm-2.20-2014.11.so
b5e98000 b5ea5000 r-xp /usr/lib/libeio.so.1.13.0
b5eb5000 b5eb7000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5ec7000 b5ecc000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5edc000 b5ef3000 r-xp /usr/lib/libefreet.so.1.13.0
b5f05000 b5f25000 r-xp /usr/lib/libeldbus.so.1.13.0
b5f35000 b5f55000 r-xp /usr/lib/libecore_con.so.1.13.0
b5f57000 b5f5d000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5f6d000 b5f74000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f84000 b5f92000 r-xp /usr/lib/libeo.so.1.13.0
b5fa2000 b5fb4000 r-xp /usr/lib/libecore_input.so.1.13.0
b5fc5000 b5fca000 r-xp /usr/lib/libecore_file.so.1.13.0
b5fda000 b5ff2000 r-xp /usr/lib/libecore_evas.so.1.13.0
b6003000 b6020000 r-xp /usr/lib/libeet.so.1.13.0
b6039000 b6081000 r-xp /usr/lib/libeina.so.1.13.0
b6092000 b60a2000 r-xp /usr/lib/libefl.so.1.13.0
b60b3000 b6198000 r-xp /usr/lib/libicuuc.so.51.1
b61b5000 b62f5000 r-xp /usr/lib/libicui18n.so.51.1
b630c000 b6344000 r-xp /usr/lib/libecore_x.so.1.13.0
b6356000 b6359000 r-xp /lib/libcap.so.2.21
b6369000 b6392000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b63a3000 b63aa000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b63bc000 b63f2000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b6403000 b64eb000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b64ff000 b6575000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6587000 b658a000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b659a000 b65a5000 r-xp /usr/lib/libvconf.so.0.2.45
b65b5000 b65b7000 r-xp /usr/lib/libvasum.so.0.3.1
b65c7000 b65c9000 r-xp /usr/lib/libttrace.so.1.1
b65d9000 b65dc000 r-xp /usr/lib/libiniparser.so.0
b65ec000 b660f000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b661f000 b6624000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6635000 b664c000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b665d000 b666a000 r-xp /usr/lib/libunwind.so.8.0.1
b66a0000 b67c4000 r-xp /lib/libc-2.20-2014.11.so
b67d9000 b67f2000 r-xp /lib/libgcc_s-4.9.so.1
b6802000 b68e4000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b68f5000 b6929000 r-xp /usr/lib/libdbus-1.so.3.8.11
b6939000 b6973000 r-xp /usr/lib/libsystemd.so.0.4.0
b6975000 b69f5000 r-xp /usr/lib/libedje.so.1.13.0
b69f8000 b6a16000 r-xp /usr/lib/libecore.so.1.13.0
b6a36000 b6b98000 r-xp /usr/lib/libevas.so.1.13.0
b6bcf000 b6be3000 r-xp /lib/libpthread-2.20-2014.11.so
b6bf7000 b6e1b000 r-xp /usr/lib/libelementary.so.1.13.0
b6e49000 b6e4d000 r-xp /usr/lib/libsmack.so.1.0.0
b6e5d000 b6e63000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e74000 b6e76000 r-xp /usr/lib/libdlog.so.0.0.0
b6e86000 b6e89000 r-xp /usr/lib/libbundle.so.0.1.22
b6e99000 b6e9b000 r-xp /lib/libdl-2.20-2014.11.so
b6eac000 b6ec5000 r-xp /usr/lib/libaul.so.0.1.0
b6ed7000 b6ed9000 r-xp /usr/lib/libappsvc.so.0.1.0
b6eea000 b6eee000 r-xp /usr/lib/libsys-assert.so
b6eff000 b6f1f000 r-xp /lib/ld-2.20-2014.11.so
b6f30000 b6f36000 r-xp /usr/bin/launchpad-loader
b8722000 b8cc6000 rw-p [heap]
bedc9000 bedea000 rwxp [stack]
bedc9000 bedea000 rwxp [stack]
End of Maps Information

Callstack Information (PID:2130)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb66fe128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb3323d13) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d13
 2: (0xb30e1abb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb3064865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb63c85bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb63d4f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb63daa8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb63dac81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf7e1cf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf7e2459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6853157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6bd4cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
e=0
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): cvg speed=0
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): target lum=61, target lum zone=16
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): lime time=164, min line=1
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): target_lum_ev0=61
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): highcount=19,lowcount=15
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): is_quick=0
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): AE_TEST:-----------SET index:230
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): AE_TEST: get index:230, exp:200000, line:1219
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): AE_TEST:-----------SET index:230
01-22 21:31:05.085+0900 I/ISP_AE  ( 2130): info x=8,y=6,w=2560,h=1920, block_size.w=80,block_size.h=60
01-22 21:31:05.095+0900 I/ISP_AE  ( 2130): calc_iso=50,real_gain=19,iso=0
01-22 21:31:05.356+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:230, cur_lum:3, next_index:280, target_lum:61
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,fb,ab,00,00,00,00
01-22 21:31:05.356+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,fb,ab,00,00,00,00
01-22 21:31:05.356+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [LED]LPF Disable
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.57, detect:   0.39,   0.42 CTemp:4025.2
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [CHROMA]START BV=0.492584 Ratio=1.000000
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [HSC]Mix=00000000,Csd=00044d04 ,(BV= 0.493,x=0.362,y=0.391)
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=0.492599 ,Awb Bv=0.492584 in/out_0
01-22 21:31:05.356+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.304657,GGain=0.999985,BGain=1.767899,Dtct=0.361649,0.391403 ,Curr=0.361649,0.391403 ,CTmep: QC=4598, AL= 4598
01-22 21:31:05.466+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:280, cur_lum:13, next_index:316, target_lum:61
01-22 21:31:05.466+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.466+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:05.466+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:05.466+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.466+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c4b0), gem(37), surface(0xb8c2c208)
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:05.486+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [LED]LPF Disable
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.96, detect:   0.37,   0.39 CTemp:4349.4
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [HSC]Mix=00001eb8,Csd=00063c57 ,(BV=-1.012,x=0.359,y=0.379)
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.011874 ,Awb Bv=-1.011871 in/out_0
01-22 21:31:05.486+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.239288,GGain=0.999985,BGain=1.647659,Dtct=0.358734,0.379395 ,Curr=0.358734,0.379395 ,CTmep: QC=4634, AL= 4634
01-22 21:31:05.516+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a48), gem(38), surface(0xb8bc4618)
01-22 21:31:05.516+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c338), gem(39), surface(0xb8bc4618)
01-22 21:31:05.576+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:316, cur_lum:34, next_index:326, target_lum:61
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:05.586+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:05.586+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [LED]LPF Disable
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.95, detect:   0.37,   0.38 CTemp:4422.5
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [HSC]Mix=00003d70,Csd=000509ff ,(BV=-1.456,x=0.358,y=0.377)
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.456176 ,Awb Bv=-1.456161 in/out_0
01-22 21:31:05.586+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.229248,GGain=0.999985,BGain=1.622070,Dtct=0.357559,0.376709 ,Curr=0.357559,0.376709 ,CTmep: QC=4658, AL= 4658
01-22 21:31:05.606+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bc49e0), gem(37), surface(0xb8c2c208)
01-22 21:31:05.686+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a48), gem(38), surface(0xb8bc4618)
01-22 21:31:05.746+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:326, cur_lum:44, next_index:331, target_lum:61
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:05.746+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:05.746+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [LED]LPF Disable
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:05.746+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.95, detect:   0.37,   0.38 CTemp:4380.5
01-22 21:31:05.756+0900 D/alPrinter1( 2130): [HSC]Mix=00005c28,Csd=000364ef ,(BV=-1.681,x=0.359,y=0.376)
01-22 21:31:05.756+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:31:05.756+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.681049 ,Awb Bv=-1.681046 in/out_0
01-22 21:31:05.756+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.212692,GGain=1.000000,BGain=1.620544,Dtct=0.359390,0.376144 ,Curr=0.359390,0.376144 ,CTmep: QC=4599, AL= 4599
01-22 21:31:05.766+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c4b0), gem(37), surface(0xb8c2c208)
01-22 21:31:05.846+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c338), gem(38), surface(0xb8bc4618)
01-22 21:31:05.906+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:331, cur_lum:50, next_index:332, target_lum:61
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:05.906+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:05.906+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [LED]LPF Disable
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.94, detect:   0.37,   0.38 CTemp:4349.9
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [HSC]Mix=00007ae0,Csd=000368e6 ,(BV=-1.710,x=0.361,y=0.376)
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.710493 ,Awb Bv=-1.710480 in/out_0
01-22 21:31:05.906+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.203400,GGain=1.000000,BGain=1.626465,Dtct=0.361069,0.376480 ,Curr=0.361069,0.376480 ,CTmep: QC=4550, AL= 4550
01-22 21:31:05.916+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bc49e0), gem(37), surface(0xb8c2c208)
01-22 21:31:05.986+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a48), gem(38), surface(0xb8bc4618)
01-22 21:31:06.066+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:332, cur_lum:50, next_index:333, target_lum:61
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:06.066+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:06.066+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [LED]LPF Disable
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.94, detect:   0.37,   0.38 CTemp:4317.4
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [HSC]Mix=00009998,Csd=000297f5 ,(BV=-1.739,x=0.362,y=0.376)
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.739348 ,Awb Bv=-1.739334 in/out_0
01-22 21:31:06.066+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.195358,GGain=0.999985,BGain=1.628830,Dtct=0.362274,0.376495 ,Curr=0.362274,0.376495 ,CTmep: QC=4513, AL= 4513
01-22 21:31:06.096+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c4b0), gem(37), surface(0xb8c2c208)
01-22 21:31:06.177+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c338), gem(38), surface(0xb8bc4618)
01-22 21:31:06.227+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:333, cur_lum:50, next_index:334, target_lum:61
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:06.227+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:06.227+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [LED]LPF Enable
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.94, detect:   0.37,   0.38 CTemp:4291.6
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [HSC]Mix=0000b850,Csd=0001d696 ,(BV=-1.740,x=0.363,y=0.376)
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:3, 0x0000b850,0x0000b850
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.767637 ,Awb Bv=-1.739883 in/out_0
01-22 21:31:06.227+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.195374,GGain=0.999985,BGain=1.628830,Dtct=0.363159,0.376328 ,Curr=0.362274,0.376495 ,CTmep: QC=4513, AL= 4513
01-22 21:31:06.247+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bc49e0), gem(37), surface(0xb8c2c208)
01-22 21:31:06.327+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a48), gem(38), surface(0xb8bc4618)
01-22 21:31:06.387+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:334, cur_lum:53, next_index:335, target_lum:61
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:06.387+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:06.387+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.94, detect:   0.37,   0.38 CTemp:4258.4
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [HSC]Mix=0000d708,Csd=0001985e ,(BV=-1.743,x=0.365,y=0.377)
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:4, 0x0000d708,0x0000d708
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.822604 ,Awb Bv=-1.742966 in/out_0
01-22 21:31:06.387+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.195023,GGain=0.999985,BGain=1.628860,Dtct=0.364777,0.376709 ,Curr=0.362320,0.376495 ,CTmep: QC=4513, AL= 4513
01-22 21:31:06.407+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bc49e0), gem(37), surface(0xb89d2c30)
01-22 21:31:06.447+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200ca0 
01-22 21:31:06.487+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2c338), gem(38), surface(0xb8bc4618)
01-22 21:31:06.547+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:335, cur_lum:54, next_index:336, target_lum:61
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:06.547+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [CMD1][if=b8b003f8,Wrap=b8b05928]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:06.547+0900 D/awb_al_cmd1( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [CALL][0xb8b003f8][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [LOCK]0
01-22 21:31:06.547+0900 D/alPrinter1( 2130): [SuperHighCTemp] Mapin:  0.94, detect:   0.37,   0.38 CTemp:4221.6
01-22 21:31:06.557+0900 I/ISP_AE  ( 2130): calc_iso=340,real_gain=111,iso=0
01-22 21:31:06.557+0900 D/alPrinter1( 2130): [HSC]Mix=0000f5c0,Csd=0000e8cd ,(BV=-1.751,x=0.366,y=0.376)
01-22 21:31:06.557+0900 D/alPrinter1( 2130): [AlHscWrap_Main]:3, 0x0000f5c0,0x0000f5c0
01-22 21:31:06.557+0900 D/alPrinter1( 2130): [AIS_WRAP]In BV=-1.875553 ,Awb Bv=-1.751297 in/out_0
01-22 21:31:06.557+0900 D/alPrinter1( 2130): [AIS_WRAP]RGain=1.193573,GGain=0.999985,BGain=1.629089,Dtct=0.365540,0.376175 ,Curr=0.362503,0.376480 ,CTmep: QC=4512, AL= 4512
01-22 21:31:06.577+0900 D/TIZEN_N_CAMERA( 2130): camera.c: camera_is_supported_face_detection(1193) > face detection NOT supported
01-22 21:31:06.577+0900 E/TIZEN_N_CAMERA( 2130): camera.c: camera_stop_face_detection(1315) > NOT_SUPPORTED(0xc0000002)
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): tunnig_param=263480
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): param_num=3
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): cur target lum=62, ev diff=0, level=4
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): AE VERSION : 0x20150828-00
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): cvg speed=0
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): target lum=62, target lum zone=8
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): lime time=134, min line=1
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): target_lum_ev0=62
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): highcount=19,lowcount=15
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): FDAE: failed open fdae_param.txt
01-22 21:31:06.787+0900 I/ISP_AE  ( 2130): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceInit :mode=-1 ins=0x0731066b
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038ccc
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e147
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x0003cccc
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:31:06.787+0900 D/alPrinter0( 2130): LSC Size:20 16
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [LSC]TableSize=   320
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [LSC]TableSize=   320
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [LSC]TableSize=   320
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [OTP]module has otp data 0xb0dc6ccc (nil) 20 16
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [LSC]TableSize=   320
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [LSC]TableSize=   320
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:31:06.787+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.252258,GGain=1.000000,BGain=1.189865,Dtct=0.000000,0.000000 ,Curr=0.321991,0.338989 ,CTmep: QC=6405, AL= 5977
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): work_mode=0 last mode=0
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): cvg speed=0
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): target lum=62, target lum zone=8
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): lime time=134, min line=1
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): target_lum_ev0=62
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): highcount=19,lowcount=15
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): is_quick=0
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): AE_TEST:-----------SET index:282
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): AE_TEST: get index:282, exp:300000, line:2238
01-22 21:31:06.907+0900 I/ISP_AE  ( 2130): AE_TEST:-----------SET index:282
01-22 21:31:06.917+0900 I/ISP_AE  ( 2130): info x=0,y=8,w=3264,h=2432, block_size.w=102,block_size.h=76
01-22 21:31:06.927+0900 I/ISP_AE  ( 2130): calc_iso=50,real_gain=19,iso=0
01-22 21:31:07.187+0900 I/ISP_AE  ( 2130): set_weight, table[0] = 1
01-22 21:31:07.187+0900 I/ISP_AE  ( 2130): set weight from 1 to 0, rtn=0
01-22 21:31:07.187+0900 I/ISP_AE  ( 2130): AE_TEST ----------------------change to fast
01-22 21:31:07.187+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:282, cur_lum:30, next_index:296, target_lum:62
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,fb,ac,00,00,00,00
01-22 21:31:07.197+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,fb,ac,00,00,00,00
01-22 21:31:07.197+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LineAdj] Mode -2147483647
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LineAdj]Tar RGB 557,733,473
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LineAdj]Ref RGB 557,750,487
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LineAdj]Tar Hi/Lo 0.736921,0.611360,0.736921,0.611360
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LineAdj]Ref Lo/Lo 0.718659,0.616618,0.718659,0.616618
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [calibration]Ref DNP: rg = 0.7187, bg = 0.6166
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [calibration]target DNP: rg = 0.7369, bg = 0.6114
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [calibration]Res Gain  : r = 0.9752, g = 1.0000, b = 1.0086
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [calibration]Nor Gain  : r = 1.0000, g = 1.0254, b = 1.0342
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LED]LPF Disable
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.61, detect:   0.32,   0.36 CTemp:6075.1
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [CHROMA]START BV=1.526535 Ratio=1.000000
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [HSC]Mix=00000000,Csd=000410fa ,(BV= 1.527,x=0.321,y=0.357)
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.526546 ,Awb Bv=1.526535 in/out_0
01-22 21:31:07.197+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.395065,GGain=1.000000,BGain=1.341843,Dtct=0.320709,0.357269 ,Curr=0.320709,0.357269 ,CTmep: QC=6409, AL= 5981
01-22 21:31:07.288+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:296, cur_lum:46, next_index:299, target_lum:62
01-22 21:31:07.298+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(37), surface(0xb8c29f20)
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.318+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.318+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [LED]LPF Disable
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.68, detect:   0.32,   0.35 CTemp:6053.8
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [HSC]Mix=00001eb8,Csd=0002e824 ,(BV= 1.476,x=0.320,y=0.356)
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:4, 0x00001eb8,0x00001eb8
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.475919 ,Awb Bv=1.475906 in/out_0
01-22 21:31:07.318+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.395737,GGain=1.000000,BGain=1.342163,Dtct=0.320312,0.356461 ,Curr=0.320709,0.357269 ,CTmep: QC=6428, AL= 6000
01-22 21:31:07.358+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(38), surface(0xb8bc4f20)
01-22 21:31:07.358+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(39), surface(0xb8bc4f20)
01-22 21:31:07.378+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be7288), gem(37), surface(0xb8c29f20)
01-22 21:31:07.388+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:299, cur_lum:49, next_index:302, target_lum:62
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.398+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.398+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [LED]LPF Disable
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.69, detect:   0.32,   0.35 CTemp:6005.0
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [HSC]Mix=00003d70,Csd=000263c3 ,(BV= 1.380,x=0.321,y=0.355)
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:3, 0x00003d70,0x00003d70
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.379704 ,Awb Bv=1.379700 in/out_0
01-22 21:31:07.398+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.380447,GGain=1.000000,BGain=1.327759,Dtct=0.320526,0.355408 ,Curr=0.320526,0.355408 ,CTmep: QC=6422, AL= 5994
01-22 21:31:07.408+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c0e3a8), gem(38), surface(0xb8bc4f20)
01-22 21:31:07.458+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(37), surface(0xb8bc4f20)
01-22 21:31:07.478+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c24600), gem(38), surface(0xb89891a0)
01-22 21:31:07.488+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:302, cur_lum:51, next_index:303, target_lum:62
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.498+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.498+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [LED]LPF Enable
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.70, detect:   0.32,   0.35 CTemp:5962.4
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [HSC]Mix=00005c28,Csd=0001a7e8 ,(BV= 1.380,x=0.321,y=0.355)
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:4, 0x00005c28,0x00005c28
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.379704 ,Awb Bv=1.379669 in/out_0
01-22 21:31:07.498+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.380447,GGain=1.000000,BGain=1.327759,Dtct=0.320816,0.354584 ,Curr=0.320526,0.355408 ,CTmep: QC=6422, AL= 5994
01-22 21:31:07.508+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c0e3a8), gem(37), surface(0xb8bc4f20)
01-22 21:31:07.538+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(38), surface(0xb8b13778)
01-22 21:31:07.588+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:303, cur_lum:52, next_index:304, target_lum:62
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.588+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.588+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.588+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.598+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c10110), gem(37), surface(0xb8bc4f20)
01-22 21:31:07.598+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.71, detect:   0.32,   0.35 CTemp:5920.9
01-22 21:31:07.598+0900 D/alPrinter0( 2130): [HSC]Mix=00007ae0,Csd=00017004 ,(BV= 1.379,x=0.321,y=0.354)
01-22 21:31:07.598+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:3, 0x00007ae0,0x00007ae0
01-22 21:31:07.598+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.333900 ,Awb Bv=1.378754 in/out_0
01-22 21:31:07.598+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.380142,GGain=1.000000,BGain=1.327530,Dtct=0.321213,0.353836 ,Curr=0.320526,0.355377 ,CTmep: QC=6422, AL= 5994
01-22 21:31:07.608+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bec5f8), gem(38), surface(0xb8b13778)
01-22 21:31:07.638+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be7288), gem(37), surface(0xb8c2c668)
01-22 21:31:07.688+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c0e3a8), gem(38), surface(0xb8bff548)
01-22 21:31:07.688+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:304, cur_lum:54, next_index:305, target_lum:62
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.688+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.688+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.688+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.698+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.72, detect:   0.32,   0.35 CTemp:5872.4
01-22 21:31:07.698+0900 D/alPrinter0( 2130): [HSC]Mix=00009998,Csd=0000b2ec ,(BV= 1.375,x=0.322,y=0.352)
01-22 21:31:07.698+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:4, 0x00009998,0x00009998
01-22 21:31:07.698+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.289506 ,Awb Bv=1.374527 in/out_0
01-22 21:31:07.698+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.378250,GGain=1.000000,BGain=1.326340,Dtct=0.321686,0.351715 ,Curr=0.320572,0.355225 ,CTmep: QC=6421, AL= 5993
01-22 21:31:07.718+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(37), surface(0xb8bec218)
01-22 21:31:07.738+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8af8e20), gem(38), surface(0xb8bff548)
01-22 21:31:07.758+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bec5f8), gem(37), surface(0xb8bc4f20)
01-22 21:31:07.788+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:305, cur_lum:55, next_index:306, target_lum:62
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.788+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.788+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.788+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.798+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.72, detect:   0.32,   0.35 CTemp:5856.9
01-22 21:31:07.798+0900 D/alPrinter0( 2130): [HSC]Mix=0000accb,Csd=00008ee0 ,(BV= 1.365,x=0.322,y=0.351)
01-22 21:31:07.798+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:3, 0x0000accb,0x0000accb
01-22 21:31:07.798+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.246438 ,Awb Bv=1.365036 in/out_0
01-22 21:31:07.798+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.373489,GGain=1.000000,BGain=1.323517,Dtct=0.322083,0.351120 ,Curr=0.320694,0.354858 ,CTmep: QC=6420, AL= 5992
01-22 21:31:07.808+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(38), surface(0xb8bc4f20)
01-22 21:31:07.838+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8af8e20), gem(37), surface(0xb8bc4f20)
01-22 21:31:07.888+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:306, cur_lum:56, next_index:307, target_lum:62
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.888+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.888+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.888+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.898+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.72, detect:   0.32,   0.35 CTemp:5861.8
01-22 21:31:07.898+0900 D/alPrinter0( 2130): [HSC]Mix=0000b708,Csd=000099ca ,(BV= 1.349,x=0.322,y=0.351)
01-22 21:31:07.898+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:4, 0x0000b708,0x0000b708
01-22 21:31:07.898+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.204618 ,Awb Bv=1.349396 in/out_0
01-22 21:31:07.898+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.366699,GGain=1.000000,BGain=1.319443,Dtct=0.322174,0.350510 ,Curr=0.320877,0.354324 ,CTmep: QC=6420, AL= 5992
01-22 21:31:07.898+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be7288), gem(38), surface(0xb8c29e70)
01-22 21:31:07.918+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c0e3a8), gem(39), surface(0xb8c29da0)
01-22 21:31:07.948+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8af8e20), gem(37), surface(0xb8bc4f20)
01-22 21:31:07.948+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x200ca0 
01-22 21:31:07.978+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c29e08), gem(38), surface(0xb8ac5d00)
01-22 21:31:07.988+0900 I/ISP_AE  ( 2130): AE_TEST:----cur_index:307, cur_lum:58, next_index:308, target_lum:62
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:31:07.988+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [CMD0][if=b0dd0930,Wrap=b0dd5e60]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:31:07.988+0900 D/awb_al_cmd0( 2130): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [CALL][0xb0dd0930][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [AIS_WRAP]msiFlash_state=0
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [LOCK]0
01-22 21:31:07.988+0900 D/alPrinter0( 2130): [SuperHighCTemp] Mapin:  0.72, detect:   0.32,   0.35 CTemp:5847.0
01-22 21:31:07.998+0900 D/alPrinter0( 2130): [HSC]Mix=0000ca3b,Csd=fffff1a6 ,(BV= 1.328,x=0.323,y=0.350)
01-22 21:31:07.998+0900 D/alPrinter0( 2130): [AlHscWrap_Main]:3, 0x0000ca3b,0x0000ca3b
01-22 21:31:07.998+0900 D/alPrinter0( 2130): [AIS_WRAP]In BV=1.163975 ,Awb Bv=1.327744 in/out_0
01-22 21:31:07.998+0900 D/alPrinter0( 2130): [AIS_WRAP]RGain=1.358444,GGain=1.000000,BGain=1.314453,Dtct=0.322739,0.349838 ,Curr=0.321091,0.353668 ,CTmep: QC=6417, AL= 5989
01-22 21:31:08.018+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b84ba0), gem(37), surface(0xb8c29f20)
01-22 21:31:08.048+0900 I/ISP_AE  ( 2130): ae_state=3
01-22 21:31:08.048+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b84ba0), gem(38), surface(0xb8c168a0)
01-22 21:31:08.078+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be7288), gem(37), surface(0xb8c170d0)
01-22 21:31:08.088+0900 I/ISP_AE  ( 2130): FDAE: ->disable, frame_idx=30
01-22 21:31:08.098+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b84ba0), gem(38), surface(0xb8c168a0)
01-22 21:31:08.148+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b84ba0), gem(37), surface(0xb8c29f20)
01-22 21:31:08.178+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be7288), gem(38), surface(0xb8c16890)
01-22 21:31:08.208+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b84ba0), gem(37), surface(0xb8af8cb0)
01-22 21:31:08.259+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8af8e20), gem(38), surface(0xb8ac5d00)
01-22 21:31:08.289+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bec790), gem(37), surface(0xb8b136c8)
01-22 21:31:08.299+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bec5f8), gem(38), surface(0xb8ac5d00)
01-22 21:31:08.349+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(37), surface(0xb8bec4d8)
01-22 21:31:08.379+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8b84ba0), gem(38), surface(0xb8c16890)
01-22 21:31:08.419+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8bec790), gem(37), surface(0xb8bec1f8)
01-22 21:31:08.429+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be7288), gem(38), surface(0xb8c170d0)
01-22 21:31:08.469+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x200ca0 bd->visible=1
01-22 21:31:08.479+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(37), surface(0xb8c16890)
01-22 21:31:08.499+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c2f9f8), gem(38), surface(0xb8bc4f20)
01-22 21:31:08.529+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be4068), gem(37), surface(0xb8bec4d8)
01-22 21:31:08.579+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(38), surface(0xb8bec4d8)
01-22 21:31:08.609+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be4068), gem(37), surface(0xb8bec4d8)
01-22 21:31:08.629+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c22a88), gem(38), surface(0xb8bec4d8)
01-22 21:31:08.669+0900 I/ISP_AE  ( 2130): calc_iso=110,real_gain=36,iso=0
01-22 21:31:08.669+0900 I/ISP_AE  ( 2130): calc_iso=110,real_gain=36,iso=0
01-22 21:31:08.689+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c69608), gem(37), surface(0xb8bec4d8)
01-22 21:31:08.909+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c698a8), gem(38), surface(0xb8af8cb0)
01-22 21:31:08.919+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be4808), gem(39), surface(0xb8bec4d8)
01-22 21:31:08.939+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be4bc8), gem(37), surface(0xb8af8cb0)
01-22 21:31:09.019+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8be4ad0), gem(38), surface(0xb8bec4d8)
01-22 21:31:09.019+0900 D/camera  ( 2130): Writing image to file.
01-22 21:31:09.039+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8af8e20), gem(37), surface(0xb8af8cb0)
01-22 21:31:09.069+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8777df8), gem(38), surface(0xb8bec4d8)
01-22 21:31:09.089+0900 I/MALI    ( 2130): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb8c316f8), gem(37), surface(0xb8af8cb0)
01-22 21:31:09.149+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:31:09.169+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:31:09.169+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01200003), visible:1
01-22 21:31:09.169+0900 D/INDICATOR(  893): main.c: _property_changed_cb(432) > UNSNIFF API 1200003
01-22 21:31:09.179+0900 D/INDICATOR(  893): util.c: util_signal_emit_by_win(116) > emission bg.translucent
01-22 21:31:09.179+0900 D/INDICATOR(  893): main.c: _rotate_window(229) > Indicator angle is 0 degree
01-22 21:31:09.179+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(242) > system cnt : 0, minictrl cnt : 0, noti cnt : 1
01-22 21:31:09.179+0900 D/INDICATOR(  893): box.c: box_get_right_item_count(243) > system_cnt + minictrl_cnt + noti_cnt = 1
01-22 21:31:09.179+0900 D/INDICATOR(  893): main.c: _rotate_window(252) > port :: hide more icon
01-22 21:31:09.179+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xf52958), gem(13), surface(0xfdc1b8)
01-22 21:31:09.189+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:31:09.189+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:31:09.219+0900 W/CRASH_MANAGER( 2361): worker.c: worker_job(1204) > 110213063616d142192986
