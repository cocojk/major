S/W Version Information
Model: TM1
Tizen-Version: 2.4.0
Build-Number: Tizen-2.4.0_Mobile-TM1_20151030.1448
Build-Date: 2015.10.30 14:48:55

Crash Information
Process Name: camera
PID: 3206
Date: 2015-01-22 21:38:37+0900
Executable File Path: /opt/usr/apps/org.example.camera/bin/camera
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = (nil)

Register Information
r0   = 0xac52bc00, r1   = 0x00000001
r2   = 0x00026677, r3   = 0x00000000
r4   = 0x00000000, r5   = 0x00026677
r6   = 0x00026677, r7   = 0xad77c578
r8   = 0xb7a2fe08, r9   = 0xad77c724
r10  = 0xb7a29840, fp   = 0x0000000d
ip   = 0xb692a110, sp   = 0xad77c4e0
lr   = 0xb6f13d37, pc   = 0xb692a128
cpsr = 0x200d0010

Memory Information
MemTotal:   987196 KB
MemFree:    428352 KB
Buffers:     19008 KB
Cached:     130372 KB
VmPeak:     593560 KB
VmSize:     534620 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       43672 KB
VmRSS:       43672 KB
VmData:     418172 KB
VmStk:         136 KB
VmExe:          20 KB
VmLib:       30868 KB
VmPTE:         230 KB
VmSwap:          0 KB

Threads Information
Threads: 48
PID = 3206 TID = 3278
3206 3208 3209 3210 3211 3213 3214 3230 3268 3269 3270 3274 3277 3278 3279 3280 3281 3282 3283 3284 3285 3286 3287 3288 3289 3292 3293 3294 3295 3296 3297 3298 3299 3300 3301 3302 3303 3304 3305 3306 3307 3308 3309 3310 3311 3312 3315 3318 

Maps Information
932fb000 93afa000 rwxp [stack:3274]
989fd000 991fc000 rwxp [stack:3270]
991fd000 999fc000 rwxp [stack:3269]
9a101000 9a900000 rwxp [stack:3315]
9b0fd000 9b8fc000 rwxp [stack:3318]
9b8fd000 9c0fc000 rwxp [stack:3268]
9c194000 9c993000 rwxp [stack:3279]
9ca01000 9d200000 rwxp [stack:3312]
9d201000 9da00000 rwxp [stack:3311]
9da01000 9e200000 rwxp [stack:3310]
9e201000 9ea00000 rwxp [stack:3309]
9ea01000 9f200000 rwxp [stack:3308]
9f201000 9fa00000 rwxp [stack:3307]
9fa01000 a0200000 rwxp [stack:3306]
a0201000 a0a00000 rwxp [stack:3305]
a0a01000 a1200000 rwxp [stack:3304]
a1201000 a1a00000 rwxp [stack:3303]
a1a01000 a2200000 rwxp [stack:3302]
a2201000 a2a00000 rwxp [stack:3301]
a2a01000 a3200000 rwxp [stack:3300]
a3201000 a3a00000 rwxp [stack:3299]
a3a01000 a4200000 rwxp [stack:3298]
a4201000 a4a00000 rwxp [stack:3297]
a4a01000 a5200000 rwxp [stack:3296]
a5618000 a5e17000 rwxp [stack:3295]
a5e18000 a6617000 rwxp [stack:3294]
a6c01000 a7400000 rwxp [stack:3293]
a7401000 a7c00000 rwxp [stack:3292]
a7c01000 a8400000 rwxp [stack:3289]
a8401000 a8c00000 rwxp [stack:3288]
a8c01000 a9400000 rwxp [stack:3287]
a9401000 a9c00000 rwxp [stack:3286]
a9c01000 aa400000 rwxp [stack:3285]
aa401000 aac00000 rwxp [stack:3284]
aac01000 ab400000 rwxp [stack:3283]
ab401000 abc00000 rwxp [stack:3281]
abc01000 ac400000 rwxp [stack:3282]
ac601000 ace00000 rwxp [stack:3280]
acf7f000 ad77e000 rwxp [stack:3278]
ad77e000 ad781000 r-xp /usr/lib/libXv.so.1.0.0
ad791000 ad7a3000 r-xp /usr/lib/gstreamer-1.0/libgstevaspixmapsink.so
ad7b4000 ad7eb000 r-xp /usr/lib/gstreamer-1.0/libgstcoreelements.so
ad7fd000 adffc000 rwxp [stack:3277]
adffc000 ae019000 r-xp /usr/lib/libAl_Awb_Sp.so
ae022000 ae025000 r-xp /usr/lib/libdeflicker.so
ae03d000 ae053000 r-xp /usr/lib/libAl_Awb.so
ae05b000 ae065000 r-xp /usr/lib/libcalibration.so
ae06e000 ae080000 r-xp /usr/lib/libaf_lib.so
ae088000 ae08e000 r-xp /usr/lib/liblsc.so
ae097000 ae0a3000 r-xp /usr/lib/libae.so
ae0ab000 ae0ec000 r-xp /usr/lib/libcamera_isp2.so.0.0.0
ae133000 ae212000 r-xp /usr/lib/libcamera-interface-sprd-sc7730.so.0.0.0
ae66f000 ae670000 r-xp /usr/lib/libcamerahdr.so.0.0.0
ae805000 ae841000 r-xp /usr/lib/libcamerahal.so.0.0.0
ae88b000 af08a000 rwxp [stack:3230]
af093000 af0ab000 r-xp /usr/lib/gstreamer-1.0/libgstcamerasrc.so
afe01000 b0600000 rwxp [stack:3214]
b0601000 b0e00000 rwxp [stack:3213]
b0f00000 b0f06000 r-xp /usr/lib/libspaf.so
b0f22000 b1721000 rwxp [stack:3211]
b1722000 b1f21000 rwxp [stack:3210]
b1f21000 b1f26000 r-xp /usr/lib/elementary/modules/ctxpopup_copypasteUI/v-1.13.0/module.so
b1fb2000 b1fba000 r-xp /usr/lib/ecore_evas/engines/extn/v-1.13/module.so
b1fcb000 b1fcc000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1fdc000 b1fe3000 r-xp /usr/lib/libfeedback.so.0.1.4
b2007000 b2008000 r-xp /usr/lib/edje/modules/feedback/v-1.13/module.so
b2018000 b202b000 r-xp /usr/lib/edje/modules/elm/v-1.13/module.so
b2186000 b218b000 r-xp /usr/lib/bufmgr/libtbm_sprd7727.so.0.0.0
b219c000 b299b000 rwxp [stack:3209]
b299b000 b2af6000 r-xp /usr/lib/egl/libMali.so
b2b0b000 b2b94000 r-xp /usr/lib/evas/modules/engines/gl_generic/v-1.13/module.so
b2bad000 b2c7b000 r-xp /usr/lib/libCOREGL.so.4.0
b2c96000 b2c99000 r-xp /usr/lib/libCOREGL_EGL.so.1.4
b2ca9000 b2cb6000 r-xp /usr/lib/libCOREGL_GLESv2.so.2.0
b2cc7000 b2cd1000 r-xp /usr/lib/evas/modules/engines/gl_x11/v-1.13/module.so
b2ce1000 b2ced000 r-xp /usr/lib/ecore_evas/engines/x/v-1.13/module.so
b2cfe000 b2d07000 r-xp /lib/libnss_files-2.20-2014.11.so
b2d18000 b2d21000 r-xp /lib/libnss_nis-2.20-2014.11.so
b2d32000 b2d43000 r-xp /lib/libnsl-2.20-2014.11.so
b2d56000 b2d5c000 r-xp /lib/libnss_compat-2.20-2014.11.so
b2d6d000 b2d71000 r-xp /usr/lib/libecore_ipc.so.1.13.0
b2d82000 b2e62000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b2e84000 b2eab000 r-xp /usr/lib/ecore_imf/modules/isf/v-1.13/module.so
b2ebe000 b36bd000 rwxp [stack:3208]
b36bd000 b36bf000 r-xp /usr/lib/ecore/system/systemd/v-1.13/module.so
b38d6000 b38da000 r-xp /usr/lib/libogg.so.0.7.1
b38ea000 b390c000 r-xp /usr/lib/libvorbis.so.0.4.3
b391c000 b3a00000 r-xp /usr/lib/libvorbisenc.so.2.0.6
b3a1c000 b3a5f000 r-xp /usr/lib/libsndfile.so.1.0.25
b3a75000 b3abc000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b3acd000 b3ad4000 r-xp /usr/lib/libjson-c.so.2.0.1
b3ae4000 b3ae6000 r-xp /usr/lib/libXau.so.6.0.0
b3af7000 b3b2c000 r-xp /usr/lib/libpulse.so.0.16.2
b3b3d000 b3b40000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b3b51000 b3b54000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b3b65000 b3ba8000 r-xp /usr/lib/libgstbase-1.0.so.0.405.0
b3bba000 b3bbf000 r-xp /usr/lib/libffi.so.6.0.2
b3bcf000 b3ca4000 r-xp /usr/lib/libxml2.so.2.9.2
b3cb9000 b3cc0000 r-xp /usr/lib/libsensord-share.so
b3cd0000 b3cd3000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b3ce4000 b3cfe000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b3d0e000 b3d28000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.6
b3d39000 b3d4e000 r-xp /lib/libexpat.so.1.5.2
b3d60000 b3dae000 r-xp /usr/lib/libssl.so.1.0.0
b3dc4000 b3dcd000 r-xp /usr/lib/libethumb.so.1.13.0
b3ddd000 b3de0000 r-xp /usr/lib/libecore_input_evas.so.1.13.0
b3df0000 b3e08000 r-xp /lib/libz.so.1.2.8
b3e18000 b3fcf000 r-xp /usr/lib/libcrypto.so.1.0.0
b5567000 b5602000 r-xp /usr/lib/libstdc++.so.6.0.20
b561e000 b5627000 r-xp /usr/lib/libXi.so.6.1.0
b5637000 b5639000 r-xp /usr/lib/libXgesture.so.7.0.0
b5649000 b564d000 r-xp /usr/lib/libXtst.so.6.1.0
b565d000 b5663000 r-xp /usr/lib/libXrender.so.1.3.0
b5673000 b5679000 r-xp /usr/lib/libXrandr.so.2.2.0
b568a000 b568c000 r-xp /usr/lib/libXinerama.so.1.0.0
b569c000 b569f000 r-xp /usr/lib/libXfixes.so.3.1.0
b56af000 b56ba000 r-xp /usr/lib/libXext.so.6.4.0
b56ca000 b56cc000 r-xp /usr/lib/libXdamage.so.1.1.0
b56dc000 b56de000 r-xp /usr/lib/libXcomposite.so.1.0.0
b56ef000 b56f6000 r-xp /usr/lib/libXcursor.so.1.0.2
b5706000 b571e000 r-xp /usr/lib/libudev.so.1.6.0
b5720000 b5734000 r-xp /usr/lib/libxcb.so.1.1.0
b5744000 b5746000 r-xp /usr/lib/libecore_imf_evas.so.1.13.0
b5756000 b575d000 r-xp /usr/lib/libembryo.so.1.13.0
b576e000 b577f000 r-xp /lib/libresolv-2.20-2014.11.so
b5793000 b57aa000 r-xp /usr/lib/liblzma.so.5.0.3
b57ba000 b57c2000 r-xp /usr/lib/libdrm.so.2.4.0
b57d2000 b57d4000 r-xp /usr/lib/libdri2.so.0.0.0
b57e4000 b57e6000 r-xp /usr/lib/libgmodule-2.0.so.0.4400.1
b57f7000 b57fe000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b580e000 b5819000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b582d000 b5833000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b5844000 b584c000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b585d000 b5862000 r-xp /usr/lib/libmmfsession.so.0.0.0
b5873000 b588a000 r-xp /usr/lib/libmmfsound.so.0.1.0
b589a000 b58ba000 r-xp /usr/lib/libexif.so.12.3.3
b58c6000 b58ce000 r-xp /usr/lib/libgstapp-1.0.so.0.405.0
b58de000 b590d000 r-xp /usr/lib/libgstvideo-1.0.so.0.405.0
b5920000 b5956000 r-xp /usr/lib/libgobject-2.0.so.0.4400.1
b5968000 b5a50000 r-xp /usr/lib/libgio-2.0.so.0.4400.1
b5a64000 b5ada000 r-xp /usr/lib/libsqlite3.so.0.8.6
b5aec000 b5aef000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b5aff000 b5b01000 r-xp /usr/lib/libvasum.so.0.3.1
b5b11000 b5b14000 r-xp /usr/lib/libiniparser.so.0
b5b24000 b5b28000 r-xp /usr/lib/libsmack.so.1.0.0
b5b38000 b5b3d000 r-xp /usr/lib/libxdgmime.so.1.1.0
b5b4e000 b5b65000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5b76000 b5b87000 r-xp /usr/lib/libsensor.so.1.2.0
b5b98000 b5bcc000 r-xp /usr/lib/libdbus-1.so.3.8.11
b5bdc000 b5bde000 r-xp /usr/lib/libttrace.so.1.1
b5bee000 b5c11000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b5c21000 b5c24000 r-xp /usr/lib/libbundle.so.0.1.22
b5c34000 b5c35000 r-xp /usr/lib/libsecurity-privilege-checker.so.1.0.1
b5c45000 b5c47000 r-xp /usr/lib/libappsvc.so.0.1.0
b5c57000 b5c6f000 r-xp /usr/lib/libpng12.so.0.50.0
b5c80000 b5ca3000 r-xp /usr/lib/libjpeg.so.8.0.2
b5cc3000 b5cd7000 r-xp /usr/lib/libector.so.1.13.0
b5ce8000 b5d00000 r-xp /usr/lib/liblua-5.1.so
b5d11000 b5d68000 r-xp /usr/lib/libfreetype.so.6.11.3
b5d7c000 b5da4000 r-xp /usr/lib/libfontconfig.so.1.8.0
b5db5000 b5dc8000 r-xp /usr/lib/libfribidi.so.0.3.1
b5dd9000 b5e13000 r-xp /usr/lib/libharfbuzz.so.0.940.0
b5e24000 b5e31000 r-xp /usr/lib/libeio.so.1.13.0
b5e41000 b5e43000 r-xp /usr/lib/libefreet_trash.so.1.13.0
b5e53000 b5e58000 r-xp /usr/lib/libefreet_mime.so.1.13.0
b5e68000 b5e7f000 r-xp /usr/lib/libefreet.so.1.13.0
b5e91000 b5eb1000 r-xp /usr/lib/libeldbus.so.1.13.0
b5ec1000 b5ee1000 r-xp /usr/lib/libecore_con.so.1.13.0
b5ee3000 b5ee9000 r-xp /usr/lib/libecore_imf.so.1.13.0
b5ef9000 b5f00000 r-xp /usr/lib/libethumb_client.so.1.13.0
b5f10000 b5f22000 r-xp /usr/lib/libecore_input.so.1.13.0
b5f33000 b5f38000 r-xp /usr/lib/libecore_file.so.1.13.0
b5f48000 b5f60000 r-xp /usr/lib/libecore_evas.so.1.13.0
b5f71000 b5f8e000 r-xp /usr/lib/libeet.so.1.13.0
b5fa7000 b608c000 r-xp /usr/lib/libicuuc.so.51.1
b60a9000 b61e9000 r-xp /usr/lib/libicui18n.so.51.1
b6200000 b6238000 r-xp /usr/lib/libecore_x.so.1.13.0
b624a000 b632d000 r-xp /usr/lib/libX11.so.6.3.0
b6340000 b63c0000 r-xp /usr/lib/libedje.so.1.13.0
b63c3000 b642e000 r-xp /lib/libm-2.20-2014.11.so
b643f000 b6445000 r-xp /lib/librt-2.20-2014.11.so
b6456000 b6490000 r-xp /usr/lib/libsystemd.so.0.4.0
b6492000 b64a0000 r-xp /usr/lib/libeo.so.1.13.0
b64b0000 b64c0000 r-xp /usr/lib/libefl.so.1.13.0
b64d1000 b65b3000 r-xp /usr/lib/libglib-2.0.so.0.4400.1
b65c4000 b65cf000 r-xp /usr/lib/libvconf.so.0.2.45
b65df000 b65e7000 r-xp /usr/lib/libtbm.so.1.0.0
b65f7000 b66b0000 r-xp /usr/lib/libgstreamer-1.0.so.0.405.0
b66c4000 b66cb000 r-xp /usr/lib/libcapi-media-tool.so.0.1.1
b66db000 b6739000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
b674e000 b6796000 r-xp /usr/lib/libeina.so.1.13.0
b67a7000 b67c0000 r-xp /usr/lib/libaul.so.0.1.0
b67d2000 b67d8000 r-xp /usr/lib/libappcore-common.so.1.1
b67e8000 b67ed000 r-xp /usr/lib/libappcore-efl.so.1.1
b67fd000 b67ff000 r-xp /usr/lib/libcapi-appfw-app-common.so.0.3.1.0
b6810000 b6815000 r-xp /usr/lib/libcapi-appfw-app-control.so.0.3.1.0
b6825000 b6827000 r-xp /lib/libdl-2.20-2014.11.so
b6838000 b6845000 r-xp /usr/lib/libunwind.so.8.0.1
b687b000 b688f000 r-xp /lib/libpthread-2.20-2014.11.so
b68a3000 b68bc000 r-xp /lib/libgcc_s-4.9.so.1
b68cc000 b69f0000 r-xp /lib/libc-2.20-2014.11.so
b6a05000 b6a09000 r-xp /usr/lib/libstorage.so.0.1
b6a19000 b6b7b000 r-xp /usr/lib/libevas.so.1.13.0
b6bb2000 b6dd6000 r-xp /usr/lib/libelementary.so.1.13.0
b6e04000 b6e0b000 r-xp /usr/lib/libefl-extension.so.0.1.0
b6e1b000 b6e39000 r-xp /usr/lib/libecore.so.1.13.0
b6e59000 b6e5b000 r-xp /usr/lib/libdlog.so.0.0.0
b6e6b000 b6e7a000 r-xp /usr/lib/libcapi-media-camera.so.0.1.88
b6e8a000 b6e91000 r-xp /usr/lib/libcapi-base-common.so.0.2.2
b6ea3000 b6ea6000 r-xp /usr/lib/libcapi-appfw-application.so.0.3.1.0
b6eca000 b6ece000 r-xp /usr/lib/libsys-assert.so
b6edf000 b6eff000 r-xp /lib/ld-2.20-2014.11.so
b6f10000 b6f15000 r-xp /opt/usr/apps/org.example.camera/bin/camera
b7699000 b7c9f000 rw-p [heap]
bec4f000 bec70000 rwxp [stack]
bec4f000 bec70000 rwxp [stack]
End of Maps Information

Callstack Information (PID:3206)
Call Stack Count: 12
 0: fwrite + 0x18 (0xb692a128) [/lib/libc.so.6] + 0x5e128
 1: _camera_capturing_cb + 0xb2 (0xb6f13d37) [/opt/usr/apps/org.example.camera/bin/camera] + 0x3d37
 2: (0xb6e6fabb) [/usr/lib/libcapi-media-camera.so.0] + 0x4abb
 3: (0xb6700865) [/usr/lib/libmmfcamcorder.so.0] + 0x25865
 4: g_closure_invoke + 0xf4 (0xb592c5bd) [/usr/lib/libgobject-2.0.so.0] + 0xc5bd
 5: (0xb5938f67) [/usr/lib/libgobject-2.0.so.0] + 0x18f67
 6: g_signal_emit_valist + 0x948 (0xb593ea8d) [/usr/lib/libgobject-2.0.so.0] + 0x1ea8d
 7: g_signal_emit + 0x14 (0xb593ec81) [/usr/lib/libgobject-2.0.so.0] + 0x1ec81
 8: (0xaf09dcf1) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xacf1
 9: (0xaf09e459) [/usr/lib/gstreamer-1.0/libgstcamerasrc.so] + 0xb459
10: (0xb6522157) [/usr/lib/libglib-2.0.so.0] + 0x51157
11: (0xb6880cf0) [/lib/libpthread.so.0] + 0x5cf0
End of Call Stack

Package Information
Package Name: org.example.camera
Package ID : org.example.camera
Version: 1.0.0
Package Type: tpk
App Name: camera
App ID: org.example.camera
Type: capp
Categories: 

Latest Debug Message Information
--------- beginning of /dev/log_main
DEFLICKER V3( 3206): hyman still_f :24
01-22 21:38:35.195+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.195+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.195+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.195+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.195+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :25
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :26
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :27
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :28
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :29
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.205+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :30
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v_s :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v_s :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :31
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :32
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :33
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :34
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.215+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :35
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :36
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :37
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.225+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :38
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :39
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :40
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :41
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :42
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.235+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :43
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :44
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :45
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :46
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :47
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.245+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb780a648), gem(47), surface(0xb7866868)
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :48
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.245+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 70
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :49
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :70
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -7
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 40
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :50
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :40
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -7
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :51
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :52
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :53
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -10
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 560
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :54
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :560
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 4
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :4
01-22 21:38:35.255+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 1 -> 3
01-22 21:38:35.255+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 1 -> 3
01-22 21:38:35.255+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 210
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :55
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :210
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 4
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 5
01-22 21:38:35.255+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :5
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 70
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :56
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :70
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 5
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -2
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 70
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :57
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :70
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -7
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 130
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :58
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :130
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -6
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 90
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :59
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :90
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -7
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman frame_flicker_value = 80
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman still_f :60
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v :80
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b0 0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b1 200
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman b2 -7
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v :0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_f_v_s :0
01-22 21:38:35.265+0900 I/ISP_DEFLICKER V3( 3206): hyman afl_v_v_s :0
01-22 21:38:35.295+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb78e8058), gem(44), surface(0xb7866868)
01-22 21:38:35.375+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b3e5e0), gem(47), surface(0xb7866868)
01-22 21:38:35.425+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb780a648), gem(44), surface(0xb7866868)
01-22 21:38:35.465+0900 I/ISP_AE  ( 3206): AE_TEST:--------------low----------------T_lum:62, be_lum:140, cur_lum:48
01-22 21:38:35.465+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:400, cur_lum:48, next_index:400, target_lum:62
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:35.465+0900 D/awb_al_cmd0( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:35.465+0900 D/awb_al_cmd0( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:35.465+0900 D/alPrinter0( 3206): [LOCK]0
01-22 21:38:35.475+0900 D/alPrinter0( 3206): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4627.3
01-22 21:38:35.475+0900 D/alPrinter0( 3206): [HSC]Mix=00007ae0,Csd=0005bff8 ,(BV=-3.098,x=0.360,y=0.387)
01-22 21:38:35.475+0900 D/alPrinter0( 3206): [AlHscWrap_Main]:4, 0x00007ae0,0x00007ae0
01-22 21:38:35.475+0900 D/alPrinter0( 3206): [AIS_WRAP]In BV=-1.666100 ,Awb Bv=-3.097916 in/out_0
01-22 21:38:35.475+0900 D/alPrinter0( 3206): [AIS_WRAP]RGain=1.297180,GGain=1.000000,BGain=1.641205,Dtct=0.359909,0.387360 ,Curr=0.355026,0.387817 ,CTmep: QC=5006, AL= 4771
01-22 21:38:35.475+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb78e8058), gem(47), surface(0xb7866868)
01-22 21:38:35.525+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:400, cur_lum:48, next_index:404, target_lum:62
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:35.525+0900 D/awb_al_cmd0( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:35.525+0900 D/awb_al_cmd0( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:35.525+0900 D/alPrinter0( 3206): [LOCK]0
01-22 21:38:35.535+0900 D/alPrinter0( 3206): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4624.3
01-22 21:38:35.535+0900 D/alPrinter0( 3206): [HSC]Mix=00009998,Csd=00058154 ,(BV=-2.895,x=0.360,y=0.387)
01-22 21:38:35.545+0900 D/alPrinter0( 3206): [AlHscWrap_Main]:3, 0x00009998,0x00009998
01-22 21:38:35.545+0900 D/alPrinter0( 3206): [AIS_WRAP]In BV=-1.836024 ,Awb Bv=-2.895355 in/out_0
01-22 21:38:35.545+0900 D/alPrinter0( 3206): [AIS_WRAP]RGain=1.293915,GGain=1.000000,BGain=1.644394,Dtct=0.360001,0.387314 ,Curr=0.355591,0.388092 ,CTmep: QC=5004, AL= 4769
01-22 21:38:35.565+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b3e5e0), gem(44), surface(0xb7af23b8)
01-22 21:38:35.575+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x201271 
01-22 21:38:35.615+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb793f178), gem(47), surface(0xb7941be0)
01-22 21:38:35.645+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:404, cur_lum:54, next_index:405, target_lum:62
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [CMD0][if=a52202a8,Wrap=a52257d8]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:35.645+0900 D/awb_al_cmd0( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [CMD0][if=a52202a8,Wrap=a52257d8]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:35.645+0900 D/awb_al_cmd0( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [CALL][0xa52202a8][0]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:35.645+0900 D/alPrinter0( 3206): [LOCK]0
01-22 21:38:35.655+0900 I/ISP_AE  ( 3206): calc_iso=460,real_gain=148,iso=0
01-22 21:38:35.655+0900 D/alPrinter0( 3206): [SuperHighCTemp] Mapin:  1.00, detect:   0.36,   0.39 CTemp:4559.1
01-22 21:38:35.655+0900 D/alPrinter0( 3206): [HSC]Mix=0000b850,Csd=0003a038 ,(BV=-2.678,x=0.362,y=0.387)
01-22 21:38:35.655+0900 D/alPrinter0( 3206): [AlHscWrap_Main]:4, 0x0000b850,0x0000b850
01-22 21:38:35.655+0900 D/alPrinter0( 3206): [AIS_WRAP]In BV=-1.875553 ,Awb Bv=-2.677673 in/out_0
01-22 21:38:35.655+0900 D/alPrinter0( 3206): [AIS_WRAP]RGain=1.287186,GGain=1.000000,BGain=1.645981,Dtct=0.362259,0.387146 ,Curr=0.356354,0.388184 ,CTmep: QC=5000, AL= 4766
01-22 21:38:35.695+0900 D/TIZEN_N_CAMERA( 3206): camera.c: camera_is_supported_face_detection(1193) > face detection NOT supported
01-22 21:38:35.695+0900 E/TIZEN_N_CAMERA( 3206): camera.c: camera_stop_face_detection(1315) > NOT_SUPPORTED(0xc0000002)
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): tunnig_param=263480
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): param_num=3
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): cur target lum=61, ev diff=0, level=4
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): AE VERSION : 0x20150828-00
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): cvg speed=0
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): target lum=61, target lum zone=16
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): lime time=164, min line=1
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): cvgn_param[0] error!!!  set default cvgn_param
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): target_lum_ev0=61
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): highcount=19,lowcount=15
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): FDAE: failed open fdae_param.txt
01-22 21:38:36.125+0900 I/ISP_AE  ( 3206): FDAE param: param_face_weight=148, convergence_speed=2, param_lock_ae=3, param_lock_weight_has_face=20
01-22 21:38:36.125+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceInit :mode=-1 ins=0x00000074
01-22 21:38:36.125+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_START_RANGE=0x00000001
01-22 21:38:36.125+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_BV_TH_OUTDOOR=0x00038000
01-22 21:38:36.125+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_BV_TH_INDOOR=0x0002e3d7
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_BV_TH_INTERP=0x270f0000
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_BV_LPF_FSMP=0x00140000
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_BV_LPF_FCUT=0x00010000
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_XY_LPF_FSMP=0x00140000
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AWB_PRM]AL_AWB_XY_LPF_FCUT=0x00010000
01-22 21:38:36.135+0900 D/alPrinter1( 3206): LSC Size:24 19
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [LSC]TableSize=   456
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [LSC]TableSize=   456
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [LSC]TableSize=   456
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [LSC]OTP Disable
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=0.000000 ,Awb Bv=6.500000 in/out_1
01-22 21:38:36.135+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.232086,GGain=1.000000,BGain=1.304459,Dtct=0.000000,0.000000 ,Curr=0.319992,0.335999 ,CTmep: QC=6085, AL= 6085
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): work_mode=0 last mode=0
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): cvg speed=0
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): target lum=61, target lum zone=16
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): lime time=164, min line=1
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): target_lum_ev0=61
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): highcount=19,lowcount=15
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): is_quick=0
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): AE_TEST:-----------SET index:230
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): AE_TEST: get index:230, exp:200000, line:1219
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): AE_TEST:-----------SET index:230
01-22 21:38:36.246+0900 I/ISP_AE  ( 3206): info x=8,y=6,w=2560,h=1920, block_size.w=80,block_size.h=60
01-22 21:38:36.256+0900 I/ISP_AE  ( 3206): calc_iso=50,real_gain=19,iso=0
01-22 21:38:36.516+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:230, cur_lum:2, next_index:280, target_lum:61
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceReset :mode=0 ins=0x00000000
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x65746e69
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,3f,ab,00,00,00,00
01-22 21:38:36.516+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,3f,ab,00,00,00,00
01-22 21:38:36.516+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [LED]LPF Disable
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.40, detect:   0.40,   0.43 CTemp:3860.5
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [CHROMA]START BV=0.492584 Ratio=1.000000
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [HSC]Mix=00000000,Csd=00009b4e ,(BV= 0.493,x=0.371,y=0.398)
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:3, 0x00000000,0x00000000
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=0.492599 ,Awb Bv=0.492584 in/out_0
01-22 21:38:36.516+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.278824,GGain=0.999985,BGain=1.845367,Dtct=0.370743,0.398148 ,Curr=0.370743,0.398148 ,CTmep: QC=4379, AL= 4379
01-22 21:38:36.626+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:280, cur_lum:13, next_index:316, target_lum:61
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:36.626+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:36.626+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [LED]LPF Disable
01-22 21:38:36.626+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:36.626+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0848), gem(37), surface(0xb7b49750)
01-22 21:38:36.636+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.96, detect:   0.38,   0.39 CTemp:4162.9
01-22 21:38:36.636+0900 D/alPrinter1( 3206): [HSC]Mix=00001333,Csd=00033a71 ,(BV=-1.012,x=0.373,y=0.389)
01-22 21:38:36.636+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:4, 0x00001333,0x00001333
01-22 21:38:36.636+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.011874 ,Awb Bv=-1.011871 in/out_0
01-22 21:38:36.636+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.203125,GGain=0.999985,BGain=1.764023,Dtct=0.372513,0.389420 ,Curr=0.372513,0.389420 ,CTmep: QC=4288, AL= 4288
01-22 21:38:36.666+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0848), gem(38), surface(0xb7ae1048)
01-22 21:38:36.686+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ae07d8), gem(40), surface(0xb7ae1048)
01-22 21:38:36.736+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:316, cur_lum:36, next_index:324, target_lum:61
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:36.746+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:36.746+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [LED]LPF Disable
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:36.746+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.97, detect:   0.37,   0.39 CTemp:4252.5
01-22 21:38:36.756+0900 D/alPrinter1( 3206): [HSC]Mix=000031eb,Csd=0002a62e ,(BV=-1.310,x=0.372,y=0.386)
01-22 21:38:36.756+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:3, 0x000031eb,0x000031eb
01-22 21:38:36.756+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.309956 ,Awb Bv=-1.309952 in/out_0
01-22 21:38:36.756+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.186630,GGain=1.000000,BGain=1.723022,Dtct=0.371536,0.385818 ,Curr=0.371536,0.385818 ,CTmep: QC=4295, AL= 4295
01-22 21:38:36.766+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0848), gem(37), surface(0xb7ae1048)
01-22 21:38:36.846+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0848), gem(38), surface(0xb7ae1048)
01-22 21:38:36.856+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping_confirm_handler(360) > [PROCESSMGR] last_pointed_win=0x201271 bd->visible=1
01-22 21:38:36.906+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:324, cur_lum:45, next_index:327, target_lum:61
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:36.906+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:36.906+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [LED]LPF Disable
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.97, detect:   0.38,   0.39 CTemp:4188.5
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [HSC]Mix=000050a3,Csd=0000fec0 ,(BV=-1.491,x=0.372,y=0.383)
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:4, 0x000050a3,0x000050a3
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.490528 ,Awb Bv=-1.490524 in/out_0
01-22 21:38:36.906+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.164734,GGain=0.999985,BGain=1.700119,Dtct=0.372467,0.383499 ,Curr=0.372467,0.383499 ,CTmep: QC=4256, AL= 4256
01-22 21:38:36.916+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ae07d8), gem(37), surface(0xb7ae1048)
01-22 21:38:36.996+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7ae07d8), gem(38), surface(0xb7ae1048)
01-22 21:38:37.056+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(121) > [APP 913] Rotation: 3 -> 1
01-22 21:38:37.056+0900 D/APP_CORE(  913): appcore-rotation.c: __changed_cb(124) > [APP 913] Rotation: 3 -> 1
01-22 21:38:37.056+0900 I/CAPI_APPFW_APPLICATION(  913): app_main.c: _ui_app_appcore_rotation_event(484) > _ui_app_appcore_rotation_event
01-22 21:38:37.066+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:327, cur_lum:52, next_index:328, target_lum:61
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:37.066+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:37.066+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [LED]LPF Disable
01-22 21:38:37.066+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:37.076+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.96, detect:   0.38,   0.38 CTemp:4164.1
01-22 21:38:37.076+0900 D/alPrinter1( 3206): [HSC]Mix=00006f5b,Csd=ffff8a8b ,(BV=-1.524,x=0.373,y=0.383)
01-22 21:38:37.076+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:3, 0x00006f5b,0x00006f5b
01-22 21:38:37.076+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.524080 ,Awb Bv=-1.524078 in/out_0
01-22 21:38:37.076+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.164734,GGain=0.999985,BGain=1.699036,Dtct=0.373093,0.383301 ,Curr=0.372467,0.383499 ,CTmep: QC=4238, AL= 4238
01-22 21:38:37.096+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af15a8), gem(37), surface(0xb7ae9e60)
01-22 21:38:37.177+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0848), gem(38), surface(0xb7ae1048)
01-22 21:38:37.227+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:328, cur_lum:51, next_index:329, target_lum:61
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:37.227+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:37.227+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [LED]LPF Disable
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.96, detect:   0.38,   0.38 CTemp:4171.2
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [HSC]Mix=0000651e,Csd=0000a9eb ,(BV=-1.589,x=0.373,y=0.383)
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:4, 0x0000651e,0x0000651e
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.588932 ,Awb Bv=-1.588928 in/out_0
01-22 21:38:37.227+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.164734,GGain=0.999985,BGain=1.699738,Dtct=0.372650,0.383209 ,Curr=0.372467,0.383499 ,CTmep: QC=4250, AL= 4250
01-22 21:38:37.247+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b40828), gem(37), surface(0xb7ae1048)
01-22 21:38:37.327+0900 D/PROCESSMGR(  535): e_mod_processmgr.c: _e_mod_processmgr_anr_ping(499) > [PROCESSMGR] ev_win=0x200035  register trigger_timer!  pointed_win=0x201271 
01-22 21:38:37.327+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af0848), gem(38), surface(0xb7ae1048)
01-22 21:38:37.367+0900 E/TIZEN_N_CAMERA( 3206): camera.c: __convert_camera_error_code(196) > [camera_start_focusing] ERROR_NOT_SUPPORTED(0xc0000002) : core frameworks error code(0x8000081a)
01-22 21:38:37.367+0900 I/camera  ( 3206): Focusing is not supported on this device. The picture will be taken without focusing.
01-22 21:38:37.387+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:329, cur_lum:51, next_index:330, target_lum:61
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:37.387+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:37.387+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [LED]LPF Enable
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.96, detect:   0.38,   0.38 CTemp:4156.9
01-22 21:38:37.387+0900 I/ISP_AE  ( 3206): calc_iso=290,real_gain=95,iso=0
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [HSC]Mix=00007851,Csd=00013202 ,(BV=-1.590,x=0.373,y=0.383)
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:3, 0x00007851,0x00007851
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.650992 ,Awb Bv=-1.590149 in/out_0
01-22 21:38:37.387+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.164734,GGain=0.999985,BGain=1.699738,Dtct=0.372986,0.383179 ,Curr=0.372467,0.383499 ,CTmep: QC=4250, AL= 4250
01-22 21:38:37.387+0900 I/ISP_AE  ( 3206): calc_iso=290,real_gain=95,iso=0
01-22 21:38:37.397+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b40f78), gem(37), surface(0xb7ae1048)
01-22 21:38:37.477+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7af15a8), gem(38), surface(0xb7ae1048)
01-22 21:38:37.547+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:330, cur_lum:53, next_index:331, target_lum:61
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:37.547+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:37.547+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:37.547+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.96, detect:   0.38,   0.38 CTemp:4132.1
01-22 21:38:37.557+0900 D/alPrinter1( 3206): [HSC]Mix=00009709,Csd=000054a3 ,(BV=-1.595,x=0.374,y=0.383)
01-22 21:38:37.557+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:4, 0x00009709,0x00009709
01-22 21:38:37.557+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.681049 ,Awb Bv=-1.595169 in/out_0
01-22 21:38:37.557+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.164444,GGain=0.999985,BGain=1.699493,Dtct=0.373581,0.382935 ,Curr=0.372482,0.383469 ,CTmep: QC=4250, AL= 4250
01-22 21:38:37.587+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b40828), gem(37), surface(0xb7ae1048)
01-22 21:38:37.647+0900 D/camera  ( 3206): Writing image to file.
01-22 21:38:37.667+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7c11840), gem(38), surface(0xb7ae1048)
01-22 21:38:37.707+0900 I/ISP_AE  ( 3206): AE_TEST:----cur_index:331, cur_lum:54, next_index:332, target_lum:61
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=3502 : 00,00,00,00,00,00,00,00
01-22 21:38:37.707+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorMode2] muiMd=0 muiAct:0  
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceSendCommand :mode=0 ins=0x00000000
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [CMD1][if=a5230368,Wrap=a5235898]ID=1503 : 00,00,00,00,00,00,00,00
01-22 21:38:37.707+0900 D/awb_al_cmd1( 3206): [alAisCmd_SetColorLock] muiAwblc:0 
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [CALL][0xa5230368][1]AlAwbInterfaceMain :mode=0 ins=0x65746e69
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [AIS_WRAP]msiFlash_state=0
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [LOCK]0
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [SuperHighCTemp] Mapin:  0.96, detect:   0.38,   0.38 CTemp:4126.7
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [HSC]Mix=00009709,Csd=00004742 ,(BV=-1.605,x=0.374,y=0.383)
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [AlHscWrap_Main]:3, 0x00009709,0x00009709
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [AIS_WRAP]In BV=-1.710493 ,Awb Bv=-1.605255 in/out_0
01-22 21:38:37.707+0900 D/alPrinter1( 3206): [AIS_WRAP]RGain=1.163696,GGain=1.000000,BGain=1.699326,Dtct=0.373795,0.383148 ,Curr=0.372559,0.383438 ,CTmep: QC=4249, AL= 4249
01-22 21:38:37.737+0900 I/MALI    ( 3206): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0xb7b40f78), gem(37), surface(0xb7ae1048)
01-22 21:38:37.797+0900 E/EFL     (  535): eo<535> lib/eo/eo.c:676 _eo_call_resolve() in lib/edje/edje_object.eo.c:316: func 'edje_obj_signal_emit' (410) could not be resolved for class 'Evas_Object_Smart'.
01-22 21:38:37.817+0900 E/E17     (  535): e_border.c: e_border_show(2088) > BD_SHOW(0x02200002)
01-22 21:38:37.827+0900 E/E17     (  535): e_border.c: e_border_hide(2248) > BD_HIDE(0x01600003), visible:1
01-22 21:38:37.827+0900 D/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2887) > pid(913) status(3)
01-22 21:38:37.827+0900 D/AUL_AMD (  819): amd_key.c: _key_ungrab(265) > _key_ungrab, win : a00002
01-22 21:38:37.837+0900 W/AUL_AMD (  819): amd_key.c: _key_ungrab(269) > fail(-1) to ungrab key(XF86Back)
01-22 21:38:37.837+0900 W/AUL_AMD (  819): amd_launch.c: __e17_status_handler(2891) > back key ungrab error
01-22 21:38:37.837+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(456) > pid(913) status(3)
01-22 21:38:37.837+0900 D/AUL_AMD (  819): amd_status.c: _status_update_app_info_list(468) > pid(913) appid(org.tizen.homescreen) pkgid(org.tizen.homescreen) status(3)
01-22 21:38:37.837+0900 D/AUL     (  819): amd_app_group.c: __set_fg_flag(172) > send_signal FG org.tizen.homescreen
01-22 21:38:37.837+0900 W/AUL     (  819): app_signal.c: aul_send_app_status_change_signal(551) > send_app_status_change_signal, pid: 913, appid: org.tizen.homescreen, status: fg
01-22 21:38:37.837+0900 I/MALI    (  535): egl_platform_x11_tizen.c: __egl_platform_map_pixmap_tizen(738) > [EGL-X11] eglimage target 0 imported bo(0x10115e8), gem(13), surface(0x1029558)
01-22 21:38:37.847+0900 D/RESOURCED(  870): proc-main.c: resourced_proc_status_change(843) > [SECURE_LOG] set foreground : 913
01-22 21:38:37.847+0900 D/RESOURCED(  870): heart-cpu.c: heart_cpu_foreground_state(201) > heart_cpu_foreground_state : pid = 913, appname = org.tizen.homescreen, pkgname = org.tizen.homescreen
01-22 21:38:37.847+0900 D/RESOURCED(  870): cpu.c: cpu_foreground_state(221) > cpu_foreground_state : pid = 913, appname = org.tizen.homescreen
01-22 21:38:37.847+0900 D/RESOURCED(  870): cgroup.c: cgroup_write_node(134) > [SECURE_LOG] cgroup_buf /sys/fs/cgroup/cpu/cgroup.procs, value 913
01-22 21:38:37.847+0900 E/RESOURCED(  870): freezer-process.c: freezer_process_pid_set(160) > freezer_process_pid_set 913 foreground
01-22 21:38:37.867+0900 W/CRASH_MANAGER( 3322): worker.c: worker_job(1204) > 110320663616d142193031
