package splineViewer;

import javax.swing.*;
import splineControler.*;

public class SplineButtonPanel extends JPanel{
	
	private JButton SubbotinQuadraticSpline, linearSplineButton, quadSplineButton, cubicSplineButton, clearButton, printButton;
	
	public SplineButtonPanel(SplineControler SControler, SplineCanvas SCanvas) {
		
		linearSplineButton	=	new JButton("Linear Spline");
		quadSplineButton	=	new	JButton("Quadratic Spline");
		cubicSplineButton	=	new JButton("Cubic Spline");
		SubbotinQuadraticSpline = new JButton("SubbotinQuadraticSpline");
		clearButton	=	new JButton("Clear");
		printButton	=	new JButton("Print");
		
		ButtonControler SBListener	=	new ButtonControler(SControler, SCanvas);
		
		linearSplineButton.addActionListener(SBListener);
		quadSplineButton.addActionListener(SBListener);
		cubicSplineButton.addActionListener(SBListener);
		SubbotinQuadraticSpline.addActionListener(SBListener);
		clearButton.addActionListener(SBListener);
		printButton.addActionListener(SBListener);
		
		add(linearSplineButton);
		add(quadSplineButton);
		add(cubicSplineButton);
		add(SubbotinQuadraticSpline);
		add(clearButton);
		add(printButton);
	}
}