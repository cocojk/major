package splineViewer;

import javax.swing.*;
import splineControler.*;

import java.awt.*;



//ť�� ���ö����� ���� ��������� ����մϴ�

public class SplineViewer extends JFrame{
	
	public SplineViewer(SplineControler SControler){

		SplineCanvas	 SCanvas=	new SplineCanvas(SControler);
		SplineButtonPanel	SBPanel	=	new SplineButtonPanel(SControler, SCanvas);
		
		add(SBPanel, BorderLayout.NORTH);
		add(SCanvas, BorderLayout.CENTER);
		
		setSize(1200, 500);
//		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}	
	
	//���� �Լ�
	public static void main(String[] args) {
		SplineControler SControler	=	new SplineControler();
		new SplineViewer(SControler);
	}
} 