function s = readCoefFromJAVA(n, fid)

s=randn(n-1,4);

for i=1:n-1
    
     w = fscanf( fid, '%f', [1 4] );
    for j=1:4
        s(i, j) = w(j);
    end;
    
end;



 


