 function curveSubbotin = computeEquationSubbotin(n,tt,S)
 
    syms x;
    format short;  
    
    
    for i=1:n-2

         curveSubbotin(i) =  S(i,1)*(x-tt(i+1))*(x-tt(i+1))+S(i,2)*(x-tt(i+1))+S(i,3);
     end;

