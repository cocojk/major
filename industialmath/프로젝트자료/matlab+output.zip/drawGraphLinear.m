function drawGraphLinear(n, t, y, curve)

%Graph �׸���
for i=1:n-1
    
   ezplot(curve(i), [t(i) t(i+1)])
   hold on
    
end;

plot(t, y, 'o', 'Color','red')
axis auto
grid on


title('Linear Spline');
xlabel('X');
ylabel('Y=S(X)');