function s = readCoefFromJAVAQuad( n,fid )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
s = randn(n-1,3);

for i=1:n-1
    w = fscanf( fid, '%f' , [1 3]);
    for j=1:3
s(i,j) = w(j);
    end
end
