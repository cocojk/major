function  S= subbotin(t,z,y,n )

S= rand(n-2,3);
h = rand(n-2);
for i =1:n-2
    h(i) = t(i+1) - t(i);
end

for i=1:n-2
    S(i,1) = (z(1,i+1)-z(1,i))/(2*h(i));
    S(i,2) = (z(1,i+1)+z(1,i))/2;
    S(i,3) = y(i+1);
end
  
        

%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here




