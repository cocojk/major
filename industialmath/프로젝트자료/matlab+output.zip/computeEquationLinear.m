 function curveLinear = computeEquationLinear(n, t,y,S)
 
    syms x;
    format short;  
    for i=1:n-1
 
         curveLinear(i) =  S(i)*(x-t(i))+y(i);
     end;

