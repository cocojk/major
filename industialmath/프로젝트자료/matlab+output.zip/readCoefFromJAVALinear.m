function s = readCoefFromJAVALinear( n,fid )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
s = randn(n-1,2);

for i=1:n-1
    w = fscanf( fid, '%f' , [1 2]);
    for j=1:2
        s(i,j)=w(j);
    end

end

