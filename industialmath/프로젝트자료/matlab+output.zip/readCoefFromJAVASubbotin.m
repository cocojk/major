function s = readCoefFromJAVASubbotin(n,fid )
 s = randn(n-2,3);
 
 for i=1:n-2
     w =fscanf( fid, '%f',[1 3]);
     for j=1:3
         s(i,j) = w(j);
     end
         

%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


end

