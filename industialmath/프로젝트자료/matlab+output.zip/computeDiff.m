function diff = computeDiff(n, S, s)

diff=randn(n-1,4);
for i=1:n-1
    for j=1:4
        diff(i,j) = S(i, j) - s(i, j);
    end;
    
end;

