function MakeSubbotin( n,x,y,button )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
while button ~=3
[xi,yi,button] = ginput(1);
plot(xi,yi,'ro');
text(xi+(xi)/15,yi+(yi)/15,int2str(n+1));
n = n+1;
x(n,1) = xi;
y(n,1) = yi;
end

xx = randn(1,n+1);
yy = randn(1,n+1);
kk= 0;
for i=1:n
kk = kk+ y(i);
end
yy(1,n+1) = kk/n;

for i=1:n
    xx(1,i) = x(i);
    yy(1,i) =y(i);
end


t = randn(1,n);
t = knotDifind(n,xx);
xx(1,n+1) = t(1,n);
if(button==3)
z = zDefine(n+1,yy,t);
    S= subbotin(t,z,yy,n+1);
  curve = computeEquationSubbotin(n+1,xx,S);
  k = knotDefin( n+1,t,xx,S );
drawGraphSubbotin(n+1, t,xx,k, yy,curve)
end