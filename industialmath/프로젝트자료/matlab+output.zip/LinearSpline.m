function S = LinearSpline(t,y,n)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
S = randn(n-1,2);
for i=1:n-1
    S(i,1) = (y(i+1)-y(i))/(t(i+1)-t(i)) ;
    S(i,2) = y(i)-t(i)*((y(i+1)-y(i))/(t(i+1)-t(i)));

end

