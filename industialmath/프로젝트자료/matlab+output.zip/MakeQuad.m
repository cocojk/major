function MakeQuad( n,x,y,button )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
while button ~=3
[xi,yi,button] = ginput(1);
plot(xi,yi,'ro');
text(xi+(xi)/15,yi+(yi)/15,int2str(n+1));
n = n+1;
x(n,1) = xi;
y(n,1) = yi;
end

if(button==3)
  S =QuadraticSpline(x,y,n);
  curve = computeEquationQuad(n,x,y,S);
drawGraphQuad(n, x, y, curve);
end