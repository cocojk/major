function t = knotDifind(n,x )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

t = randn(1,n);
t(1,1) =x(1,1);
for i=2:n
    t(1,i) = 2*x(1,i) - t(1,i-1);
end






