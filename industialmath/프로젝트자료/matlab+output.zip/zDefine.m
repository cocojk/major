function z = zDefine(n,y,t)
h = randn(1,n-2);
b = randn(1,n-1);
d = randn(1,n-1);
c = randn(1,n-2);
z = rand(1,n-1);

for i=1:n-2
    h(1,i) = t(1,i+1) -t(1,i);
end

d(1,1) = 3*h(1,1);
d(1,n-1) = 3*h(1,n-2);

for ii=2:n-2
    d(1,ii) = 3*(h(1,ii)+h(1,ii-1));
end


for i=1:n-1
    b(1,i) = 8*(y(i+1)-y(i));
end

for i=1:n-2
    c(1,i) = h(1,i);
end


for i=2:n-1
    d(1,i) = d(1,i) - (c(1,i-1)/d(1,i-1))*c(1,i-1);
    b(1,i) = b(1,i) - (c(1,i-1)/d(1,i-1))*b(1,i-1);
end

z(1,n-1) = b(1,n-1)/d(1,n-1);


for i =1:n-2
    z(1,n-1-i) = (b(1,n-1-i)-c(1,n-1-i)*z(1,n-i))/d(1,n-1-i);
end
    
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here



