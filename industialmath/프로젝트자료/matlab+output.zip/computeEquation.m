 function curve = computeEquation(n, t, S)
 
    syms x;
    format short;  
    for i=1:n-1
 
         curve(i) =  S(i, 1)*(x - t(i))^3  + S(i, 2)*(t(i+1) - x)^3  + S(i, 3)*(x - t(i))  +  S(i, 4)*(t(i+1) - x);
 
     end;


