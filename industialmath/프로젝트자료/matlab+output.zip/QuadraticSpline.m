function S = QuadraticSpline(t,y,n)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
syms z;
z = randn(n,1);
z(1) =0;
for k=1:n-1
    z(k+1) = -z(k) + 2*(y(k+1) - y(k))/(t(k+1)-t(k));
end

S = randn(n-1,1);

for i=1:n-1
    S(i,1) =  (z(i+1)-z(i))/(2*(t(i+1)-t(i)));
    S(i,2) = z(i);
    S(i,3) = y(i);
end


