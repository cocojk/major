function MakeSpline( n,x,y,button )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
while button ==1
[xi,yi,button] = ginput(1);
plot(xi,yi,'ro');
text(xi+(xi)/15,yi+(yi)/15,int2str(n+1));
n = n+1;
x(n,1) = xi;
y(n,1) = yi;
end
i = 1;
while(i==1)
switch button
 
    case 49
  S =LinearSpline(x,y,n);
  curve = computeEquationLinear(n,x,y,S);
drawGraphLinear(n, x, y, curve);


    case 50
         S =naturalCubicSpline(x,y,n);
  curve = computeEquation(n,x,S);
drawGraph(n, x, y, curve);
  
    case 51
        i =0;
        
        
    case 52
        i=0;
    case 53
        i =0;


end
end

