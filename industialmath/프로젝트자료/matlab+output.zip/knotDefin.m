function k = knotDefin( n,t,tt,S )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
k = randn(1,n-1);
for i=1:n-2
    k(1,i) = S(i,1)*(t(i)-tt(i+1))*(t(i)-tt(i+1))+S(i,2)*(t(i)-tt(i+1))+S(i,3);
end
k(1,n-1) = S(n-2,1)*(t(n-1)-tt(i+1))*(t(n-1)-tt(i+1))+S(n-2,2)*(t(n-1)-tt(i+1))+S(n-2,3);

end

