function drawGraphSubbotin(n, t,tt,k, y,curve)

%Graph �׸���

for i=1:n-2
    
   ezplot(curve(i), [t(i) t(i+1)])
 
   hold on
    
end;


plot(tt, y, 'o', 'Color','red')
plot(t,k,'o','Color','blue')

axis auto
grid on


title('Subbotin Qudratic Spline');
xlabel('X');
ylabel('Y=S(X)');