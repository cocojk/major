function diff = computeDiffSubbotin(n, S, s)

diff=randn(n-2,3);
for i=1:n-2
    for j=1:3
        diff(i,j) = S(i, j) - s(i, j);
    end;
    
end;
