 function curveQuad = computeEquationQuad(n, t,y,S)
 
    syms x;
    format short;  
    
    for i=1:n-1

         curveQuad(i) =  S(i,1)*(x-t(i))*(x-t(i))+S(i,2)*(x-t(i))+y(i);
     end;

