function diff = computeDiffLinear( n,S,s )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
diff = randn(n-1, 2);

for i=1:n-1
    for j=1:2
    diff(i,j) = S(i,j) - s(i,j);
    end
    

    



end

